#!/bin/bash

#兼容老版本
cd $(dirname $0)
cd ../../
sh bin/run.sh $@
result=$?
if [[ ${result} -ne 0 ]]; then
    exit ${result}
fi