#!/bin/bash
jobType=${1}
echo "====================================== start to create datapush task ====================="
echo "====================================== The job task is  ${jobType}	===================="

if [[ "$jobType" == "file" ]]; then
echo "====================================== Start to read the params ================"
     xmlFileName=${2}
     shellFileName=${3}
     jobName=${4}
     isOnlyTrans=${5}
     fileFetchMode=${6}
     fileSourceMapList=${7}
     fileSourcePolicy=${8}
	 fileMask=${9}
	 fileCountThreshold=${10}
	 fileSizeThreshold=${11}
	 fieldSeparator=${12}
echo "============================= The fieldSeparator is ${fieldSeparator} ===="
	 fileRetryTimes=${13}
	 fileWaitTime=${14}
	 destFileName=${15}
	 fileNumCheckMode=${16}
	 periodType=${17}
	 sendThreadCount=${18}
	 compressThreadCount=${19}
	 isAlarm=${20}
	 alarmLevel=${21}
	 alarmScope=${22}
	 dicId=${23}
	 mode=${24}
	 TSHost=${25}
	 TSPort=${26}
	 TSUsername=${27}
	 TSAuthType=${28}
	 TSDirectory=${29}
	 isOnlyLzoCompress=${30}
	 splitSize=${31}
	 fileCount=${32}
	 reSendTimes=${33}
	 waitTime=${34}
	 sourceFilePolicy=${35}
	 remoteTimeOut=${36}
	 isCombinByNoCompress=${37}
	 deptCode=${38}
	 odsTableName=${39}
	 remoteIDEPath=${40}
	 isUtc=${41}
	 dNum=${42}
	 hNum=${43}
	 logDir=${44}
	 offsetTime=${45}
	 periodLength=${46}
	 remotePatchPath=${47}
	 taskType=${48}
	 min=${49}
	 hour=${50}
	 day=${51}
	 week=${52}
	 month=${53}
	 periodTime=${54}
	 timeName=${55}
	 limitBand=${56}
	 datapush_config_scope=${57}
	 datapush_config_module=${58}
	 datapush_config_version=${59}
	 datapush_config_tag=${60}
	 update_secret_cron=${61}
	 wiseeye_config_center_apikey=${62}
	 wiseeye_config_center_url=${63}
	 TSIsOpenPeriodDir=${64}
	 TSDestFilePermission=${65}
	 ifOnlyTransISRename=${66}
echo "====================================== Finish to read the params ==================="
fi

if [[ "$jobType" == "db" ]]; then
echo "====================================== Start to read the params ===================="
     xmlFileName=${2}
     shellFileName=${3}
     jobName=${4}
     replaceSource=${6}
     replaceTarget=${7}
     dbSourceMapList=${8}
	 extractSql="${9}"
echo "============================= The extractSql is ${extractSql} ================"
	 separator=${10}
echo "============================= The separator is ${separator} =================="
	 destFileName=${11}
	 fileNumCheckMode=${12}
	 periodType=${13}
	 sendThreadCount=${14}
	 compressThreadCount=${15}
	 isAlarm=${16}
	 alarmLevel=${17}
	 alarmScope=${18}
	 dicId=${19}
	 mode=${20}
	 TSHost=${21}
	 TSPort=${22}
	 TSUsername=${23}
	 TSAuthType=${24}
	 TSDirectory=${25}
	 isOnlyLzoCompress=${26}
	 splitSize=${27}
	 fileCount=${28}
	 reSendTimes=${29}
	 waitTime=${30}
	 reSendTimes=${31}
	 sourceFilePolicy=${32}
	 remoteTimeOut=${33}
	 isCombinByNoCompress=${34}
	 deptCode=${35}
	 odsTableName=${36}
	 remoteIDEPath=${37}
	 isUtc=${38}
	 dNum=${39}
	 hNum=${40}
	 logDir=${41}
	 offsetTime=${42}
	 periodLength=${43}
	 remotePatchPath=${44}
	 taskType=${45}
	 min=${46}
	 hour=${47}
	 day=${48}
	 week=${49}
	 month=${50}
	 periodTime=${51}
	 timeName=${52}
	 limitBand=${53}
	 datapush_config_scope=${54}
	 datapush_config_module=${55}
	 datapush_config_version=${56}
	 datapush_config_tag=${57}
	 update_secret_cron=${58}
	 wiseeye_config_center_apikey=${59}
	 wiseeye_config_center_url=${60}
	 TSIsOpenPeriodDir=${61}
	 TSDestFilePermission=${62}
echo "====================================== Finish to read the params ==================="
fi

function initWiseEye() {
  echo "====================================== Start to initWiseEye ========="
  if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/wiseEye.properties" ]]; then
    rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/wiseEye.properties
  fi
  cp  /opt/hihonor/apps/common/Datapush_IDE/dam_install/template/DAM_WiseEye.properties /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/wiseEye.properties
	sed -i "s/{{wiseeye_config_center_api}}/${wiseeye_config_center_apikey}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/wiseEye.properties
	sed -i "s/{{wiseeye_config_center_url}}/${wiseeye_config_center_url}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/wiseEye.properties
  if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/conf/wiseEye.properties" ]]; then
    rm -f /opt/hihonor/apps/common/Datapush_IDE/conf/wiseEye.properties
  fi
  mv  /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/wiseEye.properties /opt/hihonor/apps/common/Datapush_IDE/conf
  echo "====================================== Finish to initWiseEye========="
}

function createFileConfigTmp() {
echo "====================================== Start to createFileConfigTmp ========="
	#在临时目录生成xml和shell脚本
    if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml" ]]; then
      rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi
    cp  /opt/hihonor/apps/common/Datapush_IDE/dam_install/template/DAM_FileAppConf.xml /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml

    if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh" ]]; then
      rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
    fi
    cp  /opt/hihonor/apps/common/Datapush_IDE/dam_install/dam_datapush_run.sh /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
    chmod +x /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh

   	 #将实际的参数值替换到xml脚本中
    replaceFileXmlParams
   	 #将实际的参数值替换到shell脚本中
    replaceFileShellParams
    #把xml和shell脚本拷贝到正式目录下

    if [ ! -d "${remotePatchPath}conf" ]; then
		  echo "Datapush_Extend/conf is not exist."
		  exit 110
	fi
    mv /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml  ${remotePatchPath}conf
    mv /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh ${remotePatchPath}conf
           #拨测并执行定时任务
    buildCrontab
 echo "====================================== Finish to createFileConfigTmp========="
}

function replaceFileShellParams(){
	echo "====================================== Start to replaceFileShellParams ========="
	sed -i "s/{{remoteIDEPath}}/${remoteIDEPath}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{isUtc}}/${isUtc}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{dNum}}/${dNum}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{hNum}}/${hNum}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{logDir}}/${logDir}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	echo "====================================== Running to replaceFileShellParams========="
	sed -i "s/{{offsetTime}}/${offsetTime}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{periodType}}/${periodType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{jobName}}/${jobName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{periodLength}}/${periodLength}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	echo "====================================== Finish to replaceFileShellParams========="
}

function createFileSourceFile() {
  echo "====================================== Start to createFileSourceFile========="
  if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_${1}.xml" ]]; then
    rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_${1}.xml
  fi
  cp /opt/hihonor/apps/common/Datapush_IDE/dam_install/template/DAM_File_Source.xml /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_${1}.xml
  echo "====================================== Running to createFileSourceFile the job is :${jobName} ========="
  sed -i "s/{{filesource_id}}/$2/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_${1}.xml
  sed -i "s/{{filesource_dir}}/$3/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_${1}.xml
  echo "createFileSourceFile end"
  echo "====================================== Finish to createFileSourceFile========="
}

function replaceFileXmlParams(){
 	echo "====================================== Start to replaceFileXmlParams========="
	sed -i "s/{{jobName}}/${jobName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{jobType}}/${jobType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{isOnlyTrans}}/${isOnlyTrans}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{ifOnlyTransISRename}}/${ifOnlyTransISRename}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileFetchMode}}/${fileFetchMode}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml

	if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_tmp.xml" ]]; then
      rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_tmp.xml
    fi
	touch /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_tmp.xml

	fileSourceMapArray=($(echo ${fileSourceMapList} | sed "s/##/\n/g"))
	fileVar=1
	for fileSourceMapItem in ${fileSourceMapArray[*]}
	do
		fileSourceArray=($(echo ${fileSourceMapItem} | sed "s/#/\n/g"))
		var=1
		filesource_id=""
		filesource_dir=""
	    for fileSourceItem in ${fileSourceArray[*]}
	    do
	    	 if [[ $var -eq 1 ]]; then
		      filesource_id=$fileSourceItem
		  	 fi

		  	 if [[ $var -eq 2 ]]; then
		      filesource_dir=$fileSourceItem
		  	 fi
		  	 ((var++))
	    done
	    createFileSourceFile ${fileVar} ${filesource_id} ${filesource_dir}
		cat /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_${fileVar}.xml >>/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_tmp.xml
		((fileVar++))
	done
    echo "====================================== Running to replaceFileXmlParams========="
    sed -i "/{{fileSourceMapList}}/r /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_tmp.xml" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "/{{fileSourceMapList}}/d" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileSourcePolicy}}/${fileSourcePolicy}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
	sed -i "s/{{fileMask}}/${fileMask}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileCountThreshold}}/${fileCountThreshold}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileSizeThreshold}}/${fileSizeThreshold}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fieldSeparator}}/${fieldSeparator}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i 's#\\\\#\\#g' /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileRetryTimes}}/${fileRetryTimes}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileWaitTime}}/${fileWaitTime}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{destFileName}}/${destFileName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{limitBand}}/${limitBand}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileNumCheckMode}}/${fileNumCheckMode}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{periodType}}/${periodType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{sendThreadCount}}/${sendThreadCount}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{compressThreadCount}}/${compressThreadCount}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{isAlarm}}/${isAlarm}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml

    if [ ${alarmLevel} == "%%%%%%" ] ;then
		sed -i "s/{{alarmLevel}}//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    else
		sed -i "s/{{alarmLevel}}/${alarmLevel}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi
    if [ ${alarmScope} == "%%%%%%" ] ;then
    	sed -i "s/{{alarmScope}}//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    else
    	sed -i "s/{{alarmScope}}/${alarmScope}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi

    sed -i "s/{{dicId}}/${dicId}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{mode}}/${mode}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSHost}}/${TSHost}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSPort}}/${TSPort}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSUsername}}/${TSUsername}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSAuthType}}/${TSAuthType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSIsOpenPeriodDir}}/${TSIsOpenPeriodDir}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSDirectory}}/${TSDirectory}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSDestFilePermission}}/${TSDestFilePermission}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{isOnlyLzoCompress}}/${isOnlyLzoCompress}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{splitSize}}/${splitSize}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileCount}}/${fileCount}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{reSendTimes}}/${reSendTimes}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{waitTime}}/${waitTime}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{sourceFilePolicy}}/${sourceFilePolicy}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{remoteTimeOut}}/${remoteTimeOut}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{isCombinByNoCompress}}/${isCombinByNoCompress}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{deptCode}}/${deptCode}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{odsTableName}}/${odsTableName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/%%%%%%//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
 	echo "====================================== Finish to replaceFileXmlParams========="
}

function createDbConfigTmp() {
    echo "====================================== Start to createDbConfigTmp========="
    #在临时目录生成xml和shell脚本
    if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml" ]]; then
      rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi
	cp /opt/hihonor/apps/common/Datapush_IDE/dam_install/template/DAM_DBAppConf.xml /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml

    if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh" ]]; then
      rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
    fi
    cp /opt/hihonor/apps/common/Datapush_IDE/dam_install/dam_datapush_run.sh /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh

	chmod +x /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
    echo "====================================== Running to createDbConfigTmp========="

    #将实际的参数值替换到xml脚本中
    replaceDbXmlParams
          #将实际的参数值替换到shell脚本中
    replaceDbShellParams
            #把xml和shell脚本拷贝到正式目录下
    mv /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml  ${remotePatchPath}conf
    mv /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh ${remotePatchPath}conf
             # 拨测并生成定时任务
    buildCrontab
	echo "====================================== Finish to createDbConfigTmp========="
}

function createDbSourceFile() {
  echo "====================================== Start to createDbSourceFile========="
  if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml" ]]; then
    rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  fi
  cp /opt/hihonor/apps/common/Datapush_IDE/dam_install/template/DAM_DB_Source.xml /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  sed -i "s/{{dbsource_id}}/$2/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  sed -i "s/{{dbsource_type}}/$3/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  sed -i "s/{{dbsource_host}}/$4/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  echo "====================================== Running to createDbSourceFile the job is :${jobName} ========="
  sed -i "s/{{dbsource_port}}/$5/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  sed -i "s/{{dbsource_database}}/$6/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  sed -i "s/{{dbsource_username}}/$7/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  sed -i "s/{{dbsource_passw}}/$8/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  if [ $9 == "%%%%%%" ] ;then
  	sed -i "s/{{dbsource_options}}//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  else
  	sed -i "s/{{dbsource_options}}/$9/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${1}.xml
  fi
  echo "====================================== Finish to createDbSourceFile========="
}

function replaceDbXmlParams(){
    echo "====================================== Start to replaceDbXmlParams========="
	sed -i "s/{{jobName}}/${jobName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{jobType}}/${jobType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{replaceSource}}/${replaceSource}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{replaceTarget}}/${replaceTarget}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml

    if [ ${replaceSource} == "%%%%%%" ] ;then
		sed -i "s/{{replaceSource}}//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    else
    	sed -i "s/{{replaceSource}}/${replaceSource}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi
    if [ ${replaceTarget} == "%%%%%%" ] ;then
		sed -i "s/{{replaceTarget}}//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    else
    	sed -i "s/{{replaceTarget}}/${replaceTarget}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi

    if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_tmp.xml" ]]; then
      rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_tmp.xml
    fi
	touch /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_tmp.xml

    echo "====================================== Running to replaceDbXmlParams========="

	dbSourceMapListArray=($(echo ${dbSourceMapList} | sed "s/##/\n/g"))
	fileVar=1
	for dbSourceMapItem in ${dbSourceMapListArray[*]}
	do
		dbSourceArray=($(echo ${dbSourceMapItem} | sed "s/#/\n/g"))
		var=1
		dbsource_id=""
		dbsource_type=""
		dbsource_host=""
		dbsource_port=""
		dbsource_database=""
		dbsource_username=""
		dbsource_passw=""
		dbsource_options=""
	    for dbSourceItem in ${dbSourceArray[*]}
	    do
	    	 if [[ $var -eq 1 ]]; then
		      dbsource_id=$dbSourceItem
             fi

		  	 if [[ $var -eq 2 ]]; then
		      dbsource_type=$dbSourceItem
		  	 fi

		  	 if [[ $var -eq 3 ]]; then
		      dbsource_host=$dbSourceItem
		  	 fi

		  	 if [[ $var -eq 4 ]]; then
		      dbsource_port=$dbSourceItem
		  	 fi

		  	 if [[ $var -eq 5 ]]; then
		      dbsource_database=$dbSourceItem
		  	 fi

		  	 if [[ $var -eq 6 ]]; then
		      dbsource_username=$dbSourceItem
		  	 fi

		  	 if [[ $var -eq 7 ]]; then
		      dbsource_passw=$dbSourceItem
		  	 fi

		  	 if [[ $var -eq 8 ]]; then
		      dbsource_options=$dbSourceItem
		  	 fi
		  	 ((var++))
	    done
	    createDbSourceFile ${fileVar} ${dbsource_id} ${dbsource_type} ${dbsource_host} ${dbsource_port} ${dbsource_database} ${dbsource_username} ${dbsource_passw} ${dbsource_options}
		cat /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_${fileVar}.xml >>/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_tmp.xml
		((fileVar++))
	done
	sed -i "/{{dbSourceMapList}}/r /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_DB_Source_tmp.xml" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "/{{dbSourceMapList}}/d" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    echo "-------------------the extractSql is -----------------"${extractSql}
    if [[ -f "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_SqlTemp.xml" ]]; then
      rm -f /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_SqlTemp.xml
    fi
    touch /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_SqlTemp.xml
    echo ""${extractSql} >> /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_SqlTemp.xml
    sed -i "/{{extractSql}}/r /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/DAM_File_Source_SqlTemp.xml"  /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "/{{extractSql}}/d" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{separator}}/${separator}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i 's#\\\\#\\#g' /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{destFileName}}/${destFileName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{limitBand}}/${limitBand}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileNumCheckMode}}/${fileNumCheckMode}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{periodType}}/${periodType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{sendThreadCount}}/${sendThreadCount}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{compressThreadCount}}/${compressThreadCount}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{isAlarm}}/${isAlarm}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    if [ ${alarmLevel} == "%%%%%%" ] ;then
		sed -i "s/{{alarmLevel}}//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    else
		sed -i "s/{{alarmLevel}}/${alarmLevel}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi
    if [ ${alarmScope} == "%%%%%%" ] ;then
    	sed -i "s/{{alarmScope}}//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    else
    	sed -i "s/{{alarmScope}}/${alarmScope}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    fi
    sed -i "s/{{dicId}}/${dicId}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{mode}}/${mode}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSHost}}/${TSHost}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSPort}}/${TSPort}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSUsername}}/${TSUsername}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSAuthType}}/${TSAuthType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSIsOpenPeriodDir}}/${TSIsOpenPeriodDir}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSDirectory}}/${TSDirectory}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{TSDestFilePermission}}/${TSDestFilePermission}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{isOnlyLzoCompress}}/${isOnlyLzoCompress}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{splitSize}}/${splitSize}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{fileCount}}/${fileCount}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{reSendTimes}}/${reSendTimes}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{waitTime}}/${waitTime}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{reSendTimes}}/${reSendTimes}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{sourceFilePolicy}}/${sourceFilePolicy}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{remoteTimeOut}}/${remoteTimeOut}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{isCombinByNoCompress}}/${isCombinByNoCompress}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{deptCode}}/${deptCode}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/{{odsTableName}}/${odsTableName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
    sed -i "s/%%%%%%//g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${xmlFileName}.xml
	echo "====================================== Finish to replaceDbXmlParams========="
}

function replaceDbShellParams(){
    echo "====================================== Start to replaceDbShellParams========="
	sed -i "s/{{remoteIDEPath}}/${remoteIDEPath}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{isUtc}}/${isUtc}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{dNum}}/${dNum}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{hNum}}/${hNum}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{logDir}}/${logDir}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
    echo "====================================== Running to replaceDbShellParams========="
	sed -i "s/{{offsetTime}}/${offsetTime}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{periodType}}/${periodType}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{jobName}}/${jobName}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
	sed -i "s/{{periodLength}}/${periodLength}/g" /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp/${shellFileName}.sh
    echo "====================================== Finish to replaceDbShellParams========="
}

function buildCrontab(){
	#export PATH=$JAVA_HOME/bin:$PATH
	CMDCHECK=`java -version 1>/dev/null 2>&1`
	JDKSVR="$?"
	if [ "$JDKSVR" -eq 0 ];then
	    echo "JDK is installed Success"
	else
	    echo "Error:JDK is not installed !!!"
	    exit 110
	fi
    if [ ! -d "${remotePatchPath}conf" ]; then
		  echo "Datapush_Extend/conf is not exist."
		  exit 110
	fi
  mkdir -p /opt/hihonor/apps/common/Datapush_IDE/logs
  mkdir -p /opt/hihonor/apps/common/Datapush_IDE/IDE/log
  chmod 750 /opt/hihonor/apps/common/Datapush_IDE/logs /opt/hihonor/apps/common/Datapush_IDE/IDE /opt/hihonor/apps/common/Datapush_IDE/IDE/log

  chmod -R 550 /opt/hihonor/apps/common/Datapush_IDE/DataPush_0.1
  chmod -R 550 /opt/hihonor/apps/common/Datapush_IDE/bin
  chmod 750 /opt/hihonor/apps/common/Datapush_IDE/conf
  chmod 640 /opt/hihonor/apps/common/Datapush_IDE/conf/*.xml
  chmod 640 /opt/hihonor/apps/common/Datapush_IDE/conf/*.properties
  chmod 750 /opt/hihonor/apps/common/Datapush_IDE/conf/properties
  chmod 700 /opt/hihonor/apps/common/Datapush_IDE/conf/properties/*
  chmod 600 /opt/hihonor/apps/common/Datapush_IDE/conf/properties/*/*
  chmod 750 /opt/hihonor/apps/common/Datapush_IDE/conf/template
  chmod 640 /opt/hihonor/apps/common/Datapush_IDE/conf/template/*
  chmod -R 770 /opt/hihonor/apps/common/Datapush_IDE/dam_install
  chmod -R 550 /opt/hihonor/apps/common/Datapush_IDE/libs
  chmod 550 /opt/hihonor/apps/common/Datapush_IDE/package.json
  chmod 700 /opt/hihonor/apps/common/Datapush_IDE/fruits
  chmod 600 /opt/hihonor/apps/common/Datapush_IDE/fruits/*
  chmod 550 /opt/hihonor/apps/common/Datapush_IDE/version.txt
  chmod 750 /opt/hihonor/apps/common/Datapush_IDE/vtask
  chmod 640 /opt/hihonor/apps/common/Datapush_IDE/vtask/*

  chmod -R 770 /opt/hihonor/apps/common/Datapush_IDE/wiseeye_install/*
  echo "Execute pullSecret shell start..."
	sh /opt/hihonor/apps/common/Datapush_IDE/wiseeye_install/pullSecret.sh pullType=5 scopeName=${datapush_config_scope} appName=${datapush_config_module} versionName=${datapush_config_version} tagName=${datapush_config_tag} jobName=${jobName}
	pullSecretRet=$?
	echo "Execute pullSecret result is ${pullSecretRet}"
	if [ "$pullSecretRet" -ne 0 ]; then
		echo "Execute pullSecret failed !!!"
		exit 110
	fi
	sh /opt/hihonor/apps/common/Datapush_IDE/DataPush_0.1/DataPush/DataPush_run.sh --context_param periodTime=${periodTime} --context_param periodType=${periodType} --context_param jobName=${jobName} --context_param periodLength=${periodLength} --context_param timeName=${timeName} 2>&1

	VTaskRet=$?
	if [ "$VTaskRet" -ne 0 ]; then
		echo "Execute verify task failed !!!"
		exit 110
	fi

	crontab -l > crontab.tmp
	sed -i "/IDE_DataPush_${jobName}.sh/d" crontab.tmp
	sed -i "/pullSecret.sh pullType=4 scopeName=${datapush_config_scope} appName=${datapush_config_module} versionName=${datapush_config_version} tagName=${datapush_config_tag} jobName=${jobName}/d" crontab.tmp
	echo "${min} ${hour} ${day} ${week} ${month} source ~/.profile && bash -lc \"sh ${remotePatchPath}conf/${shellFileName}.sh > /dev/null 2>&1\"" >> crontab.tmp
	echo "${update_secret_cron} source ~/.profile && bash -lc \"sh /opt/hihonor/apps/common/Datapush_IDE/wiseeye_install/pullSecret.sh pullType=4 scopeName=${datapush_config_scope} appName=${datapush_config_module} versionName=${datapush_config_version} tagName=${datapush_config_tag} jobName=${jobName} > /dev/null 2>&1\"" >> crontab.tmp

	crontab crontab.tmp
	if [ "$?" -eq 1 ]; then
		echo "You are not allowed to use this crontab"
		exit 110
	fi

	datapushShName="${shellFileName}.sh"
	shName=`ls ${remotePatchPath}conf | grep "$datapushShName"`
	if [ X"$shName" == X"" ];then
		echo "IDE_DataPush_$4.sh create failed!"
		exit 110
	fi

	crontabTask=`crontab -l | grep "$datapushShName"`
	if [ X"$crontabTask" == X"" ];then
		echo "Crontab task created failed! "
		exit 110
	fi

	echo "Verify task execute successful."
	exit 0
}

function main() {
  echo "jobType is "${jobType}
  #1、创建生成xml和shell脚本的临时目录，移到正式目录之后，把临时目录里的shell和xml给删除调
  if [[ ! -d "/opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp" ]]; then
    mkdir -p /opt/hihonor/apps/common/Datapush_IDE/dam_install/tmp
  fi
  #2、如果不存在/opt/hihonor/apps/common/Datapush_Extend/conf目录则创建
  if [[ ! -d "/opt/hihonor/apps/common/Datapush_Extend/conf" ]]; then
    mkdir -p /opt/hihonor/apps/common/Datapush_Extend/conf
  fi
  #3、初始化云眼配置中心API配置项
  initWiseEye
  #4、数据库和文件类型，生成正式的xml和shell脚本并执行拨测周期和定时任务
  if [[ "${jobType}" == "file" ]]; then
      createFileConfigTmp
      echo "================================files end"
  fi

  if [ "${jobType}" == "db" ]; then
      createDbConfigTmp
  	  echo "================================dbs end"
  fi
}
main