#!/usr/bin/python
# coding=utf-8
import sys
import os
import shutil
import json
import common

reload(sys)
sys.setdefaultencoding("utf-8")

configVersionPath = ''
pull_secret_param = ''
update_secret_cron = ''

# --------------datapush.ini 参数变量----------------
create_empty_open = 'true'
dam_open = 'false'
dam_url = ''
log_open = 'false'
log_host = ''
log_user = ''
# --------------任务通用配置参数变量----------------
jobName = ''
jobType = ''
file_check_mode = 'COUNT'
destFileName = ''
periodType = ''
send_thread_size = '3'
compress_thread_size = '3'
limit_band = '0'
alarm_open = 'true'
alarm_level = 'minor'
alarm_scope = 'bi'
transport_ip = ''
transport_port = ''
transport_username = ''
authType = '3'
privatePass = ''
privateFile = ''
isOpenPeriodDir = 'true'
destDirectory = ''
destFilePermission = ''
is_combine = 'false'
is_lzo = 'false'
is_zip = 'false'
zip_passw = ''
split_size = '0'
split_count = '1'
transport_timeout = '0'
transport_retry = '0'
transport_wait = '0'
workPolicy = '1'
dept_code = ''
odsName = ''
dicName = ''
crontabCycle = ''
offset = ''
offsetName = ''
isUTC = ''
sourceId = ''

# --------------文件任务配置参数变量----------------
fileSourceDir = ''
isOnlyTrans = 'false'
ifOnlyTransISRename = 'false'
fileMask = ''
file_check_count = '0'
file_check_size = '0'
file_retry = '3'
file_wait = '0'
sourcePolicy = '1'

# --------------数据库任务配置参数变量----------------
dbsource_type = ''
dbsource_host = ''
dbsource_port = ''
dbsource_database = ''
dbsource_username = ''
dbsource_passw = ''
dbsource_options = ''
dbsource_sql = ''
sql = ''
fieldSep = ''
lineSep = ''
replaceSource = ''
replaceTarget = ''

for arg in sys.argv:
    if arg.startswith('configVersionPath='):
        configVersionPath = arg.replace('configVersionPath=', '')
    elif arg.startswith('pull_secret_param='):
        pull_secret_param = arg.replace('pull_secret_param=', '')
    elif arg.startswith('update_secret_cron='):
        update_secret_cron = arg.replace('update_secret_cron=', '')
    elif arg.startswith('create_empty_open='):
        create_empty_open = arg.replace('create_empty_open=', '')
    elif arg.startswith('dam_open='):
        dam_open = arg.replace('dam_open=', '')
    elif arg.startswith('dam_url='):
        dam_url = arg.replace('dam_url=', '')
    elif arg.startswith('log_open='):
        log_open = arg.replace('log_open=', '')
    elif arg.startswith('log_host='):
        log_host = arg.replace('log_host=', '')
    elif arg.startswith('log_user='):
        log_user = arg.replace('log_user=', '')
    elif arg.startswith('jobName='):
        jobName = arg.replace('jobName=', '')
    elif arg.startswith('jobType='):
        jobType = arg.replace('jobType=', '')
    elif arg.startswith('file_check_mode='):
        file_check_mode = arg.replace('file_check_mode=', '')
    elif arg.startswith('destFileName='):
        destFileName = arg.replace('destFileName=', '')
    elif arg.startswith('periodType='):
        periodType = arg.replace('periodType=', '')
    elif arg.startswith('send_thread_size='):
        send_thread_size = arg.replace('send_thread_size=', '')
    elif arg.startswith('compress_thread_size='):
        compress_thread_size = arg.replace('compress_thread_size=', '')
    elif arg.startswith('limit_band='):
        limit_band = arg.replace('limit_band=', '')
    elif arg.startswith('alarm_open='):
        alarm_open = arg.replace('alarm_open=', '')
    elif arg.startswith('alarm_level='):
        alarm_level = arg.replace('alarm_level=', '')
    elif arg.startswith('alarm_scope='):
        alarm_scope = arg.replace('alarm_scope=', '')
    elif arg.startswith('transport_ip='):
        transport_ip = arg.replace('transport_ip=', '')
    elif arg.startswith('transport_port='):
        transport_port = arg.replace('transport_port=', '')
    elif arg.startswith('transport_username='):
        transport_username = arg.replace('transport_username=', '')
    elif arg.startswith('authType='):
        authType = arg.replace('authType=', '')
    elif arg.startswith('privatePass='):
        privatePass = arg.replace('privatePass=', '')
    elif arg.startswith('privateFile='):
        privateFile = arg.replace('privateFile=', '')
    elif arg.startswith('isOpenPeriodDir='):
        isOpenPeriodDir = arg.replace('isOpenPeriodDir=', '')
    elif arg.startswith('destDirectory='):
        destDirectory = arg.replace('destDirectory=', '')
    elif arg.startswith('destFilePermission='):
        destFilePermission = arg.replace('destFilePermission=', '')
    elif arg.startswith('is_combine='):
        is_combine = arg.replace('is_combine=', '')
    elif arg.startswith('is_lzo='):
        is_lzo = arg.replace('is_lzo=', '')
    elif arg.startswith('is_zip='):
        is_zip = arg.replace('is_zip=', '')
    elif arg.startswith('zip_passw='):
        zip_passw = arg.replace('zip_passw=', '')
    elif arg.startswith('split_size='):
        split_size = arg.replace('split_size=', '')
    elif arg.startswith('split_count='):
        split_count = arg.replace('split_count=', '')
    elif arg.startswith('transport_timeout='):
        transport_timeout = arg.replace('transport_timeout=', '')
    elif arg.startswith('transport_retry='):
        transport_retry = arg.replace('transport_retry=', '')
    elif arg.startswith('transport_wait='):
        transport_wait = arg.replace('transport_wait=', '')
    elif arg.startswith('workPolicy='):
        workPolicy = arg.replace('workPolicy=', '')
    elif arg.startswith('dept_code='):
        dept_code = arg.replace('dept_code=', '')
    elif arg.startswith('odsName='):
        odsName = arg.replace('odsName=', '')
    elif arg.startswith('dicName='):
        dicName = arg.replace('dicName=', '')
    elif arg.startswith('crontabCycle='):
        crontabCycle = arg.replace('crontabCycle=', '')
    elif arg.startswith('offset='):
        offset = arg.replace('offset=', '')
    elif arg.startswith('offsetName='):
        offsetName = arg.replace('offsetName=', '')
    elif arg.startswith('isUTC='):
        isUTC = arg.replace('isUTC=', '')
    elif arg.startswith('sourceId='):
        sourceId = arg.replace('sourceId=', '')
    elif arg.startswith('fileSourceDir='):
        fileSourceDir = arg.replace('fileSourceDir=', '')
    elif arg.startswith('isOnlyTrans='):
        isOnlyTrans = arg.replace('isOnlyTrans=', '')
    elif arg.startswith('ifOnlyTransISRename='):
        ifOnlyTransISRename = arg.replace('ifOnlyTransISRename=', '')
    elif arg.startswith('fileMask='):
        fileMask = arg.replace('fileMask=', '')
    elif arg.startswith('file_check_count='):
        file_check_count = arg.replace('file_check_count=', '')
    elif arg.startswith('file_check_size='):
        file_check_size = arg.replace('file_check_size=', '')
    elif arg.startswith('file_retry='):
        file_retry = arg.replace('file_retry=', '')
    elif arg.startswith('file_wait='):
        file_wait = arg.replace('file_wait=', '')
    elif arg.startswith('sourcePolicy='):
        sourcePolicy = arg.replace('sourcePolicy=', '')
    elif arg.startswith('dbsource_type='):
        dbsource_type = arg.replace('dbsource_type=', '')
    elif arg.startswith('dbsource_host='):
        dbsource_host = arg.replace('dbsource_host=', '')
    elif arg.startswith('dbsource_port='):
        dbsource_port = arg.replace('dbsource_port=', '')
    elif arg.startswith('dbsource_database='):
        dbsource_database = arg.replace('dbsource_database=', '')
    elif arg.startswith('dbsource_username='):
        dbsource_username = arg.replace('dbsource_username=', '')
    elif arg.startswith('dbsource_passw='):
        dbsource_passw = arg.replace('dbsource_passw=', '')
    elif arg.startswith('dbsource_options='):
        dbsource_options = arg.replace('dbsource_options=', '')
    elif arg.startswith('dbsource_sql='):
        dbsource_sql = arg.replace('dbsource_sql=', '')
    elif arg.startswith('sql='):
        sql = arg.replace('sql=', '')
    elif arg.startswith('fieldSep='):
        fieldSep = arg.replace('fieldSep=', '')
    elif arg.startswith('lineSep='):
        lineSep = arg.replace('lineSep=', '')
    elif arg.startswith('replaceSource='):
        replaceSource = arg.replace('replaceSource=', '')
    elif arg.startswith('replaceTarget='):
        replaceTarget = arg.replace('replaceTarget=', '')
if len(update_secret_cron) == 0:
    update_secret_cron = '0 */1 * * *'
configVersionPathTemplate = os.path.join(configVersionPath, 'template')


# create file tmp
def create_file_source_tmp(source_id, file_source_dir, job_source):
    file_source_tmp = os.path.join(configVersionPathTemplate, 'file_source_' + source_id + '.tmp')
    print 'file_source = ' + file_source_tmp
    if os.path.exists(file_source_tmp):
        os.remove(file_source_tmp)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'file_source.xml'), file_source_tmp)
    common.replace(file_source_tmp, '{{filesource_dir}}', file_source_dir)
    common.replace(file_source_tmp, '{{filesource_id}}', source_id)
    tmp_data = ''
    with open(file_source_tmp, 'r') as file_tmp:
        for file_line in file_tmp:
            tmp_data += file_line
    with open(job_source, 'a+') as fs:
        fs.write(tmp_data)
    os.remove(file_source_tmp)


# iac create sh
def create_shell():
    sh_conf = os.path.join(common.appConfigPath, 'IDE_DataPush_' + jobName + '.sh')
    if os.path.exists(sh_conf):
        os.remove(sh_conf)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'datapush_run.sh'), sh_conf)
    common.replace(sh_conf, '{{jobName}}', jobName)
    common.replace(sh_conf, '{{periodType}}', periodType)
    common.replace(sh_conf, '{{offset}}', offset)
    common.replace(sh_conf, '{{offsetName}}', offsetName)
    common.replace(sh_conf, '{{isUTC}}', isUTC)


# create db tmp
def create_db_source_tmp(source_id, dbsourceType, dbsourceHost, dbsourcePort,
                         dbsourceDatabase, dbsourceUsername, dbsourcePassw,
                         dbsourceSql, dbsourceOptions, job_source):
    db_source_tmp = os.path.join(configVersionPathTemplate, 'db_source_' + source_id + '.tmp')
    print 'db_source = ' + db_source_tmp
    if os.path.exists(db_source_tmp):
        os.remove(db_source_tmp)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'db_source.xml'), db_source_tmp)
    common.replace(db_source_tmp, '{{dbsource_id}}', source_id)
    common.replace(db_source_tmp, '{{dbsource_type}}', dbsourceType)
    common.replace(db_source_tmp, '{{dbsource_host}}', dbsourceHost)
    common.replace(db_source_tmp, '{{dbsource_port}}', dbsourcePort)
    common.replace(db_source_tmp, '{{dbsource_database}}', dbsourceDatabase)
    common.replace(db_source_tmp, '{{dbsource_username}}', dbsourceUsername)
    common.replace(db_source_tmp, '{{dbsource_options}}', dbsourceOptions)
    common.replace(db_source_tmp, '{{dbsource_sql}}', dbsourceSql)
    common.replace(db_source_tmp, '{{dbsource_passw}}', dbsourcePassw)
    tmp_data = ''
    with open(db_source_tmp, 'r') as db_tmp:
        for db_line in db_tmp:
            tmp_data += db_line
    with open(job_source, 'a+') as fs:
        fs.write(tmp_data)
    os.remove(db_source_tmp)


# replace public config of job
def replace_job_pub_config(job_conf):
    common.replace(job_conf, '{{jobName}}', jobName)
    common.replace(job_conf, '{{isOnlyTrans}}', isOnlyTrans)
    common.replace(job_conf, '{{ifOnlyTransISRename}}', ifOnlyTransISRename)
    common.replace(job_conf, '{{file_check_mode}}', file_check_mode)
    common.replace(job_conf, '{{destFileName}}', destFileName)
    common.replace(job_conf, '{{periodType}}', periodType)
    common.replace(job_conf, '{{send_thread_size}}', send_thread_size)
    common.replace(job_conf, '{{compress_thread_size}}', compress_thread_size)
    common.replace(job_conf, '{{limit_band}}', limit_band)
    common.replace(job_conf, '{{alarm_open}}', alarm_open)
    common.replace(job_conf, '{{alarm_level}}', alarm_level)
    common.replace(job_conf, '{{alarm_scope}}', alarm_scope)
    common.replace(job_conf, '{{transport_ip}}', transport_ip)
    common.replace(job_conf, '{{transport_port}}', transport_port)
    common.replace(job_conf, '{{transport_username}}', transport_username)
    common.replace(job_conf, '{{authType}}', authType)
    common.replace(job_conf, '{{privatePass}}', privatePass)
    common.replace(job_conf, '{{privateFile}}', privateFile)
    common.replace(job_conf, '{{isOpenPeriodDir}}', isOpenPeriodDir)
    common.replace(job_conf, '{{destDirectory}}', destDirectory)
    common.replace(job_conf, '{{destFilePermission}}', destFilePermission)
    common.replace(job_conf, '{{is_combine}}', is_combine)
    common.replace(job_conf, '{{is_lzo}}', is_lzo)
    common.replace(job_conf, '{{is_zip}}', is_zip)
    common.replace(job_conf, '{{zip_passw}}', zip_passw)
    common.replace(job_conf, '{{split_size}}', split_size)
    common.replace(job_conf, '{{split_count}}', split_count)
    common.replace(job_conf, '{{transport_timeout}}', transport_timeout)
    common.replace(job_conf, '{{transport_retry}}', transport_retry)
    common.replace(job_conf, '{{transport_wait}}', transport_wait)
    common.replace(job_conf, '{{workPolicy}}', workPolicy)
    common.replace(job_conf, '{{dept_code}}', dept_code)
    common.replace(job_conf, '{{odsName}}', odsName)


# iac create job xml,jobType=1 is file,jobType=0 is db
def create_job_config_xml():
    job_source = os.path.join(configVersionPathTemplate, jobName + '_source.xml')
    jobsList.write(jobName + '?' + periodType + '$')
    sources = sourceId.split('|')
    if jobType == '1':
        fileSourceDirs = fileSourceDir.split('|')
        for i in range(len(sources)):
            create_file_source_tmp(sources[i], fileSourceDirs[i], job_source)
    if jobType == '0':
        dbsource_types = dbsource_type.split('|')
        dbsource_ports = dbsource_port.split('|')
        dbsource_databases = dbsource_database.split('|')
        dbsource_hosts = dbsource_host.split('|')
        dbsource_passws = dbsource_passw.split('|')
        dbsource_usernames = dbsource_username.split('|')
        dbsource_optionss = dbsource_options.split('|')
        dbsource_sqls = dbsource_sql.split('|')
        for i in range(len(sources)):
            create_db_source_tmp(sources[i], dbsource_types[i], dbsource_hosts[i],
                                 dbsource_ports[i], dbsource_databases[i], dbsource_usernames[i],
                                 dbsource_passws[i], dbsource_sqls[i], dbsource_optionss[i], job_source)
    job_source_txt = ''
    with open(job_source, 'r') as sf:
        job_source_txt += sf.read()
    os.remove(job_source)
    job_conf = common.appConfigPath + '/' + jobName + '_config.xml'
    if os.path.exists(job_conf):
        os.remove(job_conf)
    if jobType == '1':
        shutil.copyfile(os.path.join(common.commonPath, 'template', 'file_config.xml'), job_conf)
        common.replace(job_conf, '{{file_sources}}', job_source_txt)
        common.replace(job_conf, '{{fileMask}}', fileMask)
        common.replace(job_conf, '{{file_check_count}}', file_check_count)
        common.replace(job_conf, '{{file_check_size}}', file_check_size)
        common.replace(job_conf, '{{file_retry}}', file_retry)
        common.replace(job_conf, '{{file_wait}}', file_wait)
        common.replace(job_conf, '{{sourcePolicy}}', sourcePolicy)
    if jobType == '0':
        shutil.copyfile(os.path.join(common.commonPath, 'template', 'db_config.xml'), job_conf)
        common.replace(job_conf, '{{db_sources}}', job_source_txt)
        common.replace(job_conf, '{{fieldSep}}', fieldSep)
        common.replace(job_conf, '{{lineSep}}', lineSep)
        common.replace(job_conf, '{{replaceSource}}', replaceSource)
        common.replace(job_conf, '{{replaceTarget}}', replaceTarget)
        common.replace(job_conf, '{{sql}}', sql)
    replace_job_pub_config(job_conf)
    shutil.copyfile(job_conf, configVersionPath + '/' + jobName + '_config.xml')


def replace_datapush_properties():
    datapush_properties = common.commonPath + '/template/datapush.ini'
    common.replace(datapush_properties, '{{create_empty_open}}', create_empty_open)
    common.replace(datapush_properties, '{{dam_open}}', dam_open)
    common.replace(datapush_properties, '{{dam_url}}', dam_url)
    common.replace(datapush_properties, '{{log_open}}', log_open)
    common.replace(datapush_properties, '{{log_host}}', log_host)
    common.replace(datapush_properties, '{{log_user}}', log_user)


def replace_iac_jobs_info_ini():
    iac_jobs_info_ini = configVersionPath + '/iac_jobs_info.ini'
    if os.path.exists(iac_jobs_info_ini):
        os.remove(iac_jobs_info_ini)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'iac_jobs_info.ini'), iac_jobs_info_ini)
    common.replace(iac_jobs_info_ini, '{{jobName}}', jobName)
    common.replace(iac_jobs_info_ini, '{{jobType}}', jobType)
    common.replace(iac_jobs_info_ini, '{{crontabCycle}}', crontabCycle)
    common.replace(iac_jobs_info_ini, '{{offsetName}}', offsetName)
    common.replace(iac_jobs_info_ini, '{{isUTC}}', isUTC)
    common.replace(iac_jobs_info_ini, '{{dicName}}', dicName)


if not os.path.exists(common.appConfigPath):
    os.makedirs(common.appConfigPath)
common.delete_file(configVersionPath, '.*\.sh')
common.delete_file(configVersionPath, '.*\.xml')

common.chmod_file(configVersionPathTemplate, '.*\.sh')

cronPath = os.path.join(configVersionPathTemplate, 'crontab.cron')
if os.path.exists(cronPath):
    os.remove(cronPath)
cron = open(cronPath, 'w+')

jobsListPath = os.path.join(configVersionPathTemplate, 'jobsList')
if os.path.exists(jobsListPath):
    os.remove(jobsListPath)
jobsList = open(jobsListPath, 'w+')

metaPath = os.path.join(configVersionPathTemplate, 'meta.txt')
if os.path.exists(metaPath):
    os.remove(metaPath)
metaFile = open(metaPath, 'w+')

replace_iac_jobs_info_ini()

metaFile.write('./crontab.cron|../crontab.cron||\n')
metaFile.write('./jobsList|../jobsList||\n')
metaFile.write(common.commonPath + '/template/wiseEye.ini|' + common.appPath + '/conf/wiseEye.properties||\n')
metaFile.write(common.commonPath + '/template/datapush.ini|' + common.appPath + '/conf/datapush.properties||\n')
metaFile.write(common.commonPath + '/template/properties/cat/cat|' + common.appPath + '/conf/properties/cat/cat||\n')
metaFile.write(common.commonPath + '/template/properties/dog/dog|' + common.appPath + '/conf/properties/dog/dog||\n')
metaFile.write(
    common.commonPath + '/template/properties/dragon/dragon|' + common.appPath + '/conf/properties/dragon/dragon||\n')
metaFile.write(
    common.commonPath + '/template/properties/duck/duck|' + common.appPath + '/conf/properties/duck/duck||\n')
metaFile.write(
    common.commonPath + '/template/properties/pig/pig|' + common.appPath + '/conf/properties/pig/pig||\n')

replace_datapush_properties()
# 创建任务配置xml
create_job_config_xml()
# 创建任务shell
create_shell()
# 任务执行脚本写入crontab
cron.write(
    crontabCycle + ' source ~/.profile && bash -lc "sh ' + common.appConfigPath + '/IDE_DataPush_' + jobName + '.sh > /dev/null 2>&1"\n')
cron.write(
    update_secret_cron + ' source ~/.profile && bash -lc "sh ' + common.commonPath + '/pullSecret.sh ' + pull_secret_param + ' > /dev/null 2>&1"\n')
jobsList.close()
cron.close()
metaFile.close()
