#!/usr/bin/python
# coding=utf-8
import sys
import os
import shutil
import common

configVersionPath = sys.argv[1]
print 'configVersionPath:' + configVersionPath
pull_secret_param = sys.argv[2]
print 'pull_secret_param:' + pull_secret_param
update_secret_cron = sys.argv[3]
if len(update_secret_cron) == 0:
    update_secret_cron = '0 */1 * * *'
print 'update_secret_cron:' + update_secret_cron
configVersionPathTemplate = os.path.join(configVersionPath, 'template')
jobName = ''
jobType = ''
sourceId = ''
fileSourceDir = ''
dbsource_type = ''
dbsource_host = ''
dbsource_port = ''
dbsource_database = ''
dbsource_username = ''
dbsource_passw = ''
dbsource_options = ''
dbsource_sql = ''
crontabCycle = ''


# create file tmp
def create_file_source_tmp(source_id, file_source_dir, job_source):
    file_source_tmp = os.path.join(configVersionPathTemplate, 'file_source_' + source_id + '.tmp')
    print 'file source = ' + file_source_tmp
    if os.path.exists(file_source_tmp):
        os.remove(file_source_tmp)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'file_source.xml'), file_source_tmp)
    common.replace(file_source_tmp, '{{filesource_id}}', source_id)
    common.replace(file_source_tmp, '{{filesource_dir}}', file_source_dir)
    tmp_data = ''
    with open(file_source_tmp, 'r') as file_tmp:
        for file_line in file_tmp:
            tmp_data += file_line
    with open(job_source, 'a+') as fs:
        fs.write(tmp_data)
    os.remove(file_source_tmp)


# create db tmp
def create_db_source_tmp(source_id, dbsourceType, dbsourceHost, dbsourcePort,
                         dbsourceDatabase, dbsourceUsername, dbsourcePassw, dbsourceOptions, dbsourceSql,
                         job_source):
    db_source_tmp = os.path.join(configVersionPathTemplate, 'db_source_' + source_id + '.tmp')
    print 'db source = ' + db_source_tmp
    if os.path.exists(db_source_tmp):
        os.remove(db_source_tmp)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'db_source.xml'), db_source_tmp)
    common.replace(db_source_tmp, '{{dbsource_id}}', source_id)
    common.replace(db_source_tmp, '{{dbsource_type}}', dbsourceType)
    common.replace(db_source_tmp, '{{dbsource_host}}', dbsourceHost)
    common.replace(db_source_tmp, '{{dbsource_port}}', dbsourcePort)
    common.replace(db_source_tmp, '{{dbsource_database}}', dbsourceDatabase)
    common.replace(db_source_tmp, '{{dbsource_username}}', dbsourceUsername)
    common.replace(db_source_tmp, '{{dbsource_passw}}', dbsourcePassw)
    common.replace(db_source_tmp, '{{dbsource_options}}', dbsourceOptions)
    common.replace(db_source_tmp, '{{dbsource_sql}}', dbsourceSql)
    tmp_data = ''
    with open(db_source_tmp, 'r') as db_tmp:
        for db_line in db_tmp:
            tmp_data += db_line
    with open(job_source, 'a+') as fs:
        fs.write(tmp_data)
    os.remove(db_source_tmp)


# iac create sh
def create_shell(job_id):
    sh_conf = os.path.join(configVersionPathTemplate, 'IDE_DataPush_' + job_id + '.sh')
    if os.path.exists(sh_conf):
        os.remove(sh_conf)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'datapush_run.sh'), sh_conf)


# iac create job xml,job_type=1 is file,job_type=0 is db
def create_xml(job_id, sourceId, job_type):
    job_source = os.path.join(configVersionPathTemplate, job_id + '_source.xml')
    jobsList.write(job_id + '?{{periodType}}$')
    sources = sourceId.split('|')
    if job_type == '1':
        fileSourceDirs = fileSourceDir.split('|')
        for i in range(len(sources)):
            create_file_source_tmp(sources[i], fileSourceDirs[i], job_source)
    if job_type == '0':
        dbsource_types = dbsource_type.split('|')
        dbsource_hosts = dbsource_host.split('|')
        dbsource_ports = dbsource_port.split('|')
        dbsource_databases = dbsource_database.split('|')
        dbsource_usernames = dbsource_username.split('|')
        dbsource_passws = dbsource_passw.split('|')
        dbsource_optionss = dbsource_options.split('|')
        dbsource_sqls = dbsource_sql.split('|')
        for i in range(len(sources)):
            create_db_source_tmp(sources[i], dbsource_types[i], dbsource_hosts[i],
                                 dbsource_ports[i], dbsource_databases[i], dbsource_usernames[i],
                                 dbsource_passws[i], dbsource_optionss[i], dbsource_sqls[i], job_source)
    job_source_txt = ''
    with open(job_source, 'r') as sf:
        job_source_txt += sf.read()
    os.remove(job_source)
    job_conf = configVersionPath + '/template/' + job_id + '_config.xml'
    if os.path.exists(job_conf):
        os.remove(job_conf)
    if job_type == '1':
        shutil.copyfile(os.path.join(common.commonPath, 'template', 'file_config.xml'), job_conf)
        common.replace(job_conf, '{{file_sources}}', job_source_txt)
    if job_type == '0':
        shutil.copyfile(os.path.join(common.commonPath, 'template', 'db_config.xml'), job_conf)
        common.replace(job_conf, '{{db_sources}}', job_source_txt)


if not os.path.exists(common.appConfigPath):
    os.makedirs(common.appConfigPath)
common.delete_file(configVersionPath, '.*\.sh')
common.delete_file(configVersionPath, '.*\.xml')

toolPath = os.path.join(configVersionPathTemplate, 'cp.sh')
if os.path.exists(toolPath):
    os.remove(toolPath)
shutil.copyfile(os.path.join(common.commonPath, 'template', 'cp.sh'), toolPath)
common.chmod_file(configVersionPathTemplate, '.*\.sh')

cronPath = os.path.join(configVersionPathTemplate, 'crontab.cron')
if os.path.exists(cronPath):
    os.remove(cronPath)
cron = open(cronPath, 'w+')

jobsListPath = os.path.join(configVersionPathTemplate, 'jobsList')
if os.path.exists(jobsListPath):
    os.remove(jobsListPath)
jobsList = open(jobsListPath, 'w+')

metaPath = os.path.join(configVersionPathTemplate, 'meta.txt')
if os.path.exists(metaPath):
    os.remove(metaPath)
metaFile = open(metaPath, 'w+')
metaFile.write('./crontab.cron|../crontab.cron||\n')
metaFile.write('./jobsList|../jobsList||\n')
metaFile.write(common.commonPath + '/template/wiseEye.ini|' + common.appPath + '/conf/wiseEye.properties||\n')
metaFile.write(common.commonPath + '/template/datapush.ini|' + common.appPath + '/conf/datapush.properties||\n')
metaFile.write(common.commonPath + '/template/properties/dog/dog|' + common.appPath + '/conf/properties/dog/dog||\n')
metaFile.write(common.commonPath + '/template/properties/cat/cat|' + common.appPath + '/conf/properties/cat/cat||\n')
metaFile.write(
    common.commonPath + '/template/properties/dragon/dragon|' + common.appPath + '/conf/properties/dragon/dragon||\n')
metaFile.write(
    common.commonPath + '/template/properties/duck/duck|' + common.appPath + '/conf/properties/duck/duck||\n')
metaFile.write(
    common.commonPath + '/template/properties/pig/pig|' + common.appPath + '/conf/properties/pig/pig||\n')
with open(configVersionPath + '/iac_jobs_info.ini') as jobsInfo:
    for line in jobsInfo:
        line = line.replace('\n', '').replace('\r', '')
        print line
        if 'jobName' in line:
            jobName = line.split('=')[1]
            # print jobsValue
            if len(jobName.lstrip()) == 0:
                continue
        if 'jobType' in line:
            jobType = line.split('=')[1]
            # print jobsType
            if len(jobType.lstrip()) == 0:
                continue
            if jobType != '0' and jobType != '1':
                raise Exception('job type not match')
        if 'sourceId' in line:
            sourceId = line.split('=')[1]
        if 'fileSourceDir' in line:
            fileSourceDir = line.split('=')[1]
        if 'dbsource_type' in line:
            dbsource_type = line.split('=')[1]
        if 'dbsource_host' in line:
            dbsource_host = line.split('=')[1]
        if 'dbsource_port' in line:
            dbsource_port = line.split('=')[1]
        if 'dbsource_database' in line:
            dbsource_database = line.split('=')[1]
        if 'dbsource_username' in line:
            dbsource_username = line.split('=')[1]
        if 'dbsource_passw' in line:
            dbsource_passw = line.split('=')[1]
        if 'dbsource_options' in line:
            dbsource_options = line.split('=')[1]
        if 'dbsource_sql' in line:
            dbsource_sql = line.split('=')[1]
        if 'crontabCycle' in line:
            crontabCycle = line.split('=')[1]
print 'jobName = ' + jobName
print 'jobType = ' + jobType
print 'sourceId = ' + sourceId
create_xml(jobName, sourceId, jobType)
metaFile.write('./' + jobName + '_config.xml|../' + jobName + '_config.xml||cp.sh ' + jobName + '_config.xml\n')
create_shell(jobName)
cron.write(
    crontabCycle + ' source ~/.profile && bash -lc "sh ' + common.appConfigPath + '/IDE_DataPush_' + jobName + '.sh > /dev/null 2>&1"\n')
cron.write(
    update_secret_cron + ' source ~/.profile && bash -lc "sh ' + common.commonPath + '/pullSecret.sh ' + pull_secret_param + ' > /dev/null 2>&1"\n')
metaFile.write(
    './IDE_DataPush_' + jobName + '.sh|../IDE_DataPush_' + jobName + '.sh||cp.sh IDE_DataPush_' + jobName + '.sh\n')
jobsList.close()
cron.close()
metaFile.close()
