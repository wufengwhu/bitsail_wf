#!/usr/bin/python
# coding=utf-8
import sys
import os
import shutil
import common

configVersionPath = sys.argv[1]
print 'configVersionPath:' + configVersionPath
pull_secret_param = sys.argv[2]
print 'pull_secret_param:' + pull_secret_param
update_secret_cron = sys.argv[3]
if len(update_secret_cron) == 0:
    update_secret_cron = '0 */1 * * *'
print 'update_secret_cron:' + update_secret_cron
configVersionPathTemplate = os.path.join(configVersionPath, 'template')


# wiseEye create sh
def create_shell(job_id):
    sh_conf = os.path.join(configVersionPathTemplate, 'IDE_DataPush_' + job_id + '.sh')
    if os.path.exists(sh_conf):
        os.remove(sh_conf)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'datapush_run.sh'), sh_conf)
    common.replace(sh_conf, '{{jobName}}', '{{' + job_id + '_jobName}}')
    common.replace(sh_conf, '{{periodType}}', '{{' + job_id + '_periodType}}')
    common.replace(sh_conf, '{{offset}}', '{{' + job_id + '_offset}}')
    common.replace(sh_conf, '{{offsetName}}', '{{' + job_id + '_offsetName}}')
    common.replace(sh_conf, '{{isUTC}}', '{{' + job_id + '_isUTC}}')


# create file tmp
def create_file_source_tmp(source_id, job_source):
    file_source_tmp = os.path.join(configVersionPathTemplate, 'file_source_' + source_id + '.tmp')
    print 'file source = ' + file_source_tmp
    if os.path.exists(file_source_tmp):
        os.remove(file_source_tmp)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'file_source.xml'), file_source_tmp)
    common.replace(file_source_tmp, '{{filesource_id}}', '{{' + source_id + '_fileSourceId}}')
    common.replace(file_source_tmp, '{{filesource_dir}}', '{{' + source_id + '_fileSourceDir}}')
    tmp_data = ''
    with open(file_source_tmp, 'r') as file_tmp:
        for file_line in file_tmp:
            tmp_data += file_line
    with open(job_source, 'a+') as fs:
        fs.write(tmp_data)
    os.remove(file_source_tmp)


# create db tmp
def create_db_source_tmp(source_id, job_source):
    db_source_tmp = os.path.join(configVersionPathTemplate, 'db_source_' + source_id + '.tmp')
    print 'db source = ' + db_source_tmp
    if os.path.exists(db_source_tmp):
        os.remove(db_source_tmp)
    shutil.copyfile(os.path.join(common.commonPath, 'template', 'db_source.xml'), db_source_tmp)
    common.replace(db_source_tmp, '{{dbsource_id}}', '{{' + source_id + '_dbsource_id}}')
    common.replace(db_source_tmp, '{{dbsource_type}}', '{{' + source_id + '_dbsource_type}}')
    common.replace(db_source_tmp, '{{dbsource_host}}', '{{' + source_id + '_dbsource_host}}')
    common.replace(db_source_tmp, '{{dbsource_port}}', '{{' + source_id + '_dbsource_port}}')
    common.replace(db_source_tmp, '{{dbsource_database}}', '{{' + source_id + '_dbsource_database}}')
    common.replace(db_source_tmp, '{{dbsource_username}}', '{{' + source_id + '_dbsource_username}}')
    common.replace(db_source_tmp, '{{dbsource_passw}}', '{{' + source_id + '_dbsource_passw}}')
    common.replace(db_source_tmp, '{{dbsource_options}}', '{{' + source_id + '_dbsource_options}}')
    common.replace(db_source_tmp, '{{dbsource_sql}}', '{{' + source_id + '_dbsource_sql}}')
    tmp_data = ''
    with open(db_source_tmp, 'r') as db_tmp:
        for db_line in db_tmp:
            tmp_data += db_line
    with open(job_source, 'a+') as fs:
        fs.write(tmp_data)
    os.remove(db_source_tmp)


# wiseEye create job xml,job_type=0 is file,job_type=1 is db
def create_xml(job_id, sources, job_type):
    job_source = os.path.join(configVersionPathTemplate, job_id + '_source.xml')
    jobsList.write(job_id + '?{{' + job_id + '_periodType}}$')
    for source_id in sources:
        if job_type == 0:
            create_file_source_tmp(source_id, job_source)
        if job_type == 1:
            create_db_source_tmp(source_id, job_source)
    job_source_txt = ''
    with open(job_source, 'r') as sf:
        job_source_txt += sf.read()
    os.remove(job_source)
    job_conf = configVersionPath + '/template/' + job_id + '_config.xml'
    if os.path.exists(job_conf):
        os.remove(job_conf)
    if job_type == 0:
        shutil.copyfile(os.path.join(common.commonPath, 'template', 'file_config.xml'), job_conf)
        common.replace(job_conf, '{{isOnlyTrans}}', '{{' + job_id + '_isOnlyTrans}}')
        common.replace(job_conf, '{{ifOnlyTransISRename}}', '{{' + job_id + '_ifOnlyTransISRename}}')
        common.replace(job_conf, '{{fileMask}}', '{{' + job_id + '_fileMask}}')
        common.replace(job_conf, '{{sourcePolicy}}', '{{' + job_id + '_sourcePolicy}}')
        common.replace(job_conf, '{{file_sources}}', job_source_txt)
    if job_type == 1:
        shutil.copyfile(os.path.join(common.commonPath, 'template', 'db_config.xml'), job_conf)
        common.replace(job_conf, '{{replaceSource}}', '{{' + job_id + '_replaceSource}}')
        common.replace(job_conf, '{{replaceTarget}}', '{{' + job_id + '_replaceTarget}}')
        common.replace(job_conf, '{{sql}}', '{{' + job_id + '_sql}}')
        common.replace(job_conf, '{{fieldSep}}', '{{' + job_id + '_fieldSep}}')
        common.replace(job_conf, '{{lineSep}}', '{{' + job_id + '_lineSep}}')
        common.replace(job_conf, '{{db_sources}}', job_source_txt)
    common.replace(job_conf, '{{jobName}}', '{{' + job_id + '_jobName}}')
    common.replace(job_conf, '{{destFileName}}', '{{' + job_id + '_destFileName}}')
    common.replace(job_conf, '{{workPolicy}}', '{{' + job_id + '_workPolicy}}')
    common.replace(job_conf, '{{isOpenPeriodDir}}', '{{' + job_id + '_isOpenPeriodDir}}')
    common.replace(job_conf, '{{destDirectory}}', '{{' + job_id + '_destDirectory}}')
    common.replace(job_conf, '{{destFilePermission}}', '{{' + job_id + '_destFilePermission}}')
    common.replace(job_conf, '{{odsName}}', '{{' + job_id + '_odsName}}')
    common.replace(job_conf, '{{periodType}}', '{{' + job_id + '_periodType}}')
    common.replace(job_conf, '{{authType}}', '{{' + job_id + '_authType}}')
    common.replace(job_conf, '{{privatePass}}', '{{' + job_id + '_privatePass}}')
    common.replace(job_conf, '{{privateFile}}', '{{' + job_id + '_privateFile}}')


if not os.path.exists(common.appConfigPath):
    os.makedirs(common.appConfigPath)
common.delete_file(configVersionPath, '.*\.sh')
common.delete_file(configVersionPath, '.*\.xml')

toolPath = os.path.join(configVersionPathTemplate, 'cp.sh')
if os.path.exists(toolPath):
    os.remove(toolPath)
shutil.copyfile(os.path.join(common.commonPath, 'template', 'cp.sh'), toolPath)
common.chmod_file(configVersionPathTemplate, '.*\.sh')

jobsListPath = os.path.join(configVersionPathTemplate, 'jobsList')
if os.path.exists(jobsListPath):
    os.remove(jobsListPath)
jobsList = open(jobsListPath, 'w+')

cronPath = os.path.join(configVersionPathTemplate, 'crontab.cron')
if os.path.exists(cronPath):
    os.remove(cronPath)
cron = open(cronPath, 'w+')

metaPath = os.path.join(configVersionPathTemplate, 'meta.txt')
if os.path.exists(metaPath):
    os.remove(metaPath)
metaFile = open(metaPath, 'w+')
metaFile.write('./crontab.cron|../crontab.cron||\n')
metaFile.write('./jobsList|../jobsList||\n')
metaFile.write(common.commonPath + '/template/wiseEye.ini|' + common.appPath + '/conf/wiseEye.properties||\n')
metaFile.write(common.commonPath + '/template/datapush.ini|' + common.appPath + '/conf/datapush.properties||\n')
metaFile.write(
    common.commonPath + '/template/properties/dragon/dragon|' + common.appPath + '/conf/properties/dragon/dragon||\n')
metaFile.write(common.commonPath + '/template/properties/cat/cat|' + common.appPath + '/conf/properties/cat/cat||\n')
metaFile.write(common.commonPath + '/template/properties/dog/dog|' + common.appPath + '/conf/properties/dog/dog||\n')
metaFile.write(
    common.commonPath + '/template/properties/duck/duck|' + common.appPath + '/conf/properties/duck/duck||\n')
metaFile.write(common.commonPath + '/template/properties/pig/pig|' + common.appPath + '/conf/properties/pig/pig||\n')
with open(configVersionPath + '/jobs_info.ini') as jobsInfo:
    for line in jobsInfo:
        line = line.replace('\n', '').replace('\r', '')
        if 'file_jobNames' in line:
            print line
            jobsValue = line.split('=')[1]
            # print jobsValue
            if len(jobsValue.lstrip()) == 0:
                continue
            for job in jobsValue.split('|'):
                print job
                job_id = job.split('-')[0]
                sources = job.split('-')[1].split(',')
                create_xml(job_id, sources, 0)
                metaFile.write(
                    './' + job_id + '_config.xml|../' + job_id + '_config.xml||cp.sh ' + job_id + '_config.xml\n')
                create_shell(job_id)
                cron.write(
                    '{{' + job_id + '_crontabCycle}} source ~/.profile && bash -lc "sh ' + common.appConfigPath + '/IDE_DataPush_{{' + job_id + '_jobName}}.sh > /dev/null 2>&1"\n')
                cron.write(update_secret_cron + ' source ~/.profile && bash -lc "sh '
                           + common.commonPath + '/pullSecret.sh ' + pull_secret_param + ' > /dev/null 2>&1"\n')
                metaFile.write(
                    './IDE_DataPush_' + job_id + '.sh|../IDE_DataPush_' + job_id + '.sh||cp.sh IDE_DataPush_' + job_id + '.sh\n')

        if 'db_jobNames' in line:
            print line
            jobsValue = line.split('=')[1]
            # print jobsValue
            if len(jobsValue.lstrip()) == 0:
                continue
            for job in jobsValue.split('|'):
                print job
                job_id = job.split('-')[0]
                sources = job.split('-')[1].split(',')
                create_xml(job_id, sources, 1)
                metaFile.write(
                    './' + job_id + '_config.xml|../' + job_id + '_config.xml||cp.sh ' + job_id + '_config.xml\n')
                create_shell(job_id)
                cron.write(
                    '{{' + job_id + '_crontabCycle}} source ~/.profile && bash -lc "sh ' + common.appConfigPath + '/IDE_DataPush_{{' + job_id + '_jobName}}.sh > /dev/null 2>&1"\n')
                cron.write(update_secret_cron + ' source ~/.profile && bash -lc "sh '
                           + common.commonPath + '/pullSecret.sh ' + pull_secret_param + ' > /dev/null 2>&1"\n')
                metaFile.write(
                    './IDE_DataPush_' + job_id + '.sh|../IDE_DataPush_' + job_id + '.sh||cp.sh IDE_DataPush_' + job_id + '.sh\n')
jobsList.close()
cron.close()
metaFile.close()
