#!/bin/bash

cd $(dirname $0)
cd ..
root_dir=$(pwd)
actionType=$1
if [ "$actionType" -eq "0" ];then
  if [ "$#" -eq "2" ];then
    java -Xms256M -Xmx2048M -cp .:${root_dir}/libs/*: com.hihonor.cloudservice.datapush.IACDamApi "$@"
  else
    echo 'The number of parameters in the pull task is incorrect'
  fi
elif [ "$actionType"  -eq "1" ];then
  if [ "$#" -eq "3" ];then
    username=`whoami`
    java -Xms256M -Xmx2048M -cp .:${root_dir}/libs/*: com.hihonor.cloudservice.datapush.IACDamApi "$@" "$username"
  else
    echo 'The startup parameters for installation and deployment do not meet requirements'
  fi
else
  echo 'The first parameter is invalid'
fi
result=$?
if [[ ${result} -ne 0 ]]; then
  echo "push DAM fail = ${result}"
else
  echo "push DAM seccuss"
fi
exit ${result}