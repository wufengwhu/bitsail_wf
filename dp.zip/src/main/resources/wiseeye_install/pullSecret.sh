#!/bin/bash

cd $(dirname $0)
cd ..
root_dir=$(pwd)

java -Xms256M -Xmx2048M -cp .:${root_dir}/libs/*: com.hihonor.cloudservice.datapush.WiseEyeConfigCenterApi "$@"
result=$?
if [[ ${result} -ne 0 ]]; then
  echo "pull secret fail = ${result}"
else
  echo "pull secret seccuss"
fi
exit ${result}