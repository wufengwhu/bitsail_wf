#!/usr/bin/sh

if test -e ~/.profile; then
  source ~/.profile
else
  echo 'profile 不存在'
fi
if test -e ~/.bashrc; then
  source ~/.bashrc
else
  echo 'bashrc 不存在'
fi

chmod +x /opt/hihonor/apps/common/Datapush_IDE/DataPush_0.1/DataPush/DataPush_run.sh
JOB_NAME={{jobName}}
PERIOD_TYPE={{periodType}}
OFFSET={{offset}}
PERIOD_TIME=""
PROJECT_NUMBER=""
TIMEZONE=""
OFFSET_NAME={{offsetName}}
IS_UTC=`echo '{{isUTC}}' | tr 'a-z' 'A-Z'`

if [[ ${PERIOD_TYPE} == "D" ]]; then
  if [[ ${IS_UTC} == "TRUE" ]]; then
    PERIOD_TIME=$(date -u +%Y%m%d%H --date="$OFFSET day")
  else
    PERIOD_TIME=$(date +%Y%m%d%H --date="$OFFSET day")
  fi
elif [[ ${PERIOD_TYPE} == "H" ]]; then
  if [[ ${IS_UTC} == "TRUE" ]]; then
    PERIOD_TIME=$(date -u +%Y%m%d%H --date="$OFFSET hour")
  else
    PERIOD_TIME=$(date +%Y%m%d%H --date="$OFFSET hour")
  fi
elif [[ ${PERIOD_TYPE} == "M" ]]; then
  if [[ ${IS_UTC} == "TRUE" ]]; then
      MINUTE=$(date -u +%M)
      if [[ ${MINUTE} -gt 29 ]]; then
        PERIOD_TIME=$(date -u +%Y%m%d%H00)
      else
        PERIOD_TIME=$(date -u +%Y%m%d%H30 --date="-1 hour")
      fi
  else
      MINUTE=$(date +%M)
      if [[ ${MINUTE} -gt 29 ]]; then
        PERIOD_TIME=$(date +%Y%m%d%H00)
      else
        PERIOD_TIME=$(date +%Y%m%d%H30 --date="-1 hour")
      fi
  fi
else
  echo "invalid PERIOD_TYPE: $PERIOD_TYPE"
  exit -1
fi
if [[ ${IS_UTC} == "TRUE" ]]; then
    TIME_NAME=$(date -u +%Y%m%d%H --date="$OFFSET_NAME hour")
else
    TIME_NAME=$(date +%Y%m%d%H --date="$OFFSET_NAME hour")
fi
if [[ ! -d "/opt/hihonor/apps/common/Datapush_IDE/IDE/log" ]]; then
  mkdir -p /opt/hihonor/apps/common/Datapush_IDE/IDE/log
fi

for i in $*; do
  if [[ "$i" == "jobName="* ]]; then
    JOB_NAME=${i:8}
  fi
  if [[ "$i" == "type="* ]]; then
    PERIOD_TYPE=${i:5}
  fi
  if [[ "$i" == "time="* ]]; then
    PERIOD_TIME=${i:5}
  fi
  if [[ "$i" == "offset="* ]]; then
    OFFSET=${i:7}
  fi
  if [[ "$i" == "pn="* ]]; then
    PROJECT_NUMBER=${i:3}
  fi
  if [[ "$i" == "ptz="* ]]; then
    TIMEZONE=${i:4}
  fi
  if [[ "$i" == "offsetName="* ]]; then
    OFFSET_NAME=${i:11}
  fi
done

sh /opt/hihonor/apps/common/Datapush_IDE/DataPush_0.1/DataPush/DataPush_run.sh --context_param periodTime=${PERIOD_TIME} --context_param periodType=${PERIOD_TYPE} --context_param jobName=${JOB_NAME} --context_param periodLength=1 --context_param projectNumber=${PROJECT_NUMBER} --context_param timeZone=${TIMEZONE} --context_param timeName=${TIME_NAME} 1>>/opt/hihonor/apps/common/Datapush_IDE/IDE/log/${JOB_NAME}_${PERIOD_TIME}.log 2>&1
recode=$?

set +e
chmod -f 640 /opt/hihonor/apps/common/Datapush_IDE/logs/Datapush_*
chmod -f 440 /opt/hihonor/apps/common/Datapush_IDE/logs/Datapush_*_tar_*
chmod -f 640 /opt/hihonor/apps/common/Datapush_IDE/IDE/log/${JOB_NAME}_${PERIOD_TIME}.log
set -e

if [[ ${recode} -ne 0 ]]; then
  echo "Datapush run failed!"
  exit 1
else
  echo "Datapush run success!"
  exit 0
fi
