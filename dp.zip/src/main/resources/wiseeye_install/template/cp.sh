#!/bin/bash
path=$(dirname $(dirname "$0"))
echo ${path}
cp -rf ${path}'/'$1 /opt/hihonor/apps/common/Datapush_Extend/conf/
if [[ $1 == *sh ]]; then
    chmod 700 /opt/hihonor/apps/common/Datapush_Extend/conf/$1
fi