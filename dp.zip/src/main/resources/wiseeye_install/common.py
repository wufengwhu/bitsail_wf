import os
import re
import stat
import shutil

appPath = os.path.join('/opt/hihonor/apps/common/Datapush_IDE')
commonPath = os.path.join(appPath, 'wiseeye_install')
appConfigPath = os.path.join('/opt/hihonor/apps/common/Datapush_Extend/conf')


def get_file_content(read_file):
    file_content = ''
    if os.path.exists(read_file):
        with open(read_file, 'r') as f:
            for content in f:
                file_content += content
    return file_content


def get_value(config_file, key):
    file_content = ''
    with open(config_file, 'r') as f:
        for content in f:
            if key in content:
                file_content = content.split('=')[1]
                break
    return file_content.replace('\n', '')


def replace(alter_file, old_str, new_str):
    file_data = ""
    with open(alter_file, 'r') as f:
        for alert_line in f:
            if old_str in alert_line:
                alert_line = alert_line.replace(old_str, new_str)
            file_data += alert_line
    with open(alter_file, 'w') as f:
        f.write(file_data)


def del_file(path):
    ls = os.listdir(path)
    for i in ls:
        c_path = os.path.join(path, i)
        if os.path.isdir(c_path):
            del_file(c_path)
        else:
            os.remove(c_path)


def delete_line(path, match_str):
    file_data = ""
    with open(path, 'r') as f:
        for alert_line in f:
            if match_str in alert_line:
                continue
            else:
                file_data += alert_line
    with open(path, 'w') as f:
        f.write(file_data)


def check_line(path, check_str):
    file_data = ""
    check = 0
    with open(path, 'r') as f:
        for alert_line in f:
            alert_line = alert_line.replace('\n', '')
            if alert_line == '':
                continue
            tmp = check_str[check_str.index('sh '):]
            if tmp in alert_line:
                file_data += check_str + '\n'
                check = 1
            else:
                file_data += alert_line + '\n'
    if check == 0:
        file_data += check_str + '\n'
    with open(path, 'w') as f:
        f.write(file_data)


def chmod_file(chmod_dir, chmod_filter):
    for main_dir, sub_dir, file_name_list in os.walk(chmod_dir):
        for filename in file_name_list:
            path = os.path.join(main_dir, filename)
            pattern = re.compile(chmod_filter)
            if pattern.search(filename) is None:
                continue
            else:
                os.chmod(path, stat.S_IRWXU)


def delete_file(chmod_dir, chmod_filter):
    for main_dir, sub_dir, file_name_list in os.walk(chmod_dir):
        for filename in file_name_list:
            path = os.path.join(main_dir, filename)
            pattern = re.compile(chmod_filter)
            if pattern.search(filename) is None:
                continue
            else:
                os.remove(path)


def copy_match_xml(source_dir, dest_dir, match_filter):
    for main_dir, sub_dir, file_name_list in os.walk(source_dir):
        for filename in file_name_list:
            path = os.path.join(main_dir, filename)
            pattern = re.compile(match_filter)
            if pattern.search(filename) is None:
                continue
            else:
                if 'template' in os.path.dirname(path):
                    continue
                else:
                    print 'match old xml:' + path + ',to dest_dir:' + dest_dir
                    shutil.copyfile(path, os.path.join(dest_dir, filename))


def copy_match_shell(source_dir, dest_dir, match_filter):
    for file_name_list in os.listdir(source_dir):
        for filename in file_name_list:
            path = os.path.join(source_dir, filename)
            pattern = re.compile(match_filter)
            if pattern.search(filename) is None:
                continue
            else:
                print 'match old shell:' + path + ',to dest_dir:' + dest_dir
                shutil.copyfile(path, os.path.join(dest_dir, filename))
