#!/usr/bin/python
# coding=utf-8
import commands
import os
import sys
import common

configPath = sys.argv[1]
timePath = sys.argv[2]
print 'param:' + configPath + ',' + timePath
ip = common.get_value(os.path.join(configPath, 'config.ini'), 'ip')
user = common.get_value(os.path.join(configPath, 'config.ini'), 'user')
jdk_path = common.get_value(os.path.join(configPath, 'config.ini'), 'jdk_path')
env_path = os.path.join(timePath, 'conf', 'IDE_EnvConf.xml')
common.replace(env_path, '##HOST_IP##', ip)
common.replace(env_path, '##HOST_USER##', user)
run_path = os.path.join(timePath, 'DataPush_0.1', 'DataPush', 'DataPush_run.sh')
jdk_version = commands.getoutput('java -version')
if '1.8.0' in jdk_version:
    print jdk_version
else:
    os.system('chmod -f 770 ' + run_path)
    common.replace(run_path, 'java', os.path.join(jdk_path, 'bin', 'java'))
common.chmod_file(timePath, '.*\.sh$')
common.chmod_file(timePath, '.*\.exp$')

if not os.path.isdir(common.appConfigPath):
    os.makedirs(common.appConfigPath)
common.copy_match_xml(common.appPath, common.appConfigPath, '.*AppConf\.xml$')
common.copy_match_xml(common.appPath, common.appConfigPath, '.*EnvConf\.xml$')
common.copy_match_xml(common.appPath, common.appConfigPath, '.*_config\.xml$')
common.copy_match_xml(common.appPath, timePath, '^IDE_.*\.sh$')

appPath_IDE = os.path.join('/opt/hihonor/apps/common/Datapush_IDE/IDE')
if os.path.exists(appPath_IDE):
    common.copy_match_shell(appPath_IDE, os.path.join(timePath, 'IDE'), '^IDE_.*\.sh$')

appPath_Conf = os.path.join('/opt/hihonor/apps/common/Datapush_IDE/conf')
if os.path.exists(appPath_Conf):
    common.copy_match_shell(appPath_Conf, os.path.join(timePath, 'conf'), '^IDE_.*\.sh$')
print 'ln ' + timePath + ' to ' + common.appPath
(ln_status, ln_out) = commands.getstatusoutput('ln -snf ' + timePath + ' ' + common.appPath)
if ln_status != 0:
    sys.exit(ln_status)
os.system('mkdir -p /opt/hihonor/apps/common/Datapush_IDE/logs')
os.system('mkdir -p /opt/hihonor/apps/common/Datapush_IDE/IDE/log')
os.system('chmod 750 /opt/hihonor/apps/common/Datapush_IDE/logs')
os.system('chmod 750 /opt/hihonor/apps/common/Datapush_IDE/IDE')
os.system('chmod 750 /opt/hihonor/apps/common/Datapush_IDE/IDE/log')

os.system('chmod -R 550 /opt/hihonor/apps/common/Datapush_IDE/DataPush_0.1')
os.system('chmod -R 550 /opt/hihonor/apps/common/Datapush_IDE/bin')
os.system('chmod 750 /opt/hihonor/apps/common/Datapush_IDE/conf')
os.system('chmod 640 /opt/hihonor/apps/common/Datapush_IDE/conf/*.xml')
os.system('chmod 640 /opt/hihonor/apps/common/Datapush_IDE/conf/*.properties')
os.system('chmod 750 /opt/hihonor/apps/common/Datapush_IDE/conf/properties')
os.system('chmod 700 /opt/hihonor/apps/common/Datapush_IDE/conf/properties/*')
os.system('chmod 600 /opt/hihonor/apps/common/Datapush_IDE/conf/properties/*/*')
os.system('chmod 750 /opt/hihonor/apps/common/Datapush_IDE/conf/template')
os.system('chmod 640 /opt/hihonor/apps/common/Datapush_IDE/conf/template/*')
os.system('chmod -R 770 /opt/hihonor/apps/common/Datapush_IDE/dam_install')
os.system('chmod -R 550 /opt/hihonor/apps/common/Datapush_IDE/libs')
os.system('chmod 550 /opt/hihonor/apps/common/Datapush_IDE/package.json')
os.system('chmod 700 /opt/hihonor/apps/common/Datapush_IDE/fruits')
os.system('chmod 600 /opt/hihonor/apps/common/Datapush_IDE/fruits/*')
os.system('chmod 550 /opt/hihonor/apps/common/Datapush_IDE/version.txt')
os.system('chmod 750 /opt/hihonor/apps/common/Datapush_IDE/vtask')
os.system('chmod 640 /opt/hihonor/apps/common/Datapush_IDE/vtask/*')
os.system('chmod -R 770 /opt/hihonor/apps/common/Datapush_IDE/wiseeye_install')
