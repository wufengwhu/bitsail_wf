#! /usr/bin/sh

if test -e ~/.profile
then
source ~/.profile
else
echo 'profile 不存在'
fi
if test -e ~/.bashrc
then
source ~/.bashrc
else
echo 'bashrc 不存在'
fi

chmod +x /opt/hihonor/apps/common/Datapush_IDE_2X/DataPush_0.1/DataPush/DataPush_run.sh


if [ ! -n "$1" ] ;then
if [ 0 -eq 1 ] ;then
a=`date -u '+%Y%m%d%H' -d'0 day -1 hours' `0000
else
a=`date '+%Y%m%d%H' -d'0 day -1 hours' `0000
fi
else
    len=`echo $1 |wc -L`
    if [ ${len} = 10 ] ;then
    	a=${1}0000
    else
        echo "input is not correct!!!The format is yyyymmddhh"
        exit 1
    fi
fi
b=`date '+%Y%m%d%H'`
if [ ! -d "/opt/hihonor/apps/common/Datapush_IDE_2X/IDE/log" ];then
mkdir -p /opt/hihonor/apps/common/Datapush_IDE_2X/IDE/log
fi

timeName=$(date +%Y%m%d%H --date="0 hour")
/opt/hihonor/apps/common/Datapush_IDE_2X/DataPush_0.1/DataPush/DataPush_run.sh --context_param periodTime=$a --context_param periodType=H --context_param jobName=ODS_OUC_HMSHIOPERQRTLOGS_HM --context_param periodLength=1 --context_param timeName=$timeName 1>>/opt/hihonor/apps/common/Datapush_IDE_2X/IDE/log/ODS_OUC_HMSHIOPERQRTLOGS_HM_$a.log 2>&1

res=$?

if [ $res -eq 0 ] ;then
    echo "Datapush task execution successful."
else
    echo "Datapush task execution failed."
fi
echo "Datapush task finished."
exit $res

