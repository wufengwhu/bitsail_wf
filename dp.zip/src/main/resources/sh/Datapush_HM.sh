#!/bin/bash

cmd=$1


for i in {1..744}
do
        sh $cmd `date +%Y%m%d%H -d "-$i hour"`
done

if [ $? -eq 0 ];then
        echo -e "\033[32mOK\033[0m"
else
        echo -e "\033[31mfail\033[0m"
fi
