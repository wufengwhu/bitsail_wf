package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class IACDataSource {

    /**
     * The Constant type.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String type;

    /**
     * The Constant ip.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String ip;

    /**
     * The Constant port.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int port;

    /**
     * The Constant database.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String database;

    /**
     * The Constant userName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String userName;

    /**
     * The Constant password.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String password;

    /**
     * The Constant additionalInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String additionalInfo;

    /**
     * The Constant sql.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String sql;

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIp() {
        return this.ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return this.port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getDatabase() {
        return this.database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAdditionalInfo() {
        return this.additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getSql() {
        return this.sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }
}