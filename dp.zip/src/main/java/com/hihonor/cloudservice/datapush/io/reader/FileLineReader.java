package com.hihonor.cloudservice.datapush.io.reader;

import com.hihonor.cloudservice.datapush.GlobalVariable;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.io.FilesBlock;
import com.hihonor.cloudservice.datapush.io.FilesChannel;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-06
 */
public class FileLineReader
        implements Runnable {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FileLineReader.class);

    /**
     * The Constant LOCK.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Object LOCK = new Object();

    /**
     * The Constant sourceFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final List<Path> sourceFiles;

    /**
     * The Constant averageSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final long averageSize;

    /**
     * The Constant destFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final List<Path> destFiles;

    /**
     * The Constant tag.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int tag;

    /**
     * The Constant averageCount.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int averageCount;

    /**
     * The Constant currentSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private long currentSize;

    /**
     * The Constant channel.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private FilesChannel channel;

    /**
     * The Constant processList.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final List<String> processList;

    public FileLineReader(List<Path> sourceFiles, int averageCount, long averageSize, List<Path> destFiles) {
        this.tag = 0;
        this.sourceFiles = sourceFiles;
        this.averageCount = averageCount;
        this.averageSize = averageSize;
        this.destFiles = destFiles;
        this.currentSize = 0L;
        this.processList = new ArrayList<>(Util.getProcess());
    }

    /**
     * selectChannel
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void selectChannel() throws IndexOutOfBoundsException {
        while (true) {
            synchronized (LOCK) {
                for (FilesChannel tmp : (GlobalVariable.getInstance()).channels.values()) {
                    if (!tmp.isActive()) {
                        tmp.setActive(true);
                        this.channel = tmp;
                        this.channel.setTag(((Path) this.destFiles.get(this.tag)).toFile().getName());
                        return;
                    }
                }
            }
        }
    }

    /**
     * run
     *
     * @author z00502253
     * @since 2020-02-22
     */
    public void run() {
        File currentFile = null;
        try {
            selectChannel();
            for (Path sourceFile : this.sourceFiles) {
                currentFile = sourceFile.toFile();
                readOne(currentFile);
            }
            assert currentFile != null;
            putLine(null, true, currentFile.getName());
            for (int i = this.tag + 1; i < this.averageCount; i++) {
                this.tag++;
                this.currentSize = 0L;
                selectChannel();
                FilesBlock filesBlock = new FilesBlock();
                filesBlock.setDataType(1);
                filesBlock.setEndTag(true);
                this.channel.getFilesBlocks().put(filesBlock);
            }
        } catch (InterruptedException | IOException | DatapushException e) {
            this.channel.setError(true);
            log.error("read error------>{}", currentFile.getName(), e);
        }
        log.debug("read-{} exit------>{}", Long.valueOf(Thread.currentThread().getId()), currentFile.getName());
    }

    /**
     * readOne
     *
     * @param source source
     * @author z00502253
     * @since 2022-07-01
     */
    private void readOne(File source) throws InterruptedException, IOException, DatapushException {
        log.info("read start------>{}", source.getName());
        long allSize = 0L;
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(FileUtils.openInputStream(source),
                    StandardCharsets.UTF_8), 4194304);
            LineIterator readerLine = new LineIterator(reader);
            while (readerLine.hasNext()) {
                String line = readerLine.next();
                this.currentSize += line.length();
                putLine(line, false, source.getName());
                allSize += line.length();
                print(source.getName(), allSize, source.length());
            }
        } finally {
            Util.closeQuietly(reader);
            log.info("read end-------->{}(sizes={})", source.getName(), Long.valueOf(allSize));
        }
    }

    /**
     * putLine
     *
     * @param line String
     * @param isLast boolean
     * @param name String
     * @author z00502253
     * @since 2022-07-01
     */
    private void putLine(String line, boolean isLast, String name) throws InterruptedException, DatapushException {
        FilesBlock filesBlock = new FilesBlock();
        filesBlock.setDataType(1);
        filesBlock.setDataLine(line);
        if (!isLast) {
            if (this.currentSize >= this.averageSize && this.destFiles.size() != this.tag + 1) {
                filesBlock.setEndTag(true);
                log.debug("ready for------->{}", Paths.get(this.channel.getTag(), new String[0]).toFile().getName());
                this.channel.getFilesBlocks().put(filesBlock);
                this.tag++;
                this.currentSize = 0L;
                selectChannel();
            } else {
                filesBlock.setEndTag(false);
                this.channel.getFilesBlocks().put(filesBlock);
            }
        } else {
            filesBlock.setEndTag(true);
            log.debug("ready for------->{}", Paths.get(this.channel.getTag(), new String[0]).toFile().getName());
            this.channel.getFilesBlocks().put(filesBlock);
            if (this.processList.size() > 0 && ((String) this.processList
                    .get(this.processList.size() - 1)).equals("100")) {
                log.info("read process---->{}({}%)", name, this.processList.get(this.processList.size() - 1));
            }
        }
    }

    /**
     * print
     *
     * @param name String
     * @param cur long
     * @param size long
     * @author z00502253
     * @since 2022-07-01
     */
    private void print(String name, long cur, long size) {
        String process = Util.getPercent(cur, size);
        if (this.processList.contains(process)) {
            this.processList.removeIf(item -> item.equals(process));
            log.info("read process---->{}({}%)", name, process);
        }
    }
}