/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common.crypt;

import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.huawei.secure.crypto.CommCryptUtil;
import com.huawei.secure.crypto.aes.AesCryptUtil;
import com.huawei.secure.crypto.codec.AegisDecoderException;
import com.huawei.secure.crypto.workkey.WorkKeyCryptUtil;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Locale;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.bouncycastle.util.encoders.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class CryptService {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(CryptService.class);

    /**
     * decryptAes
     *
     * @param plainStr String
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String decryptAes(String plainStr) throws DatapushException {
        if (plainStr == null || "".equals(plainStr)) {
            return "";
        }
        if (!plainStr.toLowerCase(Locale.US).startsWith("security")) {
            return plainStr;
        }
        try {
            return AesCryptUtil.decryptAesGcm(plainStr.trim(), CryptPropLoad
                    .getDragon().trim(), RootKey.getRootKeyUtil());
        } catch (AegisDecoderException | GeneralSecurityException gcmException) {
            try {
                RootKey.getOldRootKeyUtil();
                return AesCryptUtil.decryptByAesCbc(plainStr.trim(), CryptPropLoad.getPig().trim());
            } catch (AegisDecoderException | GeneralSecurityException cbcException) {
                throw new DatapushException("decryptByAesCbc failed", cbcException);
            }
        }
    }

    /**
     * decryptAes
     *
     * @param plainStr String
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String encryptAes(String plainStr) throws DatapushException {
        if (plainStr == null || "".equals(plainStr)) {
            return "";
        }
        try {
            return AesCryptUtil.encryptAesGcm(plainStr.trim(), CryptPropLoad.getDragon().trim(),
                    RootKey.getRootKeyUtil());
        } catch (AegisDecoderException | GeneralSecurityException e) {
            throw new DatapushException("encryptAesGcm failed", e);
        }
    }

    /**
     * encryStringByHmacSHA256
     *
     * @param plainStr String
     * @param workKey String
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String encryStringByHmacSHA256(String plainStr, String workKey) throws DatapushException {
        try {
            workKey = WorkKeyCryptUtil.decryptWorkKey(workKey, RootKey.getRootKeyUtil());
            SecretKeySpec secretKey = new SecretKeySpec(workKey.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
            Mac mac = Mac.getInstance(secretKey.getAlgorithm());
            mac.init(secretKey);
            byte[] digest = mac.doFinal(plainStr.getBytes(StandardCharsets.UTF_8));
            return "security:" + Hex.toHexString(digest);
        } catch (GeneralSecurityException | AegisDecoderException e) {
            throw new DatapushException("HmacSha256 encrypt failed");
        }
    }

    /**
     * getSecureRandom
     *
     * @param size int
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getSecureRandom(int size) {
        byte[] secureBytes;
        try {
            secureBytes = CommCryptUtil.genSecureRandomByte(size);
        } catch (GeneralSecurityException e) {
            throw new DatapushException("getSecureRandom  failed");
        }
        return DatatypeConverter.printHexBinary(secureBytes);
    }
}