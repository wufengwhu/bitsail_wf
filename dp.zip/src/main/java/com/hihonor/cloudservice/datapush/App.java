package com.hihonor.cloudservice.datapush;

import com.hihonor.cloudservice.datapush.common.FindFileUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.config.AppConfig;
import com.hihonor.cloudservice.datapush.config.SingleConfig;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;
import com.hihonor.cloudservice.datapush.tasks.Task;
import com.hihonor.cloudservice.datapush.tasks.TaskFactory;
import com.hihonor.cloudservice.datapush.tasks.TaskMonitor;
import com.hihonor.cloudservice.datapush.tasks.TaskThread;
import com.hihonor.cloudservice.datapush.entity.DamConfig;
import com.hihonor.cloudservice.datapush.entity.DbSource;
import com.hihonor.cloudservice.datapush.entity.DruidConfig;
import com.hihonor.cloudservice.datapush.entity.FileSource;
import com.hihonor.cloudservice.datapush.entity.PeriodObject;
import com.hihonor.cloudservice.datapush.entity.ProgramConfig;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-06
 */
public class App {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(App.class);

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String jobName;

    /**
     * The Constant periodObject.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static PeriodObject periodObject;

    /**
     * The Constant programConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static ProgramConfig programConfig;

    /**
     * The Constant damConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static DamConfig damConfig;

    /**
     * The Constant druidConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static DruidConfig druidConfig;

    /**
     * The Constant ENV_FILES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final ArrayList<Path> ENV_FILES = new ArrayList<>();

    /**
     * The Constant APP_FILES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final ArrayList<Path> APP_FILES = new ArrayList<>();

    /**
     * The Constant SINGLE_FILES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final ArrayList<Path> SINGLE_FILES = new ArrayList<>();

    /**
     * The Constant GLOBAL_VARIABLE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final GlobalVariable GLOBAL_VARIABLE = GlobalVariable.getInstance();

    /**
     * The Constant tasksPool.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static ThreadPoolExecutor tasksPool;

    /**
     * --context_param periodTime=$a  20210526200000
     * --context_param periodType=H
     * --context_param jobName=ODS_HMSHIOPERQRTLOGS_HM
     * --context_param periodLength=1
     * --context_param timeName=$timeName 1     2021052709  1
     *
     * @param args
     * @throws DatapushException
     */
    private static void initParams(String[] args) throws DatapushException {
        log.info("params = {}", Arrays.asList(args));
        for (String param : args) {
            String[] params = param.split("=");
            if (params.length == 2) {

                String key = params[0];
                String value = params[1];
                switch (key) {
                    case "periodTime":
                        periodObject.setPeriodTime(value);
                        break;
                    case "periodType":
                        periodObject.setPeriodType(value);
                        break;
                    case "periodLength":
                        periodObject.setPeriodLength(Util.getInt(value, 30));
                        break;
                    case "jobName":
                        jobName = value;
                        break;
                    case "projectNumber":
                        programConfig.setProjectNumber(value);
                        break;
                    case "timeZone":
                        programConfig.setTimeZone(value);
                        break;
                    case "timeName":
                        periodObject.setTimeName(value);
                        break;
                }

            }
        }
        if (Util.isEmpty(periodObject.getPeriodTime())) {
            throw new DatapushException("period time is null");
        }
        if (Util.isEmpty(periodObject.getPeriodType())) {
            throw new DatapushException("period type is null");
        }
        if (Util.isEmpty(programConfig.getProjectNumber())) {
            programConfig.setProjectNumber("");
        }
        if (Util.isEmpty(programConfig.getTimeZone())) {
            programConfig.setTimeZone("");
        }
        if (Util.isEmpty(periodObject.getTimeName())) {
            periodObject.setTimeName("");
        }
    }

    /**
     * initPeriodTime
     *
     * @author z00502253
     * @since 2020-06-24
     */
    private static void initPeriodTime() {
        Date date = new Date();
        try {
            DateFormat df = new SimpleDateFormat("yyyyMMddHHmm");
            date = df.parse(periodObject.getPeriodTime());
        } catch (ParseException e) {
            DateFormat df = new SimpleDateFormat("yyyyMMddHH");
            try {
                date = df.parse(periodObject.getPeriodTime());
            } catch (ParseException e1) {
                log.error("Catch ParseException when invoke PeriodInfo.loadConfFile.");
            }
        }
        switch (periodObject.getPeriodType()) {
            case "D":
                periodObject.setStartTime((new SimpleDateFormat("yyyy-MM-dd 00:00:00")).format(date));
                periodObject.setEndTime((new SimpleDateFormat("yyyy-MM-dd 23:59:59")).format(date));
                periodObject.setPeriodTime((new SimpleDateFormat("yyyyMMdd00")).format(date));
                break;

            case "H":
                periodObject.setStartTime((new SimpleDateFormat("yyyy-MM-dd HH:00:00")).format(date));
                periodObject.setEndTime((new SimpleDateFormat("yyyy-MM-dd HH:59:59")).format(date));
                break;

            case "M":
                periodObject.setStartTime((new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(date));
                periodObject.setEndTime((new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"))
                        .format(Util.offsetTime(date, 1, periodObject.getPeriodLength(),
                                periodObject.getPeriodType())));
                break;
        }


        periodObject.setYear((new SimpleDateFormat("yyyy")).format(date));
        periodObject.setMonth((new SimpleDateFormat("MM")).format(date));
        periodObject.setMonth_day((new SimpleDateFormat("dd")).format(date));
        periodObject.setDay((new SimpleDateFormat("yyyyMMdd")).format(date));
        periodObject.setDayEp((new SimpleDateFormat("yyyy-MM-dd")).format(date));
        periodObject.setHour((new SimpleDateFormat("HH")).format(date));
        periodObject.setMinute((new SimpleDateFormat("mm")).format(date));
        if ("00".equals(periodObject.getMinute())) {
            periodObject.setMinuteEp("[0-2][0-9]");
        } else {
            periodObject.setMinuteEp("[3-5][0-9]");
        }
    }

    /**
     * initDruid
     *
     * @param sysPro sysPro
     * @author z00502253
     * @since 2020-06-24
     */
    private static void initDruid(Properties sysPro) {
        druidConfig = new DruidConfig();
        druidConfig.setType(sysPro.getProperty("program.pool.type", "stream"));
        druidConfig.setFetchSize(Util.getInt(sysPro.getProperty("program.pool.fetchSize"), 2000));
        druidConfig.setInitSize(Util.getInt(sysPro.getProperty("program.druid.initialSize"), 1));
        druidConfig.setMinIdle(Util.getInt(sysPro.getProperty("program.druid.minIdle"), 1));
        druidConfig.setMaxWait(Util.getInt(sysPro.getProperty("program.druid.maxWait"), 60000));
        druidConfig.setTimeBetweenEvictionRunsMillis(
                Util.getInt(sysPro.getProperty("program.druid.timeBetweenEvictionRunsMillis"), 2000));
        druidConfig.setTestWhileIdle(Boolean.parseBoolean(sysPro.getProperty("program.druid.testWhileIdle",
                "true")));
        druidConfig.setValidationQuery(sysPro.getProperty("program.druid.validationQuery",
                "SELECT 1"));
        druidConfig
                .setValidationQueryTimeout(Util.getInt(sysPro.getProperty("program.druid.validationQueryTimeout"),
                        1));
        druidConfig.setMinEvictableIdleTimeMillis(
                Util.getInt(sysPro.getProperty("program.druid.minEvictableIdleTimeMillis"), 600000));
        druidConfig.setKeepAlive(Boolean.parseBoolean(sysPro.getProperty("program.druid.keepAlive",
                "true")));
        druidConfig.setTestOnBorrow(Boolean.parseBoolean(sysPro.getProperty("program.druid.testOnBorrow",
                "false")));
        druidConfig.setTestOnReturn(Boolean.parseBoolean(sysPro.getProperty("program.druid.testOnReturn",
                "false")));
        druidConfig
                .setRemoveAbandoned(Boolean.parseBoolean(sysPro.getProperty("program.druid.removeAbandoned",
                        "true")));
        druidConfig
                .setRemoveAbandonedTimeout(Util.getInt(sysPro.getProperty("program.druid.removeAbandonedTimeout"),
                        1800));
        druidConfig.setLogAbandoned(Boolean.parseBoolean(sysPro.getProperty("program.druid.logAbandoned",
                "true")));
    }

    /**
     * initConfig
     *
     * @param sysPro sysPro
     * @author z00502253
     * @since 2020-06-24
     */
    private static void initConfig(Properties sysPro) throws DatapushException, IOException {
        try {
            Element root = Util.getDocument(FileUtils.getFile(
                    new String[]{GLOBAL_VARIABLE.rootDir + "/conf/IDE_EnvConf.xml"})).getRootElement();
            GLOBAL_VARIABLE.version = root.elementTextTrim("Version");
            GLOBAL_VARIABLE.node = root.elementTextTrim("Node");
            if (!Util.checkIp(GLOBAL_VARIABLE.node) || Util.isEmpty(GLOBAL_VARIABLE.version)) {
                throw new DatapushException("IDE_EnvConf config file error");
            }
            log.info(String.format(Locale.ENGLISH, "node={%s},version={%s}",
                            new Object[]{GLOBAL_VARIABLE.node, GLOBAL_VARIABLE.version}));
        } catch (DocumentException | org.xml.sax.SAXException | DatapushException e) {
            throw new DatapushException("IDE_EnvConf config file error", e);
        }
        programConfig.setUnifiedKey(CryptService.decryptAes(FileUtils.readFileToString(
                      FileUtils.getFile(new String[]{GLOBAL_VARIABLE.rootDir + "/fruits/pears"}),"UTF-8")));
        if (Util.isEmpty(programConfig.getUnifiedKey())) {
            throw new DatapushException("UnifyPrivateKey is null");
        }
        programConfig.setZipKey(CryptService.decryptAes(sysPro.getProperty("zip.default.key", "")));
        programConfig.setConfigDir(Arrays.asList(sysPro.getProperty("program.config.path", "/")
                .split(",")));
        programConfig.setMaxTasksPool(Util.getInt(sysPro.getProperty("program.main.threads.max"), 3));
        programConfig.setMaxSubTaskPool(Util.getInt(sysPro.getProperty("program.sub.threads.max"), 3));
        programConfig.setMaxChannels(Util.getInt(sysPro.getProperty("program.channels.max"), 4));
        programConfig.setRunTimeOut(Util.getInt(sysPro.getProperty("program.run.timeout"), 150));
        programConfig.setQueueSize(Util.getInt(sysPro.getProperty("program.pool.queue.size"), 5000));
        programConfig.setSshPort(Util.getInt(sysPro.getProperty("ssh.port"), 30022));
        programConfig.setOpenPeriodDir(Boolean.parseBoolean(sysPro.getProperty("program.dir.period.open",
                "true")));
        programConfig.setCreateEmptyFile(Boolean.parseBoolean(sysPro.getProperty("file.create.empty",
                "true")));
        programConfig.setLogClearTime(Util.getInt(sysPro.getProperty("program.log.clearTime"), 30));
        damConfig = new DamConfig();
        damConfig.setOpen(Boolean.parseBoolean(sysPro.getProperty("da.open", "true")));
        if (damConfig.isOpen()) {
            damConfig.setSignKey(CryptService.decryptAes(sysPro.getProperty("da.sign")));
            damConfig.setWorkKey(sysPro.getProperty("da.work"));
            damConfig.setUrl(sysPro.getProperty("da.url"));
            damConfig.setName(sysPro.getProperty("da.server.name", ""));
            damConfig.setTimeOut(Util.getInt(sysPro.getProperty("da.request.timeout"), 300));
            damConfig.setWaitTime(Util.getInt(sysPro.getProperty("da.request.waittime"), 3000));
            damConfig.setLogOpen(Boolean.parseBoolean(sysPro.getProperty("log.open")));
            if (damConfig.isLogOpen()) {
                damConfig.setLogHosts(Arrays.asList(sysPro.getProperty("log.host").split(",")));
                damConfig.setUser(sysPro.getProperty("log.user"));
                damConfig.setLogTimeOut(Util.getInt(sysPro.getProperty("log.timeOut"), 1800));
                damConfig.setLogDir(Arrays.asList(sysPro.getProperty("log.sourceDir", "/")
                        .split(",")));
                damConfig.setLogDestDir(Paths.get(sysPro.getProperty("log.destDir", "/"),
                        new String[0]));
            }
        }
    }

    /**
     * initTaskFiles
     *
     * @param machs String[]
     * @author z00502253
     * @since 2020-06-24
     */
    private static void initTaskFiles(String[] machs) throws IOException {
        for (String match : machs) {
            for (String path : programConfig.getConfigDir()) {
                if (!path.endsWith("/")) {
                    path = path + "/";
                }
                if (match.equals("ide_env")) {
                    ENV_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path, new String[0]),
                            "IDE_EnvConf.xml"));
                }
                if (match.equals("env")) {
                    ENV_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path, new String[0]),
                            "EnvConf.xml"));
                }
                if (match.equals("app")) {
                    APP_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path, new String[0]),
                            "AppConf.xml"));
                }
                if (match.equals("sin")) {
                    SINGLE_FILES.addAll((new FindFileUtil(1)).getFileByRegex(Paths.get(path, new String[0]),
                            ".*_config\\.xml$"));
                }
                if (match.equals("ide_app")) {
                    APP_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path, new String[0]),
                            "IDE_AppConf.xml"));
                }
            }
        }
    }

    // --context_param periodTime=20210524090000
    // --context_param periodType=H
    // --context_param jobName=ODS_PHONESERVICE_HMSHIOPERQRTLOGS_HM
    // --context_param periodLength=1
    // --context_param timeName=$timeName
    public static void main(String[] args) {
        boolean isSuccess = true;
        try {
            Thread.currentThread().setName("Datapush");
            GLOBAL_VARIABLE.rootDir = Paths.get(System.getProperty("user.dir"), new String[0]).toString();
            Util.loadLogBack(GLOBAL_VARIABLE.rootDir + File.separator + "conf" + File.separator + "logback.xml");
            GLOBAL_VARIABLE.workDir = Paths.get(GLOBAL_VARIABLE.rootDir, new String[]{"work"}).toString();
            periodObject = new PeriodObject();
            programConfig = new ProgramConfig();
            initParams(args);
            loadConfig();
            log.info("Tasks = {}", GLOBAL_VARIABLE.taskInfoMap.keySet());
            if (GLOBAL_VARIABLE.taskInfoMap.size() > 0) {

                tasksPool = new ThreadPoolExecutor(GLOBAL_VARIABLE.programConfig.getMaxTasksPool() + 1,
                        GLOBAL_VARIABLE.programConfig.getMaxTasksPool() + 1, 0L,
                        TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(GLOBAL_VARIABLE.programConfig.getQueueSize()));

                GLOBAL_VARIABLE
                        .sshPool = new ThreadPoolExecutor(GLOBAL_VARIABLE.programConfig.getMaxSubTaskPool(),
                        GLOBAL_VARIABLE.programConfig.getMaxSubTaskPool(), 0L, TimeUnit.MILLISECONDS,
                        new ArrayBlockingQueue<>(GLOBAL_VARIABLE.programConfig.getQueueSize()));

                GLOBAL_VARIABLE
                        .subPool = new ThreadPoolExecutor(GLOBAL_VARIABLE.programConfig.getMaxSubTaskPool(),
                        GLOBAL_VARIABLE.programConfig.getMaxSubTaskPool(), 0L, TimeUnit.MILLISECONDS,
                        new ArrayBlockingQueue<>(GLOBAL_VARIABLE.programConfig.getQueueSize()));

                Future<Boolean> monitor = tasksPool.submit((Callable<Boolean>) new TaskMonitor(1));
                for (TaskInfo taskInfo : GLOBAL_VARIABLE.taskInfoMap.values()) {
                    dealTaskInfo(taskInfo);

                    TaskFactory taskFactory = new TaskFactory();

                    Task task = taskFactory.createTask(taskInfo);

                    if (task != null) {
                        tasksPool.submit((Runnable) new TaskThread(task, taskInfo.getJobName()));
                    }
                }

                try {
                    isSuccess = ((Boolean) monitor.get(GLOBAL_VARIABLE.programConfig.getRunTimeOut(),
                            TimeUnit.MINUTES)).booleanValue();
                } catch (InterruptedException | java.util.concurrent.ExecutionException
                        | java.util.concurrent.TimeoutException e) {
                    throw new DatapushException(e);
                }

            }
        } catch (IOException | DatapushException exception) {
            log.error("Datapush run error", exception);
            isSuccess = false;
        } finally {
            if (tasksPool != null) {
                tasksPool.shutdown();
            }
            if (GLOBAL_VARIABLE.sshPool != null) {
                GLOBAL_VARIABLE.sshPool.shutdown();
            }
            if (GLOBAL_VARIABLE.subPool != null) {
                GLOBAL_VARIABLE.subPool.shutdown();
            }
            if (!isSuccess) {
                log.info("Datapush run failed");
                System.exit(1);
            } else {
                log.info("Datapush run success");
            }
        }
    }


    /**
     * dealTaskInfo
     *
     * @param taskInfo taskInfo
     * @author z00502253
     * @since 2020-06-24
     */
    private static void dealTaskInfo(TaskInfo taskInfo) {
        taskInfo.setPeriodObject(periodObject);
        taskInfo.setDestFileName(formatMsg(taskInfo.getDestFileName(), taskInfo.getJobName()));
        if (taskInfo.getFilesTask() != null) {
            List<String> tmpFilesTask = new ArrayList<>();
            for (String tmpMask : taskInfo.getFilesTask().getFilesMask()) {
                tmpMask = formatMsg(tmpMask, taskInfo.getJobName());
                tmpFilesTask.add(tmpMask);
            }
            taskInfo.getFilesTask().setFilesMask(tmpFilesTask);

            List<FileSource> tmpFilesSource = new ArrayList<>();
            if (taskInfo.getFilesTask().getFileSources() != null) {
                for (FileSource fileSource : taskInfo.getFilesTask().getFileSources()) {
                    fileSource.setChildDirRegex(formatMsg(fileSource.getChildDirRegex(), taskInfo.getJobName()));
                    tmpFilesSource.add(fileSource);
                }
            }
            taskInfo.getFilesTask().setFileSources(tmpFilesSource);
        }
        if (taskInfo.getDatabaseTask() != null) {
            taskInfo.getDatabaseTask().setSql(formatMsg(taskInfo.getDatabaseTask().getSql(), taskInfo.getJobName()));
            for (DbSource dbSource : taskInfo.getDatabaseTask().getDbSources()) {
                if (Util.isEmpty(dbSource.getSql())) {
                    continue;
                }
                dbSource.setSql(formatMsg(dbSource.getSql(), taskInfo.getJobName()));
            }
        }
        if (Util.isEmpty(taskInfo.getLineSep())) {
            taskInfo.setLineSep("\n");
        }
        if (Util.isEmpty(taskInfo.getFieldSep())) {
            taskInfo.setFieldSep("|");
        }
    }

    /**
     * loadConfig
     *
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadConfig() throws IOException, DatapushException {
        initPeriodTime();
        Properties sysPro = new Properties();
        try (InputStream in = FileUtils.openInputStream(
                FileUtils.getFile(new String[]{GLOBAL_VARIABLE.rootDir + "/conf/datapush.properties"}))) {
            sysPro.load(in);
        }
        initConfig(sysPro);
        initDruid(sysPro);
        log.debug("{}", periodObject);
        log.debug("{}", programConfig);
        log.debug("{}", druidConfig);
        GLOBAL_VARIABLE.programConfig = programConfig;
        GLOBAL_VARIABLE.damConfig = damConfig;
        GLOBAL_VARIABLE.druidConfig = druidConfig;
        initTaskFiles(new String[]{"sin", "ide_env", "env", "ide_app", "app"});
        log.debug("env config files = {}", ENV_FILES);
        log.debug("app config files = {}", APP_FILES);
        log.debug("single config files = {}", SINGLE_FILES);
        if (Util.isNotEmpty(jobName)) {
            boolean check = false;
            for (Path single : SINGLE_FILES) {
                if (single.toFile().getName().replace("_config.xml", "").equals(jobName)) {
                    loadSingleConfigFile(single);
                    check = true;
                    break;
                }
            }
            if (!check) {
                for (Path app : APP_FILES) {
                    loadAppConfigFile(app);
                    for (String key : GLOBAL_VARIABLE.taskInfoMap.keySet()) {
                        if (key.equals(jobName)) {
                            break;
                        }
                    }
                }
            }
        } else {
            for (Path single : SINGLE_FILES) {
                loadSingleConfigFile(single);
            }
            for (Path app : APP_FILES) {
                loadAppConfigFile(app);
            }
        }
    }

    /**
     * loadSingleConfigFile
     *
     * @param path path
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadSingleConfigFile(Path path) {
        SingleConfig singleConfig = new SingleConfig(path);
        TaskInfo taskInfo = singleConfig.getTaskInfo();
        if (taskInfo != null) {
            taskInfo.setTaskState(DatapushState.RUNNING);
            taskInfo.setMonitorState(DatapushState.RUNNING);
            if (taskInfo.getAuthType() == 3) {
                taskInfo.setPrivateKeyPass(programConfig.getUnifiedKey());
                taskInfo.setPrivateKeyFile(Paths.get(GLOBAL_VARIABLE.rootDir + "/fruits/apples",
                        new String[0]).toString());
            }
            GLOBAL_VARIABLE.taskInfoMap.put(taskInfo.getJobName(), taskInfo);
        }
    }

    /**
     * loadAppConfigFile
     *
     * @param path path
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadAppConfigFile(Path path) {
        try {
            Element root = Util.getDocument(path.toFile()).getRootElement();
            Element dataPush = root.element("DataPush");
            if (dataPush != null) {
                dealJobXml(root, dataPush, 1);
                dealJobXml(root, dataPush, 2);
            }
        } catch (DocumentException | org.xml.sax.SAXException e) {
            log.error("load job app config error:", e);
        }
    }

    /**
     * dealJobXml
     *
     * @param root root
     * @param dataPush dataPush
     * @param jobType int
     * @author z00502253
     * @since 2020-02-14
     */
    public static void dealJobXml(Element root, Element dataPush, int jobType) {
        List<Element> jobs = dataPush.elements((jobType == 1) ? "FilePush" : "DbPush");
        for (Element element : jobs) {
            if (Boolean.parseBoolean(element.attributeValue("enabled"))) {
                AppConfig appConfig = new AppConfig(ENV_FILES, root, element, jobType);
                TaskInfo taskInfo = appConfig.getTaskInfo();
                if (taskInfo != null) {
                    taskInfo.setTaskState(DatapushState.RUNNING);
                    taskInfo.setMonitorState(DatapushState.RUNNING);
                    if (taskInfo.getAuthType() == 3) {
                        taskInfo.setPrivateKeyPass(programConfig.getUnifiedKey());
                        taskInfo.setPrivateKeyFile(
                                Paths.get(GLOBAL_VARIABLE.rootDir + "/fruits/apples", new String[0]).toString());
                    }
                    if (Util.isEmpty(jobName) || (Util.isNotEmpty(jobName) && taskInfo.getJobName().equals(jobName))) {
                        GLOBAL_VARIABLE.taskInfoMap.put(taskInfo.getJobName(), taskInfo);
                    }
                }
            }
        }
    }

    /**
     * formatMsg
     *
     * @param message String
     * @param jobName String
     * @return String
     * @author z00502253
     * @since 2020-06-24
     */
    private static String formatMsg(String message, String jobName) {
        if (Util.isEmpty(message)) {
            return message;
        }
        String tmp = message;
        if (periodObject.getPeriodTime().startsWith("1888")) {

            tmp = tmp.replace("${startTime}", (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"))
                    .format(new Date())).replace("${endTime}",
                    (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date()));
        } else {

            tmp = tmp.replace("${startTime}", periodObject.getStartTime()).replace("${endTime}",
                    periodObject.getEndTime());
        }
        return tmp.replace("${jobName}", jobName)
                .replace("${year}", periodObject.getYear())
                .replace("${month}", periodObject.getMonth())
                .replace("${m_day}", periodObject.getMonth_day())
                .replace("${day}", periodObject.getDay())
                .replace("${hour}", periodObject.getHour())
                .replace("${minute}", periodObject.getMinute())
                .replace("${day_ep}", periodObject.getDayEp())
                .replace("${minute_ep}", periodObject.getMinuteEp())
                .replace("${periodTime}", periodObject.getPeriodTime())
                .replace("${timeName}", periodObject.getTimeName())
                .replace("${node}", GLOBAL_VARIABLE.node)
                .replace("${project_number}", GLOBAL_VARIABLE.programConfig.getProjectNumber())
                .replace("${timezone}", GLOBAL_VARIABLE.programConfig.getTimeZone());
    }
}