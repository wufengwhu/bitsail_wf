/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common.crypt;

import com.huawei.secure.io.InputStreamReaderUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class CryptPropLoad {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CryptPropLoad.class);

    /**
     * The Constant cat.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String cat;

    /**
     * The Constant dog.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String dog;

    /**
     * The Constant duck.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String duck;

    /**
     * The Constant mouse.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String mouse;

    /**
     * The Constant dragon.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String dragon;

    /**
     * The Constant pig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String pig;

    /**
     * getCat
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getCat() {
        if (cat == null) {
            try {
                String workKeyPath = getRootPath() + "conf/properties/cat/cat";
                cat = InputStreamReaderUtils.readBoundedLines(new FileInputStream(workKeyPath),
                        2048L).get(0);
            } catch (FileNotFoundException e) {
                LOGGER.error("cat file not found.");
            } catch (IOException e) {
                LOGGER.error("cat file read failed.");
            }
        }
        return cat;
    }

    /**
     * getDog
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getDog() {
        if (dog == null) {
            try {
                String workKeyPath = getRootPath() + "conf/properties/dog/dog";
                dog = InputStreamReaderUtils.readBoundedLines(new FileInputStream(workKeyPath),
                        2048L).get(0);
            } catch (FileNotFoundException e) {
                LOGGER.error("dog file not found.");
            } catch (IOException e) {
                LOGGER.error("dog file read failed.");
            }
        }
        return dog;
    }

    /**
     * getDuck
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getDuck() {
        if (duck == null) {
            try {
                String workKeyPath = getRootPath() + "conf/properties/duck/duck";
                duck = InputStreamReaderUtils.readBoundedLines(new FileInputStream(workKeyPath),
                        2048L).get(0);
            } catch (FileNotFoundException e) {
                LOGGER.error("duck file not found.");
            } catch (IOException e) {
                LOGGER.error("duck file read failed.");
            }
        }
        return duck;
    }

    /**
     * getMouse
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getMouse() {
        if (mouse == null) {
            try {
                String workKeyPath = getRootPath() + "conf/properties/mouse/mouse";
                mouse = InputStreamReaderUtils.readBoundedLines(new FileInputStream(workKeyPath),
                        2048L).get(0);
            } catch (FileNotFoundException e) {
                LOGGER.error("mouse file not found.");
            } catch (IOException e) {
                LOGGER.error("mouse file read failed.");
            }
        }
        return mouse;
    }

    /**
     * getDragon
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getDragon() {
        if (dragon == null) {
            try {
                String workKeyPath = getRootPath() + "conf/properties/dragon/dragon";
                dragon = InputStreamReaderUtils.readBoundedLines(new FileInputStream(workKeyPath),
                        2048L).get(0);
            } catch (FileNotFoundException e) {
                LOGGER.error("dragon file not found.");
            } catch (IOException e) {
                LOGGER.error("dragon file read failed.");
            }
        }
        return dragon;
    }

    /**
     * getPig
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getPig() {
        if (pig == null) {
            try {
                String workKeyPath = getRootPath() + "conf/properties/pig/pig";
                pig = InputStreamReaderUtils.readBoundedLines(new FileInputStream(workKeyPath),
                        2048L).get(0);
            } catch (FileNotFoundException e) {
                LOGGER.error("pig file not found.");
            } catch (IOException e) {
                LOGGER.error("pig file read failed.");
            }
        }
        return pig;
    }

    /**
     * getRootPath
     *
     * @return String
     * @author z00502253
     * @since 2020-07-01
     */
    private static String getRootPath() {
        return CryptPropLoad.class.getResource("/").getPath();
    }
}