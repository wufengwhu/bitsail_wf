package com.hihonor.cloudservice.datapush.tasks;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class SshCheckThread.
 *
 * @since 2022-04-24
 */
public class SshCheckThread
        implements Runnable {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(SshCheckThread.class);

    /**
     * The Constant taskInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final TaskInfo taskInfo;

    public SshCheckThread(TaskInfo taskInfo) {
        String taskId = taskInfo.getJobName() + "-" + Util.getId();
        taskInfo.setTaskId(taskId);
        this.taskInfo = taskInfo;
    }

    /**
     * run
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void run() {
        log.info("ssh connection check, thread start...");
        Thread.currentThread().setName(this.taskInfo.getJobName() + "_SshCheckThread");
        SshCheckProcess sshCheckProcess = new SshCheckProcess(this.taskInfo);
        try {
            sshCheckProcess.checkSsh();
            this.taskInfo.setTaskState(DatapushState.SUCCESS);
        } catch (DatapushException e) {
            log.error("ssh connection check,jobName=" + this.taskInfo.getJobName()
                    + ",connection error", (Throwable) e);
        } finally {
            sshCheckProcess.putState();
            log.info("ssh connection check, jobName={},sshCheckProcess put state", this.taskInfo.getJobName());
        }
    }
}