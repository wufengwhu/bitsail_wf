package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class DruidConfig {

    /**
     * The Constant type.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String type;

    /**
     * The Constant fetchSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int fetchSize;

    /**
     * The Constant initSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int initSize;

    /**
     * The Constant minIdle.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int minIdle;

    /**
     * The Constant maxWait.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int maxWait;

    /**
     * The Constant timeBetweenEvictionRunsMillis.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int timeBetweenEvictionRunsMillis;

    /**
     * The Constant testWhileIdle.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean testWhileIdle;

    /**
     * The Constant validationQuery.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String validationQuery;

    public void setType(String type) {
        this.type = type;
    }

    /**
     * The Constant validationQueryTimeout.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int validationQueryTimeout;

    /**
     * The Constant minEvictableIdleTimeMillis.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int minEvictableIdleTimeMillis;

    /**
     * The Constant keepAlive.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean keepAlive;

    /**
     * The Constant testOnBorrow.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean testOnBorrow;

    /**
     * The Constant testOnReturn.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean testOnReturn;

    /**
     * The Constant removeAbandoned.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean removeAbandoned;

    /**
     * The Constant removeAbandonedTimeout.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int removeAbandonedTimeout;

    /**
     * The Constant logAbandoned.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean logAbandoned;

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public void setInitSize(int initSize) {
        this.initSize = initSize;
    }

    public void setMinIdle(int minIdle) {
        this.minIdle = minIdle;
    }

    public void setMaxWait(int maxWait) {
        this.maxWait = maxWait;
    }

    public void setTimeBetweenEvictionRunsMillis(int timeBetweenEvictionRunsMillis) {
        this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
    }

    public void setTestWhileIdle(boolean testWhileIdle) {
        this.testWhileIdle = testWhileIdle;
    }

    public void setValidationQuery(String validationQuery) {
        this.validationQuery = validationQuery;
    }

    public void setValidationQueryTimeout(int validationQueryTimeout) {
        this.validationQueryTimeout = validationQueryTimeout;
    }

    public void setMinEvictableIdleTimeMillis(int minEvictableIdleTimeMillis) {
        this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
    }

    public void setKeepAlive(boolean keepAlive) {
        this.keepAlive = keepAlive;
    }

    public void setTestOnBorrow(boolean testOnBorrow) {
        this.testOnBorrow = testOnBorrow;
    }

    public void setTestOnReturn(boolean testOnReturn) {
        this.testOnReturn = testOnReturn;
    }

    public void setRemoveAbandoned(boolean removeAbandoned) {
        this.removeAbandoned = removeAbandoned;
    }

    public void setRemoveAbandonedTimeout(int removeAbandonedTimeout) {
        this.removeAbandonedTimeout = removeAbandonedTimeout;
    }

    public void setLogAbandoned(boolean logAbandoned) {
        this.logAbandoned = logAbandoned;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof DruidConfig)) return false;
        DruidConfig other = (DruidConfig) o;
        if (!other.canEqual(this)) return false;
        Object this$type = getType(), other$type = other.getType();
        if ((this$type == null) ? (other$type != null) : !this$type.equals(other$type)) return false;
        if (getFetchSize() != other.getFetchSize()) return false;
        if (getInitSize() != other.getInitSize()) return false;
        if (getMinIdle() != other.getMinIdle()) return false;
        if (getMaxWait() != other.getMaxWait()) return false;
        if (getTimeBetweenEvictionRunsMillis() != other.getTimeBetweenEvictionRunsMillis()) return false;
        if (isTestWhileIdle() != other.isTestWhileIdle()) return false;
        Object this$validationQuery = getValidationQuery(), other$validationQuery = other.getValidationQuery();
        return ((this$validationQuery == null) ? (other$validationQuery != null) : !this$validationQuery
                .equals(other$validationQuery)) ? false : ((getValidationQueryTimeout()
                != other.getValidationQueryTimeout()) ? false : ((getMinEvictableIdleTimeMillis()
                != other.getMinEvictableIdleTimeMillis()) ? false : ((isKeepAlive() != other.isKeepAlive()) ? false
                : ((isTestOnBorrow() != other.isTestOnBorrow()) ? false : ((isTestOnReturn()
                != other.isTestOnReturn()) ? false : ((isRemoveAbandoned()
                != other.isRemoveAbandoned()) ? false : ((getRemoveAbandonedTimeout()
                != other.getRemoveAbandonedTimeout()) ? false : (!(isLogAbandoned() != other.isLogAbandoned())))))))));
    }

    protected boolean canEqual(Object other) {
        return other instanceof DruidConfig;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $type = getType();
        result = result * 59 + (($type == null) ? 43 : $type.hashCode());
        result = result * 59 + getFetchSize();
        result = result * 59 + getInitSize();
        result = result * 59 + getMinIdle();
        result = result * 59 + getMaxWait();
        result = result * 59 + getTimeBetweenEvictionRunsMillis();
        result = result * 59 + (isTestWhileIdle() ? 79 : 97);
        Object $validationQuery = getValidationQuery();
        result = result * 59 + (($validationQuery == null) ? 43 : $validationQuery.hashCode());
        result = result * 59 + getValidationQueryTimeout();
        result = result * 59 + getMinEvictableIdleTimeMillis();
        result = result * 59 + (isKeepAlive() ? 79 : 97);
        result = result * 59 + (isTestOnBorrow() ? 79 : 97);
        result = result * 59 + (isTestOnReturn() ? 79 : 97);
        result = result * 59 + (isRemoveAbandoned() ? 79 : 97);
        result = result * 59 + getRemoveAbandonedTimeout();
        return result * 59 + (isLogAbandoned() ? 79 : 97);
    }

    public String toString() {
        return "DruidConfig(type=" + getType() + ", fetchSize=" + getFetchSize() + ", initSize=" + getInitSize()
                + ", minIdle=" + getMinIdle() + ", maxWait=" + getMaxWait() + ", timeBetweenEvictionRunsMillis="
                + getTimeBetweenEvictionRunsMillis() + ", testWhileIdle=" + isTestWhileIdle() + ", validationQuery="
                + getValidationQuery() + ", validationQueryTimeout=" + getValidationQueryTimeout()
                + ", minEvictableIdleTimeMillis=" + getMinEvictableIdleTimeMillis() + ", keepAlive=" + isKeepAlive()
                + ", testOnBorrow=" + isTestOnBorrow() + ", testOnReturn=" + isTestOnReturn() + ", removeAbandoned="
                + isRemoveAbandoned() + ", removeAbandonedTimeout=" + getRemoveAbandonedTimeout() + ", logAbandoned="
                + isLogAbandoned() + ")";
    }

    public String getType() {
        return this.type;
    }

    public int getFetchSize() {
        return this.fetchSize;
    }

    public int getInitSize() {
        return this.initSize;
    }

    public int getMinIdle() {
        return this.minIdle;
    }

    public int getMaxWait() {
        return this.maxWait;
    }

    public int getTimeBetweenEvictionRunsMillis() {
        return this.timeBetweenEvictionRunsMillis;
    }

    public boolean isTestWhileIdle() {
        return this.testWhileIdle;
    }

    public String getValidationQuery() {
        return this.validationQuery;
    }

    public int getValidationQueryTimeout() {
        return this.validationQueryTimeout;
    }

    public int getMinEvictableIdleTimeMillis() {
        return this.minEvictableIdleTimeMillis;
    }

    public boolean isKeepAlive() {
        return this.keepAlive;
    }

    public boolean isTestOnBorrow() {
        return this.testOnBorrow;
    }

    public boolean isTestOnReturn() {
        return this.testOnReturn;
    }

    public boolean isRemoveAbandoned() {
        return this.removeAbandoned;
    }

    public int getRemoveAbandonedTimeout() {
        return this.removeAbandonedTimeout;
    }

    public boolean isLogAbandoned() {
        return this.logAbandoned;
    }
}
