package com.hihonor.cloudservice.datapush.exception;

import java.util.Locale;

/**
 * 功能描述
 *
 * @since 2022-05-06
 */
public enum DatapushState {

    FAILED(1,"failed"),

    RUNNING(-1,"running"),

    SUCCESS(0,"success"),

    REPEAT(2020,"task repeat"),

    DISKSPACE_INSUFFICIENT(2021,"insufficient disk space"),

    FILE_PATH_NOT_EXIST(2022,"the source file path does not exist"),

    SQL_ERROR(2023,"sql config error"),

    LZO_NOT_FOUND(2024,"lzop not found,please install it"),

    FILE_EMPTY(2025,"file is empty"),

    FILE_CREATE_EMPTY(2026,"create empty file failed"),

    FILE_QUALITY_NON_COMPLIANCE(2027,"Incompliant file quality ");

    /**
     * The Constant code.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int code;

    /**
     * The Constant detail.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String detail;

    public int getCode() {
        return this.code;
    }

    public String getDetail() {
        return this.detail;
    }

    DatapushState(int code, String detail) {
        this.code = code;
        this.detail = detail;
    }

    /**
     * toString
     *
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public String toString() {
        return String.format(Locale.ENGLISH, "code:%d, message:%s",
                new Object[]{Integer.valueOf(this.code), this.detail});
    }
}