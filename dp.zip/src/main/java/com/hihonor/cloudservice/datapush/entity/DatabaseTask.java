package com.hihonor.cloudservice.datapush.entity;

import java.util.List;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class DatabaseTask {

    /**
     * The Constant dbSources.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<DbSource> dbSources;

    /**
     * The Constant sql.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String sql;

    /**
     * The Constant filedSep.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String filedSep;

    /**
     * The Constant replaceSource.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String replaceSource;

    /**
     * The Constant replaceTarget.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String replaceTarget;

    public void setDbSources(List<DbSource> dbSources) {
        this.dbSources = dbSources;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public void setFiledSep(String filedSep) {
        this.filedSep = filedSep;
    }

    public void setReplaceSource(String replaceSource) {
        this.replaceSource = replaceSource;
    }

    public void setReplaceTarget(String replaceTarget) {
        this.replaceTarget = replaceTarget;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof DatabaseTask)) return false;
        DatabaseTask other = (DatabaseTask) o;
        if (!other.canEqual(this)) return false;
        List<DbSource> this$dbSources = (List<DbSource>) getDbSources(),
                other$dbSources = (List<DbSource>) other.getDbSources();
        if ((this$dbSources == null) ? (other$dbSources != null) : !this$dbSources.equals(other$dbSources))
            return false;
        Object this$sql = getSql(), other$sql = other.getSql();
        if ((this$sql == null) ? (other$sql != null) : !this$sql.equals(other$sql)) return false;
        Object this$filedSep = getFiledSep(), other$filedSep = other.getFiledSep();
        if ((this$filedSep == null) ? (other$filedSep != null) : !this$filedSep.equals(other$filedSep)) return false;
        Object this$replaceSource = getReplaceSource(), other$replaceSource = other.getReplaceSource();
        if ((this$replaceSource == null) ? (other$replaceSource != null) : !this$replaceSource
                .equals(other$replaceSource))
            return false;
        Object this$replaceTarget = getReplaceTarget(), other$replaceTarget = other.getReplaceTarget();
        return !((this$replaceTarget == null) ? (other$replaceTarget != null) : !this$replaceTarget
                .equals(other$replaceTarget));
    }

    protected boolean canEqual(Object other) {
        return other instanceof DatabaseTask;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        List<DbSource> $dbSources = (List<DbSource>) getDbSources();
        result = result * 59 + (($dbSources == null) ? 43 : $dbSources.hashCode());
        Object $sql = getSql();
        result = result * 59 + (($sql == null) ? 43 : $sql.hashCode());
        Object $filedSep = getFiledSep();
        result = result * 59 + (($filedSep == null) ? 43 : $filedSep.hashCode());
        Object $replaceSource = getReplaceSource();
        result = result * 59 + (($replaceSource == null) ? 43 : $replaceSource.hashCode());
        Object $replaceTarget = getReplaceTarget();
        return result * 59 + (($replaceTarget == null) ? 43 : $replaceTarget.hashCode());
    }

    public String toString() {
        return "DatabaseTask(dbSources=" + getDbSources() + ", sql=" + getSql() + ", filedSep="
                + getFiledSep() + ", replaceSource=" + getReplaceSource() + ", replaceTarget="
                + getReplaceTarget() + ")";
    }

    public List<DbSource> getDbSources() {
        return this.dbSources;
    }

    public String getSql() {
        return this.sql;
    }

    public String getFiledSep() {
        return this.filedSep;
    }

    public String getReplaceSource() {
        return this.replaceSource;
    }

    public String getReplaceTarget() {
        return this.replaceTarget;
    }
}