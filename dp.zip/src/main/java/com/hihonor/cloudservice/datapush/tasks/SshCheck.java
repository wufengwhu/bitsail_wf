package com.hihonor.cloudservice.datapush.tasks;

import com.alibaba.fastjson.JSON;
import com.hihonor.cloudservice.datapush.common.FindFileUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.config.AppConfig;
import com.hihonor.cloudservice.datapush.config.SingleConfig;
import com.hihonor.cloudservice.datapush.entity.DamConfig;
import com.hihonor.cloudservice.datapush.entity.ProgramConfig;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;
import com.hihonor.cloudservice.datapush.GlobalVariable;


import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class SshCheck.
 *
 * @since 2022-04-24
 */
public class SshCheck {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(SshCheck.class);

    /**
     * The Constant programConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static ProgramConfig programConfig;

    /**
     * The Constant damConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static DamConfig damConfig;

    /**
     * The Constant GLOBAL_VARIABLE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final GlobalVariable GLOBAL_VARIABLE = GlobalVariable.getInstance();

    /**
     * The Constant ENV_FILES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final ArrayList<Path> ENV_FILES = new ArrayList<>();

    /**
     * The Constant APP_FILES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final ArrayList<Path> APP_FILES = new ArrayList<>();

    /**
     * The Constant SINGLE_FILES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final ArrayList<Path> SINGLE_FILES = new ArrayList<>();

    /**
     * The Constant tasksPool.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static ThreadPoolExecutor tasksPool;

    /**
     * The Constant host.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String host;

    public String getHost() {
        return this.host;
    }

    /**
     * loadConfig
     *
     * @param jobNames List<String>
     * @author z00502253
     * @since 2022-08-15
     */
    private static void loadConfig(List<String> jobNames) throws IOException, DatapushException {
        Properties sysPro = new Properties();
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(new String[]{GLOBAL_VARIABLE.rootDir
                + "/conf/datapush.properties"}))) {
            sysPro.load(in);
        }
        initConfig(sysPro);
        log.debug("ssh check,{}", programConfig);
        GLOBAL_VARIABLE.programConfig = programConfig;
        GLOBAL_VARIABLE.damConfig = damConfig;
        initTaskFiles(new String[]{"sin", "ide_env", "env", "ide_app", "app"});
        log.debug("ssh check,env config files = {}", ENV_FILES);
        log.debug("ssh check,app config files = {}", APP_FILES);
        log.debug("ssh check,single config files = {}", SINGLE_FILES);
        for (Path single : SINGLE_FILES) {
            loadSingleConfigFile(single);
        }
        for (Path app : APP_FILES) {
            loadAppConfigFile(app);
        }
        if (jobNames.size() > 0 && GLOBAL_VARIABLE.taskInfoMap.size() > 0) {
            for (Iterator<Map.Entry<String, TaskInfo>> it = GLOBAL_VARIABLE.taskInfoMap
                    .entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<String, TaskInfo> entry = it.next();
                for (String jobName : jobNames) {
                    if (!jobName.equals(entry.getKey())) {
                        GLOBAL_VARIABLE.taskInfoMap.remove(entry.getKey());
                    }
                }
            }
        }
    }

    /**
     * loadSingleConfigFile
     *
     * @param path path
     * @author z00502253
     * @since 2022-08-15
     */
    private static void loadSingleConfigFile(Path path) {
        SingleConfig singleConfig = new SingleConfig(path);
        TaskInfo taskInfo = singleConfig.getTaskInfo();
        if (taskInfo != null && taskInfo.getAuthType() == 3) {
            taskInfo.setTaskState(DatapushState.RUNNING);
            taskInfo.setMonitorState(DatapushState.RUNNING);
            taskInfo.setPrivateKeyFile(Paths.get(GLOBAL_VARIABLE.rootDir + "/fruits/apricots",
                    new String[0]).toString());
            GLOBAL_VARIABLE.taskInfoMap.put(taskInfo.getJobName(), taskInfo);
        }
    }

    /**
     * loadAppConfigFile
     *
     * @param path path
     * @author z00502253
     * @since 2022-08-15
     */
    private static void loadAppConfigFile(Path path) {
        try {
            Element root = Util.getDocument(path.toFile()).getRootElement();
            Element dataPush = root.element("DataPush");
            if (dataPush != null) {
                dealJobXml(root, dataPush, 2);
                dealJobXml(root, dataPush, 1);
            }
        } catch (DocumentException | org.xml.sax.SAXException e) {
            log.error("ssh connection check, load job app config error:", e);
        }
    }

    /**
     * dealJobXml
     *
     * @param root root
     * @param dataPush dataPush
     * @param jobType int
     * @author z00502253
     * @since 2022-08-15
     */
    private static void dealJobXml(Element root, Element dataPush, int jobType) {
        List<Element> jobs = dataPush.elements((jobType == 2) ? "DbPush" : "FilePush");
        for (Element element : jobs) {
            if (Boolean.parseBoolean(element.attributeValue("enabled"))) {
                AppConfig appConfig = new AppConfig(ENV_FILES, root, element, jobType);
                TaskInfo taskInfo = appConfig.getTaskInfo();
                if (taskInfo != null && taskInfo.getAuthType() == 3) {
                    taskInfo.setMonitorState(DatapushState.RUNNING);
                    taskInfo.setTaskState(DatapushState.RUNNING);
                    taskInfo.setPrivateKeyFile(Paths.get(GLOBAL_VARIABLE.rootDir + "/fruits/apricots",
                            new String[0]).toString());
                    GLOBAL_VARIABLE.taskInfoMap.put(taskInfo.getJobName(), taskInfo);
                }
            }
        }
    }

    /**
     * initConfig
     *
     * @param sysPro sysPro
     * @author z00502253
     * @since 2022-08-15
     */
    private static void initConfig(Properties sysPro) throws DatapushException {
        try {
            Element root = Util.getDocument(FileUtils.getFile(new String[]{GLOBAL_VARIABLE.rootDir
                    + "/conf/IDE_EnvConf.xml"})).getRootElement();
            GLOBAL_VARIABLE.node = root.elementTextTrim("Node");
            GLOBAL_VARIABLE.version = root.elementTextTrim("Version");
            if (!Util.checkIp(GLOBAL_VARIABLE.node) || Util.isEmpty(GLOBAL_VARIABLE.version)) {
                throw new DatapushException("IDE_EnvConf config file error");
            }
            log.info(
                    String.format(Locale.ENGLISH, "node={%s},version={%s}",
                            new Object[]{GLOBAL_VARIABLE.node, GLOBAL_VARIABLE.version}));
        } catch (DocumentException | org.xml.sax.SAXException | DatapushException e) {
            throw new DatapushException("IDE_EnvConf config file error", e);
        }
        programConfig.setMaxTasksPool(Util.getInt(sysPro.getProperty("program.main.threads.max"), 3));
        programConfig.setMaxSubTaskPool(Util.getInt(sysPro.getProperty("program.sub.threads.max"), 3));
        programConfig.setConfigDir(Arrays.asList(sysPro.getProperty("program.config.path",
                "/").split(",")));
        programConfig.setMaxChannels(Util.getInt(sysPro.getProperty("program.channels.max"), 4));
        programConfig.setRunTimeOut(Util.getInt(sysPro.getProperty("program.run.timeout"), 150));
        programConfig.setQueueSize(Util.getInt(sysPro.getProperty("program.pool.queue.size"), 5000));
        programConfig.setSshPort(Util.getInt(sysPro.getProperty("ssh.port"), 30022));

        damConfig = new DamConfig();
        damConfig.setOpen(Boolean.parseBoolean(sysPro.getProperty("da.open", "true")));
        if (damConfig.isOpen()) {
            damConfig.setUrl(sysPro.getProperty("da.url"));
            damConfig.setSignKey(CryptService.decryptAes(sysPro.getProperty("da.sign")));
            damConfig.setWorkKey(sysPro.getProperty("da.work"));
            damConfig.setName(sysPro.getProperty("da.server.name", ""));
            damConfig.setTimeOut(Util.getInt(sysPro.getProperty("da.request.timeout"), 300));
            damConfig.setWaitTime(Util.getInt(sysPro.getProperty("da.request.waittime"), 3000));
        }
    }

    /**
     * initTaskFiles
     *
     * @param machs String[]
     * @author z00502253
     * @since 2022-08-15
     */
    private static void initTaskFiles(String[] machs) throws IOException {
        for (String match : machs) {
            for (String path : programConfig.getConfigDir()) {
                if (!path.endsWith("/")) {
                    path = path + "/";
                }
                if (match.equals("env")) {
                    ENV_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path,
                            new String[0]), "EnvConf.xml"));
                }
                if (match.equals("ide_env")) {
                    ENV_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path,
                            new String[0]), "IDE_EnvConf.xml"));
                }
                if (match.equals("app")) {
                    APP_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path,
                            new String[0]), "AppConf.xml"));
                }
                if (match.equals("ide_app")) {
                    APP_FILES.addAll((new FindFileUtil(1)).getFileByEndName(Paths.get(path,
                            new String[0]), "IDE_AppConf.xml"));
                }
                if (match.equals("sin")) {
                    SINGLE_FILES.addAll((new FindFileUtil(1)).getFileByRegex(Paths.get(path,
                            new String[0]), ".*_config\\.xml$"));
                }
            }
        }
    }

    /**
     * start
     *
     * @param sshPassword String
     * @param jobNames List
     * @return boolean
     * @author z00502253
     * @since 2022-06-28
     */
    public static boolean start(String sshPassword, List<String> jobNames) {
        boolean isSuccess = true;
        try {
            Thread.currentThread().setName("SshCheck");
            GLOBAL_VARIABLE.rootDir = Paths.get(System.getProperty("user.dir"), new String[0]).toString();
            programConfig = new ProgramConfig();
            loadConfig(jobNames);
            log.info("ssh connection check,Tasks = {}", GLOBAL_VARIABLE.taskInfoMap.keySet());
            if (GLOBAL_VARIABLE.taskInfoMap.size() > 0) {


                tasksPool = new ThreadPoolExecutor(GLOBAL_VARIABLE.programConfig.getMaxTasksPool() + 1,
                        GLOBAL_VARIABLE.programConfig.getMaxTasksPool() + 1, 0L,
                        TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(GLOBAL_VARIABLE.programConfig.getQueueSize()));
                Future<Boolean> monitor = tasksPool.submit(new TaskMonitor(2));
                for (TaskInfo taskInfo : GLOBAL_VARIABLE.taskInfoMap.values()) {
                    log.info("config jobName={}", taskInfo.getJobName());
                    log.info("param jobNames={}", JSON.toJSONString(jobNames));
                    if (taskInfo.getAuthType() == 3) {
                        taskInfo.setPrivateKeyPass(CryptService.decryptAes(sshPassword));
                        tasksPool.submit(new SshCheckThread(taskInfo));
                    }
                }
                try {
                    isSuccess = ((Boolean) monitor.get(GLOBAL_VARIABLE.programConfig.getRunTimeOut(),
                            TimeUnit.MINUTES)).booleanValue();
                } catch (InterruptedException | java.util.concurrent.ExecutionException
                        | java.util.concurrent.TimeoutException e) {
                    throw new DatapushException(e);
                }
            }
        } catch (IOException | DatapushException exception) {
            log.error("ssh connection check error", exception);
            isSuccess = false;
        } finally {
            if (tasksPool != null) {
                tasksPool.shutdown();
            }
        }
        return isSuccess;
    }
}