/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common.crypt;

import com.huawei.secure.crypto.rootkey.RootKeyCryptUtil;
import com.huawei.secure.crypto.rootkey.RootKeyUtil;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class RootKey {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(RootKey.class);

    /**
     * The Constant rootKeyUtil.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static volatile RootKeyUtil rootKeyUtil;

    /**
     * getRootKeyUtil
     *
     * @return static
     * @author z00502253
     * @since 2020-02-14
     */
    public static RootKeyUtil getRootKeyUtil() {
        if (rootKeyUtil == null) {
            synchronized (RootKey.class) {
                if (rootKeyUtil == null) {
                    try {
                        return rootKeyUtil = RootKeyUtil.newInstance256(CryptPropLoad.getCat(), CryptPropLoad.getDog(),
                                CryptPropLoad.getDuck(), CryptPropLoad.getMouse());
                    } catch (IOException e) {
                        LOGGER.error("rootkey create failed.");
                    }
                }
            }
        }
        return rootKeyUtil;
    }

    /**
     * getOldRootKeyUtil
     *
     * @author z00502253
     * @since 2020-02-14
     */
    public static void getOldRootKeyUtil() {
        try {
            RootKeyCryptUtil.getRootKey(CryptPropLoad.getCat(), CryptPropLoad.getDog(),
                    CryptPropLoad.getDuck(), CryptPropLoad.getMouse());
        } catch (Exception e) {
            LOGGER.error("rootkey create failed.");
        }
    }
}