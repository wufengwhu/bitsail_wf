package com.hihonor.cloudservice.datapush.common;

import java.util.concurrent.ThreadFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class ThreadFactoryUtil
        implements ThreadFactory {

    /**
     * The Constant counter.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int counter;

    /**
     * The Constant name.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String name;

    public ThreadFactoryUtil(String name) {
        this.counter = 0;
        this.name = name;
    }

    /**
     * newThread
     *
     * @param runnable runnable
     * @return Thread
     * @author z00502253
     * @since 2020-02-16
     */
    public Thread newThread(Runnable runnable) {
        this.counter++;
        return new Thread(runnable, this.name + "-" + this.counter);
    }
}
