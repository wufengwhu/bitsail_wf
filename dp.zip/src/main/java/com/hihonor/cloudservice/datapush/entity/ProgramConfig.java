package com.hihonor.cloudservice.datapush.entity;

import java.util.List;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class ProgramConfig {

    /**
     * The Constant configDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> configDir;

    /**
     * The Constant maxTasksPool.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int maxTasksPool;

    /**
     * The Constant maxSubTaskPool.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int maxSubTaskPool;

    /**
     * The Constant maxChannels.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int maxChannels;

    /**
     * The Constant runTimeOut.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int runTimeOut;

    /**
     * The Constant queueSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int queueSize;

    /**
     * The Constant sshPort.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int sshPort;

    public void setConfigDir(List<String> configDir) {
        this.configDir = configDir;
    }

    /**
     * The Constant openPeriodDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean openPeriodDir;

    /**
     * The Constant createEmptyFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean createEmptyFile;

    /**
     * The Constant logClearTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int logClearTime;

    /**
     * The Constant unifiedKey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String unifiedKey;

    /**
     * The Constant zipKey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String zipKey;

    /**
     * The Constant projectNumber.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String projectNumber;

    /**
     * The Constant timeZone.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String timeZone;

    public void setMaxTasksPool(int maxTasksPool) {
        this.maxTasksPool = maxTasksPool;
    }

    public void setMaxSubTaskPool(int maxSubTaskPool) {
        this.maxSubTaskPool = maxSubTaskPool;
    }

    public void setMaxChannels(int maxChannels) {
        this.maxChannels = maxChannels;
    }

    public void setRunTimeOut(int runTimeOut) {
        this.runTimeOut = runTimeOut;
    }

    public void setQueueSize(int queueSize) {
        this.queueSize = queueSize;
    }

    public void setSshPort(int sshPort) {
        this.sshPort = sshPort;
    }

    public void setOpenPeriodDir(boolean openPeriodDir) {
        this.openPeriodDir = openPeriodDir;
    }

    public void setCreateEmptyFile(boolean createEmptyFile) {
        this.createEmptyFile = createEmptyFile;
    }

    public void setLogClearTime(int logClearTime) {
        this.logClearTime = logClearTime;
    }

    public void setUnifiedKey(String unifiedKey) {
        this.unifiedKey = unifiedKey;
    }

    public void setZipKey(String zipKey) {
        this.zipKey = zipKey;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof ProgramConfig)) return false;
        ProgramConfig other = (ProgramConfig) o;
        if (!other.canEqual(this)) return false;
        List<String> this$configDir = (List<String>) getConfigDir(), other$configDir
                = (List<String>) other.getConfigDir();
        if ((this$configDir == null) ? (other$configDir != null) : !this$configDir.equals(other$configDir))
            return false;
        if (getMaxTasksPool() != other.getMaxTasksPool()) return false;
        if (getMaxSubTaskPool() != other.getMaxSubTaskPool()) return false;
        if (getMaxChannels() != other.getMaxChannels()) return false;
        if (getRunTimeOut() != other.getRunTimeOut()) return false;
        if (getQueueSize() != other.getQueueSize()) return false;
        if (getSshPort() != other.getSshPort()) return false;
        if (isOpenPeriodDir() != other.isOpenPeriodDir()) return false;
        if (isCreateEmptyFile() != other.isCreateEmptyFile()) return false;
        if (getLogClearTime() != other.getLogClearTime()) return false;
        Object this$unifiedKey = getUnifiedKey(), other$unifiedKey = other.getUnifiedKey();
        if ((this$unifiedKey == null) ? (other$unifiedKey != null) : !this$unifiedKey.equals(other$unifiedKey))
            return false;
        Object this$zipKey = getZipKey(), other$zipKey = other.getZipKey();
        if ((this$zipKey == null) ? (other$zipKey != null) : !this$zipKey.equals(other$zipKey)) return false;
        Object this$projectNumber = getProjectNumber(), other$projectNumber = other.getProjectNumber();
        if ((this$projectNumber == null) ? (other$projectNumber != null)
                : !this$projectNumber.equals(other$projectNumber))
            return false;
        Object this$timeZone = getTimeZone(), other$timeZone = other.getTimeZone();
        return !((this$timeZone == null) ? (other$timeZone != null) : !this$timeZone.equals(other$timeZone));
    }

    protected boolean canEqual(Object other) {
        return other instanceof ProgramConfig;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        List<String> $configDir = (List<String>) getConfigDir();
        result = result * 59 + (($configDir == null) ? 43 : $configDir.hashCode());
        result = result * 59 + getMaxTasksPool();
        result = result * 59 + getMaxSubTaskPool();
        result = result * 59 + getMaxChannels();
        result = result * 59 + getRunTimeOut();
        result = result * 59 + getQueueSize();
        result = result * 59 + getSshPort();
        result = result * 59 + (isOpenPeriodDir() ? 79 : 97);
        result = result * 59 + (isCreateEmptyFile() ? 79 : 97);
        result = result * 59 + getLogClearTime();
        Object $unifiedKey = getUnifiedKey();
        result = result * 59 + (($unifiedKey == null) ? 43 : $unifiedKey.hashCode());
        Object $zipKey = getZipKey();
        result = result * 59 + (($zipKey == null) ? 43 : $zipKey.hashCode());
        Object $projectNumber = getProjectNumber();
        result = result * 59 + (($projectNumber == null) ? 43 : $projectNumber.hashCode());
        Object $timeZone = getTimeZone();
        return result * 59 + (($timeZone == null) ? 43 : $timeZone.hashCode());
    }

    public String toString() {
        return "ProgramConfig(configDir=" + getConfigDir() + ", maxTasksPool=" + getMaxTasksPool()
                + ", maxSubTaskPool=" + getMaxSubTaskPool() + ", maxChannels=" + getMaxChannels()
                + ", runTimeOut=" + getRunTimeOut() + ", queueSize=" + getQueueSize() + ", sshPort="
                + getSshPort() + ", openPeriodDir=" + isOpenPeriodDir() + ", createEmptyFile="
                + isCreateEmptyFile() + ", logClearTime=" + getLogClearTime() + ", unifiedKey="
                + getUnifiedKey() + ", zipKey=" + getZipKey() + ", projectNumber=" + getProjectNumber()
                + ", timeZone=" + getTimeZone() + ")";
    }

    public List<String> getConfigDir() {
        return this.configDir;
    }

    public int getMaxTasksPool() {
        return this.maxTasksPool;
    }

    public int getMaxSubTaskPool() {
        return this.maxSubTaskPool;
    }

    public int getMaxChannels() {
        return this.maxChannels;
    }

    public int getRunTimeOut() {
        return this.runTimeOut;
    }

    public int getQueueSize() {
        return this.queueSize;
    }

    public int getSshPort() {
        return this.sshPort;
    }

    public boolean isOpenPeriodDir() {
        return this.openPeriodDir;
    }

    public boolean isCreateEmptyFile() {
        return this.createEmptyFile;
    }

    public int getLogClearTime() {
        return this.logClearTime;
    }

    public String getUnifiedKey() {
        return this.unifiedKey;
    }

    public String getZipKey() {
        return this.zipKey;
    }

    public String getProjectNumber() {
        return this.projectNumber;
    }

    public String getTimeZone() {
        return this.timeZone;
    }
}