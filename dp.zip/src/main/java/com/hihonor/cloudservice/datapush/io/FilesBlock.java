package com.hihonor.cloudservice.datapush.io;

import java.util.Arrays;

/**
 * 功能描述
 *
 * @since 2022-05-05
 */
public class FilesBlock {

    /**
     * The Constant dataType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int dataType;

    /**
     * The Constant endTag.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean endTag;

    /**
     * The Constant dataLine.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String dataLine;

    /**
     * The Constant dataBytes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private byte[] dataBytes;

    public void setDataType(int dataType) {
        this.dataType = dataType;
    }

    public void setEndTag(boolean endTag) {
        this.endTag = endTag;
    }

    public void setDataLine(String dataLine) {
        this.dataLine = dataLine;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-24
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof FilesBlock)) return false;
        FilesBlock other = (FilesBlock) o;
        if (!other.canEqual(this)) return false;
        if (getDataType() != other.getDataType()) return false;
        if (isEndTag() != other.isEndTag()) return false;
        Object this$dataLine = getDataLine(), other$dataLine = other.getDataLine();
        return ((this$dataLine == null) ? (other$dataLine != null) : !this$dataLine.equals(other$dataLine))
                ? false : (!!Arrays.equals(getDataBytes(), other.getDataBytes()));
    }

    /**
     * canEqual
     *
     * @param other Object
     * @return boolean
     * @author z00502253
     * @since 2022-08-15
     */
    protected boolean canEqual(Object other) {
        return other instanceof FilesBlock;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-24
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + getDataType();
        result = result * 59 + (isEndTag() ? 79 : 97);
        Object $dataLine = getDataLine();
        result = result * 59 + (($dataLine == null) ? 43 : $dataLine.hashCode());
        return result * 59 + Arrays.hashCode(getDataBytes());
    }

    public String toString() {
        return "FilesBlock(dataType=" + getDataType() + ", endTag=" + isEndTag() + ", dataLine=" + getDataLine()
                + ", dataBytes=" + Arrays.toString(getDataBytes()) + ")";
    }

    public int getDataType() {
        return this.dataType;
    }

    public boolean isEndTag() {
        return this.endTag;
    }

    public String getDataLine() {
        return this.dataLine;
    }

    /**
     * getDataBytes
     *
     * @return byte
     * @author z00502253
     * @since 2022-07-01
     */
    public byte[] getDataBytes() {
        if (this.dataBytes != null) {
            return (byte[]) this.dataBytes.clone();
        }
        return new byte[0];
    }

    /**
     * setDataBytes
     *
     * @param dataBytes byte[]
     * @author z00502253
     * @since 2022-07-01
     */
    public void setDataBytes(byte[] dataBytes) {
        if (dataBytes != null) {
            this.dataBytes = (byte[]) dataBytes.clone();
        } else {
            this.dataBytes = null;
        }
    }
}