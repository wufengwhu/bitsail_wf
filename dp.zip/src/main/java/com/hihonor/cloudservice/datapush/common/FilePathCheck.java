/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import com.hihonor.cloudservice.datapush.exception.DatapushException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class FilePathCheck {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FilePathCheck.class);

    /**
     * The Constant PATTERN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Pattern PATTERN
            = Pattern.compile("(.*([/\\\\]{1}[\\\\]{1,2}|[\\\\]{1,2}[/\\\\]{1}|\\\\).*|\\.)");

    /**
     * The Constant PATH_WHITE_LIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String PATH_WHITE_LIST
            = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-=[];\\',./ ~!@#$%^&*()_+\"{}|:<>?";

    /**
     * isSafePath
     *
     * @param filePath String
     * @return boolean
     * @author z00502253
     * @since 2020-02-14
     */
    public static boolean isSafePath(String filePath) {
        Matcher matcher = PATTERN.matcher(filePath);
        boolean isSafe = !matcher.matches();
        return isSafe;
    }

    /**
     * checkFile
     *
     * @param filePath String
     * @return String
     * @author z00502253
     * @since 2020-07-01
     */
    private static String checkFile(String filePath) {
        if (filePath == null) {
            return null;
        }
        StringBuffer tmpStrBuf = new StringBuffer();
        for (int i = 0; i < filePath.length(); i++) {
            for (int j = 0; j < "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-=[];\\',./ ~!@#$%^&*()_+\"{}|:<>?".length(); j++) {
                if (filePath.charAt(i) == "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-=[];\\',./ ~!@#$%^&*()_+\"{}|:<>?".charAt(j)) {
                    tmpStrBuf.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-=[];\\',./ ~!@#$%^&*()_+\"{}|:<>?".charAt(j));
                    break;
                }
            }
        }
        return tmpStrBuf.toString();
    }

    /**
     * checkFilePath
     *
     * @param attributeFile String
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String checkFilePath(String attributeFile) {
        String path = null;
        if (isSafePath(attributeFile)) {
            path = checkFile(attributeFile);
        } else {
            throw new DatapushException("Invalid file path");
        }
        return path;
    }
}