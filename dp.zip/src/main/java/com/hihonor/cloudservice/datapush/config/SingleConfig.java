package com.hihonor.cloudservice.datapush.config;

import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.common.Util;

import com.hihonor.cloudservice.datapush.entity.DatabaseTask;
import com.hihonor.cloudservice.datapush.entity.DbSource;
import com.hihonor.cloudservice.datapush.entity.FileSource;
import com.hihonor.cloudservice.datapush.entity.FilesTask;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class SingleConfig {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(SingleConfig.class);

    /**
     * The Constant singleFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Path singleFile;

    /**
     * The Constant root.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Element root;

    /**
     * The Constant taskInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private TaskInfo taskInfo;

    public SingleConfig(Path singleFile) {
        this.singleFile = singleFile;
    }

    /**
     * getTaskInfo
     *
     * @return vo
     * @author z00502253
     * @since 2020-02-18
     */
    public TaskInfo getTaskInfo() {
        this.taskInfo = new TaskInfo();
        this.taskInfo.setUsedHosts(new ArrayList());
        try {
            this.root = Util.getDocument(this.singleFile.toFile()).getRootElement();
            this.taskInfo.setJobName(this.root.attributeValue("jobName"));
            this.taskInfo.setTaskType(this.root.attributeValue("jobType"));
            if (!this.taskInfo.getTaskType().equals("file") && !this.taskInfo.getTaskType().equals("db")) {
                return null;
            }
            this.taskInfo.setEnable(Boolean.parseBoolean(this.root.attributeValue("enabled")));
            if (!this.taskInfo.isEnable()) {
                return null;
            }
            this.taskInfo.setCheckMode(this.root.elementTextTrim("FileNumCheckMode"));
            this.taskInfo.setDestFileName(this.root.elementTextTrim("DestFileName"));
            this.taskInfo.setPeriodType(this.root.elementTextTrim("PeriodType"));
            this.taskInfo.setAlarm(Boolean.parseBoolean(this.root.elementTextTrim("EnabledAlarm")));
            this.taskInfo.setAlarmLevel(this.root.elementTextTrim("AlarmLevel"));
            this.taskInfo.setAlarmScope(this.root.elementTextTrim("AlarmScope"));
            this.taskInfo.setSendFileMaxThreads(Util.getInt(this.root.elementTextTrim("SendThreadCount"),
                    3));
            this.taskInfo.setCompressMaxThreads(Util.getInt(this.root.elementTextTrim("CompressThreadCount"),
                    3));
            int limitBand = Util.getInt(this.root.elementTextTrim("LimitBand"), 0);
            this.taskInfo.setLimitBand((limitBand < 0) ? 0 : limitBand);
            Element destFileFormat = this.root.element("DestFileFormat");
            if (destFileFormat != null) {
                this.taskInfo.setFieldSep(Util.replaceFieldSep(destFileFormat.elementText("FieldSeparator")));
                this.taskInfo.setLineSep(Util.replaceLineSep(destFileFormat.elementText("LineSeparator")));
            }
            loadTransport();
            switch (this.taskInfo.getTaskType()) {
                case "file":
                    loadFile();
                    return this.taskInfo;
                case "db":
                    loadDatabase();
                    return this.taskInfo;
            }
            return null;
        } catch (DocumentException | org.xml.sax.SAXException | DatapushException e) {
            log.error("", e);
        }
        return this.taskInfo;
    }

    /**
     * loadTransport
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void loadTransport() throws DatapushException {
        Element transportService = this.root.element("TransportService");
        if (transportService != null) {
            this.taskInfo = JobConfig.parsingTransportService(this.taskInfo, transportService);
        }
        Element transportConf = this.root.element("TransportConf");
        if (transportConf != null) {
            this.taskInfo = JobConfig.parsingTransportConf(this.taskInfo, transportConf);
        }
    }

    /**
     * loadFile
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void loadFile() {
        this.taskInfo.setOnlyTrans(Boolean.parseBoolean(this.root.attributeValue("isOnlyTrans")));
        this.taskInfo.setOnlyTransISRename(Boolean.parseBoolean(this.root.attributeValue("ifOnlyTransISRename")));
        if (this.taskInfo.isOnlyTrans()) {
            this.taskInfo.setTaskType("only");
        }
        Element file = this.root.element("File");
        if (file != null) {
            FilesTask filesTask = new FilesTask();
            filesTask.setFetchMode(Util.getInt(file.elementTextTrim("FileFetchMode"), 3));
            filesTask.setSourcePolicy(Util.getInt(file.elementTextTrim("FileSourcePolicy"), 1));
            filesTask.setCheckFileCount(Util.getInt(file.elementTextTrim("FileCountThreshold"), 0));
            filesTask.setCheckFileSize(Util.getInt(file.elementTextTrim("FileSizeThreshold"), 0));
            int fileRetryTimes = Util.getInt(file.elementTextTrim("FileRetryTimes"), 3);
            fileRetryTimes = (fileRetryTimes > 0) ? fileRetryTimes : 1;
            filesTask.setCheckTimes(fileRetryTimes);
            filesTask.setCheckWaitTimes(Util.getInt(file.elementTextTrim("FileWaitTime"), 0) * 60 * 1000);
            List<Element> fsList = file.elements("FileSource");
            List<FileSource> fileSources = new ArrayList<>();
            for (Element fl : fsList) {
                FileSource fileSource = new FileSource();
                log.info("fileSource.Directory={}", fl.elementTextTrim("Directory"));
                fileSource.setDirectory(fl.elementTextTrim("Directory"));
                fileSource.setChildDirRegex(fl.elementTextTrim("ChildDirRegex"));
                fileSource.setFileDepth(Util.getInt(fl.elementTextTrim("FileDepth"), 1));
                fileSources.add(fileSource);
            }
            filesTask.setFileSources(fileSources);
            filesTask.setFilesMask(Arrays.asList(file.elementTextTrim("FileMask").split("\\|")));
            this.taskInfo.setFilesTask(filesTask);
        }
    }

    /**
     * loadDatabase
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void loadDatabase() throws DatapushException {
        Element db = this.root.element("DataBase");
        if (db != null) {
            DatabaseTask databaseTask = new DatabaseTask();
            databaseTask.setReplaceSource(db.attributeValue("replaceSource"));
            databaseTask.setReplaceTarget(db.attributeValue("replaceTarget"));
            databaseTask.setFiledSep(Util.replaceFieldSep(db.elementText("Separator")));
            databaseTask.setSql(db.elementTextTrim("ExtractSql"));
            List<Element> sources = db.elements("DBSource");
            List<DbSource> dbSources = new ArrayList<>();
            for (Element source : sources) {
                DbSource dbSource = new DbSource();
                dbSource.setType(source.elementTextTrim("Type"));
                dbSource.setHost(source.elementTextTrim("Host"));
                dbSource.setPort(Util.getInt(source.elementTextTrim("Port"), 3306));
                dbSource.setDataName(source.elementText("Database"));
                dbSource.setPassword(CryptService.decryptAes(source.elementText("Password")));
                dbSource.setUser(source.elementText("Username"));
                dbSource.setExtendParams(source.elementText("AdditionalInfo"));
                dbSource.setSql(source.elementTextTrim("Sql"));
                dbSources.add(dbSource);
            }
            databaseTask.setDbSources(dbSources);
            this.taskInfo.setDatabaseTask(databaseTask);
        }
    }
}