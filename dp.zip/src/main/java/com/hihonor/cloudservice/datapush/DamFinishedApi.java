package com.hihonor.cloudservice.datapush;

import com.hihonor.cloudservice.datapush.common.FindFileUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.config.SingleConfig;
import com.hihonor.cloudservice.datapush.entity.DamConfig;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.tasks.DamController;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class DamFinishedApi {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(DamFinishedApi.class);

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String jobName;

    /**
     * The Constant periodTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String periodTime;

    /**
     * The Constant status.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static int status;

    /**
     * The Constant statusDes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String statusDes;

    /**
     * The Constant damConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static DamConfig damConfig;

    /**
     * The Constant configDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static List<String> configDir;

    /**
     * The Constant taskInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static TaskInfo taskInfo;

    /**
     * loadParams
     *
     * @param args args
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadParams(String[] args) throws DatapushException {
        for (String param : args) {
            String[] params = param.split("=");
            if (params.length == 2) {
                String key = params[0];
                String value = params[1];
                switch (key) {
                    case "periodTime":
                        periodTime = value;
                        break;
                    case "jobName":
                        jobName = value;
                        break;
                    case "status":
                        status = Integer.parseInt(value);
                        break;
                }
            }
        }
        if (Util.isEmpty(jobName)) {
            throw new DatapushException("jobName is null");
        }
        if (Util.isEmpty(periodTime)) {
            throw new DatapushException("period time is null");
        }
        statusDes = "task will be killed or server shutdown";
    }

    /**
     * loadDamConfig
     *
     * @param rootDir String
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadDamConfig(String rootDir) throws IOException, DatapushException,
            SAXException, DocumentException {
        Element root = Util.getDocument(FileUtils.getFile(new String[]{rootDir + "/conf/IDE_EnvConf.xml"}))
                .getRootElement();
        (GlobalVariable.getInstance()).node = root.elementTextTrim("Node");
        if (!Util.checkIp((GlobalVariable.getInstance()).node)) {
            throw new DatapushException("IDE_EnvConf config file error!");
        }
        damConfig = new DamConfig();
        Properties sysPro = new Properties();
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(new String[]{rootDir
                + "/conf/datapush.properties"}))) {
            sysPro.load(in);
        }
        configDir = Arrays.asList(sysPro.getProperty("program.config.path", "/").split(","));
        damConfig.setOpen(Boolean.parseBoolean(sysPro.getProperty("da.open", "true")));
        if (damConfig.isOpen()) {
            damConfig.setSignKey(CryptService.decryptAes(sysPro.getProperty("da.sign")));
            damConfig.setWorkKey(sysPro.getProperty("da.work"));
            damConfig.setUrl(sysPro.getProperty("da.url"));
            damConfig.setName(sysPro.getProperty("da.server.name", ""));
            damConfig.setTimeOut(Util.getInt(sysPro.getProperty("da.request.timeout"), 300));
            damConfig.setWaitTime(Util.getInt(sysPro.getProperty("da.request.waittime"), 3000));
        }
    }

    /**
     * loadJobConfig
     *
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadJobConfig() throws IOException {
        ArrayList<Path> singleFiles = new ArrayList<>();
        for (String path : configDir) {
            if (!path.endsWith("/")) {
                path = path + "/";
            }
            singleFiles.addAll((new FindFileUtil(1)).getFileByRegex(Paths.get(path, new String[0]),
                    ".*_config\\.xml$"));
        }
        for (Path single : singleFiles) {
            if (single.toFile().getName().startsWith(jobName)) {
                SingleConfig singleConfig = new SingleConfig(single);
                taskInfo = singleConfig.getTaskInfo();
                break;
            }
        }
    }

    /**
     * main
     *
     * @param args String[]
     * @author z00502253
     * @since 2022-06-30
     */
    public static void main(String[] args) {
        Thread.currentThread().setName("DamFinishedApi");
        if (status == 0 || status == 1) {
            return;
        }
        log.info("dam finished error api start...");
        try {
            String rootDir = Paths.get(System.getProperty("user.dir"), new String[0]).toString();
            Util.loadLogBack(rootDir + File.separator + "conf" + File.separator + "logback.xml");
            (GlobalVariable.getInstance()).rootDir = rootDir;
            loadParams(args);
            loadDamConfig(rootDir);
            loadJobConfig();
            if (taskInfo == null) {
                log.debug("{} config is null", jobName);
                throw new DatapushException("config is null");
            }
            HashMap<String, Object> map = new HashMap<>(11);
            map.put("jobName", jobName);
            map.put("taskInstId", Util.isNotEmpty(taskInfo.getDamTaskId()) ? taskInfo.getDamTaskId() : "0");
            map.put("taskId", taskInfo.getTaskId());
            map.put("isAlarm", Boolean.valueOf(taskInfo.isAlarm()));
            map.put("alarmLevel", taskInfo.getAlarmLevel());
            map.put("alarmScope", taskInfo.getAlarmScope());
            map.put("srcIp", (GlobalVariable.getInstance()).node);
            map.put("cycleTime", Util.rightPad(periodTime, 12, "0").substring(0, 12));
            map.put("statusCode", Integer.valueOf(status));
            map.put("message", String.format(Locale.ENGLISH, "[%s] [%s] this task %s had a problem, %s",
                    new Object[]{
                    Util.getDirNameByTime("yyyy-MM-dd HH:mm:ss"), jobName,
                            (GlobalVariable.getInstance()).node, statusDes}));
            log.debug("Dam finished params: {}", map);
            DamController damController = new DamController(damConfig);
            damController.pushFinished(map);
        } catch (DatapushException | IOException | NullPointerException | DocumentException | SAXException e) {
            log.warn("dam finished api error", e);
        }
        log.info("dam finished error api end...");
    }
}