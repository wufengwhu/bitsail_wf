/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.comenum;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public enum PeriodTypeEnum {

    DAY("D", "天"), HOUR("H", "小时");

    /**
     * The Constant cn.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final String cn;

    /**
     * The Constant en.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final String en;

    PeriodTypeEnum(String en, String cn) {
        this.en = en;
        this.cn = cn;
    }
}