/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class FileDealUtil {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FileDealUtil.class);

    /**
     * replaceAllContent
     *
     * @param path String
     * @param value Object
     * @param append boolean
     * @author z00502253
     * @since 2020-02-14
     */
    public static void replaceAllContent(String path, Object value, boolean append) throws IOException {
        BufferedWriter out = null;
        try {
            File file = FileUtils.getFile(new String[]{path});
            CharArrayWriter tempStream = new CharArrayWriter();
            tempStream.write(append ? (value.toString() + "\n") : value.toString());
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, append), "UTF-8"));
            tempStream.writeTo(out);
            out.flush();
        } catch (IOException e) {
            throw new IOException();
        } finally {
            Util.closeQuietly(out);
        }
    }

    /**
     * replacePropValue
     *
     * @param path String
     * @param key String
     * @param value Object
     * @author z00502253
     * @since 2020-02-14
     */
    public static void replacePropValue(String path, String key, Object value) throws IOException {
        BufferedReader bufIn = null;
        BufferedWriter out = null;
        try {
            File file = FileUtils.getFile(new String[]{path});
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    new FileInputStream(file), "UTF-8"));
            bufIn = new BufferedReader(in);
            CharArrayWriter tempStream = new CharArrayWriter();
            String line = null;
            while ((line = bufIn.readLine()) != null) {
                line = line.replaceAll("^" + key + "=.*", key + "=" + value.toString());
                tempStream.write(line);
                tempStream.append(System.getProperty("line.separator"));
            }
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, false),
                    "UTF-8"));
            tempStream.writeTo(out);
            out.flush();
        } catch (IOException e) {
            throw new IOException();
        } finally {
            Util.closeQuietly(bufIn);
            Util.closeQuietly(out);
        }
    }
}