package com.hihonor.cloudservice.datapush.entity;

import java.util.List;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class IACDataPushDB
        extends IACDataPushJob {

    /**
     * The Constant dataSources.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<IACDataSource> dataSources;

    /**
     * The Constant extractSql.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String extractSql;

    /**
     * The Constant replaceSource.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String replaceSource;

    /**
     * The Constant replaceTarget.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String replaceTarget;

    public List<IACDataSource> getDataSources() {
        return this.dataSources;
    }

    public void setDataSources(List<IACDataSource> dataSources) {
        this.dataSources = dataSources;
    }

    public String getExtractSql() {
        return this.extractSql;
    }

    public void setExtractSql(String extractSql) {
        this.extractSql = extractSql;
    }

    public String getReplaceSource() {
        return this.replaceSource;
    }

    public void setReplaceSource(String replaceSource) {
        this.replaceSource = replaceSource;
    }

    public String getReplaceTarget() {
        return this.replaceTarget;
    }

    public void setReplaceTarget(String replaceTarget) {
        this.replaceTarget = replaceTarget;
    }
}