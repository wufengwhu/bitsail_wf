package com.hihonor.cloudservice.datapush.config;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.exception.DatapushException;

import com.hihonor.cloudservice.datapush.entity.DatabaseTask;
import com.hihonor.cloudservice.datapush.entity.DbSource;
import com.hihonor.cloudservice.datapush.entity.FileSource;
import com.hihonor.cloudservice.datapush.entity.FilesTask;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class AppConfig {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(AppConfig.class);

    /**
     * The Constant envFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final ArrayList<Path> envFiles;

    /**
     * The Constant root.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Element root;

    /**
     * The Constant child.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Element child;

    /**
     * The Constant type.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int type;

    /**
     * The Constant taskInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private TaskInfo taskInfo;

    public AppConfig(ArrayList<Path> envFiles, Element root, Element child, int type) {
        this.envFiles = envFiles;
        this.root = root;
        this.child = child;
        this.type = type;
    }

    /**
     * getTaskInfo
     *
     * @return vo
     * @author z00502253
     * @since 2020-02-16
     */
    public TaskInfo getTaskInfo() {
        this.taskInfo = new TaskInfo();
        this.taskInfo.setUsedHosts(new ArrayList());
        this.taskInfo.setCheckMode(this.root.elementTextTrim("FileNumCheckMode"));
        Element destFileFormat = this.root.element("DestFileFormat");
        if (destFileFormat != null) {
            this.taskInfo.setFieldSep(Util.replaceFieldSep(destFileFormat.elementText("FieldSeparator")));
            this.taskInfo.setLineSep(Util.replaceLineSep(destFileFormat.elementText("LineSeparator")));
        }
        this.taskInfo.setJobName(this.child.attributeValue("jobName"));
        this.taskInfo.setTaskType(this.child.attributeValue("jobType"));
        this.taskInfo.setDestFileName(this.child.elementTextTrim("DestFileName"));
        this.taskInfo.setPeriodType(this.child.elementTextTrim("PeriodType"));
        this.taskInfo.setAlarm(Boolean.parseBoolean(this.child.elementTextTrim("Alarms")));
        this.taskInfo.setAlarmLevel(this.child.elementTextTrim("AlarmLevel"));
        this.taskInfo.setAlarmScope(this.child.elementTextTrim("AlarmScope"));
        this.taskInfo.setSendFileMaxThreads(Util.getInt(this.child.elementTextTrim("SendThreadCount"),
                3));
        this.taskInfo.setCompressMaxThreads(Util.getInt(this.child.elementTextTrim("CompressThreadCount"),
                3));
        loadTransport();
        if (this.type == 1) {
            loadFile();
        }
        if (this.type == 2) {
            loadDatabase();
        }
        return this.taskInfo;
    }

    /**
     * loadTransport
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void loadTransport() {
        String tSID = this.child.elementTextTrim("TransportService");
        for (Path env : this.envFiles) {
            try {
                Element envRoot = Util.getDocument(env.toFile()).getRootElement();
                List<Element> transportServices = envRoot.elements("TransportService");
                for (Element transportService : transportServices) {
                    if (transportService.attributeValue("id").equals(tSID)) {
                        this.taskInfo = JobConfig.parsingTransportService(this.taskInfo, transportService);
                    }
                }

            } catch (DocumentException | org.xml.sax.SAXException | DatapushException e) {
                log.error("", e);
            }
        }
        String tCID = this.child.elementTextTrim("TransportConf");
        List<Element> transportConfigs = this.root.elements("TransportConf");
        for (Element transportConf : transportConfigs) {
            if (transportConf.attributeValue("id").equals(tCID)) {
                this.taskInfo = JobConfig.parsingTransportConf(this.taskInfo, transportConf);
                break;
            }
        }
    }

    /**
     * loadFile
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void loadFile() {
        this.taskInfo.setTaskType("file");
        FilesTask filesTask = new FilesTask();
        filesTask.setFetchMode(Util.getInt(this.child.elementTextTrim("FileFetchMode"), 3));
        filesTask.setSourcePolicy(Util.getInt(this.child.elementTextTrim("SourceFilePolicy"), 1));
        filesTask.setCheckFileCount(Util.getInt(this.child.elementTextTrim("FileCountThreshold"), 0));
        filesTask.setCheckFileSize(Util.getInt(this.child.elementTextTrim("FileSizeThreshold"), 0));
        int reRetryTimes = Util.getInt(this.child.elementTextTrim("ReRetryTimes"), 3);
        reRetryTimes = (reRetryTimes > 0) ? reRetryTimes : 1;
        filesTask.setCheckTimes(reRetryTimes);
        filesTask.setCheckWaitTimes(Util.getInt(this.child.elementTextTrim("WaitTime"), 0));
        String[] fsList = this.child.elementTextTrim("FileSource").split(",");
        List<FileSource> fileSources = new ArrayList<>();
        for (String fl : fsList) {
            boolean check = false;
            for (Path env : this.envFiles) {
                try {
                    Element envRoot = Util.getDocument(env.toFile()).getRootElement();
                    List<Element> fileSourceEls = envRoot.elements("FileSource");
                    for (Element fileSourceEl : fileSourceEls) {
                        if (fl.equals(fileSourceEl.attributeValue("id"))) {
                            FileSource fileSource = new FileSource();
                            fileSource.setDirectory(fileSourceEl.elementTextTrim("Directroy"));
                            fileSource.setChildDirRegex(fileSourceEl.elementTextTrim("ChildDirRegex"));
                            fileSource.setFileDepth(Util.getInt(fileSourceEl.elementTextTrim("FileDepth"),
                                    1));
                            fileSources.add(fileSource);
                            check = true;
                            break;
                        }
                    }
                    if (check) {
                        break;
                    }
                } catch (DocumentException | org.xml.sax.SAXException e) {
                    log.error("", e);
                }
            }
        }
        filesTask.setFileSources(fileSources);
        filesTask.setFilesMask(Arrays.asList(this.child.elementTextTrim("FileMask").split("\\|")));
        this.taskInfo.setFilesTask(filesTask);
    }

    /**
     * loadDatabase
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void loadDatabase() {
        this.taskInfo.setTaskType("db");
        DatabaseTask databaseTask = new DatabaseTask();
        databaseTask.setSql(this.child.elementTextTrim("ExtractSql"));
        databaseTask.setFiledSep(Util.replaceFieldSep(this.child.elementText("Separator")));
        String[] sources = this.child.elementTextTrim("DBSource").split(",");
        List<DbSource> dbSources = new ArrayList<>();
        for (String dl : sources) {
            boolean check = false;
            for (Path env : this.envFiles) {
                try {
                    Element envRoot = Util.getDocument(env.toFile()).getRootElement();
                    List<Element> dbSourceEls = envRoot.elements("DBSource");
                    for (Element dbSourceEl : dbSourceEls) {
                        if (dl.equals(dbSourceEl.attributeValue("id"))) {
                            DbSource dbSource = new DbSource();
                            dbSource.setType(dbSourceEl.elementTextTrim("Type"));
                            dbSource.setHost(dbSourceEl.elementTextTrim("Host"));
                            dbSource.setPort(Util.getInt(dbSourceEl.elementTextTrim("Port"), 3306));
                            dbSource.setDataName(dbSourceEl.elementText("Database"));
                            dbSource.setUser(dbSourceEl.elementText("Username"));
                            dbSource.setPassword(CryptService.decryptAes(dbSourceEl.elementText("Password")));
                            dbSource.setExtendParams(dbSourceEl.elementText("AdditionalInfo"));
                            dbSources.add(dbSource);
                            check = true;
                            break;
                        }
                    }
                    if (check) {
                        break;
                    }
                } catch (DocumentException | org.xml.sax.SAXException | DatapushException e) {
                    log.error("", e);
                }
            }
        }
        databaseTask.setDbSources(dbSources);
        this.taskInfo.setDatabaseTask(databaseTask);
    }
}