/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class DateUtil {

    /**
     * The Constant LOG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger LOG = LoggerFactory.getLogger(DateUtil.class);

    /**
     * The Constant DEFAULT_DATE_PATTERN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String DEFAULT_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";

    /**
     * timeStamp
     *
     * @param engStr String
     * @return long
     * @author z00502253
     * @since 2020-02-14
     */
    public static long timeStamp(String engStr) throws ParseException {
        SimpleDateFormat engFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
        Date date = engFormat.parse(engStr);
        return date.getTime();
    }

    /**
     * engFormat2unixTimeStamp
     *
     * @param engStr String
     * @return long
     * @author z00502253
     * @since 2020-02-14
     */
    public static long engFormat2unixTimeStamp(String engStr) throws ParseException {
        SimpleDateFormat engFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
        Date date = engFormat.parse(engStr);
        return date.getTime();
    }

    /**
     * getCurrentTime
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getCurrentTime() {
        return formatDate(new Date(), "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * formatDate
     *
     * @param date Date
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String formatDate(Date date) {
        return formatDate(date, "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * formatDate
     *
     * @param date Date
     * @param pattern String
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String formatDate(Date date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.format(date);
    }

    /**
     * getCurrentDate
     *
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getCurrentDate() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(new Date());
    }

    /**
     * parseDate
     *
     * @param dateStr String
     * @return Date
     * @author z00502253
     * @since 2020-02-14
     */
    public static Date parseDate(String dateStr) throws ParseException {
        return parseDate(dateStr, "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * parseDate
     *
     * @param dateStr String
     * @param pattern String
     * @return Date
     * @author z00502253
     * @since 2020-02-14
     */
    public static Date parseDate(String dateStr, String pattern) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.parse(dateStr);
    }

    /**
     * getBetweenDays
     *
     * @param startTime String
     * @param endTime String
     * @return int
     * @author z00502253
     * @since 2020-02-14
     */
    public static int getBetweenDays(String startTime, String endTime) throws ParseException {
        Date startDate = parseDate(startTime, "yyyyMMdd");
        Date endDate = parseDate(endTime, "yyyyMMdd");
        return (int) (Math.abs(endDate.getTime() - startDate.getTime()) / 86400000L);
    }

    /**
     * getTimezoneDiff
     *
     * @param timezone String
     * @return long
     * @author z00502253
     * @since 2020-02-14
     */
    public static long getTimezoneDiff(String timezone) {
        Calendar calendar = Calendar.getInstance();

        int zoneOffset = calendar.get(15);

        int dstOffset = calendar.get(16);

        try {
            int flag = Integer.parseInt(timezone.substring(0, 1));
            int hour = Integer.parseInt(timezone.substring(1, 3));
            int minute = Integer.parseInt(timezone.substring(3, 5));

            if (flag == 0) {
                return -((zoneOffset + dstOffset) + ((hour * 60 + minute) * 60) * 1000L);
            }
            return -((zoneOffset + dstOffset) - ((hour * 60 + minute) * 60) * 1000L);
        } catch (NumberFormatException e) {
            LOG.error("getTimezoneDiff failed!");
            return 0L;
        }
    }

    /**
     * changeDateByOffset
     *
     * @param date Date
     * @param calendarType int
     * @param offset int
     * @return Date
     * @author z00502253
     * @since 2020-02-14
     */
    public static Date changeDateByOffset(Date date, int calendarType, int offset) {
        Calendar cDate = Calendar.getInstance();
        cDate.setTime(date);
        cDate.add(calendarType, offset);
        return cDate.getTime();
    }

    /**
     * getTime
     *
     * @return Long
     * @author z00502253
     * @since 2020-02-14
     */
    public static Long getTime() {
        Calendar cd = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("EEE d MMM yyyy HH:mm:ss 'GMT'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        return Long.valueOf(cd.getTime().getTime());
    }
}