package com.hihonor.cloudservice.datapush.config;

import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.common.Util;


import java.util.Arrays;

import org.dom4j.Element;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class JobConfig {

    /**
     * parsingTransportService
     *
     * @param taskInfo vo
     * @param transportService transportService
     * @return vo
     * @author z00502253
     * @since 2020-02-16
     */
    public static TaskInfo parsingTransportService(TaskInfo taskInfo, Element transportService) {
        taskInfo.setMode(transportService.elementTextTrim("Mode"));
        if (Util.isNotEmpty(transportService.elementTextTrim("Host"))) {
            taskInfo.setHosts(Arrays.asList(transportService.elementTextTrim("Host").split(",")));
        }
        taskInfo.setPort(transportService.elementTextTrim("Port"));
        taskInfo.setHostUser(transportService.elementTextTrim("Username"));
        taskInfo.setAuthType(Util.getInt(transportService.elementTextTrim("AuthType"), 3));
        taskInfo.setPassword(
                CryptService.decryptAes(transportService.elementTextTrim("Password")));
        taskInfo.setPrivateKeyPass(
                CryptService.decryptAes(transportService.elementTextTrim("PrivateKeyPass")));
        taskInfo.setPrivateKeyFile(transportService.elementTextTrim("PrivateKeyFile"));
        taskInfo.setIsOpenPeriodDir(transportService.elementTextTrim("IsOpenPeriodDir"));
        taskInfo.setDestFilePermission(transportService.elementTextTrim("DestFilePermission"));
        taskInfo.setDirectory(
                CryptService.decryptAes(transportService.elementTextTrim("Directory")));
        return taskInfo;
    }

    /**
     * parsingTransportConf
     *
     * @param taskInfo vo
     * @param transportConf transportConf
     * @return vo
     * @author z00502253
     * @since 2020-02-16
     */
    public static TaskInfo parsingTransportConf(TaskInfo taskInfo, Element transportConf) {
        taskInfo.setTimeOut(Util.getInt(transportConf.elementTextTrim("RemoteTimeOut"), 0));
        taskInfo.setReTimes(Util.getInt(transportConf.elementTextTrim("ReSendTimes"), 0));
        taskInfo.setWaitTime(Util.getInt(transportConf.elementTextTrim("WaitTime"), 0));
        taskInfo.setTaskId(transportConf.attributeValue("id"));
        taskInfo.setCompress(Boolean.parseBoolean(transportConf.elementTextTrim("IsCombinByNoCompress")));
        taskInfo.setLzo(Boolean.parseBoolean(transportConf.elementTextTrim("IsOnlyLzoCompress")));
        taskInfo.setZip(Boolean.parseBoolean(transportConf.elementTextTrim("IsCompressAndEncrypt")));
        taskInfo.setZipPassword(transportConf.elementTextTrim("Password"));
        taskInfo.setSplitSize(Util.getInt(transportConf.elementTextTrim("SplitSize"), 0));
        taskInfo.setSplitCount(Util.getInt(transportConf.elementTextTrim("FileCount"), 1));
        taskInfo.setWorkPolicy(Util.getInt(transportConf.elementTextTrim("SourceFilePolicy"), 2));
        taskInfo.setOdsName(transportConf.elementTextTrim("OdsTableName"));
        taskInfo.setDeptCode(transportConf.elementTextTrim("DeptCode"));
        return taskInfo;
    }
}