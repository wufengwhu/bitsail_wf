package com.hihonor.cloudservice.datapush.jsch;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UserInfo;

import java.io.File;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class Ssh implements UserInfo {

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String jobName;

    /**
     * The Constant userName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String userName;

    /**
     * The Constant password.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String password;

    /**
     * The Constant passphrase.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String passphrase;

    /**
     * The Constant keyFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String keyFile;

    /**
     * The Constant knownHosts.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String knownHosts;

    /**
     * The Constant cipher.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String cipher;

    /**
     * The Constant destFilePermission.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String destFilePermission;

    /**
     * The Constant limitBand.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int limitBand;

    /**
     * The Constant host.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String host;

    /**
     * The Constant port.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int port;

    /**
     * The Constant timeOut.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int timeOut;

    /**
     * The Constant remotePath.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String remotePath;

    /**
     * The Constant localFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final File localFile;

    /**
     * The Constant command.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String command;

    Ssh(String jobName, String userName, String password, String passphrase, String keyFile, String knownHosts,
        String cipher, String destFilePermission, int limitBand, String host, int port, int timeOut,
        String remotePath, File localFile, String command) {
        this.jobName = jobName;
        this.userName = userName;
        this.password = password;
        this.passphrase = passphrase;
        this.keyFile = keyFile;
        this.knownHosts = knownHosts;
        this.cipher = cipher;
        this.destFilePermission = destFilePermission;
        this.limitBand = limitBand;
        this.host = host;
        this.port = port;
        this.timeOut = timeOut;
        this.remotePath = remotePath;
        this.localFile = localFile;
        this.command = command;
    }

    public static SshBuilder builder() {
        return new SshBuilder();
    }

    public SshBuilder toBuilder() {
        return (new SshBuilder()).jobName(this.jobName).userName(this.userName).password(this.password)
                .passphrase(this.passphrase).keyFile(this.keyFile).knownHosts(this.knownHosts).cipher(this.cipher)
                .destFilePermission(this.destFilePermission).limitBand(this.limitBand).host(this.host)
                .port(this.port).timeOut(this.timeOut).remotePath(this.remotePath).localFile(this.localFile)
                .command(this.command);
    }

    public static class SshBuilder {

        /**
         * The Constant jobName.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String jobName;

        /**
         * The Constant userName.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String userName;

        /**
         * The Constant password.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String password;

        /**
         * The Constant passphrase.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String passphrase;

        /**
         * The Constant keyFile.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String keyFile;

        /**
         * The Constant knownHosts.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String knownHosts;

        /**
         * The Constant cipher.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String cipher;

        public SshBuilder jobName(String jobName) {
            this.jobName = jobName;
            return this;
        }

        /**
         * The Constant destFilePermission.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String destFilePermission;

        /**
         * The Constant limitBand.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private int limitBand;

        /**
         * The Constant host.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String host;

        /**
         * The Constant port.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private int port;

        /**
         * The Constant timeOut.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private int timeOut;

        /**
         * The Constant remotePath.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String remotePath;

        /**
         * The Constant localFile.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private File localFile;

        /**
         * The Constant command.
         *
         * @author z00502253
         * @since 2019-12-02
         */
        private String command;

        public SshBuilder userName(String userName) {
            this.userName = userName;
            return this;
        }

        public SshBuilder password(String password) {
            this.password = password;
            return this;
        }

        public SshBuilder passphrase(String passphrase) {
            this.passphrase = passphrase;
            return this;
        }

        public SshBuilder keyFile(String keyFile) {
            this.keyFile = keyFile;
            return this;
        }

        public SshBuilder knownHosts(String knownHosts) {
            this.knownHosts = knownHosts;
            return this;
        }

        public SshBuilder cipher(String cipher) {
            this.cipher = cipher;
            return this;
        }

        public SshBuilder destFilePermission(String destFilePermission) {
            this.destFilePermission = destFilePermission;
            return this;
        }

        public SshBuilder limitBand(int limitBand) {
            this.limitBand = limitBand;
            return this;
        }

        public SshBuilder host(String host) {
            this.host = host;
            return this;
        }

        public SshBuilder port(int port) {
            this.port = port;
            return this;
        }

        public SshBuilder timeOut(int timeOut) {
            this.timeOut = timeOut;
            return this;
        }

        public SshBuilder remotePath(String remotePath) {
            this.remotePath = remotePath;
            return this;
        }

        public SshBuilder localFile(File localFile) {
            this.localFile = localFile;
            return this;
        }

        public SshBuilder command(String command) {
            this.command = command;
            return this;
        }

        public Ssh build() {
            return new Ssh(this.jobName, this.userName, this.password, this.passphrase, this.keyFile, this.knownHosts,
                    this.cipher, this.destFilePermission, this.limitBand, this.host, this.port, this.timeOut,
                    this.remotePath, this.localFile, this.command);
        }

        public String toString() {
            return "Ssh.SshBuilder(jobName=" + this.jobName + ", userName=" + this.userName + ", password="
                    + this.password + ", passphrase=" + this.passphrase + ", keyFile=" + this.keyFile
                    + ", knownHosts=" + this.knownHosts + ", cipher=" + this.cipher + ", destFilePermission="
                    + this.destFilePermission + ", limitBand=" + this.limitBand + ", host=" + this.host
                    + ", port=" + this.port + ", timeOut=" + this.timeOut + ", remotePath=" + this.remotePath
                    + ", localFile=" + this.localFile + ", command=" + this.command + ")";
        }
    }

    public String getJobName() {
        return this.jobName;
    }

    public String getUserName() {
        return this.userName;
    }

    public String getKeyFile() {
        return this.keyFile;
    }

    public String getKnownHosts() {
        return this.knownHosts;
    }

    public String getCipher() {
        return this.cipher;
    }

    public String getDestFilePermission() {
        return this.destFilePermission;
    }

    public int getLimitBand() {
        return this.limitBand;
    }

    public String getHost() {
        return this.host;
    }

    public int getPort() {
        return this.port;
    }

    public int getTimeOut() {
        return this.timeOut;
    }

    public String getRemotePath() {
        return this.remotePath;
    }

    public File getLocalFile() {
        return this.localFile;
    }

    public String getCommand() {
        return this.command;
    }

    public String getPassphrase() {
        return this.passphrase;
    }

    public String getPassword() {
        return this.password;
    }

    public boolean promptPassword(String s) {
        return true;
    }

    public boolean promptPassphrase(String s) {
        return true;
    }

    public boolean promptYesNo(String s) {
        return true;
    }

    public void showMessage(String s) {

    }

    /**
     * getConnection
     *
     * @return Session
     * @author z00502253
     * @since 2020-06-23
     */
    public Session getConnection() throws JSchException, DatapushException {
        JSch jsch = new JSch();
        if (Util.isNotEmpty(this.keyFile)) {
            jsch.addIdentity(this.keyFile);
        }
        if (Util.isNotEmpty(this.knownHosts)) {
            jsch.setKnownHosts(this.knownHosts);
        }
        Session session = jsch.getSession(this.userName, this.host, this.port);
        session.setUserInfo(this);
        session.connect(this.timeOut);
        if (session.isConnected()) {
            session.setTimeout(this.timeOut);
            return session;
        }
        throw new DatapushException("session disconnected");
    }
}