/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import com.hihonor.cloudservice.datapush.exception.DatapushState;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.LineIterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class LocalCmdUtil
        implements Callable<String> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(LocalCmdUtil.class);

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String jobName;

    /**
     * The Constant cmd.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String cmd;

    /**
     * The Constant cmdLog.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String cmdLog;

    public LocalCmdUtil(String jobName, String cmd) {
        this.jobName = jobName;
        this.cmd = cmd;
        this.cmdLog = cmd;
    }

    public LocalCmdUtil(String jobName, String cmd, String cmdLog) {
        this.jobName = jobName;
        this.cmd = cmd;
        this.cmdLog = cmdLog;
    }

    /**
     * run
     *
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public String run() {
        ThreadPoolExecutor poolExecutor = new ThreadPoolExecutor(1, 1,
                0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(1),
                new ThreadFactoryUtil(this.jobName));

        Future<String> task = poolExecutor.submit(this);
        try {
            return task.get(2L, TimeUnit.HOURS);
        } catch (InterruptedException | java.util.concurrent.ExecutionException |
                java.util.concurrent.TimeoutException e) {
            log.error("cmd error", e);
            return e.getMessage();
        } finally {
            poolExecutor.shutdown();
        }
    }

    /**
     * call
     *
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public String call() {
        String errorMessage;
        Runtime run = Runtime.getRuntime();
        Process process = null;
        try {
            if (this.cmd.contains("rsync_privatekey.exp")) {
                process = run.exec(this.cmd);
            } else {
                process = run.exec(new String[]{"/bin/sh", "-c", this.cmd});
            }
            String cmdError = stream(process.getErrorStream());
            String cmdOut = stream(process.getInputStream());
            int exitValue = process.waitFor();
            errorMessage = cmdError + "=>" + cmdOut;
            log.debug(errorMessage);
            if (exitValue != 0) {
                errorMessage = String.format(Locale.ENGLISH, System.lineSeparator() + "cmd = %s, "
                        + System.lineSeparator() + "code = %d, " +
                        System.lineSeparator() + "msg = %s", new Object[]{this.cmdLog,
                        Integer.valueOf(exitValue), errorMessage});
                log.error("shell run error-->{}", errorMessage);
            } else {
                if (this.cmd.startsWith("cat")) {
                    log.info("cat run success");
                } else {
                    log.info("{} run success", this.cmdLog);
                }
                return DatapushState.SUCCESS.getDetail();
            }
        } catch (InterruptedException | java.io.IOException e) {
            log.error("cmd run error", e);
            errorMessage = e.getMessage();
        } finally {
            if (null != process) {
                process.destroy();
            }
        }
        return errorMessage;
    }

    /**
     * stream
     *
     * @param inputStream inputStream
     * @return String
     * @author z00502253
     * @since 2022-07-01
     */
    private String stream(InputStream inputStream) {
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            inputStreamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
            reader = new BufferedReader(inputStreamReader);
            LineIterator iterator = new LineIterator(reader);
            StringBuilder result = new StringBuilder();
            while (iterator.hasNext()) {
                result.append(iterator.next());
            }
            if (Util.isNotEmpty(result.toString())) {
                return result.toString();
            }
        } finally {
            Util.closeQuietly(inputStreamReader);
            Util.closeQuietly(reader);
        }
        return "false";
    }
}