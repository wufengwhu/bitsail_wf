/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import com.alibaba.fastjson.JSON;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.huawei.secure.filter.LogFilter;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import java.util.Map;
import java.util.Objects;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.commons.io.LineIterator;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class HttpUtil {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(HttpUtil.class);

    /**
     * sendRequest
     *
     * @param url String
     * @param method String
     * @param params Map
     * @param headers Map
     * @param timeOut int
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String sendRequest(String url, String method, Map<String, Object> params,
                                     Map<String, String> headers, int timeOut) throws DatapushException {
        try {
            log.debug("Reqeust params : {}", LogFilter.doFilterByEscapeChar(JSON.toJSONString(params)));
            log.debug("Reqeust headers : {}", LogFilter.doFilterByEscapeChar(JSON.toJSONString(headers)));
        } catch (IOException e) {
            log.error("request fail", e);
            throw new DatapushException(e);
        }
        if (Util.isEmpty(url)) {
            return "";
        }
        if (url.startsWith("https")) {
            try {
                return httpsRequest(url, method, params, headers, timeOut);
            } catch (IOException | NoSuchAlgorithmException | KeyManagementException | KeyStoreException e) {
                log.error("request fail", e);
                throw new DatapushException(e);
            } catch (Exception e) {
                log.error("request fail", e);
                throw new DatapushException(e);
            }
        }
        try {
            return httpRequest(url, method, params, headers, timeOut);
        } catch (IOException | IllegalArgumentException e) {
            log.error("request fail", e);
            throw new DatapushException(e);
        } catch (Exception e) {
            log.error("request fail", e);
            throw new DatapushException(e);
        }
    }

    /**
     * httpsRequest
     *
     * @param url String
     * @param method String
     * @param params Map
     * @param headers Map
     * @param timeOut int
     * @return String
     * @author z00502253
     * @since 2022-07-01
     */
    private static String httpsRequest(String url, String method, Map<String, Object> params,
                                       Map<String, String> headers, int timeOut) throws IOException,
            KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        URL realUrl = new URL(url);
        HttpsURLConnection httpsConnection = (HttpsURLConnection) realUrl.openConnection();
        SSLContext sslContext = (new SSLContextBuilder()).loadTrustMaterial(null,
                (certificate, authType) -> true).build();
        httpsConnection.setSSLSocketFactory(sslContext.getSocketFactory());
        httpsConnection.setHostnameVerifier((HostnameVerifier) new NoopHostnameVerifier());
        for (Map.Entry<String, String> head : headers.entrySet()) {
            httpsConnection.setRequestProperty(head.getKey(), head.getValue());
        }
        httpsConnection.setConnectTimeout(timeOut * 1000);
        httpsConnection.setReadTimeout(timeOut * 1000);
        httpsConnection.setDoInput(true);
        httpsConnection.setDoOutput(true);
        httpsConnection.setUseCaches(false);
        httpsConnection.setRequestMethod(method);
        if (params != null) {
            try (DataOutputStream out = new DataOutputStream(httpsConnection.getOutputStream())) {
                out.writeBytes(JSON.toJSONString(params));
                out.flush();
            }
        }
        try (BufferedReader in = new BufferedReader(new InputStreamReader(httpsConnection
                .getInputStream(), StandardCharsets.UTF_8), 2097152)) {
            LineIterator lineIterator = new LineIterator(Objects.<Reader>requireNonNull(in));
            StringBuilder result = new StringBuilder();
            while (lineIterator.hasNext()) {
                result.append(lineIterator.next());
            }
            httpsConnection.disconnect();
            return result.toString();
        }
    }

    /**
     * httpRequest
     *
     * @param url String
     * @param method String
     * @param params Map
     * @param headers Map
     * @param timeOut int
     * @return String
     * @author z00502253
     * @since 2022-07-01
     */
    private static String httpRequest(String url, String method, Map<String, Object> params,
                                      Map<String, String> headers, int timeOut) throws IOException {
        URL realUrl = new URL(url);
        HttpURLConnection httpConnection = (HttpURLConnection) realUrl.openConnection();
        for (Map.Entry<String, String> head : headers.entrySet()) {
            httpConnection.setRequestProperty(head.getKey(), head.getValue());
        }
        httpConnection.setConnectTimeout(timeOut * 1000);
        httpConnection.setReadTimeout(timeOut * 1000);
        httpConnection.setDoOutput(true);
        httpConnection.setDoInput(true);
        httpConnection.setUseCaches(false);
        httpConnection.setRequestMethod(method);
        if (params != null) {
            try (DataOutputStream out = new DataOutputStream(httpConnection.getOutputStream())) {
                out.writeBytes(JSON.toJSONString(params));
                out.flush();
            }
        }
        try (BufferedReader in = new BufferedReader(new InputStreamReader(httpConnection
                .getInputStream(), StandardCharsets.UTF_8), 2097152)) {
            LineIterator lineIterator = new LineIterator(Objects.<Reader>requireNonNull(in));
            StringBuilder result = new StringBuilder();
            while (lineIterator.hasNext()) {
                result.append(lineIterator.next());
            }
            httpConnection.disconnect();
            return result.toString();
        }
    }
}