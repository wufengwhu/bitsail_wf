package com.hihonor.cloudservice.datapush.entity;

import com.hihonor.cloudservice.datapush.exception.DatapushState;

import java.util.List;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class TaskInfo {

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String jobName;

    /**
     * The Constant taskType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String taskType;

    /**
     * The Constant enable.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean enable;

    /**
     * The Constant onlyTrans.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean onlyTrans;

    /**
     * The Constant onlyTransISRename.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean onlyTransISRename;

    /**
     * The Constant periodType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String periodType;

    /**
     * The Constant periodObject.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private PeriodObject periodObject;

    /**
     * The Constant checkMode.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String checkMode;

    /**
     * The Constant destFileName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String destFileName;

    /**
     * The Constant alarm.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean alarm;

    /**
     * The Constant alarmLevel.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String alarmLevel;

    /**
     * The Constant alarmScope.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String alarmScope;

    /**
     * The Constant sendFileMaxThreads.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int sendFileMaxThreads;

    /**
     * The Constant compressMaxThreads.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int compressMaxThreads;

    /**
     * The Constant limitBand.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int limitBand;

    /**
     * The Constant fieldSep.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String fieldSep;

    /**
     * The Constant lineSep.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String lineSep;

    /**
     * The Constant mode.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String mode;

    /**
     * The Constant hosts.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> hosts;

    /**
     * The Constant port.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String port;

    /**
     * The Constant hostUser.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String hostUser;

    /**
     * The Constant timeOut.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int timeOut;

    /**
     * The Constant reTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int reTimes;

    /**
     * The Constant waitTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int waitTime;

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    /**
     * The Constant isOpenPeriodDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String isOpenPeriodDir;

    /**
     * The Constant directory.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String directory;

    /**
     * The Constant destFilePermission.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String destFilePermission;

    /**
     * The Constant authType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int authType;

    /**
     * The Constant password.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String password;

    /**
     * The Constant privateKeyPass.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String privateKeyPass;

    /**
     * The Constant privateKeyFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String privateKeyFile;

    /**
     * The Constant damTaskId.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String damTaskId;

    /**
     * The Constant taskId.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String taskId;

    /**
     * The Constant isCompress.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isCompress;

    /**
     * The Constant isLzo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isLzo;

    /**
     * The Constant isZip.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isZip;

    /**
     * The Constant zipPassword.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String zipPassword;

    /**
     * The Constant splitSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int splitSize;

    /**
     * The Constant splitCount.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int splitCount;

    /**
     * The Constant workPolicy.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int workPolicy;

    /**
     * The Constant odsName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String odsName;

    /**
     * The Constant deptCode.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String deptCode;

    /**
     * The Constant filesTask.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private FilesTask filesTask;

    /**
     * The Constant databaseTask.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private DatabaseTask databaseTask;

    /**
     * The Constant usedHosts.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> usedHosts;

    /**
     * The Constant taskState.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private DatapushState taskState;

    /**
     * The Constant monitorState.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private DatapushState monitorState;

    /**
     * The Constant isSendError.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isSendError;

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public void setOnlyTrans(boolean onlyTrans) {
        this.onlyTrans = onlyTrans;
    }

    public void setOnlyTransISRename(boolean onlyTransISRename) {
        this.onlyTransISRename = onlyTransISRename;
    }

    public void setPeriodType(String periodType) {
        this.periodType = periodType;
    }

    public void setPeriodObject(PeriodObject periodObject) {
        this.periodObject = periodObject;
    }

    public void setCheckMode(String checkMode) {
        this.checkMode = checkMode;
    }

    public void setDestFileName(String destFileName) {
        this.destFileName = destFileName;
    }

    public void setAlarm(boolean alarm) {
        this.alarm = alarm;
    }

    public void setAlarmLevel(String alarmLevel) {
        this.alarmLevel = alarmLevel;
    }

    public void setAlarmScope(String alarmScope) {
        this.alarmScope = alarmScope;
    }

    public void setSendFileMaxThreads(int sendFileMaxThreads) {
        this.sendFileMaxThreads = sendFileMaxThreads;
    }

    public void setCompressMaxThreads(int compressMaxThreads) {
        this.compressMaxThreads = compressMaxThreads;
    }

    public void setLimitBand(int limitBand) {
        this.limitBand = limitBand;
    }

    public void setFieldSep(String fieldSep) {
        this.fieldSep = fieldSep;
    }

    public void setLineSep(String lineSep) {
        this.lineSep = lineSep;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public void setHosts(List<String> hosts) {
        this.hosts = hosts;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public void setHostUser(String hostUser) {
        this.hostUser = hostUser;
    }

    public void setTimeOut(int timeOut) {
        this.timeOut = timeOut;
    }

    public void setReTimes(int reTimes) {
        this.reTimes = reTimes;
    }

    public void setWaitTime(int waitTime) {
        this.waitTime = waitTime;
    }

    public void setIsOpenPeriodDir(String isOpenPeriodDir) {
        this.isOpenPeriodDir = isOpenPeriodDir;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public void setDestFilePermission(String destFilePermission) {
        this.destFilePermission = destFilePermission;
    }

    public void setAuthType(int authType) {
        this.authType = authType;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPrivateKeyPass(String privateKeyPass) {
        this.privateKeyPass = privateKeyPass;
    }

    public void setPrivateKeyFile(String privateKeyFile) {
        this.privateKeyFile = privateKeyFile;
    }

    public void setDamTaskId(String damTaskId) {
        this.damTaskId = damTaskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public void setCompress(boolean isCompress) {
        this.isCompress = isCompress;
    }

    public void setLzo(boolean isLzo) {
        this.isLzo = isLzo;
    }

    public void setZip(boolean isZip) {
        this.isZip = isZip;
    }

    public void setZipPassword(String zipPassword) {
        this.zipPassword = zipPassword;
    }

    public void setSplitSize(int splitSize) {
        this.splitSize = splitSize;
    }

    public void setSplitCount(int splitCount) {
        this.splitCount = splitCount;
    }

    public void setWorkPolicy(int workPolicy) {
        this.workPolicy = workPolicy;
    }

    public void setOdsName(String odsName) {
        this.odsName = odsName;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public void setFilesTask(FilesTask filesTask) {
        this.filesTask = filesTask;
    }

    public void setDatabaseTask(DatabaseTask databaseTask) {
        this.databaseTask = databaseTask;
    }

    public void setUsedHosts(List<String> usedHosts) {
        this.usedHosts = usedHosts;
    }

    public void setTaskState(DatapushState taskState) {
        this.taskState = taskState;
    }

    public void setMonitorState(DatapushState monitorState) {
        this.monitorState = monitorState;
    }

    public void setSendError(boolean isSendError) {
        this.isSendError = isSendError;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof TaskInfo)) return false;
        TaskInfo other = (TaskInfo) o;
        if (!other.canEqual(this)) return false;
        Object this$jobName = getJobName(), other$jobName = other.getJobName();
        if ((this$jobName == null) ? (other$jobName != null) : !this$jobName.equals(other$jobName)) return false;
        Object this$taskType = getTaskType(), other$taskType = other.getTaskType();
        if ((this$taskType == null) ? (other$taskType != null) : !this$taskType.equals(other$taskType)) return false;
        if (isEnable() != other.isEnable()) return false;
        if (isOnlyTrans() != other.isOnlyTrans()) return false;
        if (isOnlyTransISRename() != other.isOnlyTransISRename()) return false;
        Object this$periodType = getPeriodType(), other$periodType = other.getPeriodType();
        if ((this$periodType == null) ? (other$periodType != null) : !this$periodType.equals(other$periodType))
            return false;
        Object this$periodObject = getPeriodObject(), other$periodObject = other.getPeriodObject();
        if ((this$periodObject == null) ? (other$periodObject != null) : !this$periodObject.equals(other$periodObject))
            return false;
        Object this$checkMode = getCheckMode(), other$checkMode = other.getCheckMode();
        if ((this$checkMode == null) ? (other$checkMode != null) : !this$checkMode.equals(other$checkMode))
            return false;
        Object this$destFileName = getDestFileName(), other$destFileName = other.getDestFileName();
        if ((this$destFileName == null) ? (other$destFileName != null) : !this$destFileName.equals(other$destFileName))
            return false;
        if (isAlarm() != other.isAlarm()) return false;
        Object this$alarmLevel = getAlarmLevel(), other$alarmLevel = other.getAlarmLevel();
        if ((this$alarmLevel == null) ? (other$alarmLevel != null) : !this$alarmLevel.equals(other$alarmLevel))
            return false;
        Object this$alarmScope = getAlarmScope(), other$alarmScope = other.getAlarmScope();
        if ((this$alarmScope == null) ? (other$alarmScope != null) : !this$alarmScope.equals(other$alarmScope))
            return false;
        if (getSendFileMaxThreads() != other.getSendFileMaxThreads()) return false;
        if (getCompressMaxThreads() != other.getCompressMaxThreads()) return false;
        if (getLimitBand() != other.getLimitBand()) return false;
        Object this$fieldSep = getFieldSep(), other$fieldSep = other.getFieldSep();
        if ((this$fieldSep == null) ? (other$fieldSep != null) : !this$fieldSep.equals(other$fieldSep)) return false;
        Object this$lineSep = getLineSep(), other$lineSep = other.getLineSep();
        if ((this$lineSep == null) ? (other$lineSep != null) : !this$lineSep.equals(other$lineSep)) return false;
        Object this$mode = getMode(), other$mode = other.getMode();
        if ((this$mode == null) ? (other$mode != null) : !this$mode.equals(other$mode)) return false;
        List<String> this$hosts = (List<String>) getHosts(), other$hosts = (List<String>) other.getHosts();
        if ((this$hosts == null) ? (other$hosts != null) : !this$hosts.equals(other$hosts)) return false;
        Object this$port = getPort(), other$port = other.getPort();
        if ((this$port == null) ? (other$port != null) : !this$port.equals(other$port)) return false;
        Object this$hostUser = getHostUser(), other$hostUser = other.getHostUser();
        if ((this$hostUser == null) ? (other$hostUser != null) : !this$hostUser.equals(other$hostUser)) return false;
        if (getTimeOut() != other.getTimeOut()) return false;
        if (getReTimes() != other.getReTimes()) return false;
        if (getWaitTime() != other.getWaitTime()) return false;
        Object this$isOpenPeriodDir = getIsOpenPeriodDir(), other$isOpenPeriodDir = other.getIsOpenPeriodDir();
        if ((this$isOpenPeriodDir == null) ? (other$isOpenPeriodDir != null) : !this$isOpenPeriodDir
                .equals(other$isOpenPeriodDir))
            return false;
        Object this$directory = getDirectory(), other$directory = other.getDirectory();
        if ((this$directory == null) ? (other$directory != null) : !this$directory.equals(other$directory))
            return false;
        Object this$destFilePermission = getDestFilePermission(),
                other$destFilePermission = other.getDestFilePermission();
        if ((this$destFilePermission == null) ? (other$destFilePermission != null) : !this$destFilePermission
                .equals(other$destFilePermission))
            return false;
        if (getAuthType() != other.getAuthType()) return false;
        Object this$password = getPassword(), other$password = other.getPassword();
        if ((this$password == null) ? (other$password != null) : !this$password.equals(other$password)) return false;
        Object this$privateKeyPass = getPrivateKeyPass(), other$privateKeyPass = other.getPrivateKeyPass();
        if ((this$privateKeyPass == null) ? (other$privateKeyPass != null) : !this$privateKeyPass
                .equals(other$privateKeyPass))
            return false;
        Object this$privateKeyFile = getPrivateKeyFile(), other$privateKeyFile = other.getPrivateKeyFile();
        if ((this$privateKeyFile == null) ? (other$privateKeyFile != null) : !this$privateKeyFile
                .equals(other$privateKeyFile))
            return false;
        Object this$damTaskId = getDamTaskId(), other$damTaskId = other.getDamTaskId();
        if ((this$damTaskId == null) ? (other$damTaskId != null) : !this$damTaskId.equals(other$damTaskId))
            return false;
        Object this$taskId = getTaskId(), other$taskId = other.getTaskId();
        if ((this$taskId == null) ? (other$taskId != null) : !this$taskId.equals(other$taskId)) return false;
        if (isCompress() != other.isCompress()) return false;
        if (isLzo() != other.isLzo()) return false;
        if (isZip() != other.isZip()) return false;
        Object this$zipPassword = getZipPassword(), other$zipPassword = other.getZipPassword();
        if ((this$zipPassword == null) ? (other$zipPassword != null) : !this$zipPassword.equals(other$zipPassword))
            return false;
        if (getSplitSize() != other.getSplitSize()) return false;
        if (getSplitCount() != other.getSplitCount()) return false;
        if (getWorkPolicy() != other.getWorkPolicy()) return false;
        Object this$odsName = getOdsName(), other$odsName = other.getOdsName();
        if ((this$odsName == null) ? (other$odsName != null) : !this$odsName.equals(other$odsName)) return false;
        Object this$deptCode = getDeptCode(), other$deptCode = other.getDeptCode();
        if ((this$deptCode == null) ? (other$deptCode != null) : !this$deptCode.equals(other$deptCode)) return false;
        Object this$filesTask = getFilesTask(), other$filesTask = other.getFilesTask();
        if ((this$filesTask == null) ? (other$filesTask != null) : !this$filesTask.equals(other$filesTask))
            return false;
        Object this$databaseTask = getDatabaseTask(), other$databaseTask = other.getDatabaseTask();
        if ((this$databaseTask == null) ? (other$databaseTask != null) : !this$databaseTask.equals(other$databaseTask))
            return false;
        List<String> this$usedHosts = (List<String>) getUsedHosts(), other$usedHosts
                = (List<String>) other.getUsedHosts();
        if ((this$usedHosts == null) ? (other$usedHosts != null) : !this$usedHosts.equals(other$usedHosts))
            return false;
        Object this$taskState = getTaskState(), other$taskState = other.getTaskState();
        if ((this$taskState == null) ? (other$taskState != null) : !this$taskState.equals(other$taskState))
            return false;
        Object this$monitorState = getMonitorState(), other$monitorState = other.getMonitorState();
        return ((this$monitorState == null) ? (other$monitorState != null) : !this$monitorState
                .equals(other$monitorState)) ? false : (!(isSendError() != other.isSendError()));
    }

    protected boolean canEqual(Object other) {
        return other instanceof TaskInfo;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $jobName = getJobName();
        result = result * 59 + (($jobName == null) ? 43 : $jobName.hashCode());
        Object $taskType = getTaskType();
        result = result * 59 + (($taskType == null) ? 43 : $taskType.hashCode());
        result = result * 59 + (isEnable() ? 79 : 97);
        result = result * 59 + (isOnlyTrans() ? 79 : 97);
        result = result * 59 + (isOnlyTransISRename() ? 79 : 97);
        Object $periodType = getPeriodType();
        result = result * 59 + (($periodType == null) ? 43 : $periodType.hashCode());
        Object $periodObject = getPeriodObject();
        result = result * 59 + (($periodObject == null) ? 43 : $periodObject.hashCode());
        Object $checkMode = getCheckMode();
        result = result * 59 + (($checkMode == null) ? 43 : $checkMode.hashCode());
        Object $destFileName = getDestFileName();
        result = result * 59 + (($destFileName == null) ? 43 : $destFileName.hashCode());
        result = result * 59 + (isAlarm() ? 79 : 97);
        Object $alarmLevel = getAlarmLevel();
        result = result * 59 + (($alarmLevel == null) ? 43 : $alarmLevel.hashCode());
        Object $alarmScope = getAlarmScope();
        result = result * 59 + (($alarmScope == null) ? 43 : $alarmScope.hashCode());
        result = result * 59 + getSendFileMaxThreads();
        result = result * 59 + getCompressMaxThreads();
        result = result * 59 + getLimitBand();
        Object $fieldSep = getFieldSep();
        result = result * 59 + (($fieldSep == null) ? 43 : $fieldSep.hashCode());
        Object $lineSep = getLineSep();
        result = result * 59 + (($lineSep == null) ? 43 : $lineSep.hashCode());
        Object $mode = getMode();
        result = result * 59 + (($mode == null) ? 43 : $mode.hashCode());
        List<String> $hosts = (List<String>) getHosts();
        result = result * 59 + (($hosts == null) ? 43 : $hosts.hashCode());
        Object $port = getPort();
        result = result * 59 + (($port == null) ? 43 : $port.hashCode());
        Object $hostUser = getHostUser();
        result = result * 59 + (($hostUser == null) ? 43 : $hostUser.hashCode());
        result = result * 59 + getTimeOut();
        result = result * 59 + getReTimes();
        result = result * 59 + getWaitTime();
        Object $isOpenPeriodDir = getIsOpenPeriodDir();
        result = result * 59 + (($isOpenPeriodDir == null) ? 43 : $isOpenPeriodDir.hashCode());
        Object $directory = getDirectory();
        result = result * 59 + (($directory == null) ? 43 : $directory.hashCode());
        Object $destFilePermission = getDestFilePermission();
        result = result * 59 + (($destFilePermission == null) ? 43 : $destFilePermission.hashCode());
        result = result * 59 + getAuthType();
        Object $password = getPassword();
        result = result * 59 + (($password == null) ? 43 : $password.hashCode());
        Object $privateKeyPass = getPrivateKeyPass();
        result = result * 59 + (($privateKeyPass == null) ? 43 : $privateKeyPass.hashCode());
        Object $privateKeyFile = getPrivateKeyFile();
        result = result * 59 + (($privateKeyFile == null) ? 43 : $privateKeyFile.hashCode());
        Object $damTaskId = getDamTaskId();
        result = result * 59 + (($damTaskId == null) ? 43 : $damTaskId.hashCode());
        Object $taskId = getTaskId();
        result = result * 59 + (($taskId == null) ? 43 : $taskId.hashCode());
        result = result * 59 + (isCompress() ? 79 : 97);
        result = result * 59 + (isLzo() ? 79 : 97);
        result = result * 59 + (isZip() ? 79 : 97);
        Object $zipPassword = getZipPassword();
        result = result * 59 + (($zipPassword == null) ? 43 : $zipPassword.hashCode());
        result = result * 59 + getSplitSize();
        result = result * 59 + getSplitCount();
        result = result * 59 + getWorkPolicy();
        Object $odsName = getOdsName();
        result = result * 59 + (($odsName == null) ? 43 : $odsName.hashCode());
        Object $deptCode = getDeptCode();
        result = result * 59 + (($deptCode == null) ? 43 : $deptCode.hashCode());
        Object $filesTask = getFilesTask();
        result = result * 59 + (($filesTask == null) ? 43 : $filesTask.hashCode());
        Object $databaseTask = getDatabaseTask();
        result = result * 59 + (($databaseTask == null) ? 43 : $databaseTask.hashCode());
        List<String> $usedHosts = (List<String>) getUsedHosts();
        result = result * 59 + (($usedHosts == null) ? 43 : $usedHosts.hashCode());
        Object $taskState = getTaskState();
        result = result * 59 + (($taskState == null) ? 43 : $taskState.hashCode());
        Object $monitorState = getMonitorState();
        result = result * 59 + (($monitorState == null) ? 43 : $monitorState.hashCode());
        return result * 59 + (isSendError() ? 79 : 97);
    }

    public String toString() {
        return "TaskInfo(jobName=" + getJobName() + ", taskType=" + getTaskType() + ", enable=" + isEnable()
                + ", onlyTrans=" + isOnlyTrans() + ", onlyTransISRename=" + isOnlyTransISRename() + ", periodType="
                + getPeriodType() + ", periodObject=" + getPeriodObject() + ", checkMode=" + getCheckMode()
                + ", destFileName=" + getDestFileName() + ", alarm=" + isAlarm() + ", alarmLevel=" + getAlarmLevel()
                + ", alarmScope=" + getAlarmScope() + ", sendFileMaxThreads=" + getSendFileMaxThreads()
                + ", compressMaxThreads=" + getCompressMaxThreads() + ", limitBand=" + getLimitBand()
                + ", fieldSep=" + getFieldSep() + ", lineSep=" + getLineSep() + ", mode=" + getMode()
                + ", hosts=" + getHosts() + ", port=" + getPort() + ", hostUser=" + getHostUser() + ", timeOut="
                + getTimeOut() + ", reTimes=" + getReTimes() + ", waitTime=" + getWaitTime() + ", isOpenPeriodDir="
                + getIsOpenPeriodDir() + ", directory=" + getDirectory() + ", destFilePermission="
                + getDestFilePermission() + ", authType=" + getAuthType() + ", password=" + getPassword()
                + ", privateKeyPass=" + getPrivateKeyPass() + ", privateKeyFile=" + getPrivateKeyFile()
                + ", damTaskId=" + getDamTaskId() + ", taskId=" + getTaskId() + ", isCompress=" + isCompress()
                + ", isLzo=" + isLzo() + ", isZip=" + isZip() + ", zipPassword=" + getZipPassword()
                + ", splitSize=" + getSplitSize() + ", splitCount=" + getSplitCount() + ", workPolicy="
                + getWorkPolicy() + ", odsName=" + getOdsName() + ", deptCode=" + getDeptCode() + ", filesTask="
                + getFilesTask() + ", databaseTask=" + getDatabaseTask() + ", usedHosts=" + getUsedHosts()
                + ", taskState=" + getTaskState() + ", monitorState=" + getMonitorState() + ", isSendError="
                + isSendError() + ")";
    }

    public String getJobName() {
        return this.jobName;
    }

    public String getTaskType() {
        return this.taskType;
    }

    public boolean isEnable() {
        return this.enable;
    }

    public boolean isOnlyTrans() {
        return this.onlyTrans;
    }

    public boolean isOnlyTransISRename() {
        return this.onlyTransISRename;
    }

    public String getPeriodType() {
        return this.periodType;
    }

    public PeriodObject getPeriodObject() {
        return this.periodObject;
    }

    public String getCheckMode() {
        return this.checkMode;
    }

    public String getDestFileName() {
        return this.destFileName;
    }

    public boolean isAlarm() {
        return this.alarm;
    }

    public String getAlarmLevel() {
        return this.alarmLevel;
    }

    public String getAlarmScope() {
        return this.alarmScope;
    }

    public int getSendFileMaxThreads() {
        return this.sendFileMaxThreads;
    }

    public int getCompressMaxThreads() {
        return this.compressMaxThreads;
    }

    public int getLimitBand() {
        return this.limitBand;
    }

    public String getFieldSep() {
        return this.fieldSep;
    }

    public String getLineSep() {
        return this.lineSep;
    }

    public String getMode() {
        return this.mode;
    }

    public List<String> getHosts() {
        return this.hosts;
    }

    public String getPort() {
        return this.port;
    }

    public String getHostUser() {
        return this.hostUser;
    }

    public int getTimeOut() {
        return this.timeOut;
    }

    public int getReTimes() {
        return this.reTimes;
    }

    public int getWaitTime() {
        return this.waitTime;
    }

    public String getIsOpenPeriodDir() {
        return this.isOpenPeriodDir;
    }

    public String getDirectory() {
        return this.directory;
    }

    public String getDestFilePermission() {
        return this.destFilePermission;
    }

    public int getAuthType() {
        return this.authType;
    }

    public String getPassword() {
        return this.password;
    }

    public String getPrivateKeyPass() {
        return this.privateKeyPass;
    }

    public String getPrivateKeyFile() {
        return this.privateKeyFile;
    }

    public String getDamTaskId() {
        return this.damTaskId;
    }

    public String getTaskId() {
        return this.taskId;
    }

    public boolean isCompress() {
        return this.isCompress;
    }

    public boolean isLzo() {
        return this.isLzo;
    }

    public boolean isZip() {
        return this.isZip;
    }

    public String getZipPassword() {
        return this.zipPassword;
    }

    public int getSplitSize() {
        return this.splitSize;
    }

    public int getSplitCount() {
        return this.splitCount;
    }

    public int getWorkPolicy() {
        return this.workPolicy;
    }

    public String getOdsName() {
        return this.odsName;
    }

    public String getDeptCode() {
        return this.deptCode;
    }

    public FilesTask getFilesTask() {
        return this.filesTask;
    }

    public DatabaseTask getDatabaseTask() {
        return this.databaseTask;
    }

    public List<String> getUsedHosts() {
        return this.usedHosts;
    }

    public DatapushState getTaskState() {
        return this.taskState;
    }

    public DatapushState getMonitorState() {
        return this.monitorState;
    }

    public boolean isSendError() {
        return this.isSendError;
    }
}