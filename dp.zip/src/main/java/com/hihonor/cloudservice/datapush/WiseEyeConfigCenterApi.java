package com.hihonor.cloudservice.datapush;

import com.hihonor.cloudservice.datapush.common.DateUtil;
import com.hihonor.cloudservice.datapush.common.FileDealUtil;
import com.hihonor.cloudservice.datapush.common.FilePathCheck;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.entity.SecretConfig;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.tasks.SshCheck;
import com.hihonor.cloudservice.datapush.tasks.WiseEyeConfigCenterController;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class WiseEyeConfigCenterApi {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(WiseEyeConfigCenterApi.class);

    /**
     * The Constant RANDOM.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final SecureRandom RANDOM = new SecureRandom();

    /**
     * The Constant SLEEP_WAIT_TIMES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int SLEEP_WAIT_TIMES = 250;

    /**
     * The Constant pullType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static int pullType;

    /**
     * The Constant scopeName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String scopeName;

    /**
     * The Constant appName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String appName;

    /**
     * The Constant versionName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String versionName;

    /**
     * The Constant tagName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String tagName;

    /**
     * The Constant wiseeyePath.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String wiseeyePath;

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String jobName;

    /**
     * The Constant sshPubkeyPath.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String sshPubkeyPath;

    /**
     * The Constant PATTERN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String PATTERN = "yyyyMMddHHmmss";

    /**
     * The Constant rootDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String rootDir;

    /**
     * The Constant unifiedPrivateKeys.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static List<SecretConfig> unifiedPrivateKeys = new ArrayList<>();

    /**
     * The Constant privatekeyfileIdRsa.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static List<SecretConfig> privatekeyfileIdRsa = new ArrayList<>();

    /**
     * The Constant sshPubKey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static List<SecretConfig> sshPubKey = new ArrayList<>();

    /**
     * The Constant sshPassword.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String sshPassword = "";

    /**
     * The Constant sshPrivateKey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String sshPrivateKey = "";

    /**
     * The Constant sshPublicKey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String sshPublicKey = "";

    /**
     * loadParams
     *
     * @param args String[]
     * @author z00502253
     * @since 2020-06-27
     */
    private static void loadParams(String[] args) throws DatapushException {
        if (args == null) {
            throw new DatapushException("args invalid");
        }
        for (String arg : args) {
            String[] params = arg.split("=");
            if (params.length != 2) {
                throw new DatapushException("args invalid");
            }
            String key = params[0];
            String value = params[1];
            switch (key) {
                case "pullType":
                    pullType = Integer.parseInt(value);
                    break;
                case "scopeName":
                    scopeName = value;
                    break;
                case "appName":
                    appName = value;
                    break;
                case "versionName":
                    versionName = value;
                    break;
                case "tagName":
                    tagName = value;
                    break;
                case "sshPubkeyPath":
                    sshPubkeyPath = value;
                    break;
                case "wiseeyePath":
                    wiseeyePath = FilePathCheck.checkFilePath(value);
                    break;
                case "jobName":
                    jobName = value;
                    break;
            }
        }
    }

    /**
     * loadConfig
     *
     * @author z00502253
     * @since 2020-06-27
     */
    private static Properties loadConfig() throws IOException {
        Properties properties = new Properties();
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(new String[]{rootDir
                + "/conf/wiseEye.properties"}))) {
            properties.load(in);
        }
        return properties;
    }

    /**
     * updateSecret
     *
     * @param itemList ArrayList
     * @author z00502253
     * @since 2022-06-27
     */
    private static void updateSecret(ArrayList<Map<String, Object>> itemList) throws IOException, DatapushException {
        for (Map<String, Object> map : itemList) {
            String key = map.get("key").toString();
            Object value = map.get("value");
            String status = map.get("status").toString();
            if ("release".equals(status)) {
                if (pullType == 0) {
                    if (key.startsWith("fruits_peach")) {
                        sshPubKey.add(getInstance(key, value, 2));
                    }
                    continue;
                }
                if (pullType == 5) {
                    if (key.startsWith("fruits_pears")) {
                        unifiedPrivateKeys.add(getInstance(key, value, 2));
                        continue;
                    }
                    if (key.startsWith("fruits_apples")) {
                        privatekeyfileIdRsa.add(getInstance(key, value, 2));
                        continue;
                    }
                    if ("cat".equals(key)) {
                        FileDealUtil.replaceAllContent(rootDir
                                + "/conf/properties/cat/cat", value, false);
                        continue;
                    }
                    if ("dog".equals(key)) {
                        FileDealUtil.replaceAllContent(rootDir
                                + "/conf/properties/dog/dog", value, false);
                        continue;
                    }
                    if ("dragon".equals(key)) {
                        FileDealUtil.replaceAllContent(rootDir + "/conf/properties/dragon/dragon",
                                value, false);
                        continue;
                    }
                    if ("pig".equals(key)) {
                        FileDealUtil.replaceAllContent(rootDir
                                + "/conf/properties/pig/pig", value, false);
                        continue;
                    }
                    if ("duck".equals(key)) {
                        FileDealUtil.replaceAllContent(rootDir + "/conf/properties/duck/duck",
                                value, false);
                        continue;
                    }
                    if ("zip_default".equals(key)) {
                        FileDealUtil.replacePropValue(rootDir + "/conf/datapush.properties",
                                "zip.default.key", value);
                        continue;
                    }
                    if ("da_sign".equals(key)) {
                        FileDealUtil.replacePropValue(rootDir + "/conf/datapush.properties",
                                "da.sign", value);
                        continue;
                    }
                    if ("da_work".equals(key)) {
                        FileDealUtil.replacePropValue(rootDir + "/conf/datapush.properties",
                                "da.work", value);
                        continue;
                    }
                    if ("wiseeye_config_center_api".equals(key)) {
                        FileDealUtil.replacePropValue(rootDir + "/conf/wiseEye.properties",
                                "config_center_apikey", CryptService.encryptAes(value.toString()));
                    }
                    continue;
                }
                if (key.startsWith("fruits_pears")) {
                    unifiedPrivateKeys.add(getInstance(key, value, 2));
                    continue;
                }
                if (key.startsWith("fruits_apples")) {
                    privatekeyfileIdRsa.add(getInstance(key, value, 2));
                }
            }
        }
        getSshKeyInfo();
        if (pullType == 0) {
            startReplace();
        } else if (SshCheck.start(sshPassword, parseJobName())) {
            log.info("ssh connection success");
            startReplace();
        } else {
            throw new DatapushException("SSH connection verification failed. ");
        }
    }

    /**
     * parseJobName
     *
     * @return List
     * @author z00502253
     * @since 2022-06-27
     */
    private static List<String> parseJobName() throws IOException {
        Properties jobInfo;
        String[] fileJobNames, dbJobNames;
        Properties iacJobInfo;
        List<String> jobNames = new ArrayList<>();
        switch (pullType) {
            case 1:
                jobInfo = new Properties();
                try (InputStreamReader jobInfoIn = new InputStreamReader(new FileInputStream(wiseeyePath
                        + "/jobs_info.ini"), "UTF-8")) {

                    jobInfo.load(jobInfoIn);
                }
                fileJobNames = jobInfo.getProperty("file_jobNames").split("\\|");
                for (String fileJobName : fileJobNames) {
                    jobNames.add(fileJobName.split("-")[0]);
                }

                dbJobNames = jobInfo.getProperty("db_jobNames").split("\\|");
                for (String dbJobName : dbJobNames) {
                    jobNames.add(dbJobName.split("-")[0]);
                }
                break;
            case 2:
                iacJobInfo = new Properties();
                try (InputStreamReader iacJobInfoIn = new InputStreamReader(new FileInputStream(wiseeyePath
                        + "/iac_jobs_info.ini"), "UTF-8")) {

                    iacJobInfo.load(iacJobInfoIn);
                }
                jobNames.add(iacJobInfo.getProperty("jobName"));
                break;
            case 3:
                jobNames.add(jobName);
                break;
            case 5:
                jobNames.add(jobName);
                break;
        }
        return jobNames;
    }

    /**
     * getInstance
     *
     * @param key String
     * @param value Object
     * @param index int
     * @return vo
     * @author z00502253
     * @since 2022-06-27
     */
    private static SecretConfig getInstance(String key, Object value, int index) throws DatapushException {
        SecretConfig secretConfig = new SecretConfig();
        String[] keyArray = key.split("_");
        secretConfig.setKey(key.replace("_" + keyArray[index], ""));
        secretConfig.setValue(value);
        try {
            secretConfig.setExpiredTime(DateUtil.parseDate(keyArray[index], "yyyyMMddHHmmss"));
        } catch (ParseException e) {
            throw new DatapushException(key + " key invalid", e);
        }
        return secretConfig;
    }

    /**
     * getSshKeyInfo
     *
     * @author z00502253
     * @since 2022-06-27
     */
    private static void getSshKeyInfo() throws IOException {
        if (pullType == 0) {
            if (sshPubKey.size() > 0) {
                if (sshPubKey.size() > 1) {
                    Collections.sort(sshPubKey, (secretConfig1, secretConfig2) -> secretConfig2.getExpiredTime()
                            .compareTo(secretConfig1.getExpiredTime()));
                }

                sshPublicKey = ((SecretConfig) sshPubKey.get(0)).getValue().toString();
            } else {
                throw new DatapushException("ssh_pub_key key missing");
            }
        } else {
            if (unifiedPrivateKeys.size() > 0) {
                if (unifiedPrivateKeys.size() > 1) {
                    Collections.sort(unifiedPrivateKeys, (secretConfig1, secretConfig2) -> secretConfig2
                            .getExpiredTime().compareTo(secretConfig1.getExpiredTime()));
                }

                sshPassword = ((SecretConfig) unifiedPrivateKeys.get(0)).getValue().toString();
            } else {
                throw new DatapushException("unified_private_key key missing");
            }
            if (privatekeyfileIdRsa.size() > 0) {
                if (privatekeyfileIdRsa.size() > 1) {
                    Collections.sort(privatekeyfileIdRsa, (secretConfig1, secretConfig2) -> secretConfig2
                            .getExpiredTime().compareTo(secretConfig1.getExpiredTime()));
                }

                sshPrivateKey = ((SecretConfig) privatekeyfileIdRsa.get(0)).getValue().toString();
                FileDealUtil.replaceAllContent(rootDir + "/fruits/apricots", ((SecretConfig) privatekeyfileIdRsa
                        .get(0)).getValue(), false);
            } else {
                throw new DatapushException("privatekeyfile_id_rsa key missing");
            }
        }
    }

    /**
     * startReplace
     *
     * @author z00502253
     * @since 2022-06-27
     */
    private static void startReplace() throws IOException {
        log.info("ssh connection success，start replace ssh private key...");
        if (pullType == 0) {
            FileDealUtil.replaceAllContent(sshPubkeyPath, sshPublicKey, true);
        } else {
            FileDealUtil.replaceAllContent(rootDir + "/fruits/pears", sshPassword, false);
            FileDealUtil.replaceAllContent(rootDir + "/fruits/apples", sshPrivateKey, false);
        }
        log.info("ssh connection success，end replace ssh private key...");
    }

    /**
     * main
     *
     * @param args String[]
     * @author z00502253
     * @since 2022-06-30
     */
    public static void main(String[] args) {
        boolean isSuccess = true;
        Thread.currentThread().setName("WiseEyeConfigCenterApi");
        log.info("secret update start...");
        try {
            loadParams(args);
            if (pullType == 4) {
                int chose = RANDOM.nextInt(250);
                Thread.sleep(chose * 1000L);
            }
            rootDir = Paths.get(System.getProperty("user.dir"), new String[0]).toString();
            Util.loadLogBack(rootDir + File.separator + "conf" + File.separator + "pull_secret_logback.xml");
            Properties properties = loadConfig();
            WiseEyeConfigCenterController wiseEyeConfigCenterController = new WiseEyeConfigCenterController(pullType,
                    properties);
            int scopeId = wiseEyeConfigCenterController.getScope(scopeName);
            int appId = wiseEyeConfigCenterController.getApp(scopeId, appName);
            int versionId = wiseEyeConfigCenterController.getVersion(appId, versionName);
            int tagId = wiseEyeConfigCenterController.getTag(versionId, tagName);

            ArrayList<Map<String, Object>> itemList = wiseEyeConfigCenterController.getConfigItem(scopeId, appId,
                    versionId, tagId);
            updateSecret(itemList);
        } catch (Exception e) {
            log.error("secret update error", e);
            isSuccess = false;
        } finally {
            if (!isSuccess) {
                log.info("secret update failed");
                System.exit(1);
            } else {
                log.info("secret update success");
            }
        }
        log.info("secret update end...");
    }
}