package com.hihonor.cloudservice.datapush.jsch;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-06
 */
public class Cmd {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(Cmd.class);

    /**
     * The Constant sshInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Ssh sshInfo;

    public Cmd(Ssh sshInfo) {
        this.sshInfo = sshInfo;
    }

    /**
     * run
     *
     * @author z00502253
     * @since 2020-06-23
     */
    public void run() throws DatapushException, JSchException, IOException {
        ByteArrayOutputStream errorOut = new ByteArrayOutputStream(1024);
        InputStream in = null;
        Session session = null;
        ChannelExec channel = null;
        try {
            session = this.sshInfo.getConnection();
            log.info("ssh connect success...");
            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand(this.sshInfo.getCommand());
            channel.setInputStream(null);
            channel.setErrStream(errorOut);
            in = channel.getInputStream();
            channel.connect(this.sshInfo.getTimeOut());
            log.info("channel connect success...");
            checkCmdResult(channel, in, errorOut);
            if (this.sshInfo.getCommand().contains("unzip")) {
                log.info("[{}] unzip run success", this.sshInfo.getCommand());
            } else {
                log.info("[{}] run success", this.sshInfo.getCommand());
            }
        } finally {
            Util.closeQuietly(in);
            Util.closeQuietly(errorOut);
            if (null != channel) {
                channel.disconnect();
            }
            if (null != session) {
                session.disconnect();
            }
        }
    }

    /**
     * checkCmdResult
     *
     * @param channel channel
     * @param in in
     * @param errorOut errorOut
     * @author z00502253
     * @since 2022-07-01
     */
    private void checkCmdResult(ChannelExec channel, InputStream in, ByteArrayOutputStream errorOut)
            throws IOException, DatapushException {
        byte[] tmp = new byte[1024];
        while (in.available() > 0) {
            int cmdByte = in.read(tmp, 0, tmp.length);
            if (cmdByte < 0) {
                break;
            }
        }
        if (!channel.isClosed()) {
            Util.sleep(1000L);
            checkCmdResult(channel, in, errorOut);
        }
        if (in.available() > 0) {
            checkCmdResult(channel, in, errorOut);
        }
        String errorMsg = errorOut.toString("UTF-8");
        if (Util.isNotEmpty(errorMsg)) {
            log.info("errorOut--------->{}", errorMsg);
        }
        if (channel.getExitStatus() != 0) {
            String error = "code : " + channel.getExitStatus() + ",msg : " + errorMsg;
            log.error(error);
            throw new DatapushException(error);
        }
    }
}
