package com.hihonor.cloudservice.datapush.io.writer;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.io.FilesBlock;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-05
 */
public class FileLineWriter extends FileJobWriter implements Callable<Boolean> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FileLineWriter.class);

    public FileLineWriter(Path file, long averageSize) {
        super(file, averageSize);
    }

    /**
     * call
     *
     * @return Boolean
     * @author z00502253
     * @since 2020-02-16
     */
    public Boolean call() {
        BufferedWriter writer = null;
        boolean isExit = false;
        try {
            writer = new BufferedWriter(new OutputStreamWriter(FileUtils.openOutputStream(this.source),
                    StandardCharsets.UTF_8), 4194304);
            writeLine(writer);
            isExit = true;
        } catch (IOException | InterruptedException | UnsupportedOperationException | DatapushException e) {
            log.error("write writeFile thread error", e);
        } finally {
            Util.closeQuietly(writer);
            if (this.channel != null) {
                this.channel.setActive(false);
            }
        }
        log.debug("write-{} exit------>{}", Long.valueOf(Thread.currentThread().getId()), this.source.getName());
        return Boolean.valueOf(isExit);
    }

    /**
     * writeLine
     *
     * @param writer writer
     * @author z00502253
     * @since 2022-08-15
     */
    private void writeLine(BufferedWriter writer) throws InterruptedException, IOException,
            UnsupportedOperationException, DatapushException {
        int i = 0;
        selectChannel();
        long startTime = System.currentTimeMillis();
        while (true) {
            if (this.channel.isError()) {
                throw new DatapushException("line read channel error");
            }
            FilesBlock filesBlock = this.channel.getFilesBlocks().poll(100L, TimeUnit.MILLISECONDS);
            if (filesBlock == null) {
                continue;
            }
            if (i == 0) {
                log.info("line write start----->{}", this.source.getName());
                startTime = System.currentTimeMillis();
                i++;
            }
            if (filesBlock.getDataLine() != null) {
                writer.write(filesBlock.getDataLine());
                writer.newLine();
                writer.flush();
                this.currentSize += filesBlock.getDataLine().length();
                print(this.source.getName());
            }
            if (filesBlock.isEndTag()) {
                if (this.processList.size() > 0 && ((String)
                        this.processList.get(this.processList.size() - 1)).equals("100")) {
                    log.info("line write process--->{}({}%)", this.source.getName(),
                            this.processList.get(this.processList.size() - 1));
                }
                log.info("line write end------->{}(size = {}, use times = {} ms)",
                        new Object[]{this.source.getName(), Long.valueOf(this.source.length()),
                        Long.valueOf(System.currentTimeMillis() - startTime)});
                return;
            }
        }
    }
}