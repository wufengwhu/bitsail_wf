package com.hihonor.cloudservice.datapush.io;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 * 功能描述
 *
 * @since 2022-05-05
 */
public class FilesChannel {

    /**
     * The Constant tag.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String tag;

    /**
     * The Constant isActive.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isActive;

    /**
     * The Constant isError.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isError;

    /**
     * The Constant filesBlocks.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private BlockingQueue<FilesBlock> filesBlocks;

    public void setTag(String tag) {
        this.tag = tag;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public void setError(boolean isError) {
        this.isError = isError;
    }

    public void setFilesBlocks(BlockingQueue<FilesBlock> filesBlocks) {
        this.filesBlocks = filesBlocks;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-24
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof FilesChannel)) return false;
        FilesChannel other = (FilesChannel) o;
        if (!other.canEqual(this)) return false;
        Object this$tag = getTag(), other$tag = other.getTag();
        if ((this$tag == null) ? (other$tag != null) : !this$tag.equals(other$tag)) return false;
        if (isActive() != other.isActive()) return false;
        if (isError() != other.isError()) return false;
        BlockingQueue<FilesBlock> this$filesBlocks = (BlockingQueue<FilesBlock>) getFilesBlocks(),
                other$filesBlocks = (BlockingQueue<FilesBlock>) other.getFilesBlocks();
        return !((this$filesBlocks == null) ? (other$filesBlocks != null)
                : !this$filesBlocks.equals(other$filesBlocks));
    }

    /**
     * canEqual
     *
     * @param other Object
     * @return boolean
     * @author z00502253
     * @since 2022-08-15
     */
    protected boolean canEqual(Object other) {
        return other instanceof FilesChannel;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-24
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $tag = getTag();
        result = result * 59 + (($tag == null) ? 43 : $tag.hashCode());
        result = result * 59 + (isActive() ? 79 : 97);
        result = result * 59 + (isError() ? 79 : 97);
        BlockingQueue<FilesBlock> $filesBlocks = (BlockingQueue<FilesBlock>) getFilesBlocks();
        return result * 59 + (($filesBlocks == null) ? 43 : $filesBlocks.hashCode());
    }

    public String toString() {
        return "FilesChannel(tag=" + getTag() + ", isActive=" + isActive() + ", isError=" + isError()
                + ", filesBlocks=" + getFilesBlocks() + ")";
    }

    public String getTag() {
        return this.tag;
    }

    public boolean isActive() {
        return this.isActive;
    }

    public boolean isError() {
        return this.isError;
    }

    public BlockingQueue<FilesBlock> getFilesBlocks() {
        return this.filesBlocks;
    }

    public FilesChannel(String tag, int initSize) {
        this.tag = tag;
        this.isActive = false;
        this.isError = false;
        this.filesBlocks = new ArrayBlockingQueue<>(initSize);
    }
}