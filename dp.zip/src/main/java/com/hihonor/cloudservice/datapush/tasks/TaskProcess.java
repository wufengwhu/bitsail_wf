package com.hihonor.cloudservice.datapush.tasks;


import com.hihonor.cloudservice.datapush.entity.FileSource;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;
import com.hihonor.cloudservice.datapush.jsch.Ssh;
import com.hihonor.cloudservice.datapush.GlobalVariable;
/*     */ import com.hihonor.cloudservice.datapush.common.CacheDestHost;
/*     */ import com.hihonor.cloudservice.datapush.common.FindDirUtil;
/*     */ import com.hihonor.cloudservice.datapush.common.FindFileUtil;
/*     */ import com.hihonor.cloudservice.datapush.common.LocalCmdUtil;
/*     */ import com.hihonor.cloudservice.datapush.common.Util;
/*     */
/*     */
/*     */
/*     */
/*     */ import com.hihonor.cloudservice.datapush.io.WriteFileThread;
/*     */ import com.hihonor.cloudservice.datapush.jsch.Cmd;
/*     */ import com.hihonor.cloudservice.datapush.jsch.Scp;
/*     */
/*     */ import com.jcraft.jsch.JSchException;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;

/**
 * The Class TaskProcess.
 *
 * @since 2022-04-24
 */
public class TaskProcess {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(TaskProcess.class);

    /**
     * The Constant globalVariable.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final GlobalVariable globalVariable = GlobalVariable.getInstance();

    /**
     * The Constant sshBuilder.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final Ssh.SshBuilder sshBuilder = Ssh.builder();

    /**
     * The Constant taskInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final TaskInfo taskInfo;

    /**
     * The Constant work.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final Path work;

    /**
     * The Constant backUp.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final Path backUp;

    /**
     * The Constant tmpDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final Path tmpDir;

    /**
     * The Constant host.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String host;

    /**
     * The Constant hostTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public int hostTimes;

    /**
     * The Constant workFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public ArrayList<Path> workFiles;

    /**
     * The Constant checkTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public int checkTimes;

    /**
     * The Constant checkFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final ArrayList<Path> checkFiles;

    /**
     * The Constant isSplit.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public boolean isSplit;

    /**
     * The Constant averageCount.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public int averageCount;

    /**
     * The Constant averageSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public long averageSize;

    /**
     * The Constant forciblyUseOrigin.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public boolean forciblyUseOrigin;

    /**
     * The Constant remoteFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public ArrayList<String> remoteFiles;

    /**
     * The Constant random.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final SecureRandom random = new SecureRandom();

    /**
     * The Constant mfsDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String mfsDir;

    /**
     * The Constant sendTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int sendTimes;


    public TaskProcess(TaskInfo taskInfo, String taskId) {
        this.taskInfo = taskInfo;
        this.work = Paths.get(this.globalVariable.workDir, new String[]{taskId});
        this.backUp = Paths.get(this.globalVariable.rootDir, new String[]{"backup"});
        this.tmpDir = Paths.get(taskInfo.getDirectory(), new String[]{"temp", taskId});
        this.mfsDir = taskInfo.getDirectory();
        this.sshBuilder.jobName(taskInfo.getJobName())
                .userName(taskInfo.getHostUser())
                .port(Util.getInt(taskInfo.getPort(), this.globalVariable.programConfig.getSshPort()))
                .timeOut(taskInfo.getTimeOut())
                .limitBand(taskInfo.getLimitBand())
                .destFilePermission(taskInfo.getDestFilePermission());
        if (taskInfo.getAuthType() == 1) {
            this.sshBuilder.password(taskInfo.getPassword());
        } else {
            this.sshBuilder.passphrase(taskInfo.getPrivateKeyPass()).keyFile(taskInfo.getPrivateKeyFile());
        }
        this.hostTimes = taskInfo.getReTimes();
        this.workFiles = new ArrayList<>();
        this.sendTimes = taskInfo.getReTimes();
        this.remoteFiles = new ArrayList<>();
        this.checkFiles = new ArrayList<>();
        this.forciblyUseOrigin = false;
    }

    /**
     * init
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void init() throws DatapushException {
        log.info("task run start...");
        try {
            if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888") &&
                    this.taskInfo.getFilesTask() != null) {
                this.taskInfo.getFilesTask().setSourcePolicy(3);
                this.taskInfo.getFilesTask().setCheckFileCount(0);
                this.taskInfo.getFilesTask().setCheckFileSize(0);
                FileSource fileSource = new FileSource();
                fileSource.setDirectory(this.globalVariable.rootDir + "/vtask/");
                fileSource.setFileDepth(1);
                List<FileSource> fileSources = new ArrayList<>();
                fileSources.add(fileSource);
                this.taskInfo.getFilesTask().setFileSources(fileSources);
                this.taskInfo.getFilesTask().setFilesMask(new ArrayList(Collections.singletonList("1888*.txt")));
            }

            if (!this.forciblyUseOrigin && !Files.exists(this.work, new java.nio.file.LinkOption[0]) &&
                    this.work.toFile().mkdirs()) {
                log.debug("create work success---->{}", this.work);
            }

            if (!Files.exists(this.backUp, new java.nio.file.LinkOption[0]) &&
                    this.backUp.toFile().mkdirs()) {
                log.debug("create backup success---->{}", this.backUp);
            }
        } catch (SecurityException e) {
            log.error("create dir error", e);
            throw new DatapushException(e);
        }
    }

    /**
     * getHost
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void getHost() throws DatapushException {
        boolean isUsedLocal = true;
        if (this.globalVariable.damConfig.isOpen()) {
            DamController damController = new DamController(this.globalVariable.damConfig);
            try {
                String[] value = damController.pushRequest(buildRequest());
                if ("400".equals(value[1])) {
                    throw new DatapushException("Dam pushRequest return error = " + value[2]);
                }

                if ("101".equals(value[0])) {
                    log.error("The task was repeated execute, {} job exit!", this.taskInfo.getJobName());
                    this.taskInfo.setTaskState(DatapushState.REPEAT);
                    throw new DatapushException("The task " + this.taskInfo.getJobName() + " was repeated execute!");
                }
                if (!"0".equals(value[0])) {
                    throw new DatapushException("Dam pushRequest return error message=code is not zero");
                }
                if (Util.isNotEmpty(value[3])) {
                    this.taskInfo.setDamTaskId(value[3]);
                }
                if (Util.isEmpty(value[4])) {
                    throw new DatapushException("Dam pushRequest return error message=ip is null");
                }
                this.host = value[4];
                CacheDestHost.modify(this.taskInfo.getJobName(), this.host);

                isUsedLocal = false;
            } catch (DatapushException e) {
                if (this.taskInfo.getTaskState() == DatapushState.REPEAT) {
                    log.warn("file check mode is repeat, the Dam cannot be connected.");
                    throw new DatapushException(e);
                }
                log.warn("Dam pushRequest Fail...{}", e.getMessage());
                this.host = CacheDestHost.getHostByDestHostFile(this.taskInfo.getJobName());
                if (Util.isNotEmpty(this.host)) {
                    isUsedLocal = false;
                } else {
                    log.error("Dam putRequest error", (Throwable) e);
                }
            }
        }
        if (isUsedLocal) {
            log.warn("Start to randomly obtain the target host from the task configuration file.");
            int chose = this.random.nextInt(this.taskInfo.getHosts().size());
            this.host = this.taskInfo.getHosts().get(chose);
        }
        log.info("Push node ip={}, port={}", this.host, Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                this.globalVariable.programConfig
                .getSshPort())));
        mkdirDir();
    }

    /**
     * mkdirDir
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void mkdirDir() {
        boolean isOpenPeriodDir = Util.isNotEmpty(this.taskInfo.getIsOpenPeriodDir())
                ? Boolean.parseBoolean(this.taskInfo.getIsOpenPeriodDir())
                : this.globalVariable.programConfig.isOpenPeriodDir();
        if (isOpenPeriodDir) {
            this.taskInfo.setDirectory(

                    Paths.get(this.mfsDir, new String[]{
                            Util.getTimeStr(this.taskInfo.getPeriodObject().getPeriodType(), this.taskInfo
                                    .getPeriodObject().getPeriodTime())
                    }).toString());
        }
        String dirCmd = "mkdir -p " + this.taskInfo.getDirectory() + ";mkdir -p " + this.tmpDir + ";";
        this.sshBuilder.host(this.host).command(dirCmd);
        Cmd cmd = new Cmd(this.sshBuilder.build());
        Future<String> future = this.globalVariable.sshPool.submit(new CommonThread(cmd,
                this.taskInfo.getJobName() + "_mkdirDir"));
        try {
            String state = future.get(2L, TimeUnit.HOURS);
            if (!state.equals(DatapushState.SUCCESS.getDetail())) {
                throw new DatapushException(state);
            }
        } catch (InterruptedException | java.util.concurrent.ExecutionException
                | java.util.concurrent.TimeoutException | DatapushException e) {
            this.hostTimes--;
            this.taskInfo.getUsedHosts().add(this.host);
            if (this.hostTimes == -1) {
                throw new DatapushException(e);
            }
            Util.sleep(this.taskInfo.getWaitTime());
            getHost();
        }
    }

    /**
     * checkFile
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void checkFile() throws DatapushException {
        if (this.taskInfo.getFilesTask().getFileSources().size() != this.taskInfo
                .getFilesTask().getFilesMask().size()) {
            throw new DatapushException("file config error,the number of file sources " +
                    "is inconsistent with that of file rules");
        }

        this.checkFiles.clear();
        try {
            for (int i = 0; i < this.taskInfo.getFilesTask().getFileSources().size(); i++) {
                FileSource fileSource = this.taskInfo.getFilesTask().getFileSources().get(i);
                List<Path> pathList = new ArrayList<>();
                Path parentPath = Paths.get(fileSource.getDirectory(), new String[0]);
                if (Util.isNotEmpty(fileSource.getChildDirRegex())) {
                    pathList = (new FindDirUtil(2)).getDirByRegex(parentPath,
                            fileSource.getChildDirRegex().replace("*", ".*"));
                } else {
                    pathList.add(parentPath);
                }
                for (Path path : pathList) {
                    log.info("check file source dir = {}", path);
                    if (Files.notExists(path, new java.nio.file.LinkOption[0])) {
                        log.warn("{} not exists", path);
                        this.taskInfo.setTaskState(DatapushState.FILE_PATH_NOT_EXIST);
                        throw new DatapushException(DatapushState.FILE_PATH_NOT_EXIST.getDetail());
                    }
                    String match = this.taskInfo.getFilesTask().getFilesMask().get(i);
                    if (match.contains("*")) {
                        match = match.replace("*", ".*");
                    }
                    try {
                        this.checkFiles.addAll((new FindFileUtil(fileSource.getFileDepth()))
                                .getFileByRegex(path, match));
                    } catch (IOException e) {
                        log.error("", e);
                    }
                }
            }
            startCheck();
        } catch (IOException e) {
            throw new DatapushException(e);
        }
    }

    /**
     * startCheck
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void startCheck() {
        if (this.taskInfo.getFilesTask().getCheckFileSize() != 0 || this.taskInfo.getFilesTask()
                .getCheckFileCount() != 0) {
            this.checkTimes--;
            if (this.checkTimes == -1) {
                if (!this.globalVariable.programConfig.isCreateEmptyFile() && this.checkFiles.size() == 0) {
                    log.error("check file is empty");
                    this.taskInfo.setMonitorState(DatapushState.FILE_EMPTY);
                    throw new DatapushException(DatapushState.FILE_EMPTY);
                }
                this.taskInfo.setMonitorState(DatapushState.FILE_QUALITY_NON_COMPLIANCE);
                throw new DatapushException(DatapushState.FILE_QUALITY_NON_COMPLIANCE);
            }

            if (this.taskInfo.getFilesTask().getCheckFileSize() > 0) {
                long totalSize = Util.getPathsSize(this.checkFiles);
                if (totalSize < this.taskInfo.getFilesTask().getCheckFileSize() * 1024L * 1024L) {
                    log.info("check file threshold again");
                    Util.sleep(this.taskInfo.getFilesTask().getCheckWaitTimes());
                    checkFile();
                }
            } else if (this.taskInfo.getFilesTask().getCheckFileCount() > 0) {
                if (this.checkFiles.size() < this.taskInfo.getFilesTask().getCheckFileCount()) {
                    log.info("check file threshold again");
                    Util.sleep(this.taskInfo.getFilesTask().getCheckWaitTimes());
                    checkFile();
                }
            } else {
                log.debug("checkTimes = {}", Integer.valueOf(this.checkTimes));
            }
        }

        if (!this.globalVariable.programConfig.isCreateEmptyFile() && this.checkFiles.size() == 0) {
            log.error("check file is empty");
            this.taskInfo.setMonitorState(DatapushState.FILE_EMPTY);
            throw new DatapushException(DatapushState.FILE_EMPTY);
        }
        log.info("check file size = {}", Integer.valueOf(this.checkFiles.size()));
        log.info("check file threshold success");
    }

    /**
     * touchEmptyFile
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void touchEmptyFile() {
        try {
            if (this.globalVariable.programConfig.isCreateEmptyFile() && this.checkFiles.size() == 0) {
                if (!Files.exists(this.work, new java.nio.file.LinkOption[0]) &&
                        this.work.toFile().mkdirs()) {
                    log.debug("create work success---->{}", this.work);
                }

                Path empty = Paths.get(this.work.toString(),
                        new String[]{this.taskInfo.getDestFileName().replace("${num}", "1")});
                Files.createFile(empty, (FileAttribute<?>[]) new FileAttribute[0]);
                this.checkFiles.add(empty);
            }
        } catch (IOException e) {
            throw new DatapushException("empty file create fail");
        }
    }

    /**
     * copyFileByJDK
     *
     * @param checkFiles List
     * @author z00502253
     * @since 2022-06-28
     */
    public void copyFileByJDK(List<Path> checkFiles) throws DatapushException {
        log.info("copy files by io...");
        if (this.forciblyUseOrigin) {
            this.workFiles.addAll(checkFiles);
        } else {
            List<Path> tmp;
            long totalSize = Util.getPathsSize(checkFiles);
            if (this.taskInfo.getSplitSize() == 0 && this.taskInfo.getSplitCount() == 0) {
                this.isSplit = false;
                this.averageSize = totalSize;
                this.averageCount = 1;
            } else if (this.taskInfo.getSplitSize() != 0) {
                this.averageSize = this.taskInfo.getSplitSize() * 1024L * 1024L;
                this.averageCount = (int) (totalSize / this.averageSize);
                if (totalSize % this.averageSize != 0L) {
                    this.averageCount++;
                }
                this.isSplit = true;
            } else {
                this.averageSize = totalSize / this.taskInfo.getSplitCount();
                this.averageCount = this.taskInfo.getSplitCount();
                this.isSplit = true;
            }
            if (this.averageCount == 0) {
                this.averageCount = 1;
            }
            WriteFileThread writeFileThread = new WriteFileThread(this.taskInfo.getJobName(), 1, checkFiles);
            writeFileThread.extend(this.averageCount, this.averageSize, Paths.get(this.work.toString(),
                    new String[]{this.taskInfo.getDestFileName()}), this.isSplit);

            Future<List<Path>> task = this.globalVariable.subPool.submit((Callable<List<Path>>) writeFileThread);

            try {
                tmp = task.get();
            } catch (InterruptedException | java.util.concurrent.ExecutionException e) {
                throw new DatapushException("copy file to work by jvm error", e);
            }
            if (tmp != null) {
                this.workFiles = new ArrayList<>(tmp);
            }
        }

        log.info("split files = {}", this.workFiles);
    }

    /**
     * compressFile
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void compressFile() throws DatapushException {
        if (this.taskInfo.isLzo()) {
            StringBuilder lzoMessage = new StringBuilder();
            for (int i = 0; i < this.workFiles.size(); i++) {
                Path lzoFile = Paths.get(this.work.toString(),
                        new String[]{((Path) this.workFiles.get(i)).getFileName() + ".lzo"});
                lzoMessage.append("lzop ");
                lzoMessage.append("-o ").append(lzoFile.toString())
                        .append(" ")
                        .append(((Path) this.workFiles.get(i)).toString())
                        .append(";");
                this.workFiles.set(i, lzoFile);
            }
            LocalCmdUtil localCmd = new LocalCmdUtil(this.taskInfo.getJobName(), lzoMessage.toString());
            String state = localCmd.run();
            if (!state.equals(DatapushState.SUCCESS.getDetail())) {
                throw new DatapushException(state);
            }
        } else if (this.taskInfo.isZip()) {
            StringBuilder zipMessage = new StringBuilder();
            StringBuilder zipLog = new StringBuilder();
            for (int i = 0; i < this.workFiles.size(); i++) {
                Path zipFile = Paths.get(this.work.toString(),
                        new String[]{((Path) this.workFiles.get(i)).getFileName() + ".zip"});
                zipMessage.append("zip -j -9 ");
                String zipPW = this.taskInfo.getZipPassword();
                if (Util.isEmpty(zipPW)) {
                    zipPW = this.globalVariable.programConfig.getZipKey();
                }
                if (Util.isNotEmpty(zipPW)) {
                    zipMessage.append("-P ").append(zipPW).append(" ");
                }
                zipMessage.append(zipFile.toString()).append(" ").append(((Path) this.workFiles
                        .get(i)).toString()).append(";");

                zipLog.append("zip -j -9 ");
                if (Util.isNotEmpty(zipPW)) {
                    zipLog.append("-P ").append(zipPW).append(" ");
                }
                zipLog.append(zipFile.toString()).append(" ").append(((Path) this.workFiles
                        .get(i)).toString()).append(";");
                this.workFiles.set(i, zipFile);
            }
            LocalCmdUtil localCmd = new LocalCmdUtil(this.taskInfo.getJobName(), zipMessage
                    .toString(), zipLog.toString());
            String state = localCmd.run();
            if (!state.equals(DatapushState.SUCCESS.getDetail())) {
                throw new DatapushException(state);
            }
        } else {
            log.debug("no compress");
        }
    }

    /**
     * scpFile
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void scpFile() throws DatapushException {
        this.sshBuilder.host(this.host).remotePath(this.tmpDir.toString());
        List<Future<String>> futureList = new ArrayList<>();
        for (int i = 0; i < this.workFiles.size(); i++) {
            Path workFile = this.workFiles.get(i);
            this.sshBuilder.localFile(workFile.toFile());
            this.remoteFiles.add(Paths.get(this.tmpDir.toString(),
                    new String[]{workFile.toFile().getName()}).toString());

            Ssh ssh = this.sshBuilder.build();
            if (this.taskInfo.getMode().equalsIgnoreCase("rsync")) {
                StringBuilder rsyncStr = new StringBuilder();
                rsyncStr.append(this.globalVariable.rootDir)
                        .append("/bin/rsync_privatekey.exp ")
                        .append(ssh.getKeyFile())
                        .append(" ").append(workFile.toString())
                        .append(" ").append(ssh.getUserName())
                        .append(" ").append(ssh.getHost())
                        .append(" ").append(ssh.getRemotePath());
                if (this.forciblyUseOrigin && this.taskInfo.isOnlyTransISRename() && this.taskInfo
                        .getDestFileName().contains("${num}")) {
                    rsyncStr.append("/").append(this.taskInfo.getDestFileName().replace("${num}",
                            "" + (i + 1)));
                } else {
                    rsyncStr.append("/").append(workFile.getFileName());
                }
                rsyncStr.append(" ").append(ssh.getPassphrase());
                log.info("rsync = {}", rsyncStr);
                LocalCmdUtil cmdUtil = new LocalCmdUtil(this.taskInfo.getJobName(), rsyncStr.toString());
                futureList.add(this.globalVariable.sshPool.submit(new CommonThread(cmdUtil,
                        this.taskInfo.getJobName() + "_rsync")));
            } else {
                String fileName = workFile.toFile().getName();
                if (this.forciblyUseOrigin && this.taskInfo.isOnlyTransISRename()
                        && this.taskInfo.getDestFileName().contains("${num}")) {
                    fileName = this.taskInfo.getDestFileName().replace("${num}", "" + (i + 1));
                }
                Scp scp = new Scp(ssh, fileName);
                futureList.add(this.globalVariable.sshPool.submit(new CommonThread(scp,
                        this.taskInfo.getJobName() + "_SCP")));
            }
        }
        String isSuccess = DatapushState.SUCCESS.getDetail();
        for (Future<String> future : futureList) {
            try {
                String state = future.get(2L, TimeUnit.HOURS);
                if (!state.equals(DatapushState.SUCCESS.getDetail())) {
                    throw new DatapushException(state);
                }
            } catch (InterruptedException | java.util.concurrent.ExecutionException
                    | java.util.concurrent.TimeoutException | DatapushException e) {
                log.error("scp error", e);
                isSuccess = e.getMessage();
            }
        }
        if (!isSuccess.equals(DatapushState.SUCCESS.getDetail())) {
            this.sendTimes--;
            this.taskInfo.getUsedHosts().add(this.host);
            if (this.sendTimes == -1) {
                throw new DatapushException(isSuccess);
            }
            Util.sleep(this.taskInfo.getWaitTime());
            getHost();
            scpFile();
        }
    }

    /**
     * getUnzip
     *
     * @return String
     * @author z00502253
     * @since 2022-06-30
     */
    private String getUnzip() {
        StringBuilder unzipMessage = new StringBuilder();
        for (String remoteFile : this.remoteFiles) {
            unzipMessage.append("unzip -o ");
            String zipPW = this.taskInfo.getZipPassword();
            if (Util.isEmpty(zipPW)) {
                zipPW = this.globalVariable.programConfig.getZipKey();
            }
            if (Util.isNotEmpty(zipPW)) {
                unzipMessage.append("-P ").append(zipPW).append(" ");
            }
            unzipMessage.append(remoteFile)
                    .append(" -d ")
                    .append(Paths.get(this.tmpDir.toString(), new String[]{"unzipped"
                    })).append("&&")
                    .append("rm -f ")
                    .append(remoteFile)
                    .append("&&");
        }
        unzipMessage.append("cat ")
                .append(Paths.get(this.tmpDir.toString(), new String[]{"unzipped"
                })).append("/* >")
                .append(Paths.get(this.tmpDir.toString(), new String[]{this.taskInfo.getDestFileName()}).toString())
                .append("&&");
        if (StringUtils.isNotEmpty(this.taskInfo.getDestFilePermission())) {
            unzipMessage.append("chmod ")
                    .append(this.taskInfo.getDestFilePermission())
                    .append(" ").append(Paths.get(this.tmpDir.toString(),
                    new String[]{this.taskInfo.getDestFileName()}).toString())
                    .append("&&");
        }
        unzipMessage.append("mv -f ")
                .append(Paths.get(this.tmpDir.toString(), new String[]{this.taskInfo.getDestFileName()}).toString())
                .append(" ")
                .append(this.taskInfo.getDirectory())
                .append("&&");
        unzipMessage.append("rm -rf ").append(this.tmpDir.toString());
        return unzipMessage.toString();
    }

    /**
     * dealRemoteFile
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void dealRemoteFile() throws DatapushException {
        String[] msg = {"", ""};
        if (this.taskInfo.isLzo() && !this.forciblyUseOrigin) {
            StringBuilder lzoMessage = new StringBuilder();
            if (StringUtils.isNotEmpty(this.taskInfo.getDestFilePermission())) {
                lzoMessage.append("chmod ")
                        .append(this.taskInfo.getDestFilePermission())
                        .append(" ").append(this.tmpDir.toString())
                        .append("/*&&");
            }
            lzoMessage.append("mv -f ").append(this.tmpDir.toString()).append("/* ")
                    .append(this.taskInfo.getDirectory()).append("&&rm -rf ")
                    .append(this.tmpDir.toString());
            msg[0] = lzoMessage.toString();
            msg[1] = "mv lzo files error";
        } else if (this.taskInfo.isZip() && !this.forciblyUseOrigin) {
            msg[0] = getUnzip();
            msg[1] = "unzip and compress files error";
        } else if (this.taskInfo.isCompress() && this.isSplit && !this.forciblyUseOrigin) {
            StringBuilder compressMessage = new StringBuilder();
            compressMessage.append("cat ").append(this.tmpDir.toString()).append("/* >>")
                    .append(Paths.get(this.tmpDir.toString(), new String[]{this.taskInfo.getDestFileName()}).toString())
                    .append("&&");
            if (StringUtils.isNotEmpty(this.taskInfo.getDestFilePermission())) {
                compressMessage.append("chmod ")
                        .append(this.taskInfo.getDestFilePermission()).append(" ")
                        .append(Paths.get(this.tmpDir.toString(),
                                new String[]{this.taskInfo.getDestFileName()}).toString())
                        .append("&&");
            }
            compressMessage.append("mv -f ")
                    .append(Paths.get(this.tmpDir.toString(), new String[]{this.taskInfo.getDestFileName()}).toString())
                    .append(" ").append(this.taskInfo.getDirectory())
                    .append("&&rm -rf ").append(this.tmpDir.toString());
            msg[0] = compressMessage.toString();
            msg[1] = "compress files error";
        } else {
            StringBuilder message = new StringBuilder();
            if (StringUtils.isNotEmpty(this.taskInfo.getDestFilePermission())) {
                message.append("chmod ")
                        .append(this.taskInfo.getDestFilePermission()).append(" ")
                        .append(this.tmpDir.toString()).append("/*")
                        .append("&&");
            }
            message.append("mv -f ").append(this.tmpDir.toString()).append("/* ")
                    .append(this.taskInfo.getDirectory()).append("&&rm -rf ")
                    .append(this.tmpDir.toString());
            msg[0] = message.toString();
            msg[1] = "mv files error";
        }
        this.sshBuilder.host(this.host).command(msg[0]);
        Cmd cmd = new Cmd(this.sshBuilder.build());
        Future<String> future = this.globalVariable.sshPool.submit(new CommonThread(cmd,
                this.taskInfo.getJobName() + "_dealRemoteFile"));
        try {
            String state = future.get(2L, TimeUnit.HOURS);
            if (!state.equals(DatapushState.SUCCESS.getDetail())) {
                throw new DatapushException(msg[1] + "-->" + state);
            }
        } catch (InterruptedException | java.util.concurrent.ExecutionException
                | java.util.concurrent.TimeoutException | DatapushException e) {
            log.error(msg[1], e);
            throw new DatapushException(e);
        }
    }

    /**
     * dealLocalFile
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void dealLocalFile() throws DatapushException {
        try {
            if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888")) {
                this.taskInfo.setWorkPolicy(1);
                if (this.taskInfo.getFilesTask() != null) {
                    this.taskInfo.getFilesTask().setSourcePolicy(3);
                }
            }
            if (this.taskInfo.getWorkPolicy() == 1) {
                if (this.work.toFile().isDirectory()) {
                    Stream<Path> paths = Files.list(this.work);
                    paths.forEach(file -> {
                        try {
                            log.debug("delete work file-------->{}", file.toString());
                            Files.deleteIfExists(file);
                        } catch (IOException e) {
                            log.debug("The task file does not exist in the work directory-------->{}",
                                    file.getFileName());
                        }
                    });
                    Files.delete(this.work);
                } else {
                    log.debug("The task subdirectory does not exist in the work directory-------->{}",
                            this.work.getFileName());
                }
            }
            if (this.taskInfo.getWorkPolicy() == 2) {
                for (Path file : this.workFiles) {
                    if (file.toFile().exists()) {
                        Files.copy(file, Paths.get(this.backUp.toString(), new String[]{file.toFile().getName()}), new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
                        continue;
                    }
                    log.debug("back up tmp file is not exists-------->{}", file.getFileName());
                }
            }

            if (this.taskInfo.getFilesTask() != null) {
                if (this.taskInfo.getFilesTask().getSourcePolicy() == 1) {
                    for (Path file : this.checkFiles) {
                        if (file.toFile().exists()) {
                            Files.delete(file);
                            continue;
                        }
                        log.debug("delete source file is not exists-------->{}", file.getFileName());
                    }
                }

                if (this.taskInfo.getFilesTask().getSourcePolicy() == 2) {
                    for (Path file : this.checkFiles) {
                        if (file.toFile().exists()) {
                            Files.copy(file, Paths.get(this.backUp.toString(), new String[]{file.toFile().getName()}), new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
                            continue;
                        }
                        log.debug("back up source file is not exists-------->{}", file.getFileName());
                    }

                }
            }
        } catch (IOException e) {
            throw new DatapushException("deal local files error", e);
        }
    }

    /**
     * putState
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void putState() {
        if (this.taskInfo.getTaskState() == DatapushState.RUNNING) {
            this.taskInfo.setTaskState(DatapushState.FAILED);
        }
        if (this.globalVariable.damConfig.isOpen() && this.taskInfo.getTaskState() != DatapushState.REPEAT) {
            DamController damController = new DamController(this.globalVariable.damConfig);
            try {
                damController.pushFinished(buildFinished());
            } catch (DatapushException | NullPointerException e) {
                log.error("Dam pushFinished error", e);
            }
        }
        log.info("task run end...");
        if (this.taskInfo.getTaskState() == DatapushState.SUCCESS) {
            this.taskInfo.setMonitorState(DatapushState.SUCCESS);
        } else {
            this.taskInfo.setMonitorState(DatapushState.FAILED);
        }
    }

    /**
     * cleanTmpFiles
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void cleanTmpFiles() {
        if (this.workFiles != null && this.workFiles.size() > 0) {
            if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888")) {
                for (Path file : this.workFiles) {
                    if (file == null) {
                        continue;
                    }

                    try {
                        String fileName = file.getFileName().toString();
                        if (Util.isEmpty(fileName)) {
                            continue;
                        }
                        this.sshBuilder.command("rm -rf " + this.taskInfo.getDirectory() + "/" + fileName);
                        Cmd cmdTool = new Cmd(this.sshBuilder.build());
                        cmdTool.run();
                    } catch (DatapushException | IOException | JSchException | NullPointerException e) {
                        log.warn("test file delete error!");
                        log.debug("test file delete error!", e);
                    }
                }
            } else {
                String rmTempCmd = "rm -rf " + this.taskInfo.getDirectory() + "/temp/" + this.taskInfo.getJobName() + "*";

                this.sshBuilder.host(this.host).command(rmTempCmd);
                Cmd cmd = new Cmd(this.sshBuilder.build());
                try {
                    cmd.run();
                } catch (JSchException | IOException ex) {
                    log.error("rm temp error", ex);
                }
            }
        }
    }

    /**
     * buildRequest
     *
     * @return Map
     * @author z00502253
     * @since 2022-06-30
     */
    private Map<String, Object> buildRequest() {
        Map<String, Object> map = new HashMap<>(11);
        map.put("taskId", this.taskInfo.getTaskId());
        map.put("mfsPath", this.taskInfo.getDirectory());
        map.put("dataPushV", this.globalVariable.version);
        map.put("deptCode", this.taskInfo.getDeptCode());
        map.put("srcIp", this.globalVariable.node);
        map.put("taskType", Integer.valueOf(this.taskInfo.getTaskType().equalsIgnoreCase("db") ? 2 : 1));
        map.put("cycleTime", Util.rightPad(this.taskInfo.getPeriodObject().getPeriodTime(), 12, "0")
                .substring(0, 12));
        map.put("odsTableName", this.taskInfo.getOdsName());
        map.put("sendThreadCount", Integer.valueOf(this.taskInfo.getSendFileMaxThreads()));
        map.put("jobName", this.taskInfo.getJobName());
        if (this.taskInfo.getUsedHosts().size() > 0) {
            map.put("abortedIP", this.taskInfo.getUsedHosts().toString().replace("[", "")
                    .replace("]", "").trim());
        }
        log.info("Dam request params : {}", map);
        return map;
    }

    /**
     * buildFinished
     *
     * @return HashMap
     * @author z00502253
     * @since 2022-06-30
     */
    private HashMap<String, Object> buildFinished() {
        HashMap<String, Object> map = new HashMap<>(10);
        map.put("jobName", this.taskInfo.getJobName());
        map.put("taskInstId", Util.isNotEmpty(this.taskInfo.getDamTaskId()) ? this.taskInfo.getDamTaskId() : "0");
        map.put("taskId", this.taskInfo.getTaskId());
        map.put("isAlarm", Boolean.valueOf(this.taskInfo.isAlarm()));
        map.put("alarmLevel", this.taskInfo.getAlarmLevel());
        map.put("alarmScope", this.taskInfo.getAlarmScope());
        map.put("srcIp", this.globalVariable.node);
        map.put("cycleTime", Util.rightPad(this.taskInfo.getPeriodObject().getPeriodTime(), 12,
                "0").substring(0, 12));
        if (this.taskInfo.getTaskState() == DatapushState.SUCCESS) {
            map.put("statusCode", "0");
            map.put("message", this.taskInfo.getTaskState().toString());
        } else {
            map.put("statusCode", Integer.valueOf(this.taskInfo.getTaskState().getCode()));
            map.put("message",
                    String.format(Locale.ENGLISH, "[%s] [%s] this task %s had a problem, %s", new Object[]{
                            Util.getDirNameByTime("yyyy-MM-dd HH:mm:ss"), this.taskInfo.getJobName(),
                            this.globalVariable.node, this.taskInfo
                            .getTaskState().toString()}));
        }
        log.info("Dam finished params: {}", map);
        return map;
    }
}