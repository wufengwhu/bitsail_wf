package com.hihonor.cloudservice.datapush.tasks;

import com.hihonor.cloudservice.datapush.common.FindFileUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.entity.PeriodObject;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;
import com.hihonor.cloudservice.datapush.jsch.Ssh;
import com.hihonor.cloudservice.datapush.GlobalVariable;


import com.hihonor.cloudservice.datapush.jsch.Cmd;
import com.hihonor.cloudservice.datapush.jsch.Sftp;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class TaskMonitor.
 *
 * @since 2022-04-24
 */
public class TaskMonitor implements Callable<Boolean> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(TaskMonitor.class);

    /**
     * The Constant globalVariable.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final GlobalVariable globalVariable = GlobalVariable.getInstance();

    /**
     * The Constant rand.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final SecureRandom rand = new SecureRandom();

    /**
     * The Constant startTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final long startTime;

    /**
     * The Constant isRun.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isRun;

    /**
     * The Constant maxMemory.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private double maxMemory;

    /**
     * The Constant processType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int processType;

    public TaskMonitor(int processType) {
        this.isRun = true;
        this.startTime = System.currentTimeMillis();
        this.maxMemory = 0.0D;
        this.processType = processType;
    }

    /**
     * call
     *
     * @return Boolean
     * @author z00502253
     * @since 2022-06-28
     */
    public Boolean call() {
        Thread.currentThread().setName("Datapush_Monitor");
        boolean isSuccess = true;
        while (this.isRun) {
            Util.sleep(1000L);
            checkUsePower();
            boolean isComplete = true;
            for (TaskInfo taskInfo : this.globalVariable.taskInfoMap.values()) {
                log.debug("taskInfo jobName={}, MonitorState={}", taskInfo.getJobName(), taskInfo.getMonitorState());
                if (taskInfo.getMonitorState() == DatapushState.RUNNING) {
                    isComplete = false;
                    break;
                }
                if (taskInfo.getMonitorState() != DatapushState.SUCCESS) {
                    if (this.processType == 1) {
                        sendLogs(taskInfo);
                    }
                    taskInfo.setSendError(true);
                    isSuccess = false;
                    continue;
                }
                if (this.processType == 1) {
                    Util.dealIDELogFiles(taskInfo.getJobName(), this.globalVariable.rootDir,
                            this.globalVariable.programConfig
                            .getLogClearTime());
                }
            }

            if (!checkRunTime()) {
                this.isRun = false;
                isSuccess = false;
            }
            if (isComplete) {
                this.isRun = false;
            }
        }
        log.info("The maximum memory usage is {}M.", String.format(Locale.ENGLISH, "%.2f",
                new Object[]{Double.valueOf(this.maxMemory)}));
        return Boolean.valueOf(isSuccess);
    }

    /**
     * checkUsePower
     *
     * @author z00502253
     * @since 2022-06-30
     */
    private void checkUsePower() {
        double total = Runtime.getRuntime().totalMemory() / 1048576.0D;
        double free = Runtime.getRuntime().freeMemory() / 1048576.0D;
        double currentMemory = total - free;
        if (this.maxMemory < currentMemory) {
            this.maxMemory = currentMemory;
        }
        log.debug("Use Current Memory Size(M) = {}", String.format(Locale.ENGLISH, "%.2f",
                new Object[]{Double.valueOf(total - free)}));
    }

    /**
     * checkRunTime
     *
     * @author z00502253
     * @since 2022-06-30
     */
    private boolean checkRunTime() {
        long runTime = (System.currentTimeMillis() - this.startTime) / 60000L;
        if (runTime > this.globalVariable.programConfig.getRunTimeOut()) {
            log.warn("Monitor System stop,system run time {} min,and time out is {} min!!!", Long.valueOf(runTime),
                    Integer.valueOf(this.globalVariable.programConfig.getRunTimeOut()));
            return false;
        }
        return true;
    }

    /**
     * sendLogs
     *
     * @param taskInfo vo
     * @author z00502253
     * @since 2022-06-30
     */
    private void sendLogs(TaskInfo taskInfo) {
        if (!this.globalVariable.damConfig.isLogOpen() || taskInfo.isSendError()) {
            return;
        }
        log.info("start send logs for failed task {}!", taskInfo.getJobName());
        String periodTime = getTime(taskInfo.getPeriodObject());
        String match = taskInfo.getJobName() + "_" + periodTime + ".*|Datapush.*\\.log";
        List<Path> errorFiles = null;
        for (String path : this.globalVariable.damConfig.getLogDir()) {
            try {
                errorFiles = (new FindFileUtil(1)).getFileByRegex(Paths.get(path, new String[0]), match);
            } catch (IOException e) {
                log.debug("match log files error", e);
            }
            if (null != errorFiles && errorFiles.size() > 0) {
                break;
            }
        }
        if (null == errorFiles || errorFiles.size() == 0) {
            return;
        }
        int timeOut = this.globalVariable.damConfig.getLogTimeOut() * 60 * 1000;


        Ssh.SshBuilder builder = Ssh.builder().jobName(taskInfo.getJobName()).port(Util.getInt(taskInfo.getPort(),
                this.globalVariable.programConfig.getSshPort())).userName(this.globalVariable.damConfig.getUser())
                .keyFile(this.globalVariable.rootDir + File.separator + "fruits" + File.separator + "apples")
                .passphrase(this.globalVariable.programConfig.getUnifiedKey()).timeOut(timeOut)
                .remotePath(this.globalVariable.damConfig.getLogDestDir() + "/" + taskInfo
                .getPeriodObject().getPeriodTime().substring(0, 6) + "/");
        for (Path path : errorFiles) {
            for (int i = 0; i < this.globalVariable.damConfig.getLogHosts().size(); i++) {
                int chose = this.rand.nextInt(this.globalVariable.damConfig.getLogHosts().size());
                builder.host(this.globalVariable.damConfig.getLogHosts().get(chose))
                        .localFile(path.toFile())
                        .command("mkdir -p " + this.globalVariable.damConfig.getLogDestDir().toString());
                if (sendLogsRetry(builder)) {
                    break;
                }
            }
        }
        log.info("end send logs for failed task {}!", taskInfo.getJobName());
    }

    /**
     * getTime
     *
     * @param periodObject vo
     * @return String
     * @author z00502253
     * @since 2022-06-30
     */
    private String getTime(PeriodObject periodObject) {
        String periodTime = periodObject.getPeriodTime();
        switch (periodObject.getPeriodType()) {
            case "M":
                periodTime = periodTime.substring(0, 12);
                break;

            case "H":
                periodTime = periodTime.substring(0, 10);
                break;

            case "D":
                periodTime = periodTime.substring(0, 8);
                break;
        }


        return periodTime;
    }

    /**
     * sendLogsRetry
     *
     * @param builder builder
     * @return boolean
     * @author z00502253
     * @since 2022-06-30
     */
    private boolean sendLogsRetry(Ssh.SshBuilder builder) {
        for (int i = 1; i <= 3; i++) {
            Ssh ssh = builder.build();
            log.debug("log file send to {}------->{}", ssh.getHost(), ssh.getLocalFile().getName());
            Cmd cmdTool = new Cmd(ssh);
            try {
                cmdTool.run();
            } catch (DatapushException | IOException | com.jcraft.jsch.JSchException e) {
                log.debug("log file send to {} failed------->{}",
                        new Object[]{ssh.getHost(), ssh.getLocalFile().getName(), e});
            }
            Sftp scpTool = new Sftp(ssh);
            try {
                scpTool.run();
                log.debug("log file send to {} successfully------->{}", ssh.getHost(), ssh.getLocalFile().getName());
                return true;
            } catch (DatapushException | com.jcraft.jsch.JSchException | IOException
                    | com.jcraft.jsch.SftpException e) {
                log.debug("log file send to {} failed,retry {}------->{}",
                        new Object[]{ssh.getHost(), Integer.valueOf(i), ssh
                        .getLocalFile().getName()});
                Util.sleep(this.rand.nextInt(30000));
            }
        }
        return false;
    }
}