package com.hihonor.cloudservice.datapush.tasks.impl;

import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;
import com.hihonor.cloudservice.datapush.tasks.Task;
import com.hihonor.cloudservice.datapush.tasks.TaskProcess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class OriginalFileTask.
 *
 * @since 2022-04-24
 */
public class OriginalFileTask
        extends TaskProcess
        implements Task {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(OriginalFileTask.class);

    public OriginalFileTask(TaskInfo taskInfo, String taskId) {
        super(taskInfo, taskId);
        this.checkTimes = taskInfo.getFilesTask().getCheckTimes();
        this.forciblyUseOrigin = true;
    }

    /**
     * execute
     *
     * @author z00502253
     * @since 2022-06-27
     */
    public void execute() {
        log.info("OriginalFileTask：work dir = {},tmp dir = {}", this.work.toString(), this.tmpDir.toString());

        try {
            init();

            getHost();

            checkFile();

            touchEmptyFile();

            copyFileByJDK(this.checkFiles);

            scpFile();

            dealRemoteFile();

            dealLocalFile();

            this.taskInfo.setTaskState(DatapushState.SUCCESS);
        } catch (DatapushException e) {
            log.error("original file task error", (Throwable) e);
        } finally {
            cleanTmpFiles();
            putState();
        }
    }
}