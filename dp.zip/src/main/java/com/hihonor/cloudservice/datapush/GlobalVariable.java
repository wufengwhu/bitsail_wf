package com.hihonor.cloudservice.datapush;

import com.hihonor.cloudservice.datapush.entity.DamConfig;
import com.hihonor.cloudservice.datapush.entity.DruidConfig;
import com.hihonor.cloudservice.datapush.entity.ProgramConfig;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.io.FilesChannel;


import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class GlobalVariable {

    /**
     * The Constant globalVariable.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static volatile GlobalVariable globalVariable;

    /**
     * The Constant sshPool.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public ThreadPoolExecutor sshPool;

    /**
     * The Constant channels.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public ConcurrentHashMap<String, FilesChannel> channels = new ConcurrentHashMap<>();

    /**
     * The Constant subPool.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public ThreadPoolExecutor subPool;

    /**
     * The Constant taskInfoMap.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public ConcurrentHashMap<String, TaskInfo> taskInfoMap = new ConcurrentHashMap<>();

    /**
     * The Constant rootDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String rootDir;

    /**
     * createVariable
     *
     * @author z00502253
     * @since 2022-08-16
     */
    private static void createVariable() {
        synchronized (GlobalVariable.class) {
            if (globalVariable == null)
                globalVariable = new GlobalVariable();
        }
    }

    public String workDir;

    public String node;

    public String version;

    public ProgramConfig programConfig;

    public DruidConfig druidConfig;

    public DamConfig damConfig;

    /**
     * createVariable
     *
     * @author z00502253
     * @since 2022-08-16
     */
    public static GlobalVariable getInstance() {
        if (globalVariable == null) {
            createVariable();
        }
        return globalVariable;
    }
}