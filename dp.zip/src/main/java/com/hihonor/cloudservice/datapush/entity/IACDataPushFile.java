package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class IACDataPushFile
        extends IACDataPushJob {

    /**
     * The Constant fileSource.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String fileSource;

    /**
     * The Constant remoteTimeOut.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int remoteTimeOut;

    /**
     * The Constant reSendTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int reSendTimes;

    /**
     * The Constant fileMask.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String fileMask;

    /**
     * The Constant pushTimePer.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int pushTimePer;

    /**
     * The Constant fileFetchMode.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int fileFetchMode = 3;

    /**
     * The Constant fileSizeThreshold.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int fileSizeThreshold;

    /**
     * The Constant reRetryTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int reRetryTimes;

    /**
     * The Constant fileCountThreshold.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int fileCountThreshold;

    /**
     * The Constant reRetryWaitTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int reRetryWaitTime;

    /**
     * The Constant isOnlyTrans.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String isOnlyTrans;

    /**
     * The Constant ifOnlyTransISRename.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String ifOnlyTransISRename;

    public String getFileSource() {
        return this.fileSource;
    }

    public void setFileSource(String fileSource) {
        this.fileSource = fileSource;
    }

    public int getRemoteTimeOut() {
        return this.remoteTimeOut;
    }

    public void setRemoteTimeOut(int remoteTimeOut) {
        this.remoteTimeOut = remoteTimeOut;
    }

    public int getReSendTimes() {
        return this.reSendTimes;
    }

    public void setReSendTimes(int reSendTimes) {
        this.reSendTimes = reSendTimes;
    }

    public String getFileMask() {
        return this.fileMask;
    }

    public void setFileMask(String fileMask) {
        this.fileMask = fileMask;
    }

    public int getPushTimePer() {
        return this.pushTimePer;
    }

    public void setPushTimePer(int pushTimePer) {
        this.pushTimePer = pushTimePer;
    }

    public int getFileFetchMode() {
        return this.fileFetchMode;
    }

    public void setFileFetchMode(int fileFetchMode) {
        this.fileFetchMode = fileFetchMode;
    }

    public int getFileSizeThreshold() {
        return this.fileSizeThreshold;
    }

    public void setFileSizeThreshold(int fileSizeThreshold) {
        this.fileSizeThreshold = fileSizeThreshold;
    }

    public int getReRetryTimes() {
        return this.reRetryTimes;
    }

    public void setReRetryTimes(int reRetryTimes) {
        this.reRetryTimes = reRetryTimes;
    }

    public int getFileCountThreshold() {
        return this.fileCountThreshold;
    }

    public void setFileCountThreshold(int fileCountThreshold) {
        this.fileCountThreshold = fileCountThreshold;
    }

    public int getReRetryWaitTime() {
        return this.reRetryWaitTime;
    }

    public void setReRetryWaitTime(int reRetryWaitTime) {
        this.reRetryWaitTime = reRetryWaitTime;
    }

    public String getIsOnlyTrans() {
        return this.isOnlyTrans;
    }

    public void setIsOnlyTrans(String isOnlyTrans) {
        this.isOnlyTrans = isOnlyTrans;
    }

    public String getIfOnlyTransISRename() {
        return this.ifOnlyTransISRename;
    }

    public void setIfOnlyTransISRename(String ifOnlyTransISRename) {
        this.ifOnlyTransISRename = ifOnlyTransISRename;
    }
}