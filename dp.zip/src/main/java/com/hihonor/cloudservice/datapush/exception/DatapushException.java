package com.hihonor.cloudservice.datapush.exception;

/**
 * 功能描述
 *
 * @since 2022-05-06
 */
public class DatapushException
        extends RuntimeException {

    /**
     * The Constant state.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final DatapushState state;

    public DatapushException(DatapushState state) {
        super(state.getDetail());
        this.state = state;
    }

    public DatapushException(String message) {
        super(message);
        this.state = DatapushState.FAILED;
    }

    public DatapushException(Throwable cause) {
        super(cause);
        this.state = DatapushState.FAILED;
    }

    public DatapushException(String message, Throwable cause) {
        super(message, cause);
        this.state = DatapushState.FAILED;
    }

    public DatapushState getState() {
        return this.state;
    }
}