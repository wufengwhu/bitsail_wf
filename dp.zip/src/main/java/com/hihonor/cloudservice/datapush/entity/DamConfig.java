package com.hihonor.cloudservice.datapush.entity;

import java.nio.file.Path;
import java.util.List;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class DamConfig {

    /**
     * The Constant open.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean open;

    /**
     * The Constant url.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String url;

    /**
     * The Constant signKey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String signKey;

    /**
     * The Constant workKey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String workKey;

    /**
     * The Constant name.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String name;

    /**
     * The Constant timeOut.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int timeOut;

    /**
     * The Constant waitTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int waitTime;

    public void setOpen(boolean open) {
        this.open = open;
    }

    /**
     * The Constant iacRetryTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int iacRetryTimes;

    /**
     * The Constant logOpen.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean logOpen;

    /**
     * The Constant logHosts.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> logHosts;

    /**
     * The Constant user.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String user;

    /**
     * The Constant logTimeOut.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int logTimeOut;

    /**
     * The Constant logDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> logDir;

    /**
     * The Constant logDestDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Path logDestDir;

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String jobName;

    public void setUrl(String url) {
        this.url = url;
    }

    public void setSignKey(String signKey) {
        this.signKey = signKey;
    }

    public void setWorkKey(String workKey) {
        this.workKey = workKey;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTimeOut(int timeOut) {
        this.timeOut = timeOut;
    }

    public void setWaitTime(int waitTime) {
        this.waitTime = waitTime;
    }

    public void setIacRetryTimes(int iacRetryTimes) {
        this.iacRetryTimes = iacRetryTimes;
    }

    public void setLogOpen(boolean logOpen) {
        this.logOpen = logOpen;
    }

    public void setLogHosts(List<String> logHosts) {
        this.logHosts = logHosts;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setLogTimeOut(int logTimeOut) {
        this.logTimeOut = logTimeOut;
    }

    public void setLogDir(List<String> logDir) {
        this.logDir = logDir;
    }

    public void setLogDestDir(Path logDestDir) {
        this.logDestDir = logDestDir;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-18
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof DamConfig)) return false;
        DamConfig other = (DamConfig) o;
        if (!other.canEqual(this)) return false;
        if (isOpen() != other.isOpen()) return false;
        Object this$url = getUrl(), other$url = other.getUrl();
        if ((this$url == null) ? (other$url != null) : !this$url.equals(other$url)) return false;
        Object this$signKey = getSignKey(), other$signKey = other.getSignKey();
        if ((this$signKey == null) ? (other$signKey != null) : !this$signKey.equals(other$signKey)) return false;
        Object this$workKey = getWorkKey(), other$workKey = other.getWorkKey();
        if ((this$workKey == null) ? (other$workKey != null) : !this$workKey.equals(other$workKey)) return false;
        Object this$name = getName(), other$name = other.getName();
        if ((this$name == null) ? (other$name != null) : !this$name.equals(other$name)) return false;
        if (getTimeOut() != other.getTimeOut()) return false;
        if (getWaitTime() != other.getWaitTime()) return false;
        if (getIacRetryTimes() != other.getIacRetryTimes()) return false;
        if (isLogOpen() != other.isLogOpen()) return false;
        List<String> this$logHosts = (List<String>) getLogHosts(), other$logHosts = (List<String>) other.getLogHosts();
        if ((this$logHosts == null) ? (other$logHosts != null) : !this$logHosts.equals(other$logHosts)) return false;
        Object this$user = getUser(), other$user = other.getUser();
        if ((this$user == null) ? (other$user != null) : !this$user.equals(other$user)) return false;
        if (getLogTimeOut() != other.getLogTimeOut()) return false;
        List<String> this$logDir = (List<String>) getLogDir(), other$logDir = (List<String>) other.getLogDir();
        if ((this$logDir == null) ? (other$logDir != null) : !this$logDir.equals(other$logDir)) return false;
        Object this$logDestDir = getLogDestDir(), other$logDestDir = other.getLogDestDir();
        if ((this$logDestDir == null) ? (other$logDestDir != null) : !this$logDestDir.equals(other$logDestDir))
            return false;
        Object this$jobName = getJobName(), other$jobName = other.getJobName();
        return !((this$jobName == null) ? (other$jobName != null) : !this$jobName.equals(other$jobName));
    }

    protected boolean canEqual(Object other) {
        return other instanceof DamConfig;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-18
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + (isOpen() ? 79 : 97);
        Object $url = getUrl();
        result = result * 59 + (($url == null) ? 43 : $url.hashCode());
        Object $signKey = getSignKey();
        result = result * 59 + (($signKey == null) ? 43 : $signKey.hashCode());
        Object $workKey = getWorkKey();
        result = result * 59 + (($workKey == null) ? 43 : $workKey.hashCode());
        Object $name = getName();
        result = result * 59 + (($name == null) ? 43 : $name.hashCode());
        result = result * 59 + getTimeOut();
        result = result * 59 + getWaitTime();
        result = result * 59 + getIacRetryTimes();
        result = result * 59 + (isLogOpen() ? 79 : 97);
        List<String> $logHosts = (List<String>) getLogHosts();
        result = result * 59 + (($logHosts == null) ? 43 : $logHosts.hashCode());
        Object $user = getUser();
        result = result * 59 + (($user == null) ? 43 : $user.hashCode());
        result = result * 59 + getLogTimeOut();
        List<String> $logDir = (List<String>) getLogDir();
        result = result * 59 + (($logDir == null) ? 43 : $logDir.hashCode());
        Object $logDestDir = getLogDestDir();
        result = result * 59 + (($logDestDir == null) ? 43 : $logDestDir.hashCode());
        Object $jobName = getJobName();
        return result * 59 + (($jobName == null) ? 43 : $jobName.hashCode());
    }

    public String toString() {
        return "DamConfig(open=" + isOpen() + ", url=" + getUrl() + ", signKey=" + getSignKey() + ", workKey="
                + getWorkKey() + ", name=" + getName() + ", timeOut=" + getTimeOut() + ", waitTime=" + getWaitTime()
                + ", iacRetryTimes=" + getIacRetryTimes() + ", logOpen=" + isLogOpen() + ", logHosts=" + getLogHosts()
                + ", user=" + getUser() + ", logTimeOut=" + getLogTimeOut() + ", logDir=" + getLogDir()
                + ", logDestDir=" + getLogDestDir() + ", jobName=" + getJobName() + ")";
    }

    public boolean isOpen() {
        return this.open;
    }

    public String getUrl() {
        return this.url;
    }

    public String getSignKey() {
        return this.signKey;
    }

    public String getWorkKey() {
        return this.workKey;
    }

    public String getName() {
        return this.name;
    }

    public int getTimeOut() {
        return this.timeOut;
    }

    public int getWaitTime() {
        return this.waitTime;
    }

    public int getIacRetryTimes() {
        return this.iacRetryTimes;
    }

    public boolean isLogOpen() {
        return this.logOpen;
    }

    public List<String> getLogHosts() {
        return this.logHosts;
    }

    public String getUser() {
        return this.user;
    }

    public int getLogTimeOut() {
        return this.logTimeOut;
    }

    public List<String> getLogDir() {
        return this.logDir;
    }

    public Path getLogDestDir() {
        return this.logDestDir;
    }

    public String getJobName() {
        return this.jobName;
    }
}