package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class DbSource {

    /**
     * The Constant type.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String type;

    /**
     * The Constant host.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String host;

    /**
     * The Constant port.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int port;

    /**
     * The Constant dataName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String dataName;

    /**
     * The Constant user.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String user;

    /**
     * The Constant password.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String password;

    /**
     * The Constant extendParams.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String extendParams;

    /**
     * The Constant sql.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String sql;

    public void setType(String type) {
        this.type = type;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setDataName(String dataName) {
        this.dataName = dataName;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setExtendParams(String extendParams) {
        this.extendParams = extendParams;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof DbSource)) return false;
        DbSource other = (DbSource) o;
        if (!other.canEqual(this)) return false;
        Object this$type = getType(), other$type = other.getType();
        if ((this$type == null) ? (other$type != null) : !this$type.equals(other$type)) return false;
        Object this$host = getHost(), other$host = other.getHost();
        if ((this$host == null) ? (other$host != null) : !this$host.equals(other$host)) return false;
        if (getPort() != other.getPort()) return false;
        Object this$dataName = getDataName(), other$dataName = other.getDataName();
        if ((this$dataName == null) ? (other$dataName != null) : !this$dataName.equals(other$dataName)) return false;
        Object this$user = getUser(), other$user = other.getUser();
        if ((this$user == null) ? (other$user != null) : !this$user.equals(other$user)) return false;
        Object this$password = getPassword(), other$password = other.getPassword();
        if ((this$password == null) ? (other$password != null) : !this$password.equals(other$password)) return false;
        Object this$extendParams = getExtendParams(), other$extendParams = other.getExtendParams();
        if ((this$extendParams == null) ? (other$extendParams != null) : !this$extendParams.equals(other$extendParams))
            return false;
        Object this$sql = getSql(), other$sql = other.getSql();
        return !((this$sql == null) ? (other$sql != null) : !this$sql.equals(other$sql));
    }

    protected boolean canEqual(Object other) {
        return other instanceof DbSource;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $type = getType();
        result = result * 59 + (($type == null) ? 43 : $type.hashCode());
        Object $host = getHost();
        result = result * 59 + (($host == null) ? 43 : $host.hashCode());
        result = result * 59 + getPort();
        Object $dataName = getDataName();
        result = result * 59 + (($dataName == null) ? 43 : $dataName.hashCode());
        Object $user = getUser();
        result = result * 59 + (($user == null) ? 43 : $user.hashCode());
        Object $password = getPassword();
        result = result * 59 + (($password == null) ? 43 : $password.hashCode());
        Object $extendParams = getExtendParams();
        result = result * 59 + (($extendParams == null) ? 43 : $extendParams.hashCode());
        Object $sql = getSql();
        return result * 59 + (($sql == null) ? 43 : $sql.hashCode());
    }

    public String toString() {
        return "DbSource(type=" + getType() + ", host=" + getHost() + ", port=" + getPort() + ", dataName="
                + getDataName() + ", user=" + getUser() + ", password=" + getPassword() + ", extendParams="
                + getExtendParams() + ", sql=" + getSql() + ")";
    }

    public String getType() {
        return this.type;
    }

    public String getHost() {
        return this.host;
    }

    public int getPort() {
        return this.port;
    }

    public String getDataName() {
        return this.dataName;
    }

    public String getUser() {
        return this.user;
    }

    public String getPassword() {
        return this.password;
    }

    public String getExtendParams() {
        return this.extendParams;
    }

    public String getSql() {
        return this.sql;
    }
}