package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class PeriodObject {

    /**
     * The Constant periodTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String periodTime;

    /**
     * The Constant periodType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String periodType;

    /**
     * The Constant periodLength.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int periodLength;

    /**
     * The Constant startTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String startTime;

    /**
     * The Constant endTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String endTime;

    /**
     * The Constant year.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String year;

    /**
     * The Constant month.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String month;

    public void setPeriodTime(String periodTime) {
        this.periodTime = periodTime;
    }

    /**
     * The Constant month_day.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String month_day;

    /**
     * The Constant day.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String day;

    /**
     * The Constant dayEp.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String dayEp;

    /**
     * The Constant hour.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String hour;

    /**
     * The Constant minute.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String minute;

    /**
     * The Constant minuteEp.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String minuteEp;

    /**
     * The Constant timeName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String timeName;

    public void setPeriodType(String periodType) {
        this.periodType = periodType;
    }

    public void setPeriodLength(int periodLength) {
        this.periodLength = periodLength;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public void setMonth_day(String month_day) {
        this.month_day = month_day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setDayEp(String dayEp) {
        this.dayEp = dayEp;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public void setMinute(String minute) {
        this.minute = minute;
    }

    public void setMinuteEp(String minuteEp) {
        this.minuteEp = minuteEp;
    }

    public void setTimeName(String timeName) {
        this.timeName = timeName;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof PeriodObject)) return false;
        PeriodObject other = (PeriodObject) o;
        if (!other.canEqual(this)) return false;
        Object this$periodTime = getPeriodTime(), other$periodTime = other.getPeriodTime();
        if ((this$periodTime == null) ? (other$periodTime != null) : !this$periodTime.equals(other$periodTime))
            return false;
        Object this$periodType = getPeriodType(), other$periodType = other.getPeriodType();
        if ((this$periodType == null) ? (other$periodType != null) : !this$periodType.equals(other$periodType))
            return false;
        if (getPeriodLength() != other.getPeriodLength()) return false;
        Object this$startTime = getStartTime(), other$startTime = other.getStartTime();
        if ((this$startTime == null) ? (other$startTime != null) : !this$startTime.equals(other$startTime))
            return false;
        Object this$endTime = getEndTime(), other$endTime = other.getEndTime();
        if ((this$endTime == null) ? (other$endTime != null) : !this$endTime.equals(other$endTime)) return false;
        Object this$year = getYear(), other$year = other.getYear();
        if ((this$year == null) ? (other$year != null) : !this$year.equals(other$year)) return false;
        Object this$month = getMonth(), other$month = other.getMonth();
        if ((this$month == null) ? (other$month != null) : !this$month.equals(other$month)) return false;
        Object this$month_day = getMonth_day(), other$month_day = other.getMonth_day();
        if ((this$month_day == null) ? (other$month_day != null) : !this$month_day.equals(other$month_day))
            return false;
        Object this$day = getDay(), other$day = other.getDay();
        if ((this$day == null) ? (other$day != null) : !this$day.equals(other$day)) return false;
        Object this$dayEp = getDayEp(), other$dayEp = other.getDayEp();
        if ((this$dayEp == null) ? (other$dayEp != null) : !this$dayEp.equals(other$dayEp)) return false;
        Object this$hour = getHour(), other$hour = other.getHour();
        if ((this$hour == null) ? (other$hour != null) : !this$hour.equals(other$hour)) return false;
        Object this$minute = getMinute(), other$minute = other.getMinute();
        if ((this$minute == null) ? (other$minute != null) : !this$minute.equals(other$minute)) return false;
        Object this$minuteEp = getMinuteEp(), other$minuteEp = other.getMinuteEp();
        if ((this$minuteEp == null) ? (other$minuteEp != null) : !this$minuteEp.equals(other$minuteEp)) return false;
        Object this$timeName = getTimeName(), other$timeName = other.getTimeName();
        return !((this$timeName == null) ? (other$timeName != null) : !this$timeName.equals(other$timeName));
    }

    protected boolean canEqual(Object other) {
        return other instanceof PeriodObject;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $periodTime = getPeriodTime();
        result = result * 59 + (($periodTime == null) ? 43 : $periodTime.hashCode());
        Object $periodType = getPeriodType();
        result = result * 59 + (($periodType == null) ? 43 : $periodType.hashCode());
        result = result * 59 + getPeriodLength();
        Object $startTime = getStartTime();
        result = result * 59 + (($startTime == null) ? 43 : $startTime.hashCode());
        Object $endTime = getEndTime();
        result = result * 59 + (($endTime == null) ? 43 : $endTime.hashCode());
        Object $year = getYear();
        result = result * 59 + (($year == null) ? 43 : $year.hashCode());
        Object $month = getMonth();
        result = result * 59 + (($month == null) ? 43 : $month.hashCode());
        Object $month_day = getMonth_day();
        result = result * 59 + (($month_day == null) ? 43 : $month_day.hashCode());
        Object $day = getDay();
        result = result * 59 + (($day == null) ? 43 : $day.hashCode());
        Object $dayEp = getDayEp();
        result = result * 59 + (($dayEp == null) ? 43 : $dayEp.hashCode());
        Object $hour = getHour();
        result = result * 59 + (($hour == null) ? 43 : $hour.hashCode());
        Object $minute = getMinute();
        result = result * 59 + (($minute == null) ? 43 : $minute.hashCode());
        Object $minuteEp = getMinuteEp();
        result = result * 59 + (($minuteEp == null) ? 43 : $minuteEp.hashCode());
        Object $timeName = getTimeName();
        return result * 59 + (($timeName == null) ? 43 : $timeName.hashCode());
    }

    public String toString() {
        return "PeriodObject(periodTime=" + getPeriodTime() + ", periodType=" + getPeriodType() + ", periodLength="
                + getPeriodLength() + ", startTime=" + getStartTime() + ", endTime=" + getEndTime() + ", year="
                + getYear() + ", month=" + getMonth() + ", month_day=" + getMonth_day() + ", day=" + getDay()
                + ", dayEp=" + getDayEp() + ", hour=" + getHour() + ", minute=" + getMinute() + ", minuteEp="
                + getMinuteEp() + ", timeName=" + getTimeName() + ")";
    }


    public String getPeriodTime() {
        return this.periodTime;
    }


    public String getPeriodType() {
        return this.periodType;
    }


    public int getPeriodLength() {
        return this.periodLength;
    }


    public String getStartTime() {
        return this.startTime;
    }


    public String getEndTime() {
        return this.endTime;
    }


    public String getYear() {
        return this.year;
    }


    public String getMonth() {
        return this.month;
    }


    public String getMonth_day() {
        return this.month_day;
    }


    public String getDay() {
        return this.day;
    }


    public String getDayEp() {
        return this.dayEp;
    }

    public String getHour() {
        return this.hour;
    }


    public String getMinute() {
        return this.minute;
    }

    public String getMinuteEp() {
        return this.minuteEp;
    }

    public String getTimeName() {
        return this.timeName;
    }
}

