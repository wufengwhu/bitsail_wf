package com.hihonor.cloudservice.datapush.jsch;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-06
 */
public class Scp {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(Scp.class);

    /**
     * The Constant sshInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Ssh sshInfo;

    /**
     * The Constant destFileName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String destFileName;

    public Scp(Ssh sshInfo, String destFileName) {
        this.sshInfo = sshInfo;
        this.destFileName = destFileName;
    }

    /**
     * run
     *
     * @author z00502253
     * @since 2020-06-23
     */
    public void run() throws DatapushException, JSchException, IOException {
        log.info("start send to {}--------->{}", this.sshInfo.getRemotePath(), this.destFileName);
        OutputStream out = null;
        InputStream in = null;
        FileInputStream fileInputStream = null;
        Session session = null;
        ChannelExec channel = null;
        try {
            long startTime = System.currentTimeMillis();
            session = this.sshInfo.getConnection();
            log.info("ssh connect success--------->{}", this.destFileName);
            channel = (ChannelExec) session.openChannel("exec");
            String commandStr = buildCmd();
            channel.setCommand(commandStr);
            out = channel.getOutputStream();
            in = channel.getInputStream();
            channel.connect(this.sshInfo.getTimeOut());
            log.info("channel connect success--------->{}", this.destFileName);
            if (checkAck(in) != 0) {
                throw new DatapushException("SendFile No response from server");
            }
            String fileCmd = "C0644 " + this.sshInfo.getLocalFile().length() + " " + this.destFileName + "\n";
            out.write(fileCmd.getBytes(StandardCharsets.UTF_8));
            out.flush();
            if (checkAck(in) != 0) {
                throw new DatapushException("SendFile No response from server");
            }
            fileInputStream = FileUtils.openInputStream(this.sshInfo.getLocalFile());
            sendFile(out, fileInputStream);
            sendAck(out);
            if (checkAck(in) != 0) {
                throw new DatapushException("SendFile No response from server");
            }
            log.info("end send to {} end--------->{}(size = {} byte,use times = {} ms)",
                    new Object[]{this.sshInfo.getRemotePath(), this.destFileName,
                    Long.valueOf(this.sshInfo.getLocalFile().length()),
                    Long.valueOf(System.currentTimeMillis() - startTime)});
        } finally {
            Util.closeQuietly(out);
            Util.closeQuietly(in);
            Util.closeQuietly(fileInputStream);
            if (null != channel) {
                channel.disconnect();
            }
            if (null != session) {
                session.disconnect();
            }
        }
    }

    /**
     * buildCmd
     *
     * @return String
     * @author z00502253
     * @since 2022-07-01
     */
    private String buildCmd() {
        StringBuilder commandStr = new StringBuilder();
        commandStr.append("scp ");
        if (Util.isNotEmpty(this.sshInfo.getCipher())) {
            commandStr.append("-c ").append(this.sshInfo.getCipher() + " ");
        }
        if (this.sshInfo.getLimitBand() > 0) {
            commandStr.append("-l ").append(this.sshInfo.getLimitBand() + " ");
        }
        commandStr.append("-t ").append(this.sshInfo.getRemotePath());
        return commandStr.toString();
    }

    /**
     * checkAck
     *
     * @param in in
     * @return int
     * @author z00502253
     * @since 2022-07-01
     */
    private int checkAck(InputStream in) throws IOException, DatapushException {
        int ackByte = in.read();
        if (ackByte == 0) {
            return ackByte;
        }
        if (ackByte == -1) {
            return ackByte;
        }
        if (ackByte == 1 || ackByte == 2) {
            StringBuilder str = new StringBuilder();

            while (true) {
                int errorByte = in.read();
                str.append((char) errorByte);
                if (errorByte == 10)
                    throw new DatapushException("unknown response, code " + ackByte + " message: " + str.toString());
            }
        }
        return ackByte;
    }

    /**
     * sendAck
     *
     * @param out out
     * @author z00502253
     * @since 2022-07-01
     */
    private void sendAck(OutputStream out) throws IOException {
        byte[] ask = {0};
        out.write(ask, 0, 1);
        out.flush();
    }

    /**
     * sendFile
     *
     * @param out out
     * @param fileInputStream fileInputStream
     * @author z00502253
     * @since 2022-07-01
     */
    private void sendFile(OutputStream out, FileInputStream fileInputStream) throws IOException {
        byte[] buf = new byte[2048];
        long currentSize = 0L;
        List<String> processList = new ArrayList<>(Util.getProcess());
        while (true) {
            int len = fileInputStream.read(buf, 0, buf.length);
            if (len <= 0) {
                break;
            }
            out.write(buf, 0, len);
            currentSize += len;
            printProcess(processList, Util.getPercent(currentSize, this.sshInfo.getLocalFile().length()));
        }
        out.flush();
    }

    /**
     * printProcess
     *
     * @param processList List<String>
     * @param process String
     * @author z00502253
     * @since 2022-07-01
     */
    private void printProcess(List<String> processList, String process) {
        if (processList.contains(process)) {
            processList.removeIf(item -> item.equals(process));
            log.info("send process---------->{}({}%)", this.sshInfo.getLocalFile().getName(), process);
        }
    }
}