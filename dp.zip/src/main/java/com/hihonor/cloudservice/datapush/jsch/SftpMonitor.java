package com.hihonor.cloudservice.datapush.jsch;

import com.hihonor.cloudservice.datapush.common.Util;
import com.jcraft.jsch.SftpProgressMonitor;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class SftpMonitor
        implements SftpProgressMonitor {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(SftpMonitor.class);

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String jobName;

    /**
     * The Constant fileName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String fileName;

    /**
     * The Constant count.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private long count = 0L;

    /**
     * The Constant totalSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final long totalSize;

    /**
     * The Constant startTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final long startTime;

    /**
     * The Constant processList.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final List<String> processList;

    SftpMonitor(String jobName, String fileName, long totalSize) {
        this.jobName = jobName;
        this.fileName = fileName;
        this.startTime = System.currentTimeMillis();
        this.processList = new ArrayList<>(Util.getProcess());
        this.totalSize = totalSize;
    }

    /**
     * init
     *
     * @param op int
     * @param src String
     * @param dest String
     * @param max long
     * @author z00502253
     * @since 2020-06-23
     */
    public void init(int op, String src, String dest, long max) {
        log.info("send start, op={}, src={}, dest={}, max={}------>{}", new Object[]{Integer.valueOf(op),
                src, dest, Long.valueOf(max), this.fileName});
        this.count = 0L;
    }

    /**
     * count
     *
     * @param count long
     * @return boolean
     * @author z00502253
     * @since 2020-06-23
     */
    public boolean count(long count) {
        this.count += count;
        String process = Util.getPercent(this.count, this.totalSize);
        if (this.processList.contains(process)) {
            this.processList.removeIf(item -> item.equals(process));
            log.info("send process------>{}({}%)", process, this.fileName);
        }
        return true;
    }

    /**
     * end
     *
     * @author z00502253
     * @since 2020-06-23
     */
    public void end() {
        log.info("end end------>{}(size = {} byte,use times = {} ms)",
                new Object[]{this.fileName, Long.valueOf(this.totalSize),
                Long.valueOf(System.currentTimeMillis() - this.startTime)});
    }
}