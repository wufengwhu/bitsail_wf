package com.hihonor.cloudservice.datapush.entity;

import java.util.List;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class FilesTask {

    /**
     * The Constant fetchMode.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int fetchMode;

    /**
     * The Constant fileSources.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<FileSource> fileSources;

    /**
     * The Constant filesMask.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> filesMask;

    /**
     * The Constant sourcePolicy.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int sourcePolicy;

    /**
     * The Constant checkFileCount.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int checkFileCount;

    /**
     * The Constant checkFileSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int checkFileSize;

    /**
     * The Constant checkTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int checkTimes;

    /**
     * The Constant checkWaitTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int checkWaitTimes;

    public void setFetchMode(int fetchMode) {
        this.fetchMode = fetchMode;
    }

    public void setFileSources(List<FileSource> fileSources) {
        this.fileSources = fileSources;
    }

    public void setFilesMask(List<String> filesMask) {
        this.filesMask = filesMask;
    }

    public void setSourcePolicy(int sourcePolicy) {
        this.sourcePolicy = sourcePolicy;
    }

    public void setCheckFileCount(int checkFileCount) {
        this.checkFileCount = checkFileCount;
    }

    public void setCheckFileSize(int checkFileSize) {
        this.checkFileSize = checkFileSize;
    }

    public void setCheckTimes(int checkTimes) {
        this.checkTimes = checkTimes;
    }

    public void setCheckWaitTimes(int checkWaitTimes) {
        this.checkWaitTimes = checkWaitTimes;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof FilesTask)) return false;
        FilesTask other = (FilesTask) o;
        if (!other.canEqual(this)) return false;
        if (getFetchMode() != other.getFetchMode()) return false;
        List<FileSource> this$fileSources = (List<FileSource>) getFileSources(), other$fileSources
                = (List<FileSource>) other.getFileSources();
        if ((this$fileSources == null) ? (other$fileSources != null) : !this$fileSources.equals(other$fileSources))
            return false;
        List<String> this$filesMask = (List<String>) getFilesMask(), other$filesMask
                = (List<String>) other.getFilesMask();
        return ((this$filesMask == null) ? (other$filesMask != null) : !this$filesMask.equals(other$filesMask))
                ? false : ((getSourcePolicy() != other.getSourcePolicy()) ? false : ((getCheckFileCount()
                != other.getCheckFileCount()) ? false : ((getCheckFileSize()
                != other.getCheckFileSize()) ? false : ((getCheckTimes()
                != other.getCheckTimes()) ? false : (!(getCheckWaitTimes() != other.getCheckWaitTimes()))))));
    }

    protected boolean canEqual(Object other) {
        return other instanceof FilesTask;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + getFetchMode();
        List<FileSource> $fileSources = (List<FileSource>) getFileSources();
        result = result * 59 + (($fileSources == null) ? 43 : $fileSources.hashCode());
        List<String> $filesMask = (List<String>) getFilesMask();
        result = result * 59 + (($filesMask == null) ? 43 : $filesMask.hashCode());
        result = result * 59 + getSourcePolicy();
        result = result * 59 + getCheckFileCount();
        result = result * 59 + getCheckFileSize();
        result = result * 59 + getCheckTimes();
        return result * 59 + getCheckWaitTimes();
    }

    public String toString() {
        return "FilesTask(fetchMode=" + getFetchMode() + ", fileSources=" + getFileSources() + ", filesMask="
                + getFilesMask() + ", sourcePolicy=" + getSourcePolicy() + ", checkFileCount=" + getCheckFileCount()
                + ", checkFileSize=" + getCheckFileSize() + ", checkTimes=" + getCheckTimes() + ", checkWaitTimes="
                + getCheckWaitTimes() + ")";
    }

    public int getFetchMode() {
        return this.fetchMode;
    }

    public List<FileSource> getFileSources() {
        return this.fileSources;
    }

    public List<String> getFilesMask() {
        return this.filesMask;
    }

    public int getSourcePolicy() {
        return this.sourcePolicy;
    }

    public int getCheckFileCount() {
        return this.checkFileCount;
    }

    public int getCheckFileSize() {
        return this.checkFileSize;
    }

    public int getCheckTimes() {
        return this.checkTimes;
    }

    public int getCheckWaitTimes() {
        return this.checkWaitTimes;
    }
}