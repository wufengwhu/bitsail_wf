package com.hihonor.cloudservice.datapush.tasks;

/**
 * The Class TaskThread.
 *
 * @since 2022-04-24
 */
public class TaskThread
        implements Runnable {

    /**
     * The Constant task.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Task task;

    /**
     * The Constant name.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String name;

    public TaskThread(Task task, String name) {
        this.task = task;
        this.name = name;
    }

    /**
     * run
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void run() {
        Thread.currentThread().setName(this.name);
        if (this.task != null)
            this.task.execute();
    }
}