/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class FindDirUtil
        extends SimpleFileVisitor<Path> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FindDirUtil.class);

    /**
     * The Constant maxDirDepth.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int maxDirDepth;

    /**
     * The Constant result.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private ArrayList<Path> result;

    /**
     * The Constant match.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String match;

    /**
     * The Constant methodType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int methodType;

    public FindDirUtil(int maxDirDepth) {
        this.maxDirDepth = maxDirDepth;
    }

    /**
     * getDirByEndName
     *
     * @param path path
     * @param match String
     * @return ArrayList
     * @author z00502253
     * @since 2020-02-14
     */
    public ArrayList<Path> getDirByEndName(Path path, String match) throws IOException {
        this.result = new ArrayList<>();
        this.match = match;
        this.methodType = 0;
        Files.walkFileTree(path, EnumSet.noneOf(FileVisitOption.class), this.maxDirDepth, this);
        return this.result;
    }

    /**
     * getDirByRegex
     *
     * @param path path
     * @param match String
     * @return List
     * @author z00502253
     * @since 2020-02-14
     */
    public List<Path> getDirByRegex(Path path, String match) throws IOException {
        this.result = new ArrayList<>();
        this.match = match;
        this.methodType = 1;
        Files.walkFileTree(path, EnumSet.noneOf(FileVisitOption.class), this.maxDirDepth, this);
        return this.result;
    }

    /**
     * addByEndName
     *
     * @param file file
     * @author z00502253
     * @since 2022-07-01
     */
    private void addByEndName(Path file) {
        if (file.endsWith(this.match)) {
            this.result.add(file);
        }
    }

    /**
     * addByRegex
     *
     * @param dir dir
     * @author z00502253
     * @since 2022-07-01
     */
    private void addByRegex(Path dir) {
        Pattern pattern = Pattern.compile(this.match);
        Matcher matcher = pattern.matcher(dir.toString().substring(dir.toString().lastIndexOf(File.separator) + 1));
        if (matcher.matches()) {
            this.result.add(dir);
        }
    }

    /**
     * visitFileFailed
     *
     * @param file file
     * @param exc exc
     * @return vo
     * @author z00502253
     * @since 2022-07-01
     */
    public FileVisitResult visitFileFailed(Path file, IOException exc) {
        return FileVisitResult.CONTINUE;
    }

    /**
     * preVisitDirectory
     *
     * @param dir dir
     * @param attrs attrs
     * @return enum
     * @author z00502253
     * @since 2020-02-14
     */
    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
        if (!Files.isDirectory(dir, new java.nio.file.LinkOption[0])) {
            return FileVisitResult.CONTINUE;
        }
        if (this.methodType == 1) {
            addByRegex(dir);
        } else {
            addByEndName(dir);
        }
        return FileVisitResult.CONTINUE;
    }
}