package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class IACDataPushJob {

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String jobName;

    /**
     * The Constant pushTimehh.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int pushTimehh;

    /**
     * The Constant pushTimePer.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int pushTimePer;

    /**
     * The Constant pushTimeHH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int pushTimeHH;

    /**
     * The Constant sourceFilePolicy.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int sourceFilePolicy;

    /**
     * The Constant remoteDirectory.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String remoteDirectory;

    /**
     * The Constant isOnlyLzoCompress.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String isOnlyLzoCompress;

    /**
     * The Constant remoteTimeOut.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int remoteTimeOut;

    /**
     * The Constant splitSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int splitSize;

    /**
     * The Constant reSendTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int reSendTimes;

    /**
     * The Constant sendThreadCount.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int sendThreadCount;

    /**
     * The Constant waitTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int waitTime;

    /**
     * The Constant isAlarm.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String isAlarm;

    /**
     * The Constant alarmLevel.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String alarmLevel;

    /**
     * The Constant alarmScope.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String alarmScope;

    /**
     * The Constant mode.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String mode;

    /**
     * The Constant osUser.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String osUser;

    /**
     * The Constant destFileName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String destFileName;

    /**
     * The Constant fieldSeparator.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String fieldSeparator;

    /**
     * The Constant mfsPath.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String mfsPath;

    /**
     * The Constant isUtc.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String isUtc;

    /**
     * The Constant offsetTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String offsetTime;

    /**
     * The Constant isCombinByNoCompress.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String isCombinByNoCompress;

    /**
     * The Constant periodType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String periodType;

    /**
     * The Constant odsTableName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String odsTableName;

    /**
     * The Constant dicName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String dicName;

    /**
     * The Constant limitBand.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String limitBand;

    /**
     * The Constant tSIsOpenPeriodDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String tSIsOpenPeriodDir;

    /**
     * The Constant tSDestFilePermission.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String tSDestFilePermission;

    public String getJobName() {
        return this.jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public int getPushTimehh() {
        return this.pushTimehh;
    }

    public void setPushTimehh(int pushTimehh) {
        this.pushTimehh = pushTimehh;
    }

    public int getPushTimePer() {
        return this.pushTimePer;
    }

    public void setPushTimePer(int pushTimePer) {
        this.pushTimePer = pushTimePer;
    }

    public int getPushTimeHH() {
        return this.pushTimeHH;
    }

    public void setPushTimeHH(int pushTimeHH) {
        this.pushTimeHH = pushTimeHH;
    }

    public int getSourceFilePolicy() {
        return this.sourceFilePolicy;
    }

    public void setSourceFilePolicy(int sourceFilePolicy) {
        this.sourceFilePolicy = sourceFilePolicy;
    }

    public String getRemoteDirectory() {
        return this.remoteDirectory;
    }

    public void setRemoteDirectory(String remoteDirectory) {
        this.remoteDirectory = remoteDirectory;
    }

    public String getIsOnlyLzoCompress() {
        return this.isOnlyLzoCompress;
    }

    public void setIsOnlyLzoCompress(String isOnlyLzoCompress) {
        this.isOnlyLzoCompress = isOnlyLzoCompress;
    }

    public int getRemoteTimeOut() {
        return this.remoteTimeOut;
    }

    public void setRemoteTimeOut(int remoteTimeOut) {
        this.remoteTimeOut = remoteTimeOut;
    }

    public int getSplitSize() {
        return this.splitSize;
    }

    public void setSplitSize(int splitSize) {
        this.splitSize = splitSize;
    }

    public int getReSendTimes() {
        return this.reSendTimes;
    }

    public void setReSendTimes(int reSendTimes) {
        this.reSendTimes = reSendTimes;
    }

    public int getSendThreadCount() {
        return this.sendThreadCount;
    }

    public void setSendThreadCount(int sendThreadCount) {
        this.sendThreadCount = sendThreadCount;
    }

    public int getWaitTime() {
        return this.waitTime;
    }

    public void setWaitTime(int waitTime) {
        this.waitTime = waitTime;
    }

    public String getIsAlarm() {
        return this.isAlarm;
    }

    public void setIsAlarm(String isAlarm) {
        this.isAlarm = isAlarm;
    }

    public String getAlarmLevel() {
        return this.alarmLevel;
    }

    public void setAlarmLevel(String alarmLevel) {
        this.alarmLevel = alarmLevel;
    }

    public String getAlarmScope() {
        return this.alarmScope;
    }

    public void setAlarmScope(String alarmScope) {
        this.alarmScope = alarmScope;
    }

    public String getMode() {
        return this.mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getOsUser() {
        return this.osUser;
    }

    public void setOsUser(String osUser) {
        this.osUser = osUser;
    }


    public String getDestFileName() {
        return this.destFileName;
    }

    public void setDestFileName(String destFileName) {
        this.destFileName = destFileName;
    }

    public String getFieldSeparator() {
        return this.fieldSeparator;
    }

    public void setFieldSeparator(String fieldSeparator) {
        this.fieldSeparator = fieldSeparator;
    }

    public String getMfsPath() {
        return this.mfsPath;
    }

    public void setMfsPath(String mfsPath) {
        this.mfsPath = mfsPath;
    }

    public String getIsUtc() {
        return this.isUtc;
    }

    public void setIsUtc(String isUtc) {
        this.isUtc = isUtc;
    }

    public String getOffsetTime() {
        return this.offsetTime;
    }

    public void setOffsetTime(String offsetTime) {
        this.offsetTime = offsetTime;
    }

    public String getIsCombinByNoCompress() {
        return this.isCombinByNoCompress;
    }

    public void setIsCombinByNoCompress(String isCombinByNoCompress) {
        this.isCombinByNoCompress = isCombinByNoCompress;
    }

    public String getPeriodType() {
        return this.periodType;
    }

    public void setPeriodType(String periodType) {
        this.periodType = periodType;
    }

    public String getOdsTableName() {
        return this.odsTableName;
    }

    public void setOdsTableName(String odsTableName) {
        this.odsTableName = odsTableName;
    }

    public String getDicName() {
        return this.dicName;
    }

    public void setDicName(String dicName) {
        this.dicName = dicName;
    }

    public String getLimitBand() {
        return this.limitBand;
    }

    public void setLimitBand(String limitBand) {
        this.limitBand = limitBand;
    }

    public String getTSIsOpenPeriodDir() {
        return this.tSIsOpenPeriodDir;
    }

    public void setTSIsOpenPeriodDir(String tSIsOpenPeriodDir) {
        this.tSIsOpenPeriodDir = tSIsOpenPeriodDir;
    }

    public String getTSDestFilePermission() {
        return this.tSDestFilePermission;
    }

    public void setTSDestFilePermission(String tSDestFilePermission) {
        this.tSDestFilePermission = tSDestFilePermission;
    }
}