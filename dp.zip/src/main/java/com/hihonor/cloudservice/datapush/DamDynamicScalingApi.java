package com.hihonor.cloudservice.datapush;

import com.alibaba.fastjson.JSONObject;
import com.hihonor.cloudservice.datapush.common.HttpUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.exception.DatapushException;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class DamDynamicScalingApi {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(DamDynamicScalingApi.class);

    /**
     * The Constant EXPANSION_FLAG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String EXPANSION_FLAG = "add";

    /**
     * The Constant SHRINK_FLAG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String SHRINK_FLAG = "del";

    /**
     * The Constant UPDATE_FLAG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String UPDATE_FLAG = "update";

    /**
     * The Constant TIMEOUT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int TIMEOUT = 10;

    /**
     * The Constant version.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String version = "";

    /**
     * The Constant IP.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String IP = "";

    /**
     * The Constant user.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String user = "";

    /**
     * The Constant scope.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String scope = "";

    /**
     * The Constant changeFlag.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String changeFlag = "";

    /**
     * The Constant jobList.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> jobList = null;

    /**
     * The Constant damOpen.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean damOpen = false;

    /**
     * The Constant damUrl.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String damUrl = "";

    /**
     * The Constant damSign.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String damSign = "";

    /**
     * The Constant damWork.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String damWork = "";

    /**
     * main
     *
     * @param args String[]
     * @author z00502253
     * @since 2022-06-30
     */
    public static void main(String[] args) {
        DamDynamicScalingApi dTool = new DamDynamicScalingApi();
        dTool.loadConf();
        if (!dTool.damOpen) {
            return;
        }
        try {
            dTool.dealArgs(args);
            int status = dTool.sendRequest();
            if (0 == status) {
                log.info("request success!");
            } else {
                log.error("request error!");
            }
        } catch (DatapushException e) {
            log.error("exit failed! {}", e.getMessage());
            System.exit(-1);
        }
    }

    /**
     * loadConf
     *
     * @author z00502253
     * @since 2020-06-24
     */
    private void loadConf() {
        InputStream in = null;
        try {
            String rootDir = FileUtils.getFile(new String[]{System.getProperty("user.dir")}).getCanonicalPath();
            (GlobalVariable.getInstance()).rootDir = rootDir;

            Util.loadLogBack(rootDir + File.separator + "conf" + File.separator + "logback.xml");
            log.info("------------------start------------------");
            in = FileUtils.openInputStream(
                    FileUtils.getFile(new String[]{rootDir + File.separator + "conf" + File.separator
                            + "datapush.properties"}));
            Properties properties = new Properties();
            properties.load(in);
            this.damOpen = Boolean.parseBoolean(properties.getProperty("da.open"));
            if (this.damOpen) {
                this.damUrl = properties.getProperty("da.url") + "/" + properties.getProperty("da.server.name")
                        + "/dynamicScaling";
                log.info("Dam url is {}", this.damUrl);
                Util.closeQuietly(in);
                Properties kp = new Properties();
                in = FileUtils.openInputStream(FileUtils.getFile(new String[]{rootDir
                        + "/conf/config/datapush.properties"}));
                kp.load(in);
                this.damSign = CryptService.decryptAes(kp.getProperty("da.sign"));
                this.damWork = kp.getProperty("da.work");
                Util.closeQuietly(in);
            }
        } catch (IOException | DatapushException e) {
            log.error("load config failed", e);
        } finally {
            Util.closeQuietly(in);
        }
        log.info("load conf success");
    }

    /**
     * dealArgs
     *
     * @param args String[]
     * @author z00502253
     * @since 2020-06-24
     */
    private void dealArgs(String[] args) throws DatapushException {
        log.info("params = {}", Arrays.toString((Object[]) args));
        this.changeFlag = args[0];
        this.IP = args[1];
        this.scope = args[2];
        this.jobList = Arrays.asList(args[3].split("\\$"));
        if (args.length > 4) {
            this.version = args[4];
            this.user = args[5];
        }
        if (!"add".equalsIgnoreCase(this.changeFlag) && !"del".equals(this.changeFlag) &&
                !"update".equals(this.changeFlag)) {
            throw new DatapushException("flag must equal add or update or del!");
        }
        log.info("deal args success");
    }

    /**
     * sendRequest
     *
     * @return int
     * @author z00502253
     * @since 2020-06-24
     */
    private int sendRequest() throws DatapushException {
        String result = "";
        int status = -1;
        Map<String, String> headers = buildHeader();
        Map<String, Object> params = buildParams();
        try {
            result = HttpUtil.sendRequest(this.damUrl, "POST", params, headers, 10);
            log.info("result:{} ", result);
            JSONObject jsonObject = JSONObject.parseObject(result);
            status = jsonObject.getInteger("status").intValue();
        } catch (DatapushException e) {
            log.warn("", (Throwable) e);
            throw new DatapushException("send request error");
        }
        return status;
    }

    /**
     * buildParams
     *
     * @return Map<String, Object>
     * @author z00502253
     * @since 2020-06-24
     */
    private Map<String, Object> buildParams() {
        Map<String, Object> params = new HashMap<>(6);
        params.put("dyScalingFlag", this.changeFlag);
        params.put("ip", this.IP);
        params.put("scope", this.scope);
        params.put("joblist", this.jobList);
        if (Util.isNotEmpty(this.user)) {
            params.put("user", this.user);
        }
        if (Util.isNotEmpty(this.version)) {
            params.put("version", this.version);
        }
        log.info("build params success!");
        log.info("dyScalingFlag is： {} | node is: {} | scope is：{} | joblist is: {}",
                new Object[]{this.changeFlag, this.IP, this.scope, this.jobList});
        return params;
    }

    /**
     * buildHeader
     *
     * @return Map<String, Object>
     * @author z00502253
     * @since 2020-06-24
     */
    private Map<String, String> buildHeader() throws DatapushException {
        long timestamp = System.currentTimeMillis();
        Map<String, String> headers = new HashMap<>(4);
        try {
            String random = CryptService.getSecureRandom(16);
            String sign = "random=" + random + "&systemid=" + this.damSign + "&timestamp=" + timestamp;
            sign = URLEncoder.encode(URLEncoder.encode(sign, "UTF-8"), "UTF-8");
            sign = CryptService.encryStringByHmacSHA256(sign, this.damWork);
            headers.put("Content-Type", "application/json");
            headers.put("timestamp", Long.toString(timestamp));
            headers.put("random", random);
            headers.put("sign", sign);
        } catch (UnsupportedEncodingException e) {
            log.error("build header error, {}", e.getMessage());
            throw new DatapushException("build header error", e);
        }
        log.info("build header success!");
        return headers;
    }
}