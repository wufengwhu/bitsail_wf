/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class FindFileUtil
        extends SimpleFileVisitor<Path> {

    /**
     * The Constant maxDirDepth.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int maxDirDepth;

    /**
     * The Constant result.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private ArrayList<Path> result;

    /**
     * The Constant match.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String match;

    /**
     * The Constant methodType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int methodType;

    public FindFileUtil(int maxDirDepth) {
        this.maxDirDepth = maxDirDepth;
    }

    /**
     * getFileByEndName
     *
     * @param path path
     * @param match String
     * @return ArrayList
     * @author z00502253
     * @since 2020-02-16
     */
    public ArrayList<Path> getFileByEndName(Path path, String match) throws IOException {
        this.result = new ArrayList<>();
        this.match = match;
        this.methodType = 0;
        Files.walkFileTree(path, EnumSet.noneOf(FileVisitOption.class), this.maxDirDepth, this);
        return this.result;
    }

    /**
     * getFileByRegex
     *
     * @param path path
     * @param match String
     * @return List
     * @author z00502253
     * @since 2020-02-16
     */
    public List<Path> getFileByRegex(Path path, String match) throws IOException {
        this.result = new ArrayList<>();
        this.match = match;
        this.methodType = 1;
        Files.walkFileTree(path, EnumSet.noneOf(FileVisitOption.class), this.maxDirDepth, this);
        return this.result;
    }

    /**
     * addByEndName
     *
     * @param file file
     * @author z00502253
     * @since 2022-07-01
     */
    private void addByEndName(Path file) {
        if (file.endsWith(this.match)) {
            this.result.add(file);
        }
    }

    /**
     * addByRegex
     *
     * @param file file
     * @author z00502253
     * @since 2022-07-01
     */
    private void addByRegex(Path file) {
        Pattern pattern = Pattern.compile(this.match);
        Matcher matcher = pattern.matcher(file.toFile().getName());
        if (matcher.matches()) {
            this.result.add(file);
        }
    }

    /**
     * visitFile
     *
     * @param file path
     * @param attrs attrs
     * @return vo
     * @author z00502253
     * @since 2020-02-16
     */
    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
        if (!file.toFile().exists()) {
            return FileVisitResult.CONTINUE;
        }
        if (this.methodType == 1) {
            addByRegex(file);
        } else {
            addByEndName(file);
        }
        return FileVisitResult.CONTINUE;
    }

    /**
     * visitFileFailed
     *
     * @param file file
     * @return vo
     * @author z00502253
     * @since 2022-07-01
     */
    public FileVisitResult visitFileFailed(Path file, IOException exc) {
        return FileVisitResult.CONTINUE;
    }
}