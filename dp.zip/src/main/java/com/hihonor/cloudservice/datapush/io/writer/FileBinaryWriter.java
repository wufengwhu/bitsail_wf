package com.hihonor.cloudservice.datapush.io.writer;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.io.FilesBlock;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-05
 */
public class FileBinaryWriter
        extends FileJobWriter
        implements Callable<Boolean> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FileBinaryWriter.class);

    public FileBinaryWriter(Path file, long averageSize) {
        super(file, averageSize);
    }

    /**
     * call
     *
     * @return Boolean
     * @author z00502253
     * @since 2020-02-16
     */
    public Boolean call() {
        BufferedOutputStream writer = null;
        try {
            writer = new BufferedOutputStream(FileUtils.openOutputStream(this.source), 4194304);
            writeBinary(writer);
            return Boolean.valueOf(true);
        } catch (IOException | InterruptedException | UnsupportedOperationException | DatapushException e) {
            log.error("write writeFile thread error", e);
        } finally {
            Util.closeQuietly(writer);
            if (this.channel != null) {
                this.channel.setActive(false);
            }
        }
        log.debug("write-{} exit------>{}", Long.valueOf(Thread.currentThread().getId()), this.source.getName());
        return Boolean.valueOf(false);
    }

    /**
     * writeBinary
     *
     * @param writer writer
     * @author z00502253
     * @since 2022-08-15
     */
    private void writeBinary(BufferedOutputStream writer) throws InterruptedException, IOException, DatapushException {
        int i = 0;
        selectChannel();
        long startTime = System.currentTimeMillis();
        while (true) {
            if (this.channel.isError()) {
                throw new DatapushException("binary read channel error");
            }
            FilesBlock filesBlock = this.channel.getFilesBlocks().poll(100L, TimeUnit.MILLISECONDS);
            if (filesBlock == null) {
                continue;
            }
            if (i == 0) {
                log.info("binary write start----->{}", this.source.getName());
                startTime = System.currentTimeMillis();
                i++;
            }
            if (filesBlock.getDataBytes() != null) {
                writer.write(filesBlock.getDataBytes());
                writer.flush();
                this.currentSize += (filesBlock.getDataBytes()).length;
                print(this.source.getName());
            }
            if (filesBlock.isEndTag()) {
                if (this.processList.size() > 0 && ((String) this.processList.get(this.processList.size() - 1))
                        .equals("100")) {
                    log.info("binary write process--->{}({}%)", this.source.getName(),
                            this.processList.get(this.processList.size() - 1));
                }
                log.info("binary write end------->{}(size = {}, use times = {} ms)",
                        new Object[]{this.source.getName(), Long.valueOf(this.source.length()),
                        Long.valueOf(System.currentTimeMillis() - startTime)});
                return;
            }
        }
    }
}