package com.hihonor.cloudservice.datapush.jsch;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class Sftp {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(Sftp.class);

    /**
     * The Constant sshInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Ssh sshInfo;

    public Sftp(Ssh sshInfo) {
        this.sshInfo = sshInfo;
    }

    /**
     * run
     *
     * @author z00502253
     * @since 2020-06-23
     */
    public void run() throws DatapushException, JSchException, SftpException, IOException {
        Session session = null;
        ChannelSftp channel = null;
        InputStream inputStream = null;
        try {
            session = this.sshInfo.getConnection();
            log.info("ssh connect success...");
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect(this.sshInfo.getTimeOut());
            log.info("channel connect success...");
            inputStream = FileUtils.openInputStream(this.sshInfo.getLocalFile());
            channel.put(inputStream, this.sshInfo.getRemotePath() + "/"
                     + this.sshInfo.getLocalFile().getName(), new SftpMonitor(this.sshInfo
                    .getJobName(), this.sshInfo.getLocalFile().getName(), this.sshInfo
                    .getLocalFile().length()), 1);

            channel.quit();
        } finally {
            Util.closeQuietly(inputStream);
            if (null != channel) {
                channel.disconnect();
            }
            if (null != session)
                session.disconnect();
        }
    }
}