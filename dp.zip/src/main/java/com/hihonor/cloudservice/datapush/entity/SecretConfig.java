package com.hihonor.cloudservice.datapush.entity;

import java.util.Date;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class SecretConfig {

    /**
     * The Constant key.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String key;

    /**
     * The Constant value.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Object value;

    /**
     * The Constant expiredTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Date expiredTime;

    public String getKey() {
        return this.key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Object getValue() {
        return this.value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Date getExpiredTime() {
        return new Date(this.expiredTime.getTime());
    }

    public void setExpiredTime(Date expiredTime) {
        this.expiredTime = new Date(expiredTime.getTime());
    }
}