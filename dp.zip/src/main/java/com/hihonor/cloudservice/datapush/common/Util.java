package com.hihonor.cloudservice.datapush.common;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.joran.spi.JoranException;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.huawei.secure.xml.SAXReaderSecurity;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.bouncycastle.util.encoders.Hex;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public final class Util {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(Util.class);

    /**
     * getId
     *
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String getId() {
        return UUID.randomUUID().toString().toLowerCase()
                .replace("-", "").replace(" ", "");
    }

    /**
     * getSplitFile
     *
     * @param name String
     * @param nameSuffix String
     * @param fileIndex int
     * @return File
     * @author z00502253
     * @since 2020-02-16
     */
    public static File getSplitFile(String name, String nameSuffix, int fileIndex) {
        if (name.indexOf(".") > 0) {
            return FileUtils.getFile(new String[]{getSplitName(name, nameSuffix, fileIndex)});
        }
        return FileUtils.getFile(new String[]{name + nameSuffix + getSplitFlag(fileIndex)});
    }

    /**
     * getSplitName
     *
     * @param name String
     * @param nameSuffix String
     * @param fileIndex int
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String getSplitName(String name, String nameSuffix, int fileIndex) {
        if (name.indexOf(".") > 0) {
            return name.substring(0, name.lastIndexOf(".")) + nameSuffix +
                    getSplitFlag(fileIndex) + name.substring(name.lastIndexOf("."));
        }
        return name + nameSuffix + getSplitFlag(fileIndex);
    }

    /**
     * getDirNameByTime
     *
     * @param format String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String getDirNameByTime(String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            return sdf.format(Calendar.getInstance().getTime());
        } catch (IllegalArgumentException | NullPointerException e) {
            log.error("define directory by time error");
            return "";
        }
    }

    /**
     * getProcessID
     *
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String getProcessID() {
        String processName = ManagementFactory.getRuntimeMXBean().getName();
        if (isNotEmpty(processName) &&
                processName.indexOf('@') > 0) {
            return processName.substring(0, processName.indexOf('@'));
        }
        return UUID.randomUUID().toString().replace("-", "");
    }

    /**
     * byte2HexStr
     *
     * @param array byte[]
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String byte2HexStr(byte[] array) {
        if (null == array) {
            return "";
        }
        return Hex.toHexString(array);
    }

    /**
     * offsetTime
     *
     * @param time Date
     * @param offSet int
     * @param cycleLength int
     * @param periodType String
     * @return Date
     * @author z00502253
     * @since 2020-02-16
     */
    public static Date offsetTime(Date time, int offSet, int cycleLength, String periodType) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(time);
        switch (Character.toUpperCase(periodType.trim().charAt(0))) {
            case 'D':
                cal.add(5, offSet * cycleLength);
                break;

            case 'H':
                cal.add(11, offSet * cycleLength);
                break;

            case 'M':
                cal.add(12, offSet * cycleLength);
                break;
        }
        cal.add(13, -1);
        return cal.getTime();
    }

    /**
     * replaceFieldSep
     *
     * @param fSep String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String replaceFieldSep(String fSep) {
        if (fSep == null || fSep.length() == 0) {
            return fSep;
        }
        String baseSep = fSep;
        baseSep = baseSep.replace("\\t", "\t");
        baseSep = baseSep.replace("\\001", "\001");
        return baseSep;
    }

    /**
     * resetReplaceFieldSep
     *
     * @param fieldSep String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String resetReplaceFieldSep(String fieldSep) {
        if (fieldSep == null || fieldSep.length() == 0) {
            return fieldSep;
        }
        String restFieldSep = fieldSep;
        restFieldSep = restFieldSep.replace("\t", "\\t");
        restFieldSep = restFieldSep.replace("\001", "\\001");
        return restFieldSep;
    }

    /**
     * replaceLineSep
     *
     * @param lSep String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String replaceLineSep(String lSep) {
        if (lSep == null || lSep.length() == 0) {
            return lSep;
        }
        String baseSep = lSep;
        baseSep = baseSep.replace("\\r", "\r");
        baseSep = baseSep.replace("\\n", "\n");
        return baseSep;
    }

    /**
     * resetReplaceLineSep
     *
     * @param lineSep String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String resetReplaceLineSep(String lineSep) {
        if (lineSep == null || lineSep.length() == 0) {
            return lineSep;
        }
        String restLineSep = lineSep;
        restLineSep = restLineSep.replace("\r", "\\r");
        restLineSep = restLineSep.replace("\n", "\\n");
        return restLineSep;
    }

    /**
     * closeQuietly
     *
     * @param closeable closeable
     * @author z00502253
     * @since 2020-02-16
     */
    public static void closeQuietly(Closeable closeable) {
        if (null != closeable) {
            try {
                closeable.close();
            } catch (IOException e) {
                log.debug("close error", e);
            }
        }
    }

    /**
     * getDocument
     *
     * @param file file
     * @return Document
     * @author z00502253
     * @since 2020-02-16
     */
    public static Document getDocument(File file) throws DocumentException, SAXException {
        return SAXReaderSecurity.getInstance().read(file);
    }

    /**
     * loadLogBack
     *
     * @param logPath String
     * @author z00502253
     * @since 2020-02-16
     */
    public static void loadLogBack(String logPath) throws DatapushException {
        try {
            File logFile = FileUtils.getFile(new String[]{logPath});
            if (logFile.exists()) {
                LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
                JoranConfigurator joranConfigurator = new JoranConfigurator();
                joranConfigurator.setContext((Context) loggerContext);
                loggerContext.reset();
                joranConfigurator.doConfigure(logFile);
            } else {
                log.warn("no found log config file={}", logPath);
                throw new DatapushException("load log config fail : no found log file");
            }
        } catch (JoranException | DatapushException e) {
            log.error("load log config failed", e);
            throw new DatapushException("load log config failed", e);
        }
    }

    /**
     * sleep
     *
     * @param time long
     * @author z00502253
     * @since 2020-02-16
     */
    public static void sleep(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            log.warn("sleep error", e);
        }
    }

    /**
     * deleteFile
     *
     * @param file file
     * @author z00502253
     * @since 2022-07-01
     */
    private static void deleteFile(File file) {
        try {
            file.delete();
        } catch (SecurityException | NullPointerException e) {
            log.warn("delete fail", e);
        }
    }

    /**
     * getPathsSize
     *
     * @param files List<Path>
     * @return long
     * @author z00502253
     * @since 2020-02-16
     */
    public static long getPathsSize(List<Path> files) {
        long all = 0L;
        for (Path path : files) {
            all += path.toFile().length();
        }
        return all;
    }

    /**
     * isEmpty
     *
     * @param cs cs
     * @return boolean
     * @author z00502253
     * @since 2020-02-16
     */
    public static boolean isEmpty(CharSequence cs) {
        return (cs == null || cs.length() == 0);
    }

    /**
     * isNotEmpty
     *
     * @param cs cs
     * @return boolean
     * @author z00502253
     * @since 2020-02-16
     */
    public static boolean isNotEmpty(CharSequence cs) {
        return !isEmpty(cs);
    }

    /**
     * rightPad
     *
     * @param str String
     * @param size int
     * @param padStr String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String rightPad(String str, int size, String padStr) {
        if (str == null) {
            return str;
        }
        if (str.length() >= size) {
            return str.substring(0, size);
        }
        char[] padding = new char[size - str.length()];
        char[] padChars = padStr.toCharArray();
        for (int i = 0; i < size - str.length(); i++) {
            padding[i] = padChars[i % padStr.length()];
        }
        return str.concat(new String(padding));
    }

    /**
     * getInt
     *
     * @param value String
     * @param defaultValue int
     * @return int
     * @author z00502253
     * @since 2020-02-16
     */
    public static int getInt(String value, int defaultValue) {
        int intValue;
        if (isEmpty(value)) {
            return defaultValue;
        }
        try {
            intValue = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            log.info("use default value {}", Integer.valueOf(defaultValue));
            intValue = defaultValue;
        }
        return intValue;
    }

    /**
     * getProcess
     *
     * @return List<String>
     * @author z00502253
     * @since 2020-02-16
     */
    public static List<String> getProcess() {
        return Arrays.asList(new String[]{"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"});
    }

    /**
     * getSplitFlag
     *
     * @param num int
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String getSplitFlag(int num) {
        char[] chs = new char[2];
        if (num % 26 == 0) {
            chs[0] = (char) (num / 26 + 96);
            chs[1] = 'z';
        } else {
            chs[0] = (char) (num / 26 + 97);
            chs[1] = (char) (num % 26 + 96);
        }
        return new String(chs);
    }

    /**
     * getPercent
     *
     * @param cur long
     * @param total long
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String getPercent(long cur, long total) {
        NumberFormat numberFormat = NumberFormat.getInstance();
        numberFormat.setMaximumFractionDigits(0);
        return numberFormat.format(((float) cur / (float) total * 100.0F));
    }

    /**
     * getTimeStr
     *
     * @param type String
     * @param periodTime String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String getTimeStr(String type, String periodTime) {
        switch (type.toUpperCase()) {
            case "M":
                String tmpDir = periodTime.substring(0, 12).replace("//", "/");
                return tmpDir;
            case "H":
                tmpDir = periodTime.substring(0, 10).replace("//", "/");
                return tmpDir;
            case "D":
                tmpDir = periodTime.substring(0, 8).replace("//", "/");
                return tmpDir;
        }
        String tmpDir = getDirNameByTime("yyyyMMdd").replace("//", "/");
        return tmpDir;
    }

    /**
     * getDistanceTime
     *
     * @param startTime long
     * @param endTime long
     * @return int
     * @author z00502253
     * @since 2020-02-16
     */
    public static int getDistanceTime(long startTime, long endTime) {
        long diff;
        if (startTime < endTime) {
            diff = endTime - startTime;
        } else {
            diff = startTime - endTime;
        }
        return (int) (diff / 86400000L);
    }

    /**
     * dealIDELogFiles
     *
     * @param jobName String
     * @param rootDir String
     * @param logClearTime int
     * @author z00502253
     * @since 2020-02-16
     */
    public static void dealIDELogFiles(String jobName, String rootDir, int logClearTime) {
        try {
            Path logDir = Paths.get(rootDir, new String[]{"IDE", "log"});
            if (!logDir.toFile().exists()) {
                return;
            }
            List<Path> logFiles = (new FindFileUtil(1)).getFileByRegex(logDir, "^" + jobName + ".*");
            for (Path logFile : logFiles) {
                if (getDistanceTime(logFile.toFile().lastModified(),
                        Calendar.getInstance().getTimeInMillis()) >= logClearTime) {
                    log.debug("{} will be deleted...(created time = {} days)", logFile.getFileName(),
                            Integer.valueOf(getDistanceTime(logFile.toFile().lastModified(),
                                    Calendar.getInstance().getTimeInMillis())));
                    FileUtils.forceDelete(logFile.toFile());
                }
            }
        } catch (IOException e) {
            log.warn("delete ide logs error", e);
        }
    }

    /**
     * checkIp
     *
     * @param ip String
     * @return boolean
     * @author z00502253
     * @since 2020-02-16
     */
    public static boolean checkIp(String ip) {
        String reg = "^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])$";

        Pattern pattern = Pattern.compile(reg);
        return pattern.matcher(ip).matches();
    }

    /**
     * join
     *
     * @param list List<String>
     * @param separator String
     * @return String
     * @author z00502253
     * @since 2020-02-16
     */
    public static String join(List<String> list, String separator) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < list.size(); i++) {
            if (i == list.size() - 1) {
                stringBuffer.append(list.get(i));
            } else {
                stringBuffer.append((String) list.get(i) + separator);
            }
        }
        return stringBuffer.toString();
    }
}