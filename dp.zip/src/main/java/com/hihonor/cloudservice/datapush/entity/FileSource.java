package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class FileSource {

    /**
     * The Constant directory.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String directory;

    /**
     * The Constant childDirRegex.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String childDirRegex;

    /**
     * The Constant fileDepth.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int fileDepth;

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public void setChildDirRegex(String childDirRegex) {
        this.childDirRegex = childDirRegex;
    }

    public void setFileDepth(int fileDepth) {
        this.fileDepth = fileDepth;
    }

    /**
     * equals
     *
     * @param o Object
     * @return boolean
     * @author z00502253
     * @since 2020-02-20
     */
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof FileSource)) return false;
        FileSource other = (FileSource) o;
        if (!other.canEqual(this)) return false;
        Object this$directory = getDirectory(), other$directory = other.getDirectory();
        if ((this$directory == null) ? (other$directory != null) : !this$directory.equals(other$directory))
            return false;
        Object this$childDirRegex = getChildDirRegex(), other$childDirRegex = other.getChildDirRegex();
        return ((this$childDirRegex == null) ? (other$childDirRegex != null)
                : !this$childDirRegex.equals(other$childDirRegex)) ? false
                : (!(getFileDepth() != other.getFileDepth()));
    }

    protected boolean canEqual(Object other) {
        return other instanceof FileSource;
    }

    /**
     * hashCode
     *
     * @return int
     * @author z00502253
     * @since 2020-02-20
     */
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $directory = getDirectory();
        result = result * 59 + (($directory == null) ? 43 : $directory.hashCode());
        Object $childDirRegex = getChildDirRegex();
        result = result * 59 + (($childDirRegex == null) ? 43 : $childDirRegex.hashCode());
        return result * 59 + getFileDepth();
    }

    public String toString() {
        return "FileSource(directory=" + getDirectory() + ", childDirRegex=" + getChildDirRegex()
                + ", fileDepth=" + getFileDepth() + ")";
    }

    public String getDirectory() {
        return this.directory;
    }

    public String getChildDirRegex() {
        return this.childDirRegex;
    }

    public int getFileDepth() {
        return this.fileDepth;
    }
}

