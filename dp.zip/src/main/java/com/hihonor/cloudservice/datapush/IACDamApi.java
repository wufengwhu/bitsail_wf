package com.hihonor.cloudservice.datapush;

import com.hihonor.cloudservice.datapush.comenum.PeriodTypeEnum;
import com.hihonor.cloudservice.datapush.common.FilePathCheck;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.config.SingleConfig;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.tasks.DamController;
import com.hihonor.cloudservice.datapush.tasks.WiseEyeConfigCenterController;


import com.hihonor.cloudservice.datapush.entity.DamConfig;
import com.hihonor.cloudservice.datapush.entity.DbSource;
import com.hihonor.cloudservice.datapush.entity.FileSource;
import com.hihonor.cloudservice.datapush.entity.IACDataPushDB;
import com.hihonor.cloudservice.datapush.entity.IACDataPushFile;
import com.hihonor.cloudservice.datapush.entity.IACDataSource;
import com.hihonor.cloudservice.datapush.entity.IacDataPushHostsInfo;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

/**
 * 功能描述
 *
 * @since 2022-04-22
 */
public class IACDamApi {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(IACDamApi.class);

    /**
     * The Constant actionType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String actionType;

    /**
     * The Constant configIniPath.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String configIniPath;

    /**
     * The Constant datapushScope.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String datapushScope;

    /**
     * The Constant userName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String userName;

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String jobName;

    /**
     * The Constant jobType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String jobType;

    /**
     * The Constant crontabCycle.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String crontabCycle;

    /**
     * The Constant offsetName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String offsetName;

    /**
     * The Constant isUTC.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String isUTC;

    /**
     * The Constant dicName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String dicName;

    /**
     * The Constant packageConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static Properties packageConfig;

    /**
     * The Constant damConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static DamConfig damConfig;

    /**
     * loadParams
     *
     * @param args String[]
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadParams(String[] args) throws DatapushException {
        if (args == null || args.length < 2) {
            throw new DatapushException("args missing");
        }
        actionType = args[0];
        configIniPath = FilePathCheck.checkFilePath(args[1]);
        if ("0".equals(actionType)) {
            if (args.length != 2) {
                throw new DatapushException("job args missing");
            }
        } else if ("1".equals(actionType)) {
            if (args.length != 4) {
                throw new DatapushException("install args missing");
            }
            datapushScope = args[2];
            userName = args[3];
        } else {
            throw new DatapushException("IAC push DAM actionType Invalid");
        }
    }

    /**
     * loadJobIni
     *
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadJobIni() throws IOException {
        Properties jobInfo = new Properties();
        try (InputStreamReader jobInfoIn = new InputStreamReader(new FileInputStream(configIniPath
                + "/iac_jobs_info.ini"), "UTF-8")) {
            jobInfo.load(jobInfoIn);
        }
        jobName = jobInfo.getProperty("jobName");
        log.debug("jobName={}", jobName);
        jobType = jobInfo.getProperty("jobType");
        log.debug("jobType={}", jobType);
        crontabCycle = jobInfo.getProperty("crontabCycle");
        log.debug("crontabCycle={}", crontabCycle);
        offsetName = jobInfo.getProperty("offsetName");
        log.debug("offsetName={}", offsetName);
        isUTC = jobInfo.getProperty("isUTC");
        log.debug("isUTC={}", isUTC);
        dicName = URLEncoder.encode(jobInfo.getProperty("dicName")
                .replace(new String(Character.toChars(27)), ""), "UTF-8");
        log.debug("dicName={}", dicName);
    }

    /**
     * loadConfigIni
     *
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadConfigIni() throws IOException {
        packageConfig = new Properties();
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(new String[]{configIniPath
                + "/config.ini"}))) {
            packageConfig.load(in);
        }
    }

    /**
     * dealInstallReq
     *
     * @param rootDir String
     * @param damController damController
     * @author z00502253
     * @since 2020-06-24
     */
    private static void dealInstallReq(String rootDir, DamController damController) throws IOException {
        log.info("The IAC requests the DAM to start pushing deployment information");
        IacDataPushHostsInfo iacDataPushHostsInfo = new IacDataPushHostsInfo();
        iacDataPushHostsInfo.setJobName(jobName);
        iacDataPushHostsInfo.setLstdyTime(packageConfig.getProperty("time"));
        iacDataPushHostsInfo.setHostStatus("success");
        iacDataPushHostsInfo.setPatchStatus("success");
        iacDataPushHostsInfo.setVersion(packageConfig.getProperty("pkg_version"));
        iacDataPushHostsInfo.setScopeId(getScopeId(rootDir, datapushScope));
        iacDataPushHostsInfo.setChanneld("");
        iacDataPushHostsInfo.setHostId(packageConfig.getProperty("ip"));
        iacDataPushHostsInfo.setChannelUserName(userName);
        List<IacDataPushHostsInfo> datapushHostInfoList = new ArrayList<>();
        datapushHostInfoList.add(iacDataPushHostsInfo);
        HashMap<String, Object> requestParam = new HashMap<>();
        requestParam.put("actionType", Integer.valueOf(1));
        requestParam.put("datapushHostInfoList", datapushHostInfoList);
        damController.iacPush(requestParam);
        log.info("The IAC requests the DAM to end pushing deployment information");
    }

    /**
     * getScopeId
     *
     * @param rootDir String
     * @param scopeName String
     * @return int
     * @author z00502253
     * @since 2020-06-24
     */
    private static int getScopeId(String rootDir, String scopeName) throws IOException {
        Properties properties = new Properties();
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(
                new String[]{rootDir + "/conf/wiseEye.properties"}))) {
            properties.load(in);
        }
        WiseEyeConfigCenterController wiseEyeConfigCenterController = new WiseEyeConfigCenterController(properties);
        return wiseEyeConfigCenterController.getScope(scopeName);
    }

    /**
     * dealJobReq
     *
     * @param rootDir String
     * @param damController damController
     * @author z00502253
     * @since 2020-06-24
     */
    private static void dealJobReq(String rootDir, DamController damController) throws IOException {
        log.info("The IAC requests the DAM to start pushing task information");
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(new String[]{rootDir
                + "/conf/datapush.properties"}))) {
            Properties sysPro = new Properties();
            sysPro.load(in);
        }
        if ("0".equals(jobType)) {
            dealDBJobReq(damController);
        } else if ("1".equals(jobType)) {
            dealFileJobReq(damController);
        } else {
            throw new DatapushException("job type no match");
        }
        log.info("The IAC requests the DAM to end pushing task information");
    }

    /**
     * getTaskInfo
     *
     * @param jobName String
     * @author z00502253
     * @since 2020-06-24
     */
    private static TaskInfo getTaskInfo(String jobName) {
        String jobConfigPath = configIniPath + "/" + jobName + "_config.xml";
        Path path = Paths.get(jobConfigPath, new String[0]);
        SingleConfig singleConfig = new SingleConfig(path);
        return singleConfig.getTaskInfo();
    }

    /**
     * dealDBJobReq
     *
     * @param damController damController
     * @author z00502253
     * @since 2020-06-24
     */
    private static void dealDBJobReq(DamController damController) throws IOException {
        TaskInfo taskInfo = getTaskInfo(jobName);
        HashMap<String, Object> requestParam = new HashMap<>();
        requestParam.put("actionType", "0");
        requestParam.put("taskType", "0");
        requestParam.put("datapushDb", buildIACDataPushDB(taskInfo));
        damController.iacPush(requestParam);
    }

    /**
     * buildIACDataPushDB
     *
     * @param taskInfo taskInfo
     * @author z00502253
     * @since 2020-06-24
     */
    private static IACDataPushDB buildIACDataPushDB(TaskInfo taskInfo) throws IOException {
        IACDataPushDB iacDataPushDB = new IACDataPushDB();
        iacDataPushDB.setDataSources(buildIACDataSource(taskInfo));
        iacDataPushDB.setReplaceSource(Util.resetReplaceFieldSep(taskInfo.getDatabaseTask().getReplaceSource()));
        iacDataPushDB.setReplaceTarget(Util.resetReplaceFieldSep(taskInfo.getDatabaseTask().getReplaceTarget()));
        iacDataPushDB.setExtractSql(taskInfo.getDatabaseTask().getSql());
        iacDataPushDB.setJobName(jobName);
        iacDataPushDB.setIsOnlyLzoCompress(taskInfo.isLzo() + "");
        iacDataPushDB.setMode(taskInfo.getMode());
        iacDataPushDB.setSplitSize(taskInfo.getSplitSize());
        iacDataPushDB.setSendThreadCount(taskInfo.getSendFileMaxThreads());
        iacDataPushDB.setRemoteTimeOut(taskInfo.getTimeOut());
        iacDataPushDB.setOsUser(taskInfo.getHostUser());
        iacDataPushDB.setReSendTimes(taskInfo.getReTimes());
        iacDataPushDB.setWaitTime(taskInfo.getWaitTime() / 60000);
        iacDataPushDB.setRemoteDirectory(taskInfo.getDirectory().endsWith("/") ? taskInfo
                .getDirectory() : (taskInfo.getDirectory() + "/"));
        iacDataPushDB.setSourceFilePolicy(taskInfo.getWorkPolicy());
        iacDataPushDB.setPeriodType(taskInfo.getPeriodType());
        iacDataPushDB.setTSIsOpenPeriodDir(Util.isNotEmpty(taskInfo.getIsOpenPeriodDir()) ? taskInfo
                .getIsOpenPeriodDir().toLowerCase() : "true");
        iacDataPushDB.setTSDestFilePermission(taskInfo.getDestFilePermission());
        String[] cronArray = crontabCycle.split(" ");
        if (PeriodTypeEnum.HOUR.en.equalsIgnoreCase(iacDataPushDB.getPeriodType())) {
            iacDataPushDB.setPushTimeHH(1);
        } else if (PeriodTypeEnum.DAY.en.equalsIgnoreCase(iacDataPushDB.getPeriodType())) {
            try {
                iacDataPushDB.setPushTimeHH(Integer.parseInt(cronArray[1]));
            } catch (NumberFormatException e) {
                throw new DatapushException("The crontab expression of the DB task is incorrect.");
            }
        } else {
            throw new DatapushException("The period type can only be D or H.");
        }
        try {
            iacDataPushDB.setPushTimehh(Integer.parseInt(cronArray[0]));
        } catch (NumberFormatException e) {
            throw new DatapushException("The crontab expression of the DB task is incorrect.");
        }
        iacDataPushDB.setPushTimePer(1);
        iacDataPushDB.setOdsTableName(taskInfo.getOdsName());
        iacDataPushDB.setDestFileName(taskInfo.getDestFileName());
        iacDataPushDB.setFieldSeparator(Util.resetReplaceFieldSep(taskInfo.getFieldSep()));
        iacDataPushDB.setIsAlarm(taskInfo.isAlarm() + "");
        iacDataPushDB.setAlarmScope(taskInfo.getAlarmScope());
        iacDataPushDB.setAlarmLevel(taskInfo.getAlarmLevel());
        iacDataPushDB.setMfsPath(iacDataPushDB.getRemoteDirectory());
        iacDataPushDB.setOffsetTime(offsetName);
        iacDataPushDB.setIsUtc(isUTC);
        iacDataPushDB.setIsCombinByNoCompress(taskInfo.isCompress() + "");
        iacDataPushDB.setDicName(dicName);
        iacDataPushDB.setLimitBand(taskInfo.getLimitBand() + "");
        return iacDataPushDB;
    }

    /**
     * buildIACDataSource
     *
     * @param taskInfo taskInfo
     * @return List
     * @author z00502253
     * @since 2020-06-24
     */
    private static List<IACDataSource> buildIACDataSource(TaskInfo taskInfo) throws IOException {
        List<IACDataSource> dataSources = new ArrayList<>();
        for (DbSource dbSources : taskInfo.getDatabaseTask().getDbSources()) {
            IACDataSource iacDataSource = new IACDataSource();
            iacDataSource.setType(dbSources.getType());
            iacDataSource.setIp(dbSources.getHost());
            iacDataSource.setPort(dbSources.getPort());
            iacDataSource.setDatabase(dbSources.getDataName());
            iacDataSource.setUserName(dbSources.getUser());
            iacDataSource.setPassword(dbSources.getPassword());
            iacDataSource.setAdditionalInfo(Util.isEmpty(dbSources.getExtendParams()) ? "" :
                    URLEncoder.encode(dbSources.getExtendParams(), "UTF-8"));
            iacDataSource.setSql(dbSources.getSql());
            dataSources.add(iacDataSource);
        }
        return dataSources;
    }

    /**
     * dealFileJobReq
     *
     * @param damController damController
     * @author z00502253
     * @since 2020-06-24
     */
    private static void dealFileJobReq(DamController damController) {
        TaskInfo taskInfo = getTaskInfo(jobName);
        HashMap<String, Object> requestParam = new HashMap<>();
        requestParam.put("actionType", "0");
        requestParam.put("taskType", "1");
        requestParam.put("datapushFile", buildIACDataPushFile(taskInfo));
        damController.iacPush(requestParam);
    }

    /**
     * buildIACDataPushFile
     *
     * @param taskInfo taskInfo
     * @author z00502253
     * @since 2020-06-24
     */
    private static IACDataPushFile buildIACDataPushFile(TaskInfo taskInfo) {
        IACDataPushFile iacDataPushFile = new IACDataPushFile();
        iacDataPushFile.setFileSource(buildFileSource(taskInfo));
        iacDataPushFile.setFileMask(Util.join(taskInfo.getFilesTask().getFilesMask(), "\\|"));
        iacDataPushFile.setFileFetchMode(taskInfo.getFilesTask().getFetchMode());
        iacDataPushFile.setFileCountThreshold(taskInfo.getFilesTask().getCheckFileCount());
        iacDataPushFile.setFileSizeThreshold(taskInfo.getFilesTask().getCheckFileSize());
        iacDataPushFile.setReRetryTimes(taskInfo.getFilesTask().getCheckTimes());
        iacDataPushFile.setReRetryWaitTime(taskInfo.getFilesTask().getCheckWaitTimes() / 60000);
        iacDataPushFile.setIsOnlyTrans(taskInfo.isOnlyTrans() + "");
        iacDataPushFile.setJobName(jobName);
        iacDataPushFile.setIsOnlyLzoCompress(taskInfo.isLzo() + "");
        iacDataPushFile.setMode(taskInfo.getMode());
        iacDataPushFile.setSplitSize(taskInfo.getSplitSize());
        iacDataPushFile.setSendThreadCount(taskInfo.getSendFileMaxThreads());
        iacDataPushFile.setRemoteTimeOut(taskInfo.getTimeOut());
        iacDataPushFile.setReSendTimes(taskInfo.getReTimes());
        iacDataPushFile.setOsUser(taskInfo.getHostUser());
        iacDataPushFile.setWaitTime(taskInfo.getWaitTime() / 60000);
        iacDataPushFile.setSourceFilePolicy(taskInfo.getWorkPolicy());
        iacDataPushFile.setRemoteDirectory(taskInfo.getDirectory().endsWith("/") ? taskInfo
                .getDirectory() : (taskInfo.getDirectory() + "/"));
        iacDataPushFile.setPeriodType(taskInfo.getPeriodType());
        iacDataPushFile.setIfOnlyTransISRename(taskInfo.isOnlyTransISRename() + "");
        iacDataPushFile.setTSIsOpenPeriodDir(Util.isNotEmpty(taskInfo.getIsOpenPeriodDir()) ? taskInfo
                .getIsOpenPeriodDir().toLowerCase() : "true");
        iacDataPushFile.setTSDestFilePermission(taskInfo.getDestFilePermission());
        String[] cronArray = crontabCycle.split(" ");
        if (PeriodTypeEnum.HOUR.en.equalsIgnoreCase(iacDataPushFile.getPeriodType())) {
            iacDataPushFile.setPushTimeHH(1);
        } else if (PeriodTypeEnum.DAY.en.equalsIgnoreCase(iacDataPushFile.getPeriodType())) {
            try {
                iacDataPushFile.setPushTimeHH(Integer.parseInt(cronArray[1]));
            } catch (NumberFormatException e) {
                throw new DatapushException("The crontab expression of the file task is incorrect.");
            }
        } else {
            throw new DatapushException("The period type can only be D or H.");
        }
        try {
            iacDataPushFile.setPushTimehh(Integer.parseInt(cronArray[0]));
        } catch (NumberFormatException e) {
            throw new DatapushException("The crontab expression of the file task is incorrect.");
        }
        iacDataPushFile.setPushTimePer(1);
        iacDataPushFile.setDestFileName(taskInfo.getDestFileName());
        iacDataPushFile.setFieldSeparator(Util.isEmpty(taskInfo.getFieldSep()) ? "|" : taskInfo.getFieldSep());
        iacDataPushFile.setIsAlarm(taskInfo.isAlarm() + "");
        iacDataPushFile.setAlarmLevel(taskInfo.getAlarmLevel());
        iacDataPushFile.setAlarmScope(taskInfo.getAlarmScope());
        iacDataPushFile.setMfsPath(iacDataPushFile.getRemoteDirectory());
        iacDataPushFile.setOffsetTime(offsetName);
        iacDataPushFile.setIsUtc(isUTC);
        iacDataPushFile.setIsCombinByNoCompress(taskInfo.isCompress() + "");
        iacDataPushFile.setOdsTableName(taskInfo.getOdsName());
        iacDataPushFile.setDicName(dicName);
        iacDataPushFile.setLimitBand(taskInfo.getLimitBand() + "");
        return iacDataPushFile;
    }

    /**
     * buildFileSource
     *
     * @param taskInfo taskInfo
     * @return String
     * @author z00502253
     * @since 2020-02-24
     */
    private static String buildFileSource(TaskInfo taskInfo) {
        StringBuffer fileSourceSB = new StringBuffer();
        for (int i = 0; i < taskInfo.getFilesTask().getFileSources().size(); i++) {
            String fileSource = ((FileSource) taskInfo.getFilesTask().getFileSources().get(i)).getDirectory();
            if (i == taskInfo.getFilesTask().getFileSources().size() - 1) {
                fileSourceSB.append(fileSource.endsWith("/") ? fileSource : (fileSource + "/"));
            } else {
                fileSourceSB.append(fileSource.endsWith("/") ? fileSource : (fileSource + "/" + ","));
            }
        }
        return fileSourceSB.toString();
    }

    /**
     * loadDamConfig
     *
     * @param rootDir String
     * @author z00502253
     * @since 2020-06-24
     */
    private static void loadDamConfig(String rootDir) throws IOException, DatapushException,
            SAXException, DocumentException {
        Element root = Util.getDocument(FileUtils.getFile(new String[]{rootDir + "/conf/IDE_EnvConf.xml"}))
                .getRootElement();
        (GlobalVariable.getInstance()).node = root.elementTextTrim("Node");
        if (!Util.checkIp((GlobalVariable.getInstance()).node)) {
            throw new DatapushException("IDE_EnvConf config file error");
        }
        damConfig = new DamConfig();
        Properties sysPro = new Properties();
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(new String[]{rootDir
                + "/conf/datapush.properties"}))) {
            sysPro.load(in);
        }
        damConfig.setOpen(Boolean.parseBoolean(sysPro.getProperty("da.open", "true")));
        if (damConfig.isOpen()) {
            damConfig.setSignKey(CryptService.decryptAes(sysPro.getProperty("da.sign")));
            damConfig.setWorkKey(sysPro.getProperty("da.work"));
            damConfig.setName(sysPro.getProperty("da.server.name", ""));
            damConfig.setUrl(sysPro.getProperty("da.url"));
            damConfig.setIacRetryTimes(Util.getInt(sysPro.getProperty("da.iac.request.retryTimes"), 3));
            damConfig.setTimeOut(Util.getInt(sysPro.getProperty("da.request.timeout"), 300));
            damConfig.setWaitTime(Util.getInt(sysPro.getProperty("da.request.waittime"), 3000));
        }
    }

    /**
     * main
     *
     * @param args String[]
     * @author z00502253
     * @since 2022-06-30
     */
    public static void main(String[] args) {
        boolean isSuccess = true;
        try {
            Thread.currentThread().setName("IACDamApi");
            log.info("IAC push dam api start...");
            String rootDir = Paths.get(System.getProperty("user.dir"), new String[0]).toString();
            Util.loadLogBack(rootDir + File.separator + "conf" + File.separator + "push_DAM_logback.xml");
            loadParams(args);
            loadDamConfig(rootDir);
            if (damConfig.isOpen()) {
                loadJobIni();
                loadConfigIni();
                DamController damController = new DamController(damConfig);
                if ("0".equals(actionType)) {
                    dealJobReq(rootDir, damController);
                } else {
                    dealInstallReq(rootDir, damController);
                }
            } else {
                log.info("IAC push dam not open...");
            }
        } catch (DatapushException | IOException | NullPointerException | DocumentException | SAXException e) {
            log.error("IAC push dam Request api error", e);
            isSuccess = false;
        } finally {
            if (!isSuccess) {
                log.info("IAC push DAM run failed");
                System.exit(1);
            } else {
                log.info("IAC push DAM run success");
            }
        }
    }
}