package com.hihonor.cloudservice.datapush.io;

import com.hihonor.cloudservice.datapush.GlobalVariable;
import com.hihonor.cloudservice.datapush.common.ThreadFactoryUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.io.reader.FileBinaryReader;
import com.hihonor.cloudservice.datapush.io.reader.FileLineReader;
import com.hihonor.cloudservice.datapush.io.writer.FileBinaryWriter;
import com.hihonor.cloudservice.datapush.io.writer.FileLineWriter;


import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-05
 */
public class WriteFileThread
        implements Callable<List<Path>> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(WriteFileThread.class);

    /**
     * The Constant globalVariable.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final GlobalVariable globalVariable = GlobalVariable.getInstance();

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String jobName;

    /**
     * The Constant type.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int type;

    /**
     * The Constant sourceFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final List<Path> sourceFiles;

    /**
     * The Constant destFiles.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final List<Path> destFiles;

    /**
     * The Constant destFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Path destFile;

    /**
     * The Constant averageCount.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int averageCount;

    /**
     * The Constant averageSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private long averageSize;

    /**
     * The Constant isSplit.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean isSplit;

    /**
     * The Constant workPath.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Path workPath;

    public WriteFileThread(String jobName, int type, List<Path> sourceFiles) {
        this.jobName = jobName;
        this.type = type;
        this.sourceFiles = sourceFiles;
        this.destFiles = new ArrayList<>();
        init();
    }

    /**
     * extend
     *
     * @param averageCount int
     * @param averageSize long
     * @param destFile Path
     * @param isSplit boolean
     * @author z00502253
     * @since 2020-02-24
     */
    public void extend(int averageCount, long averageSize, Path destFile, boolean isSplit) {
        this.averageCount = averageCount;
        this.averageSize = averageSize;
        this.destFile = destFile;
        this.isSplit = isSplit;
        log.info("spit count = {}, split size = {}", Integer.valueOf(averageCount), Long.valueOf(averageSize));
    }

    /**
     * extend
     *
     * @param workPath workPath
     * @author z00502253
     * @since 2022-08-15
     */
    public void extend(Path workPath) {
        this.workPath = workPath;
    }

    /**
     * init
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void init() {
        for (int i = 0; i < this.globalVariable.programConfig.getMaxChannels()
                - this.globalVariable.channels.size(); i++) {
            String uid = Util.getId();
            this.globalVariable.channels.put(uid, new FilesChannel(uid,
                    this.globalVariable.programConfig.getQueueSize()));
        }
        log.info("split channel size = {}", Integer.valueOf(this.globalVariable.channels.size()));
    }

    /**
     * call
     *
     * @return List
     * @author z00502253
     * @since 2020-02-24
     */
    public List<Path> call() {
        if (this.type == 1 && splitFiles() && this.destFiles.size() != 0)
            return this.destFiles;
        if (this.type == 2 && mvOriginFile() && this.destFiles.size() != 0) {
            return this.destFiles;
        }
        log.warn("unknown type!");

        return null;
    }

    /**
     * splitFiles
     *
     * @return boolean
     * @author z00502253
     * @since 2022-07-01
     */
    private boolean splitFiles() {
        ThreadPoolExecutor writePool = new ThreadPoolExecutor(this.globalVariable.programConfig.getMaxSubTaskPool(),
                this.globalVariable.programConfig.getMaxSubTaskPool(), 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(this.globalVariable.programConfig.getQueueSize()), (ThreadFactory)
                new ThreadFactoryUtil(this.jobName + "-writer"));

        List<Future<Boolean>> writeTasks = new ArrayList<>();
        for (int i = 1; i <= this.averageCount; i++) {
            Path tmpFile;
            if (this.isSplit) {
                tmpFile = Util.getSplitFile(this.destFile.toString(), "_part_", i).toPath();
            } else {
                tmpFile = Paths.get(this.destFile.toString(), new String[0]);
            }
            this.destFiles.add(tmpFile);
            FileLineWriter lineWriter = new FileLineWriter(tmpFile, this.averageSize);
            writeTasks.add(writePool.submit((Callable<Boolean>) lineWriter));
        }


        ThreadPoolExecutor readPool = new ThreadPoolExecutor(this.globalVariable.programConfig.getMaxSubTaskPool(),
                this.globalVariable.programConfig.getMaxSubTaskPool(), 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(this.globalVariable.programConfig.getQueueSize()), (ThreadFactory)
                new ThreadFactoryUtil(this.jobName + "-reader"));

        FileLineReader lineReader = new FileLineReader(this.sourceFiles, this.averageCount,
                this.averageSize, this.destFiles);
        readPool.execute((Runnable) lineReader);
        return closePool(readPool, writePool, writeTasks);
    }

    /**
     * mvOriginFile
     *
     * @return boolean
     * @author z00502253
     * @since 2022-07-01
     */
    private boolean mvOriginFile() {
        ThreadPoolExecutor writePool = new ThreadPoolExecutor(this.globalVariable.programConfig.getMaxSubTaskPool(),
                this.globalVariable.programConfig.getMaxSubTaskPool(), 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(this.globalVariable.programConfig.getQueueSize()), (ThreadFactory)
                new ThreadFactoryUtil(this.jobName + "-writer"));


        ThreadPoolExecutor readPool = new ThreadPoolExecutor(this.globalVariable.programConfig.getMaxSubTaskPool(),
                this.globalVariable.programConfig.getMaxSubTaskPool(), 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(this.globalVariable.programConfig.getQueueSize()),
                (ThreadFactory) new ThreadFactoryUtil(this.jobName + "-reader"));

        List<Future<Boolean>> writeTasks = new ArrayList<>();
        for (Path sourceFile : this.sourceFiles) {
            Path tmpFile = Paths.get(this.workPath.toString(), new String[]{sourceFile.toFile().getName()});
            this.destFiles.add(tmpFile);
            FileBinaryWriter binaryWriter = new FileBinaryWriter(tmpFile, sourceFile.toFile().length());
            writeTasks.add(writePool.submit((Callable<Boolean>) binaryWriter));
            FileBinaryReader binaryReader = new FileBinaryReader(sourceFile, tmpFile);
            readPool.execute((Runnable) binaryReader);
        }
        return closePool(readPool, writePool, writeTasks);
    }

    /**
     * closePool
     *
     * @param readPool readPool
     * @param writePool writePool
     * @param writeTasks List<Future<Boolean>>
     * @return boolean
     * @author z00502253
     * @since 2020-02-24
     */
    public boolean closePool(ThreadPoolExecutor readPool, ThreadPoolExecutor writePool,
                             List<Future<Boolean>> writeTasks) {
        readPool.shutdown();
        writePool.shutdown();
        boolean isSuccess = true;
        for (Future<Boolean> task : writeTasks) {
            try {
                if (!((Boolean) task.get(2L, TimeUnit.HOURS)).booleanValue()) {
                    throw new DatapushException("split file error");
                }
            } catch (InterruptedException | java.util.concurrent.ExecutionException
                    | java.util.concurrent.TimeoutException | DatapushException e) {
                log.error("split file error", e);
                isSuccess = false;
            }
        }
        return isSuccess;
    }
}