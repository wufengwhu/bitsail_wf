package com.hihonor.cloudservice.datapush.tasks.impl;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.fastjson.JSONObject;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.entity.DbSource;
import com.hihonor.cloudservice.datapush.entity.DruidConfig;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;
import com.hihonor.cloudservice.datapush.io.WriteDbThread;
import com.hihonor.cloudservice.datapush.tasks.Task;
import com.hihonor.cloudservice.datapush.tasks.TaskProcess;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import com.mysql.jdbc.Driver;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import oracle.jdbc.driver.OracleDriver;
import org.apache.hive.jdbc.HiveDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class DatabaseFileTask.
 *
 * @since 2022-04-24
 */
public class DatabaseFileTask extends TaskProcess implements Task {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(DatabaseFileTask.class);

    public DatabaseFileTask(TaskInfo taskInfo, String taskId) {
        super(taskInfo, taskId);
    }

    /**
     * execute
     *
     * @author z00502253
     * @since 2022-06-27
     */
    public void execute() {
        try {
            init();
            getHost();
            if (Util.isNotEmpty(this.taskInfo.getDatabaseTask().getSql()) &&
                    this.taskInfo.getDatabaseTask().getSql().lastIndexOf(";") + 1 == this.taskInfo
                            .getDatabaseTask().getSql().length()) {
                this.taskInfo.getDatabaseTask()
                        .setSql(this.taskInfo.getDatabaseTask()
                                .getSql()
                                .substring(0, this.taskInfo.getDatabaseTask().getSql().lastIndexOf(";")));
            }

            getDbFiles();

            copyFileByJDK(this.workFiles);

            compressFile();

            scpFile();

            dealRemoteFile();

            dealLocalFile();

            this.taskInfo.setTaskState(DatapushState.SUCCESS);
        } catch (Exception e) {
            log.error("database task error", e);
            if (e.toString().contains("lzop: command not found")) {
                this.taskInfo.setTaskState(DatapushState.LZO_NOT_FOUND);
            }
        } finally {
            cleanTmpFiles();
            putState();
        }
    }

    /**
     * getDruidDataSource
     *
     * @param user String
     * @param pw String
     * @return vo
     * @author z00502253
     * @since 2022-08-15
     */
    private DruidDataSource getDruidDataSource(String user, String pw) {
        DruidConfig druidConf = this.globalVariable.druidConfig;
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setUsername(user);
        dataSource.setPassword(pw);
        dataSource.setInitialSize(druidConf.getInitSize());
        dataSource.setMinIdle(druidConf.getMinIdle());
        dataSource.setMaxWait(druidConf.getMaxWait());
        dataSource.setTimeBetweenEvictionRunsMillis(druidConf.getTimeBetweenEvictionRunsMillis());
        dataSource.setMinEvictableIdleTimeMillis(druidConf.getMinEvictableIdleTimeMillis());
        dataSource.setTestWhileIdle(druidConf.isTestWhileIdle());
        dataSource.setValidationQuery(druidConf.getValidationQuery());
        dataSource.setValidationQueryTimeout(druidConf.getValidationQueryTimeout());
        dataSource.setTestOnReturn(druidConf.isTestOnReturn());
        dataSource.setTestOnBorrow(druidConf.isTestOnBorrow());
        dataSource.setKeepAlive(druidConf.isKeepAlive());
        dataSource.setRemoveAbandoned(druidConf.isRemoveAbandoned());
        dataSource.setRemoveAbandonedTimeout(druidConf.getRemoveAbandonedTimeout());
        dataSource.setLogAbandoned(druidConf.isLogAbandoned());
        dataSource.setPoolPreparedStatements(true);
        return dataSource;
    }

    /**
     * checkAdditionalParams
     *
     * @param dbSource dbSource
     * @return String
     * @author z00502253
     * @since 2022-08-15
     */
    private String checkAdditionalParams(DbSource dbSource) {
        if (Util.isEmpty(dbSource.getExtendParams())) {
            if (this.globalVariable.druidConfig.getType().equalsIgnoreCase("cursor")) {
                return "?useCursorFetch=true";
            }
        } else if (!dbSource.getExtendParams().contains("useCursorFetch=true") && this.globalVariable.druidConfig
                .getType().equalsIgnoreCase("cursor")) {
            return dbSource.getExtendParams() + "&useCursorFetch=true";
        }

        return Util.isNotEmpty(dbSource.getExtendParams()) ? dbSource.getExtendParams() : "";
    }

    /**
     * buildDataSource
     *
     * @param dbSource dbSource
     * @return vo
     * @author z00502253
     * @since 2022-08-15
     */
    private DruidDataSource buildDataSource(DbSource dbSource) {
        DruidDataSource dataSource = getDruidDataSource(dbSource.getUser(), dbSource.getPassword());
        String url = null;
        if (dbSource.getType().toLowerCase().equals("mysql")) {

            url = "jdbc:mysql://" + dbSource.getHost() + ":" + dbSource.getPort() + "/" + dbSource.getDataName()
                    + checkAdditionalParams(dbSource);
            buildMysqlDataSource(dbSource, dataSource);
        }
        if (dbSource.getType().toLowerCase().equals("oracle")) {

            url = "jdbc:oracle:thin:@//" + dbSource.getHost() + ":" + dbSource.getPort() + "/"
                    + dbSource.getDataName() + (Util.isNotEmpty(dbSource.getExtendParams())
                    ? dbSource.getExtendParams() : "");
            buildOracleDataSource(dbSource, dataSource);
        }
        if (dbSource.getType().toLowerCase().equals("mssqlserver")) {

            url = "jdbc:sqlserver://" + dbSource.getHost() + ":" + dbSource.getPort() + "/"
                    + dbSource.getDataName() + (Util.isNotEmpty(dbSource.getExtendParams())
                    ? dbSource.getExtendParams() : "");
            buildMssqlserverDataSource(dbSource, dataSource);
        }
        if (dbSource.getType().toLowerCase().equals("hive")) {

            url = "jdbc:hive2://" + dbSource.getHost() + ":" + dbSource.getPort() + "/"
                    + dbSource.getDataName() + (Util.isNotEmpty(dbSource.getExtendParams())
                    ? dbSource.getExtendParams() : "");
            buildHiveDataSource(dataSource);
        }
        dataSource.setUrl(url);
        return dataSource;
    }

    /**
     * buildMysqlDataSource
     *
     * @param dbSource dbSource
     * @param dataSource dataSource
     * @author z00502253
     * @since 2022-08-15
     */
    private void buildMysqlDataSource(DbSource dbSource, DruidDataSource dataSource) {
        dataSource.setDriverClassName(Driver.class.getCanonicalName());
        dataSource.setPoolPreparedStatements(false);
        if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888") &&
                !this.taskInfo.getDatabaseTask().getSql().toLowerCase().contains("limit")) {
            this.taskInfo.getDatabaseTask().setSql(this.taskInfo.getDatabaseTask().getSql() + " limit 1;");
        }
        if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888") && Util.isNotEmpty(dbSource.getSql()) &&
                !dbSource.getSql().toLowerCase().contains("limit")) {
            dbSource.setSql(dbSource.getSql() + " limit 1;");
        }
    }

    /**
     * buildOracleDataSource
     *
     * @param dbSource dbSource
     * @param dataSource dataSource
     * @author z00502253
     * @since 2022-08-15
     */
    private void buildOracleDataSource(DbSource dbSource, DruidDataSource dataSource) {
        dataSource.setDriverClassName(OracleDriver.class.getCanonicalName());
        dataSource.setValidationQuery("select 1 from dual");
        if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888")) {
            if (this.taskInfo.getDatabaseTask().getSql().toLowerCase().contains("where")) {
                this.taskInfo.getDatabaseTask()
                        .setSql(this.taskInfo.getDatabaseTask().getSql().replaceAll("(?i)where",
                                "where rownum <= 1 and "));
            } else {
                this.taskInfo.getDatabaseTask().setSql(this.taskInfo.getDatabaseTask().getSql()
                        + " where rownum <= 1;");
            }
            if (Util.isNotEmpty(dbSource.getSql())) {
                if (dbSource.getSql().toLowerCase().contains("where")) {
                    dbSource.setSql(dbSource.getSql().replaceAll("(?i)where",
                            "where rownum <= 1 and "));
                } else {
                    dbSource.setSql(dbSource.getSql() + " where rownum <= 1;");
                }
            }
        }
    }

    /**
     * buildMssqlserverDataSource
     *
     * @param dbSource dbSource
     * @param dataSource dataSource
     * @author z00502253
     * @since 2022-08-15
     */
    private void buildMssqlserverDataSource(DbSource dbSource, DruidDataSource dataSource) {
        dataSource.setDriverClassName(SQLServerDriver.class.getCanonicalName());
        dataSource.setValidationQuery("select 1");
        if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888") &&
                !this.taskInfo.getDatabaseTask().getSql().toLowerCase().contains("select top ")) {
            this.taskInfo.getDatabaseTask()
                    .setSql("select top 1 " + this.taskInfo.getDatabaseTask().getSql().trim().substring(6));
        }
        if (this.taskInfo.getPeriodObject().getPeriodTime().startsWith("1888") && Util.isNotEmpty(dbSource.getSql()) &&
                !dbSource.getSql().toLowerCase().contains("select top ")) {
            dbSource.setSql("select top 1 " + dbSource.getSql().trim().substring(6));
        }
    }

    /**
     * buildHiveDataSource
     *
     * @param dataSource dataSource
     * @author z00502253
     * @since 2022-08-15
     */
    private void buildHiveDataSource(DruidDataSource dataSource) {
        dataSource.setDriverClassName(HiveDriver.class.getCanonicalName());
        dataSource.setValidationQuery("select 1");
    }

    /**
     * getDbFiles
     *
     * @author z00502253
     * @since 2022-08-15
     */
    private void getDbFiles() throws DatapushException {
        List<DbSource> dbSources = this.taskInfo.getDatabaseTask().getDbSources();
        List<Future<Boolean>> dbTasks = new ArrayList<>();
        for (int i = 0; i < dbSources.size(); i++) {

            try {
                Path dbFilePart = Paths.get(this.work.toString(),
                        new String[]{Util.getSplitName(this.taskInfo.getDestFileName(),
                                "_db_part_", i + 1)});
                this.workFiles.add(dbFilePart);
                DruidDataSource dataSource = buildDataSource(dbSources.get(i));
                JSONObject dbParams = new JSONObject();
                dbParams.put("jobName", this.taskInfo.getJobName());
                if (Util.isNotEmpty(((DbSource) dbSources.get(i)).getSql())) {
                    dbParams.put("sql", ((DbSource) dbSources.get(i)).getSql());
                } else {
                    dbParams.put("sql", this.taskInfo.getDatabaseTask().getSql());
                }
                dbParams.put("queryType", this.globalVariable.druidConfig.getType());
                dbParams.put("fetchSize", Integer.valueOf(this.globalVariable.druidConfig.getFetchSize()));
                dbParams.put("lineSep", this.taskInfo.getLineSep());
                dbParams.put("filedSep", this.taskInfo.getDatabaseTask().getFiledSep());
                dbParams.put("replaceSource", this.taskInfo.getDatabaseTask().getReplaceSource());
                dbParams.put("replaceTarget", this.taskInfo.getDatabaseTask().getReplaceTarget());
                dbTasks.add(this.globalVariable.subPool
                        .submit((Callable<Boolean>) new WriteDbThread(dataSource
                                .getConnection(), dbFilePart, dbParams)));
            } catch (SQLException sqlException) {
                this.taskInfo.setTaskState(DatapushState.SQL_ERROR);
                log.error("sql error", sqlException);
                throw new DatapushException("db connect error");
            }
        }
        for (Future<Boolean> dbTask : dbTasks) {
            try {
                if (!((Boolean) dbTask.get(2L, TimeUnit.HOURS)).booleanValue()) {
                    throw new DatapushException("db task run error");
                }
            } catch (InterruptedException | java.util.concurrent.ExecutionException
                    | java.util.concurrent.TimeoutException | DatapushException e) {
                throw new DatapushException("db task write error", e);
            }
        }
    }
}