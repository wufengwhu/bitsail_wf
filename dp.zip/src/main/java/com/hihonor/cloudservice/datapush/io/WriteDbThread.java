package com.hihonor.cloudservice.datapush.io;

import com.alibaba.druid.pool.DruidPooledConnection;
import com.alibaba.fastjson.JSONObject;
import com.hihonor.cloudservice.datapush.common.Util;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.concurrent.Callable;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-05
 */
public class WriteDbThread
        implements Callable<Boolean> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(WriteDbThread.class);

    /**
     * The Constant delete.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String delete = UUID.randomUUID().toString();

    /**
     * The Constant connection.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final DruidPooledConnection connection;

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String jobName;

    /**
     * The Constant sql.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String sql;

    /**
     * The Constant dbPartFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Path dbPartFile;

    /**
     * The Constant queryType.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String queryType;

    /**
     * The Constant fetchSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int fetchSize;

    /**
     * The Constant lineSep.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String lineSep;

    /**
     * The Constant filedSep.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String filedSep;

    /**
     * The Constant replaceSource.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String replaceSource;

    /**
     * The Constant replaceTarget.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String replaceTarget;

    public WriteDbThread(DruidPooledConnection connection, Path dbPartFile, JSONObject dbParams) {
        this.connection = connection;
        this.dbPartFile = dbPartFile;
        this.jobName = dbParams.getString("jobName");
        this.sql = dbParams.getString("sql");
        this.queryType = dbParams.getString("queryType");
        this.fetchSize = dbParams.getInteger("fetchSize").intValue();
        this.lineSep = dbParams.getString("lineSep");
        this.filedSep = dbParams.getString("filedSep");
        this.replaceSource = dbParams.getString("replaceSource");
        this.replaceTarget = dbParams.getString("replaceTarget");
    }

    /**
     * call
     *
     * @return Boolean
     * @author z00502253
     * @since 2020-02-24
     */
    public Boolean call() {
        Thread.currentThread().setName(this.jobName + "_WriteDbThread_" + this.dbPartFile.getFileName());
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        BufferedWriter writer = null;
        try {
            log.info("SQL = {}", this.sql);
            statement = this.connection.prepareStatement(this.sql, 1003, 1007);
            if (this.queryType.equalsIgnoreCase("cursor")) {
                statement.setFetchSize(this.fetchSize);
            } else {
                statement.setFetchSize(-2147483648);
            }
            resultSet = statement.executeQuery();

            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(FileUtils
                    .getFile(this.dbPartFile.toFile(), new String[0]).getCanonicalPath(),
                    false), StandardCharsets.UTF_8));

            write(writer, resultSet);
            log.info("db write success------------->{}", this.dbPartFile.toFile().getName());
            return Boolean.valueOf(true);
        } catch (SQLException | IOException e) {
            log.error("db sql run error", e);
            return Boolean.valueOf(false);
        } finally {
            close(writer, resultSet, statement);
        }
    }

    /**
     * write
     *
     * @param writer writer
     * @param resultSet resultSet
     * @author z00502253
     * @since 2022-07-01
     */
    private void write(BufferedWriter writer, ResultSet resultSet) throws SQLException, IOException {
        StringBuilder dbCodeStr = new StringBuilder();
        int columns = resultSet.getMetaData().getColumnCount();
        long rows = 0L;
        while (resultSet.next()) {
            for (int i = 1; i <= columns; i++) {
                String record = (resultSet.getString(i) == null) ? "" : resultSet.getString(i);
                if (Util.isNotEmpty(this.replaceSource) && (this.replaceSource
                        .equals("\\n") || this.replaceSource.equals("\\r") || this.replaceSource.equals("\\r\\n"))) {
                    record = record.replaceAll(this.replaceSource, this.replaceTarget);
                }
                if (i == columns) {
                    if (!this.delete.equals(record)) {
                        dbCodeStr.append(record);
                    } else {
                        int indexLast = dbCodeStr.lastIndexOf(this.filedSep);
                        dbCodeStr.delete(indexLast, dbCodeStr.length());
                    }

                } else if (!this.delete.equals(record)) {
                    dbCodeStr.append(record);
                    dbCodeStr.append(this.filedSep);
                }
            }

            dbCodeStr.append(this.lineSep);
            writer.write(dbCodeStr.toString());
            writer.flush();
            dbCodeStr.delete(0, dbCodeStr.length());
            rows++;
            if (rows % 1000000L == 0L) {
                log.info("SQL data read and write process : {} records", Long.valueOf(rows));
            }
        }
        log.info("SQL data read and write process : {} records", Long.valueOf(rows));
    }

    /**
     * close
     *
     * @param writer writer
     * @param resultSet resultSet
     * @param statement statement
     * @author z00502253
     * @since 2022-07-01
     */
    private void close(BufferedWriter writer, ResultSet resultSet, PreparedStatement statement) {
        if (writer != null) {
            try {
                writer.close();
            } catch (IOException e) {
                log.warn("db write close error", e);
            }
        }
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                log.warn(" resultSet close error", e);
            }
        }
        if (statement != null)
            try {
                statement.close();
            } catch (SQLException e) {
                log.warn(" statement close error", e);
            }
    }
}