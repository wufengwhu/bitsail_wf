/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class CacheDestHost {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(CacheDestHost.class);

    /**
     * The Constant DEST_HOST_PATH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Path DEST_HOST_PATH = Paths.get(System.getProperty("user.dir"),
            new String[]{"conf/dest_host.properties"});

    /**
     * modify
     *
     * @param jobName String
     * @param host String
     * @author z00502253
     * @since 2020-02-14
     */
    public static void modify(String jobName, String host) {
        log.info("Start to modify the destination address of the task cache.");
        Properties destHostPro = new Properties();
        try {
            try (InputStream in = FileUtils.openInputStream(FileUtils
                    .getFile(new String[]{DEST_HOST_PATH.toString()}))) {
                destHostPro.load(in);
            }
            String destHost = destHostPro.getProperty(jobName);
            if (Util.isNotEmpty(destHost)) {
                FileDealUtil.replacePropValue(DEST_HOST_PATH.toString(), jobName, host);
            } else {
                String appendConent = jobName + "=" + host + System.lineSeparator();

                Files.write(DEST_HOST_PATH, appendConent.getBytes(Charset.forName("UTF-8")),
                        new OpenOption[]{StandardOpenOption.APPEND, StandardOpenOption.CREATE,
                                StandardOpenOption.SYNC, StandardOpenOption.WRITE});
            }

            log.info("The task target host in the task cache file is updated successfully.");
        } catch (IOException e) {
            log.warn("An exception occurred when updating the target host in the task cache file:{}", e.getMessage());
        } catch (Exception e) {
            log.warn("An exception occurred when updating the target host in the task cache file:{}", e.getMessage());
        }
    }

    /**
     * getSecureRandom
     *
     * @param jobName String
     * @return String
     * @author z00502253
     * @since 2020-02-14
     */
    public static String getHostByDestHostFile(String jobName) {
        log.info("Start to obtain the target host from the task cache.");
        String destHost = null;
        Properties destHostPro = new Properties();
        try (InputStream in = FileUtils.openInputStream(FileUtils.getFile(new String[]{DEST_HOST_PATH.toString()}))) {
            destHostPro.load(in);
            destHost = destHostPro.getProperty(jobName);
            if (Util.isEmpty(destHost)) {
                log.warn("The target host of the task is not found in the task cache file.");
            } else {
                log.info("The target host is successfully obtained from the task cache.");
            }
        } catch (IOException e) {
            log.warn("Failed to obtain the target host from the task cache file {}", e.getMessage());
        }
        return destHost;
    }
}