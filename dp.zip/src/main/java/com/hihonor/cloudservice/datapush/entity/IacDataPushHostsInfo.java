package com.hihonor.cloudservice.datapush.entity;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class IacDataPushHostsInfo {

    /**
     * The Constant jobName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String jobName;

    /**
     * The Constant lstdyTime.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String lstdyTime;

    /**
     * The Constant hostStatus.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String hostStatus;

    /**
     * The Constant patchStatus.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String patchStatus;

    /**
     * The Constant version.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String version;

    /**
     * The Constant scopeId.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int scopeId;

    /**
     * The Constant channeld.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String channeld;

    /**
     * The Constant hostId.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String hostId;

    /**
     * The Constant channelUserName.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String channelUserName;

    public String getJobName() {
        return this.jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getLstdyTime() {
        return this.lstdyTime;
    }

    public void setLstdyTime(String lstdyTime) {
        this.lstdyTime = lstdyTime;
    }

    public String getHostStatus() {
        return this.hostStatus;
    }

    public void setHostStatus(String hostStatus) {
        this.hostStatus = hostStatus;
    }

    public String getPatchStatus() {
        return this.patchStatus;
    }

    public void setPatchStatus(String patchStatus) {
        this.patchStatus = patchStatus;
    }

    public String getVersion() {
        return this.version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getScopeId() {
        return this.scopeId;
    }

    public void setScopeId(int scopeId) {
        this.scopeId = scopeId;
    }

    public String getChanneld() {
        return this.channeld;
    }

    public void setChanneld(String channeld) {
        this.channeld = channeld;
    }

    public String getHostId() {
        return this.hostId;
    }

    public void setHostId(String hostId) {
        this.hostId = hostId;
    }

    public String getChannelUserName() {
        return this.channelUserName;
    }

    public void setChannelUserName(String channelUserName) {
        this.channelUserName = channelUserName;
    }
}