package com.hihonor.cloudservice.datapush.tasks;

import com.hihonor.cloudservice.datapush.common.LocalCmdUtil;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;


import com.hihonor.cloudservice.datapush.jsch.Cmd;
import com.hihonor.cloudservice.datapush.jsch.Scp;

import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class CommonThread.
 *
 * @since 2022-04-24
 */
public class CommonThread
        implements Callable<String> {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(CommonThread.class);

    /**
     * The Constant object.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Object object;

    /**
     * The Constant name.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String name;

    public CommonThread(Object object, String name) {
        this.object = object;
        this.name = name;
    }

    /**
     * call
     *
     * @return String
     * @author z00502253
     * @since 2022-06-27
     */
    public String call() {
        Thread.currentThread().setName(this.name + "_CommonThread");
        String error = DatapushState.FAILED.getDetail();
        if (this.object instanceof Scp) {
            Scp scp = (Scp) this.object;
            try {
                scp.run();
                return DatapushState.SUCCESS.getDetail();
            } catch (DatapushException | com.jcraft.jsch.JSchException | java.io.IOException e) {
                log.error("scp error", e);
                error = e.getMessage();
            }
        }
        if (this.object instanceof Cmd) {
            Cmd cmd = (Cmd) this.object;
            try {
                cmd.run();
                return DatapushState.SUCCESS.getDetail();
            } catch (DatapushException | com.jcraft.jsch.JSchException | java.io.IOException e) {
                log.error("cmd error", e);
                error = e.getMessage();
            }
        }
        if (this.object instanceof LocalCmdUtil) {
            LocalCmdUtil localCmd = (LocalCmdUtil) this.object;
            error = localCmd.run();
        }
        return error;
    }
}