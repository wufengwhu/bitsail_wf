package com.hihonor.cloudservice.datapush.tasks;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.tasks.impl.CommonFileTask;
import com.hihonor.cloudservice.datapush.tasks.impl.DatabaseFileTask;
import com.hihonor.cloudservice.datapush.tasks.impl.OriginalFileTask;


import java.util.Locale;

/**
 * The Class TaskFactory.
 *
 * @since 2022-04-24
 */
public class TaskFactory {

    /**
     * createTask
     *
     * @param taskInfo taskInfo
     * @return vo
     * @author z00502253
     * @since 2022-06-28
     */
    public Task createTask(TaskInfo taskInfo) {
        String taskId = taskInfo.getJobName() + "-" + Util.getId();
        switch (taskInfo.getTaskType().toLowerCase(Locale.ENGLISH)) {
            case "file":
                return (Task) new CommonFileTask(taskInfo, taskId);
            case "db":
                return (Task) new DatabaseFileTask(taskInfo, taskId);
            case "only":
                return (Task) new OriginalFileTask(taskInfo, taskId);
        }
        return null;
    }
}