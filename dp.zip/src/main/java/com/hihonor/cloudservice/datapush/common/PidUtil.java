/*
 * Copyright (c) Honor Device Co., Ltd. 2021-2021. All rights reserved.
 */

package com.hihonor.cloudservice.datapush.common;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * 功能描述
 *
 * @since 2022-04-24
 */
public class PidUtil extends ClassicConverter {

    /**
     * convert
     *
     * @param iLoggingEvent iLoggingEvent
     * @return String
     * @author z00502253
     * @since 2022-07-01
     */
    public String convert(ILoggingEvent iLoggingEvent) {
        return Util.getProcessID();
    }
}