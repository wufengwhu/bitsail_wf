package com.hihonor.cloudservice.datapush.tasks;

import com.alibaba.fastjson.JSONObject;
import com.hihonor.cloudservice.datapush.common.HttpUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.entity.DamConfig;
import com.hihonor.cloudservice.datapush.exception.DatapushException;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class DamController.
 *
 * @since 2022-04-24
 */
public class DamController {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(DamController.class);

    /**
     * The Constant damConfig.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final DamConfig damConfig;

    /**
     * The Constant url.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String url;

    /**
     * The Constant iacRetryTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private int iacRetryTimes;

    public DamController(DamConfig damConfig) {
        this.damConfig = damConfig;
        String serverName = damConfig.getName();
        if (Util.isNotEmpty(serverName)) {
            serverName = "/" + serverName;
        } else {
            serverName = "";
        }
        this.url = damConfig.getUrl() + serverName;
        this.iacRetryTimes = damConfig.getIacRetryTimes();
    }

    /**
     * buildHeaders
     *
     * @return Map
     * @author z00502253
     * @since 2022-08-15
     */
    private Map<String, String> buildHeaders() throws DatapushException {
        String random, sign;
        long timestamp = System.currentTimeMillis();


        try {
            random = CryptService.getSecureRandom(16);
            sign = "random=" + random + "&systemid=" + this.damConfig.getSignKey() + "&timestamp=" + timestamp;
            sign = URLEncoder.encode(URLEncoder.encode(sign, "UTF-8"), "UTF-8");
            sign = CryptService.encryStringByHmacSHA256(sign, this.damConfig.getWorkKey());
        } catch (UnsupportedEncodingException e) {
            throw new DatapushException(e);
        }
        Map<String, String> headers = new HashMap<>(4);
        headers.put("Content-Type", "application/json");
        headers.put("timestamp", Long.toString(timestamp));
        headers.put("random", random);
        headers.put("sign", sign);
        return headers;
    }

    /**
     * pushRequest
     *
     * @param map Map
     * @return String[]
     * @author z00502253
     * @since 2022-06-27
     */
    public String[] pushRequest(Map<String, Object> map) throws DatapushException {
        String result = HttpUtil.sendRequest(this.url + "/pushRequest", "POST", map,
                buildHeaders(), this.damConfig.getTimeOut());
        if (Util.isNotEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            log.info("Dam get result is : {}", jsonObject.toJSONString());
            String[] returnValue = new String[5];
            for (Map.Entry<String, Object> json : (Iterable<Map.Entry<String, Object>>) jsonObject.entrySet()) {
                String key = json.getKey();
                if ("code".equals(key)) {
                    returnValue[0] = String.valueOf(jsonObject.getInteger("code"));
                }
                if ("status".equals(key)) {
                    returnValue[1] = String.valueOf(jsonObject.getInteger("status"));
                }
                if ("errMsgInfo".equals(key)) {
                    returnValue[2] = jsonObject.getString("errMsgInfo");
                }
                if ("taskInstId".equals(key)) {
                    returnValue[3] = String.valueOf(jsonObject.get("taskInstId"));
                }
                if ("destIp".equals(key)) {
                    returnValue[4] = jsonObject.getString("destIp");
                }
            }
            return returnValue;
        }
        throw new DatapushException("Dam pushRequest error");
    }

    /**
     * pushFinished
     *
     * @param map Map
     * @author z00502253
     * @since 2022-06-27
     */
    public void pushFinished(HashMap<String, Object> map) throws DatapushException {
        String result = HttpUtil.sendRequest(this.url + "/pushFinished", "POST", map,
                buildHeaders(), this.damConfig.getTimeOut());
        if (Util.isNotEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            log.info("Dam finish result is : {}", jsonObject.toJSONString());
            if (jsonObject.getInteger("status") != null
                    && jsonObject.getInteger("status").intValue() == 400) {
                throw new DatapushException("Dam pushFinished error = " + jsonObject.getString("errMsgInfo"));
            }
        } else {
            throw new DatapushException("Dam pushRequest error");
        }
    }

    /**
     * iacPush
     *
     * @param map HashMap
     * @author z00502253
     * @since 2022-06-27
     */
    public void iacPush(HashMap<String, Object> map) throws DatapushException {
        try {
            log.info("iac push dam request times = {}", Integer.valueOf(this.damConfig.getIacRetryTimes()
                    - this.iacRetryTimes + 1));
            String result = HttpUtil.sendRequest(this.url + "/saveIACDatapushInfo", "POST", map,
                    buildHeaders(), this.damConfig.getTimeOut());
            if (Util.isNotEmpty(result)) {
                JSONObject jsonObject = JSONObject.parseObject(result);
                log.debug("IAC Reqeust DAM result is : {}", jsonObject.toJSONString());
                if (jsonObject.getInteger("code") == null || jsonObject.getInteger("code").intValue() != 0) {
                    throw new DatapushException("IAC Reqeust DAM fail = " + jsonObject.getInteger("code"));
                }
                log.info("IAC Reqeust DAM success");
            } else {

                throw new DatapushException("IAC Reqeust DAM error");
            }
        } catch (Exception e) {
            this.iacRetryTimes--;
            if (this.iacRetryTimes == -1) {
                throw new DatapushException(e);
            }
            Util.sleep(this.damConfig.getWaitTime());
            iacPush(map);
        }
    }
}