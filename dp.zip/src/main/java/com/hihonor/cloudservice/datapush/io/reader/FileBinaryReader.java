package com.hihonor.cloudservice.datapush.io.reader;

import com.hihonor.cloudservice.datapush.GlobalVariable;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.io.FilesBlock;
import com.hihonor.cloudservice.datapush.io.FilesChannel;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-06
 */
public class FileBinaryReader
        implements Runnable {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FileBinaryReader.class);

    /**
     * The Constant LOCK.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Object LOCK = new Object();

    /**
     * The Constant sourceFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final File sourceFile;

    /**
     * The Constant destFile.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final File destFile;

    /**
     * The Constant channel.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private FilesChannel channel;

    /**
     * The Constant processList.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final List<String> processList;

    public FileBinaryReader(Path sourceFile, Path destFile) {
        this.sourceFile = sourceFile.toFile();
        this.destFile = destFile.toFile();
        this.processList = new ArrayList<>(Util.getProcess());
    }

    /**
     * selectChannel
     *
     * @author z00502253
     * @since 2022-07-01
     */
    private void selectChannel() {
        while (true) {
            synchronized (LOCK) {
                for (FilesChannel tmp : (GlobalVariable.getInstance()).channels.values()) {
                    if (!tmp.isActive()) {
                        tmp.setActive(true);
                        this.channel = tmp;
                        this.channel.setTag(this.destFile.getName());
                        return;
                    }
                }
            }
        }
    }

    /**
     * run
     *
     * @author z00502253
     * @since 2020-02-22
     */
    public void run() {
        selectChannel();
        log.info("read start------>{}", this.sourceFile.getName());
        BufferedInputStream reader = null;
        try {
            reader = new BufferedInputStream(FileUtils.openInputStream(this.sourceFile), 4194304);
            byte[] data = new byte[4194304];
            long currentSize = 0L;
            int len;
            while ((len = reader.read(data, 0, data.length)) != -1) {
                byte[] tmp = new byte[len];
                System.arraycopy(data, 0, tmp, 0, len);
                putBinary(tmp, false);
                currentSize += len;
                print(this.sourceFile.getName(), currentSize, this.sourceFile.length());
            }
            putBinary(null, true);
            if (this.processList.size() > 0 && ((String) this.processList.get(this.processList.size() - 1))
                    .equals("100")) {
                log.info("read process---->{}({}%)", this.sourceFile.getName(), this.processList
                        .get(this.processList.size() - 1));
            }
        } catch (IOException | InterruptedException e) {
            this.channel.setError(true);
            log.error("read error------>{}", this.sourceFile.getName(), e);
        } finally {
            Util.closeQuietly(reader);
            log.info("read end-------->{}(sizes={})", this.sourceFile.getName(),
                    Long.valueOf(this.sourceFile.length()));
        }
        log.debug("read-{} exit------>{}", Long.valueOf(Thread.currentThread().getId()), this.sourceFile.getName());
    }

    /**
     * putBinary
     *
     * @param binary byte[]
     * @param isLast boolean
     * @author z00502253
     * @since 2022-07-01
     */
    private void putBinary(byte[] binary, boolean isLast) throws InterruptedException {
        FilesBlock filesBlock = new FilesBlock();
        filesBlock.setDataType(2);
        filesBlock.setEndTag(isLast);
        filesBlock.setDataBytes(binary);
        this.channel.getFilesBlocks().put(filesBlock);
    }

    /**
     * print
     *
     * @param name String
     * @param cur long
     * @param size long
     * @author z00502253
     * @since 2022-07-01
     */
    private void print(String name, long cur, long size) {
        String process = Util.getPercent(cur, size);
        if (this.processList.contains(process)) {
            this.processList.removeIf(item -> item.equals(process));
            log.info("read process---->{}({}%)", name, process);
        }
    }
}