package com.hihonor.cloudservice.datapush.tasks;

import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.entity.TaskInfo;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
import com.hihonor.cloudservice.datapush.exception.DatapushState;
import com.hihonor.cloudservice.datapush.GlobalVariable;
import com.hihonor.cloudservice.datapush.common.CacheDestHost;


import com.hihonor.cloudservice.datapush.jsch.Ssh;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class SshCheckProcess.
 *
 * @since 2022-04-24
 */
public class SshCheckProcess {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(SshCheckProcess.class);

    /**
     * The Constant globalVariable.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final GlobalVariable globalVariable = GlobalVariable.getInstance();

    /**
     * The Constant sshBuilder.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final Ssh.SshBuilder sshBuilder = Ssh.builder();

    /**
     * The Constant taskInfo.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final TaskInfo taskInfo;

    /**
     * The Constant tmpDir.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final Path tmpDir;

    /**
     * The Constant host.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String host;

    /**
     * The Constant hostTimes.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public int hostTimes;

    /**
     * The Constant random.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final SecureRandom random = new SecureRandom();

    public SshCheckProcess(TaskInfo taskInfo) {
        this.taskInfo = taskInfo;
        this.tmpDir = Paths.get(taskInfo.getDirectory(), new String[]{"temp", taskInfo.getTaskId()});
        this.sshBuilder.jobName(taskInfo.getJobName())
                .userName(taskInfo.getHostUser())
                .port(Util.getInt(taskInfo.getPort(), this.globalVariable.programConfig.getSshPort()))
                .timeOut(taskInfo.getTimeOut());
        this.sshBuilder.passphrase(taskInfo.getPrivateKeyPass()).keyFile(taskInfo.getPrivateKeyFile());
        this.hostTimes = taskInfo.getReTimes();
    }

    /**
     * checkSsh
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void checkSsh() throws DatapushException {
        log.info("ssh connection check,jobName={}, get Host start...", this.taskInfo.getJobName());
        boolean isUsedLocal = true;
        if (this.globalVariable.damConfig.isOpen()) {
            log.info("ssh connection check,jobName={},  request DAM get Host start...", this.taskInfo.getJobName());
            DamController damController = new DamController(this.globalVariable.damConfig);
            try {
                String[] value = damController.pushRequest(buildRequest());
                if ("400".equals(value[1])) {
                    throw new DatapushException("ssh connection check,Dam pushRequest return error = " + value[2]);
                }

                if ("101".equals(value[0])) {
                    log.error("ssh connection check,The task was repeated execute, {} job exit!",
                            this.taskInfo.getJobName());
                    this.taskInfo.setTaskState(DatapushState.REPEAT);
                    throw new DatapushException("ssh check,The task " + this.taskInfo.getJobName()
                            + " was repeated execute!");
                }

                if (!"0".equals(value[0])) {
                    throw new DatapushException("ssh connection check,Dam pushRequest " +
                            "return error message=code is not zero");
                }

                if (Util.isNotEmpty(value[3])) {
                    this.taskInfo.setDamTaskId(value[3]);
                }

                if (Util.isEmpty(value[4])) {
                    throw new DatapushException("ssh connection check,Dam pushRequest return error message=ip is null");
                }

                this.host = value[4];
                CacheDestHost.modify(this.taskInfo.getJobName(), this.host);

                isUsedLocal = false;
            } catch (DatapushException e) {
                if (this.taskInfo.getTaskState() == DatapushState.REPEAT) {
                    log.warn("ssh connection check,file check mode is repeat, the Dam cannot be connected.");
                    throw new DatapushException(e);
                }
                log.warn("ssh connection check, Dam pushRequest Fail...{}", e.getMessage());
                this.host = CacheDestHost.getHostByDestHostFile(this.taskInfo.getJobName());
                if (Util.isNotEmpty(this.host)) {
                    isUsedLocal = false;
                } else {
                    log.error("ssh connection check, Dam putRequest error", (Throwable) e);
                }
            }
        }
        if (isUsedLocal) {
            log.warn("ssh connection check, Start to randomly obtainthe target host from the task configuration file.");

            int chose = this.random.nextInt(this.taskInfo.getHosts().size());
            this.host = this.taskInfo.getHosts().get(chose);
        }
        log.info("ssh connection check,jobName={}, Push node ip={}, port={}",
                new Object[]{this.taskInfo.getJobName(), this.host,
                Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                        this.globalVariable.programConfig.getSshPort()))});
        getSshConnection();
    }

    /**
     * getSshConnection
     *
     * @author z00502253
     * @since 2022-08-15
     */
    private void getSshConnection() {
        Session session = null;
        try {
            log.info("ssh connection check,jobName={},ip={}, port={}  ssh build connection start...",
                    new Object[]{this.taskInfo.getJobName(), this.host,
                    Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                            this.globalVariable.programConfig.getSshPort()))});
            session = this.sshBuilder.host(this.host).build().getConnection();
            log.info("ssh connection check, connection success. jobName={}, Push node ip={}, port={}",
                    new Object[]{this.taskInfo.getJobName(), this.host,
                    Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                            this.globalVariable.programConfig.getSshPort()))});
        } catch (JSchException e) {
            log.error("ssh connection check,jobName={},ip={}, port={} ssh build connection error",
                    new Object[]{this.taskInfo.getJobName(), this.host,
                    Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                            this.globalVariable.programConfig.getSshPort()))});
            log.error("ssh connection error", (Throwable) e);
            this.taskInfo.getUsedHosts().add(this.host);
            this.hostTimes--;
            if (this.hostTimes == -1) {
                log.error("ssh connection hostTimes == -1,jobName={},ip={}, port={}",
                        new Object[]{this.taskInfo.getJobName(), this.host,
                        Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                                this.globalVariable.programConfig.getSshPort()))});
                throw new DatapushException(e);
            }
            log.error("ssh connection finally,jobName={},WaitTime={},ip={}, port={}",
                    new Object[]{this.taskInfo.getJobName(),
                    Integer.valueOf(this.taskInfo.getWaitTime()),
                            this.host, Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                            this.globalVariable.programConfig.getSshPort()))});
            Util.sleep(this.taskInfo.getWaitTime());
            checkSsh();
        } finally {
            log.info("ssh connection finally,jobName={},ip={}, port={}",
                    new Object[]{this.taskInfo.getJobName(), this.host,
                    Integer.valueOf(Util.getInt(this.taskInfo.getPort(),
                            this.globalVariable.programConfig.getSshPort()))});
            if (null != session) {
                session.disconnect();
            }
        }
    }

    /**
     * putState
     *
     * @author z00502253
     * @since 2022-06-28
     */
    public void putState() {
        if (this.taskInfo.getTaskState() == DatapushState.RUNNING) {
            this.taskInfo.setTaskState(DatapushState.FAILED);
        }
        log.info("ssh connection check,jobName={}, host={},check end...", this.taskInfo.getJobName(), this.host);
        if (this.taskInfo.getTaskState() == DatapushState.SUCCESS) {
            this.taskInfo.setMonitorState(DatapushState.SUCCESS);
        } else {
            this.taskInfo.setMonitorState(DatapushState.FAILED);
        }
    }

    /**
     * buildRequest
     *
     * @return Map<String, Object>
     * @author z00502253
     * @since 2022-08-15
     */
    private Map<String, Object> buildRequest() {
        Map<String, Object> map = new HashMap<>(11);
        map.put("taskId", this.taskInfo.getTaskId());
        map.put("mfsPath", this.taskInfo.getDirectory());
        map.put("deptCode", this.taskInfo.getDeptCode());
        map.put("dataPushV", this.globalVariable.version);
        map.put("taskType", Integer.valueOf(this.taskInfo.getTaskType().equalsIgnoreCase("db") ? 2 : 1));
        map.put("srcIp", this.globalVariable.node);
        map.put("odsTableName", this.taskInfo.getOdsName());
        map.put("jobName", this.taskInfo.getJobName());
        map.put("sendThreadCount", Integer.valueOf(this.taskInfo.getSendFileMaxThreads()));
        if (this.taskInfo.getUsedHosts().size() > 0) {
            map.put("abortedIP", this.taskInfo.getUsedHosts().toString()
                    .replace("[", "").replace("]", "").trim());
        }
        log.debug("ssh connection check, Dam request params : {}", map);
        log.info("ssh connection check, Dam request params : {}", map);
        return map;
    }
}