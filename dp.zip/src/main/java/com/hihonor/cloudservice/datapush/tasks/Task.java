package com.hihonor.cloudservice.datapush.tasks;

/**
 * The Class Task.
 *
 * @since 2022-04-24
 */
public interface Task {
    void execute();
}