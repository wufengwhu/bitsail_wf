package com.hihonor.cloudservice.datapush.tasks;

import com.alibaba.fastjson.JSONObject;
/*     */ import com.hihonor.cloudservice.datapush.common.HttpUtil;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.common.crypt.CryptService;
import com.hihonor.cloudservice.datapush.exception.DatapushException;
/*     */
/*     */
/*     */
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;

/**
 * The Class WiseEyeConfigCenterController.
 *
 * @since 2022-04-24
 */
public class WiseEyeConfigCenterController {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(WiseEyeConfigCenterController.class);

    /**
     * The Constant requestTimeout.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final int requestTimeout;

    /**
     * The Constant apikey.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String apikey;

    /**
     * The Constant url.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final String url;


    public WiseEyeConfigCenterController(Properties properties) {
        this.apikey = CryptService.decryptAes(properties.getProperty("config_center_apikey"));
        this.url = properties.getProperty("config_center_url");
        this.requestTimeout = Util.getInt(properties.getProperty("request.timeout"), 300);
    }

    public WiseEyeConfigCenterController(int pullType, Properties properties) {
        if (pullType == 5) {
            this.apikey = properties.getProperty("config_center_apikey");
        } else {
            this.apikey = CryptService.decryptAes(properties.getProperty("config_center_apikey"));
        }
        this.url = properties.getProperty("config_center_url");
        this.requestTimeout = Util.getInt(properties.getProperty("request.timeout"), 300);
    }

    /**
     * getScope
     *
     * @param name String
     * @return int
     * @author z00502253
     * @since 2022-06-28
     */
    public int getScope(String name) {
        int scopeId = -1;

        Map<String, String> headers = new HashMap<>(1);
        headers.put("APIKEY", this.apikey);
        headers.put("Content-Type", "application/json");

        String getConfigScopesUrl = this.url + "/scopes/?name=" + name;
        String result = HttpUtil.sendRequest(getConfigScopesUrl, "GET", null, headers,
                this.requestTimeout);
        if (Util.isNotEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            log.debug("wiseEye config center get config scope result is : {}", jsonObject.toJSONString());
            int status = jsonObject.getInteger("status").intValue();
            log.info("getScope api return status:{}", Integer.valueOf(status));
            if (status == 0) {
                ArrayList<Map<String, Object>> scopeList = (ArrayList<Map<String, Object>>)
                        jsonObject.getObject("scopes", ArrayList.class);
                if (scopeList != null && scopeList.size() > 0) {
                    if (scopeList.size() == 1) {
                        scopeId = ((Integer) ((Map) scopeList.get(0)).get("id")).intValue();
                    } else {
                        throw new DatapushException("wiseEye config center get Config scope size is not 1");
                    }
                } else {
                    throw new DatapushException("wiseEye config center get Config scope is null");
                }
            } else {
                throw new DatapushException(jsonObject.getString("error"));
            }
        } else {
            throw new DatapushException("wiseEye config center get Config scope error");
        }
        return scopeId;
    }

    /**
     * getApp
     *
     * @param scopeId int
     * @param name String
     * @return int
     * @author z00502253
     * @since 2022-06-28
     */
    public int getApp(int scopeId, String name) {
        int appId = -1;

        Map<String, String> headers = new HashMap<>(2);
        headers.put("APIKEY", this.apikey);
        headers.put("Content-Type", "application/json");

        String getConfigAppsUrl = this.url + "/applications/?scope_id=" + scopeId + "&name=" + name;
        String result = HttpUtil.sendRequest(getConfigAppsUrl, "GET", null, headers,
                this.requestTimeout);
        if (Util.isNotEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            log.debug("wiseEye config center get config application result is : {}", jsonObject.toJSONString());
            int status = jsonObject.getInteger("status").intValue();
            log.info("getApp api return status:{}", Integer.valueOf(status));
            if (status == 0) {
                ArrayList<Map<String, Object>> appList = (ArrayList<Map<String, Object>>)
                        jsonObject.getObject("applications", ArrayList.class);
                if (appList != null && appList.size() > 0) {
                    for (Map<String, Object> map : appList) {
                        if (name.equals(map.get("name"))) {
                            appId = ((Integer) map.get("id")).intValue();
                            break;
                        }
                    }
                    if (appId == -1) {
                        throw new DatapushException("wiseEye config center get Config " +
                                "application is not match application name");
                    }
                } else {

                    throw new DatapushException("wiseEye config center get Config application is null");
                }
            } else {
                throw new DatapushException(jsonObject.getString("error"));
            }
        } else {
            throw new DatapushException("wiseEye config center get Config application error");
        }
        return appId;
    }

    /**
     * getVersion
     *
     * @param appId int
     * @param name String
     * @return int
     * @author z00502253
     * @since 2022-06-28
     */
    public int getVersion(int appId, String name) {
        int versionId = -1;

        Map<String, String> headers = new HashMap<>(2);
        headers.put("APIKEY", this.apikey);
        headers.put("Content-Type", "application/json");

        String getConfigVersionUrl = this.url + "/business/version/?app_id=" + appId + "&name=" + name;
        String result = HttpUtil.sendRequest(getConfigVersionUrl, "GET", null, headers,
                this.requestTimeout);
        if (Util.isNotEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            log.debug("wiseEye config center get config version result is : {}", jsonObject.toJSONString());
            int status = jsonObject.getInteger("status").intValue();
            log.info("getVersion api return status:{}", Integer.valueOf(status));
            if (status == 0) {
                ArrayList<Map<String, Object>> versionList = (ArrayList<Map<String, Object>>)
                        jsonObject.getObject("version", ArrayList.class);
                if (versionList != null && versionList.size() > 0) {
                    for (Map<String, Object> map : versionList) {
                        if (name.equals(map.get("name"))) {
                            versionId = ((Integer) map.get("id")).intValue();
                            break;
                        }
                    }
                    if (versionId == -1) {
                        throw new DatapushException("wiseEye config center get Config " +
                                "application is not match version name");
                    }
                } else {

                    throw new DatapushException("wiseEye config center get Config version is null");
                }
            } else {
                throw new DatapushException(jsonObject.getString("error"));
            }
        } else {
            throw new DatapushException("wiseEye config center get Config version error");
        }
        return versionId;
    }

    /**
     * getTag
     *
     * @param versionId int
     * @param name String
     * @return int
     * @author z00502253
     * @since 2022-06-28
     */
    public int getTag(int versionId, String name) {
        int tagId = -1;

        Map<String, String> headers = new HashMap<>(2);
        headers.put("APIKEY", this.apikey);
        headers.put("Content-Type", "application/json");

        String getConfigTagUrl = this.url + "/business/tag/?version_id=" + versionId + "&name=" + name;
        String result = HttpUtil.sendRequest(getConfigTagUrl, "GET", null, headers, this.requestTimeout);
        if (Util.isNotEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            log.debug("wiseEye config center get config tag result is : {}", jsonObject.toJSONString());
            int status = jsonObject.getInteger("status").intValue();
            log.info("getTag api return status:{}", Integer.valueOf(status));
            if (status == 0) {
                ArrayList<Map<String, Object>> tagList = (ArrayList<Map<String, Object>>)
                        jsonObject.getObject("tag", ArrayList.class);
                if (tagList != null && tagList.size() > 0) {
                    for (Map<String, Object> map : tagList) {
                        if (name.equals(map.get("name"))) {
                            tagId = ((Integer) map.get("id")).intValue();
                            break;
                        }
                    }
                    if (tagId == -1) {
                        throw new DatapushException("wiseEye config center get Config tag is not match tag name");
                    }
                } else {
                    throw new DatapushException("wiseEye config center get Config tag is null");
                }
            } else {
                throw new DatapushException(jsonObject.getString("error"));
            }
        } else {
            throw new DatapushException("wiseEye config center get Config tag error");
        }
        return tagId;
    }

    /**
     * getConfigItem
     *
     * @param scopeId int
     * @param appId int
     * @param versionId int
     * @param tagId int
     * @return ArrayList
     * @author z00502253
     * @since 2022-06-28
     */
    public ArrayList<Map<String, Object>> getConfigItem(int scopeId, int appId, int versionId, int tagId) {
        ArrayList<Map<String, Object>> itemList;
        Map<String, String> headers = new HashMap<>(2);
        headers.put("APIKEY", this.apikey);
        headers.put("Content-Type", "application/json");

        String getConfigItemUrl = this.url + "/business/item/?scope_id=" + scopeId + "&app_id=" + appId
                + "&version_id=" + versionId + "&tag_id=" + tagId;
        String result = HttpUtil.sendRequest(getConfigItemUrl, "GET", null, headers,
                this.requestTimeout);
        if (Util.isNotEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            log.debug("wiseEye config center get config item result is : {}", jsonObject.toJSONString());
            int status = jsonObject.getInteger("status").intValue();
            log.info("getConfigItem api return status:{}", Integer.valueOf(status));
            if (status == 0) {
                itemList = (ArrayList<Map<String, Object>>) jsonObject.getObject("item_list", ArrayList.class);
            } else {
                throw new DatapushException(jsonObject.getString("error"));
            }
        } else {
            throw new DatapushException("wiseEye config center get Config Item error");
        }
        return itemList;
    }
}
