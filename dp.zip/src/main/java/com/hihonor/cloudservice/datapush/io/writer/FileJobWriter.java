package com.hihonor.cloudservice.datapush.io.writer;

import com.hihonor.cloudservice.datapush.GlobalVariable;
import com.hihonor.cloudservice.datapush.common.Util;
import com.hihonor.cloudservice.datapush.io.FilesChannel;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述
 *
 * @since 2022-05-05
 */
public class FileJobWriter {

    /**
     * The Constant log.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger log = LoggerFactory.getLogger(FileJobWriter.class);

    /**
     * The Constant LOCK.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Object LOCK = new Object();

    /**
     * The Constant channel.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public FilesChannel channel;

    /**
     * The Constant source.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final File source;

    /**
     * The Constant averageSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final long averageSize;

    /**
     * The Constant currentSize.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public long currentSize;

    /**
     * The Constant processList.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final List<String> processList;

    public FileJobWriter(Path file, long averageSize) {
        this.source = file.toFile();
        this.averageSize = averageSize;
        this.currentSize = 0L;
        this.processList = new ArrayList<>(Util.getProcess());
    }

    /**
     * selectChannel
     *
     * @author z00502253
     * @since 2020-02-22
     */
    public void selectChannel() {
        while (true) {
            synchronized (LOCK) {
                for (FilesChannel tmp : (GlobalVariable.getInstance()).channels.values()) {
                    if (tmp.isActive() && tmp.getTag().equals(this.source.getName())) {
                        this.channel = tmp;
                        return;
                    }
                }
            }
        }
    }

    /**
     * print
     *
     * @param name String
     * @author z00502253
     * @since 2020-02-22
     */
    public void print(String name) {
        String process = Util.getPercent(this.currentSize, this.averageSize);
        if (this.processList.contains(process)) {
            this.processList.removeIf(item -> item.equals(process));
            log.info("write process--->{}({}%)", name, process);
        }
    }
}