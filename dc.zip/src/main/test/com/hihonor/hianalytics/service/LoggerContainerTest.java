package com.hihonor.hianalytics.service;

import com.hihonor.hianalytics.debugview.DebugSecurityProducer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.junit.Test;

public class LoggerContainerTest {

    private static KafkaProducer<String, String> debugViewProducer;

    @Test
    public void getLogger() {
        try {

            debugViewProducer = DebugSecurityProducer.geSecurityProducer();

        } catch (Exception e) {
            System.out.println("Failed to use SecurityProducer,exception is " + e.getMessage());
        }


    }
}