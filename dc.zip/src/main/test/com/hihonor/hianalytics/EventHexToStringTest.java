package com.hihonor.hianalytics;


import com.hihonor.hianalytics.utils.HexUtils;
import com.hihonor.hianalytics.utils.InflaterUtil;
import com.hihonor.hianalytics.utils.StreamUtil;

import static com.hihonor.hianalytics.utils.CommonUtils.hexString2ByteArray;
import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * @author w00027882
 */
public class EventHexToStringTest {


    private static String hexToJsonString(String hexEvent) throws Exception {
        byte[] bytes = HexUtils.toBytes(hexEvent);
        String eventStr = new String(InflaterUtil.decompress(bytes), UTF_8);
        eventStr.replaceAll("\\*|\t|\r|\n", "");
        // to json string
        System.out.println("原始json: " + eventStr);
        return eventStr;
    }

    private static String jsonStringToHex(String json) throws Exception {
        String event = json.replaceAll("\\s*|\r|\n|\t", "");

        // 对event obj 压缩
        byte[] eventInfoCompressedData = StreamUtil.getBitZip(event.getBytes(UTF_8));
        String hexEventInfo = HexUtils.byteArray2HexString(eventInfoCompressedData);
        System.out.println("压缩16进制: " + hexEventInfo);
        return hexEventInfo;
    }


    public static void main(String[] args) {
        String hexEvent = "789c5555ed6a5c390c7d97f95d8a2c5bb2d49729b22c37814d279da485a5f4ddf7dcb0b02c19c88caf6d49e7ebfebe3d55ec7adcbefcbebd3eeeeff7bcfff5f5573dde9eefdf6f5f6eedf6e996f797d747bdbd7d7db9effa77edad1ebf9eb39e377e3f3ddf5febf1e3f18ef5787dfd58c399cf4fcf4ff7eff7c7e76ff15259dfdf51e4d3ede925f27a5ee5b38fb2992ad426b725ea4e2367b4b33b17af1ccab98f6083c9ec3184780d722fd9575b4fcfe7eafb36789d9e7d8dd17d52b46e51b6bd9c237bae61cb5acf1a817b5865b5a9ed0cefe9e17df1ee73e44e3e1a1b55820eef417aec7435fc9d4e9d827b4f4d2c6e9e9a197bf0dc2ea7e9eeba384a4770862cfc77223f73edd986ecedbc8070c3cdd299a86df26d4786cf89367966f99e5683c5b955632560a076d4a7a265deb56b8c794e996d9939ab6b9ad33aa8b7ab8fb196570bc785cada690e2048b5379b294e603f339dd6b1559250bfd9d52f7a6f3419d505b300a74c1bcb4e3bb3dbde815fc7ac736be86e8801291190e235d52ca3dcd1b1754aaea41412065ab2a8165b111a069e1dd3a2a24468161a051e0a36665c58f55ab6145b6d5a98118f16b9f4e84c8b1d206a02a093b50f40d4d194bb6b2cf7760a65b58dcc012dbc3fbfd4db7bbcbc5ef254eba6c34588f83fa9bec7373c7cfcfdf57f727cd48f9f38f9a1d96a6db15311243288352e90656de910a7f5bcfdf974ab5f3879ed556aa3490c8cdac51724028a9634e15e41bbef6571a2ca42746c33cc758644ced3879c053a5d01c514ea0a714f60ee58d9b852cf043dd055f5241f0cd65b11ad35b0b1d10720a6953ec5f7b16a598193bb31c8838879a7c99a43611eb4e467194e82a80525d8e81ca067c31632944e8cad5b3b3c35a0050706860f5df4c6a6d1208a09445ca041c710029f8d0bf6dc3d6c79bfd0d9a0ce16bc678720aa0078d579755ba3594bf42f4a181b68eeee6b29a96fd6d109189ce91bfa4db82efb397b3acdb35b599bc968eb8a075f277c01a9090943ae9d4e37cf030119c47472a2c644347463ee81698000d8e3e373634c4936885060a609d24a24d0005a44050dd248288b1c6cadcb8feb426b5a6aad3af0571c11b80434d40a2aab8e1127248096ebbaf6524d6452213b7a436d500490169cbc6097f060709bd9aa18da6252190b52866b094c82a71334e0189696d4072cc513b10187bbfa41726d6d8ed11a7744501b26630e4274766de8a8e10ac253c2d7740581fd14ca0a06c5401435690a88dc397687dfa05864016977786e05ec18c2c83180b0f8c0ad1531151e3a10dd5a484e82c7359b862a70111bc80688618773c1506b3a0e65c1ce48d63602dbc7429d6497e68a30c6dcc81058a78708a76c072b0016897fa0633c1468d1a1106e24951b590974971c86c221c30d769193dcf17538821a9645cc13a464cd47314cd3107420cd9a7aeba010e1725dbca074437ecb01a4d97217230e5d05e98fa8c54548f78bd000b2a00be298f010074ac61ab008e4ea39afe89e3d07ae46f77ef5b78fae0e01b41ab5bc25888c85cb720b06be1237d2794e371af01c5e21e01a4398d8ac1c5676699903af038c190d6177e448c3aba1518337a071ef6672a501e200326808910538d13b800eccb3ca61ee4b9558f3f9f17250b8167684d2b10e447041bf04803ab73fff0022e63ab3";
        byte[] baKeyword = hexString2ByteArray(hexEvent);
//        System.out.println(new String(baKeyword, UTF_8));
        try {
            hexToJsonString(hexEvent);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 从文件读json
//        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
//        File file = new File(classLoader.getResource("event.json").getFile());
//        try {
//            InputStream in = new FileInputStream(file);
//            String jsonStream = IOUtils.toString(in, StandardCharsets.UTF_8);
//            String srcJsonStream = jsonStream.replaceAll("\\s*|\t|\r|\n", "");
//            System.out.println(srcJsonStream);
//            jsonStringToHex(srcJsonStream);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }
}
