/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import lombok.Data;

/**
 * 功能描述
 *
 * @author z00502253
 * @since 2019-07-03
 */
@Data
public class Result {

    /**
     * 返回状态
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final int SUCCESS = 0;

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final int SERVER_ERROR = 500;

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final int FAILED_DEFAULT = 3999;

    /**
     * 返回码 默认为成功
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private int retCode = SUCCESS;

    /**
     * 错误信息
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String errInfo;

    /**
     * 返回对象
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private Object obj;


    public boolean isSuccess() {
        return SUCCESS == retCode;
    }
}
