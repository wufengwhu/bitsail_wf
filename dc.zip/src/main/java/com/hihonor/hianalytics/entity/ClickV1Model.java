/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import lombok.Data;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Data
public class ClickV1Model extends Model {

    /**
     * 渠道ID
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String cid = "";

    /**
     * 业务ID
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String sid = "";

    /**
     * type 类型：点击（2）
     *
     * @author lWX788624
     * @since 2022-04-20
     */
    private String type = "2";

    /**
     * cookie_id
     *
     * @author lWX788624
     * @since 2022-04-20
     */
    private String cookieId = "";

    /**
     * OS
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String url = "";

    /**
     * 扩展字段
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String ext = "";

    /**
     * 重写toString
     *
     * @return 格式化后点击数据
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(cid).append('\001');
        sb.append(type).append('\001');
        sb.append(sid).append('\001');
        sb.append(url).append('\001');
        sb.append(serverts).append('\001');
        sb.append(ip).append('\001');
        sb.append(cookieId).append('\001');
        sb.append(ext).append('\001');
        sb.append(ua);
        return sb.toString();
    }
}
