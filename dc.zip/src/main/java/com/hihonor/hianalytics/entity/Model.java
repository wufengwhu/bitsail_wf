/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Slf4j
@Data
public abstract class Model {


    /**
     * 类型ID:浏览日志，目标跟踪，链接跟踪，用户自定义跟踪
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String typeId = "";

    /**
     * IP
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String ip = "";

    /**
     * user-agent
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String ua = "";

    /**
     * 服务端时间戳
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String serverts = "";

    /**
     * OS
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String os = "unknown";

    /**
     * 浏览器
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String browser = "unknown";

    /**
     * 浏览器版本
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String version = "unknown";

    /**
     * 扩展字段productId
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String productId = "";

    /**
     * 通过反射把上报数据设置到Model中
     * click -> clickModle ; exposure -> ExposureV1Model; webv1 -> webv1Modle
     * @param map 上报数据
     * @param model Model
     * @param args 必须字段
     * @param webFlag 是否JS上报数据
     * @return 设置数据是否成功
     * @see [类、类#方法、类#成员]
     */
    public boolean setData(Map<?, ?> map, Model model, String[] args, boolean webFlag){
        Date date = new Date();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        model.setServerts(sf.format(date));
        // get params
        Set<?> entry = map.keySet();
        // 校验必选参数
        if (args != null) {
            for (String arg : args) {
                if (!entry.contains(arg)) {
                    return false;
                }
            }
        }
        // 获取webV1Model 的字段
        Field[] fields = model.getClass().getDeclaredFields();

        for (Field field : fields) {
            try {
                if (entry.contains(field.getName())) {
                    String[] values= (String[]) map.get(field.getName());
                    if (null == values) {
                        continue;
                    }
                    field.set(model,values[0]);
                } else if (webFlag && "type".equals(field.getName())) {
                    if (!setTypeData(map, model, field)) {
                        return false;
                    }
                }

            } catch (IllegalAccessException e) {
                log.error("Set Model's field[" + field.getName() + "] failed,exception is {}", e.getMessage());
            }
        }
        return true;
    }

    /**
     * setTypeData
     *
     * @param map Map
     * @param model model
     * @param field field
     * @return boolean
     * @author z00502253
     * @since 2022-07-04
     */
    private boolean setTypeData(Map<?, ?> map, Model model, Field field) throws IllegalAccessException {
        String[] values = (String[]) map.get("action_name");
        typeId = "1";

        if (null == values) {
            values = (String[]) map.get("idgoal");
            typeId = "2";
        }

        if (null == values) {
            values = (String[]) map.get("link");
            typeId = "3";
        }

        if (null == values) {
            values = (String[]) map.get("download");
            typeId = "4";
        }

        if (null != values) {
            field.set(model, values[0]);
            return true;
        } else {
            return false;
        }
    }
}
