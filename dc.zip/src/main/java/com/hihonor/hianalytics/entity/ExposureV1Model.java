/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import lombok.Data;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Data
public class ExposureV1Model extends Model {

    /**
     * 业务ID cid
     *
     * @author z00502253
     * @since 2019-12-02
     */
    protected String cid = "";

    /**
     * 类型：曝光（1）
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String type = "1";

    /**
     * cookie_id
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String cookieId = "";


    /**
     * sid
     *
     * @author z00502253
     * @since 2019-12-02
     */
    protected String sid = "";

    /**
     * 扩展字段
     *
     * @author z00502253
     * @since 2019-12-02
     */
    protected String ext = "";


    /**
     * 重写toString
     *
     * @return 格式化后曝光数据
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(type).append('\001');
        sb.append(sid).append('\001');
        sb.append(cid).append('\001');
        sb.append(version).append('\001');
        sb.append(ip).append('\001');
        sb.append(os).append('\001');
        sb.append(browser).append('\001');
        sb.append(ext).append('\001');
        sb.append(serverts).append('\001');
        sb.append(cookieId).append('\001');
        sb.append(ua);
        return sb.toString();
    }
}
