/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.utils.CommonUtils;
import com.hihonor.hianalytics.utils.DataCollectorException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.Base64;

/**
 * The Class HiAnalyticsEntity
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HiAnalyticsEntity {

    /**
     * data
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public String data;

    /**
     * appId
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String appId;

    /**
     * urlPath
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public String urlPath;

    /**
     * isEncrypt
     * add by w00027882 用来区分上报的data 是否时加密的
     */
    public boolean isEncrypt;

    public HiAnalyticsEntity(String data) {
        this.data = data;
    }

    public HiAnalyticsEntity(String data, String appId, String urlPath) {
        this.data = data;
        this.appId = appId;
        this.urlPath = urlPath;
    }


    /**
     * 功能描述:更新数据
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public void updateData(String data) {
        this.data = data;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public void decompressData() throws DataCollectorException {
        byte[] compressData = null;
        // 是否支持base64编码
        if ("true".equals(ServerConfig.getInstance().getAsString(ConfigKeys.LOGREPORT_SUPPORTED_DEVELOPER_BASE64))) {
            compressData = Base64.getDecoder().decode(CommonUtils.hexString2ByteArray(data));
        } else {
            compressData = CommonUtils.hexString2ByteArray(data);
        }
        // 解压缩数据
        data = CommonUtils.deCompress(compressData);
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public String getCommonSubType() {
        int index = urlPath.lastIndexOf("/");
        if (index == -1) {
            return StringUtils.EMPTY;
        } else {
            return urlPath.substring(index + 1);
        }
    }
}
