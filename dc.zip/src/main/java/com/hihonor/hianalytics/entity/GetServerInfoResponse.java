/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.utils.CommonUtils;
import lombok.Data;

/**
 * The Class GetServerInfoResponse
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Data
public class GetServerInfoResponse {

    /**
     * resultcode
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String resultcode;

    /**
     * serverUrl
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String serverUrl;

    /**
     * serverUrls
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private List<String> serverUrls;


    /**
     * toString
     *
     * @return String
     * @author z00502253
     * @since 2022-07-04
     */
    @Override
    public String toString() {
        Map<String, Object> data = new HashMap<String, Object>();
        if (!CommonUtils.isNull(serverUrl) || serverUrls != null) {
            data.put("serverUrl", serverUrl);
            data.put("serverUrls", serverUrls);
        }
        if (!CommonUtils.isNull(resultcode)) {
            data.put("resultcode", resultcode);
        } else {
            data.put("resultcode", "100002");
        }
        return JSONObject.toJSONString(data);
    }
}
