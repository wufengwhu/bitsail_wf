/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import lombok.Data;

import java.util.List;

/**
 * 功能描述：批量上报数据模型
 *
 * @author z00502253
 * @since 2020-01-29
 */
@Data
public class BatchUploadEntity {

    /**
     * size
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public int size;

    /**
     * msgs
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public List<String> msgs;

}
