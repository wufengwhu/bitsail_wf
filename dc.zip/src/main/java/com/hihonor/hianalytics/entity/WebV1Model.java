/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 功能描述 运营大数据的model
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Data
@Slf4j
public class WebV1Model extends Model {

    /**
     * 收益(只有类型为idgoal的时候才可能存在该字段)
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String revenue = "";

    /**
     * ID
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String idsite = "";

    /**
     * 随机数
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String r = "";

    /**
     * 客户端时间(小时)
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String h = "";

    /**
     * 客户端时间(分钟)
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String m = "";

    /**
     * 客户端时间(秒)
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String s = "";

    /**
     * 被跟踪页面url
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String url = "";

    /**
     * 渠道,来源url
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String urlref = "";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String refpath = "";

    /**
     * Cookie
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _id = "";

    /**
     * Cookie创建时间
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _idts = "";

    /**
     * 访问次数
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _idvc = "";

    /**
     * 新访问者.注:未使用
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _idn = "";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _rcn = "";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _rck = "";

    /**
     * 渠道,来源时间
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _refts = "";

    /**
     * 最后一次访问时间
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _viewts = "";

    /**
     * 屏幕颜色深度
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String scd = "";

    /**
     * 窗口分辨率
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String vpr = "";

    /**
     * 上次订单时间
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _ects = "";

    /**
     * 渠道,来源url
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _ref = "";

    /**
     * 用户自定义page数据
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String cvar = "";

    /**
     * java插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String java = "0";

    /**
     * pdf插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String pdf = "0";

    /**
     * quicktime插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String qt = "0";

    /**
     * realaudio插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String realp = "0";

    /**
     * wma插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String wma = "0";

    /**
     * director插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String dir = "0";

    /**
     * flash插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String fla = "0";

    /**
     * gears插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String gears = "0";

    /**
     * silverlight插件支持
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String ag = "0";

    /**
     * 屏幕分辨率
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String res = "";

    /**
     * 是否支持cookie
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String cookie = "";

    /**
     * 用户自定义数据
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String data = "";

    /**
     * 用户自定义visit数据
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String _cvar = "";

    /**
     * 类型:浏览日志，目标跟踪，链接跟踪，用户自定义跟踪
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String type = "";

    // 语言
    private String language = "";

    // server_cookie
    private String sid = "";

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRevenue() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }

    public String getIdsite() {
        return idsite;
    }

    public void setIdsite(String idsite) {
        this.idsite = idsite;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public String getR() {
        return r;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public void setR(String r) {
        this.r = r;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public String getH() {
        return h;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public void setH(String h) {
        this.h = h;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public String getM() {
        return m;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public void setM(String m) {
        this.m = m;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public String getS() {
        return s;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-09
     */
    public void setS(String s) {
        this.s = s;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrlref() {
        return urlref;
    }

    public void setUrlref(String urlref) {
        this.urlref = urlref;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-10
     */
    public String getId() {
        return _id;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-10
     */
    public void setId(String id) {
        this._id = id;
    }

    public String getIdts() {
        return _idts;
    }

    public void setIdts(String idts) {
        this._idts = idts;
    }

    public String getIdvc() {
        return _idvc;
    }

    public void setIdvc(String idvc) {
        this._idvc = idvc;
    }

    public String getIdn() {
        return _idn;
    }

    public void setIdn(String idn) {
        this._idn = idn;
    }

    public String getRcn() {
        return _rcn;
    }

    public void setRcn(String rcn) {
        this._rcn = rcn;
    }

    public String getRck() {
        return _rck;
    }

    public void setRck(String rck) {
        this._rck = rck;
    }

    public String getRefts() {
        return _refts;
    }

    public void setRefts(String refts) {
        this._refts = refts;
    }

    public String getViewts() {
        return _viewts;
    }

    public void setViewts(String viewts) {
        this._viewts = viewts;
    }

    public String getScd() {
        return scd;
    }

    public void setScd(String scd) {
        this.scd = scd;
    }

    public String getVpr() {
        return vpr;
    }

    public void setVpr(String vpr) {
        this.vpr = vpr;
    }

    public String getEcts() {
        return _ects;
    }

    public void setEcts(String ects) {
        this._ects = ects;
    }

    public String getRef() {
        return _ref;
    }

    public void setRef(String ref) {
        this._ref = ref;
    }

    public String getCvar() {
        return cvar;
    }

    public void setCvar(String cvar) {
        this.cvar = cvar;
    }

    public String getJava() {
        return java;
    }

    public void setJava(String java) {
        this.java = java;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public String getQt() {
        return qt;
    }

    public void setQt(String qt) {
        this.qt = qt;
    }

    public String getRealp() {
        return realp;
    }

    public void setRealp(String realp) {
        this.realp = realp;
    }

    public String getWma() {
        return wma;
    }

    public void setWma(String wma) {
        this.wma = wma;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public String getFla() {
        return fla;
    }

    public void setFla(String fla) {
        this.fla = fla;
    }

    public String getGears() {
        return gears;
    }

    public void setGears(String gears) {
        this.gears = gears;
    }

    public String getAg() {
        return ag;
    }

    public void setAg(String ag) {
        this.ag = ag;
    }

    public String getRes() {
        return res;
    }

    public void setRes(String res) {
        this.res = res;
    }

    public String getCookie() {
        return cookie;
    }

    public void setCookie(String cookie) {
        this.cookie = cookie;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getCvar1() {
        return _cvar;
    }

    public void setCvar1(String cvar1) {
        this._cvar = cvar1;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    /**
     * 客户端时间检验
     *
     * @return 客户端时间是否正常
     * @see [类、类#方法、类#成员]
     */
    public boolean chkClientTime() {
        boolean result = false;
        SimpleDateFormat sd = new SimpleDateFormat("H:m:s");
        String clientTime = h + ":" + m + ":" + s;
        try {
            if (clientTime.equals(sd.format(sd.parse(clientTime)))) {
                result = true;
            }
        } catch (ParseException e) {
            log.error("Invalid ClientTime,exception is {}", e.getMessage());
        }
        return result;
    }

    /**
     * 数据检验
     *
     * @return 是否缺少必要数据
     * @see [类、类#方法、类#成员]
     */
    public boolean chkData() {
        String[] chkParam = {idsite, url, _id, _idts, _idvc};

        for (String p : chkParam) {
            if (p == null || "".equals(p)) {
                log.error("Invalid Data:idsite: idsite, url, _id, _idts, _idvc.");
                return false;
            }
        }
        return true;
    }

    /**
     * 重写toString
     *
     * @return 格式化后JS上报数据
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(typeId).append('\001');
        sb.append(type).append('\001');
        sb.append(revenue).append('\001');
        sb.append(idsite).append('\001');
        sb.append(h).append('\001');
        sb.append(m).append('\001');
        sb.append(s).append('\001');
        sb.append(url).append('\001');
        sb.append(urlref).append('\001');
        sb.append(refpath).append('\001');
        sb.append(_id).append('\001');
        sb.append(_idts).append('\001');
        sb.append(_idvc).append('\001');
        sb.append(_idn).append('\001');
        sb.append(_rcn).append('\001');
        sb.append(_rck).append('\001');
        sb.append(_refts).append('\001');
        sb.append(_viewts).append('\001');
        sb.append(scd).append('\001');
        sb.append(vpr).append('\001');
        sb.append(_ects).append('\001');
        sb.append(_ref).append('\001');
        sb.append(cvar).append('\001');
        sb.append(java).append('\001');
        sb.append(pdf).append('\001');
        sb.append(qt).append('\001');
        sb.append(realp).append('\001');
        sb.append(wma).append('\001');
        sb.append(dir).append('\001');
        sb.append(fla).append('\001');
        sb.append(gears).append('\001');
        sb.append(ag).append('\001');
        sb.append(res).append('\001');
        sb.append(cookie).append('\001');
        sb.append(data).append('\001');
        sb.append(_cvar).append('\001');
        sb.append(serverts).append('\001');
        sb.append(ip).append('\001');
        sb.append(os).append('\001');
        sb.append(browser).append('\001');
        sb.append(version).append('\001');
        sb.append(language).append('\001');
        sb.append(sid).append('\001');
        sb.append(ua);
        return sb.toString();
    }
}
