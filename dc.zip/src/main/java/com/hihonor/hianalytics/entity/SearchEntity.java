/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.entity;

import lombok.Data;

import java.util.List;

/**
 * 功能描述：大搜三方数据上报模型，集成HiAnalyticsEntity
 *
 * @author z00502253
 * @since 2020-01-17
 */

@Data
public class SearchEntity extends HiAnalyticsEntity {

    /**
     * appId
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String appId;

    /**
     * logType
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String logType;

    /**
     * requestId
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String requestId;

    /**
     * ip
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String ip;

    /**
     * megs
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private List<String> megs;

    /**
     * serverTime
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public long serverTime;

    public SearchEntity(String data, String serviceName, String logType, String urlPath, String requestId) {
        super(data);
        this.urlPath = urlPath;
        this.requestId = requestId;
        this.appId = serviceName;
        this.logType = logType;
    }
}
