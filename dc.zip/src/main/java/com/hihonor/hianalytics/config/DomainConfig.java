/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.config;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

import com.hihonor.hianalytics.utils.CommonUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * 域名配置
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Component
public final class DomainConfig {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(DomainConfig.class);

    /**
     * 配置实例.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static DomainConfig domainConfig = new DomainConfig();

    /**
     * 配置项对象.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private Properties prop = new Properties();

    private DomainConfig() {
        initServerInfoProperties();
    }

    /**
     * 获取配置实例（单例）
     *
     * @return 配置实例
     * @author z00502253
     * @since 2022-07-05
     */
    public static DomainConfig getInstance() {
        return domainConfig;
    }

    /**
     * 导入配置文件 导入配置项：日志存储路径，日志文件名格式等
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private void initServerInfoProperties() {
        InputStream input = null;
        try {
            input = DomainConfig.class.getResourceAsStream("/serverInfo.properties");
            prop.load(input);
        } catch (FileNotFoundException e) {
            logger.error("Can't find serverInfo.properties file,exception is {}", e.getMessage());
        } catch (IOException e) {
            logger.error("Can't load serverInfo.properties file,exception is {}", e.getMessage());
        } finally {
            IOUtils.closeQuietly(input);
        }

    }

    /**
     * 重新初始化配置
     *
     * @author z00502253
     * @since 2022-07-05
     */
    void reInitProperties() {
        initServerInfoProperties();
    }

    /**
     * 获取配置文件里面的key
     *
     * @return keySet
     * @see [类、类#方法、类#成员]
     * @author z00502253
     * @since 2022-07-05
     */
    private Set<String> keySet() {
        return prop.stringPropertyNames();
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public String getAsStringIgnoreCase(String key) {
        Set<String> keySet = keySet();
        if (keySet == null) {
            return null;
        }
        if (CommonUtils.isNull(key)) {
            return null;
        }
        for (String k : keySet) {
            if (key.equalsIgnoreCase(k)) {
                return prop.getProperty(k);
            }
        }
        return null;
    }

}
