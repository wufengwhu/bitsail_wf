package com.hihonor.hianalytics.config;

/**
 * <p>
 * kafka 常量池
 * </p>
 *
 * @author w00027882
 * @date Created in 20230414
 */
interface KafkaConstants {
    /**
     * 默认分区大小
     */
    Integer DEFAULT_PARTITION_NUM = 3;

    /**
     * Topic 名称
     */
    String TOPIC_TEST = "test";
}
