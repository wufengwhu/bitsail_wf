/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.File;

/**
 * 配置文件Listener
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Component
@Slf4j
public class ConfigFileListener extends FileAlterationListenerAdaptor {

    /**
     * 配置文件路径
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String SERVER_CONFIG_NAME = "config.properties";

    /**
     * The Constant DOMAIN_CONFIG_NAME.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String DOMAIN_CONFIG_NAME = "serverInfo.properties";

    /**
     * onFileChange
     *
     * @param file 被修改的文件
     * @author z00502253
     * @since 2022-07-05
     */
    @Override
    public void onFileChange(File file) {
        if (file == null) {
            log.error("Failed to load config, Config file is null");
            return;
        }
        if (StringUtils.equalsIgnoreCase(SERVER_CONFIG_NAME, file.getName())) {
            ServerConfig.getInstance().reInitProperties();
            log.info("Load config file: sConfig ok");
        }
        if (StringUtils.equalsIgnoreCase(DOMAIN_CONFIG_NAME, file.getName())) {
            DomainConfig.getInstance().reInitProperties();
            log.info("Load config file: dConfig ok");
        }
    }
}
