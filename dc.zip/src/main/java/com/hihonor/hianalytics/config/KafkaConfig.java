package com.hihonor.hianalytics.config;


import lombok.AllArgsConstructor;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * kafka配置类
 * </p>
 *
 * @author w00027882
 * @date Created in 20230414
 */
@Configuration
@EnableKafka

public class KafkaConfig {
    @Value("${encrypt.kafka.bootstrap-servers}")
    private String encryptServers;

    @Value("${decrypt.kafka.bootstrap-servers}")
    private String decryptServers;

    @Value("${spring.kafka.producer.client-id}")
    private String clientId;

    @Value("${spring.kafka.producer.key-serializer}")
    private String keySerializer;

    @Value("${spring.kafka.producer.value-serializer}")
    private String valueSerializer;

    @Value("${spring.kafka.producer.retries}")
    private String retry;

    @Bean(name="encryptKafkaTemplate")
    public KafkaTemplate<String, String> encryptKafkaTemplate() {
        return new KafkaTemplate<>(encryptProducerFactory());
    }

    @Bean(name="decryptKafkaTemplate")
    public KafkaTemplate<String, String> decryptKafkaTemplate() {
        return new KafkaTemplate<>(decryptProducerFactory());
    }

    @Bean
    public ProducerFactory<String, String> encryptProducerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, encryptServers);
        props.put(ProducerConfig.RETRIES_CONFIG, retry);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(props);
    }

    @Bean
    public ProducerFactory<String, String> decryptProducerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, decryptServers);
        props.put(ProducerConfig.RETRIES_CONFIG, retry);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(props);
    }

}
