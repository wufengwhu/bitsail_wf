/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2012-2019. All rights reserved.
 */

package com.hihonor.hianalytics.config;

import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author z00502253
 * @since 2020-01-28
 */
@Component
public interface HttpReturnCode {

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    int PARAMETER_INVALID = 400;

    /**
     * 功能描述 无权限
     *
     * @author z00502253
     * @since 2019-12-03
     */
    int NO_AUTHORIZATION = 401;

    /**
     * 功能描述 参数为空
     *
     * @author z00502253
     * @since 2019-12-03
     */
    int PARAMETER_EMPTY = 402;

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    int NO_SERVICE_ID = 404;

    /**
     * 功能描述 上报数据长度超过限制大小
     *
     * @author zwx811366
     * @since 2019-01-06
     */
    int REQUEST_CONTENT_INVALID = 413;

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    int SYSTEM_ERROR = 500;
}
