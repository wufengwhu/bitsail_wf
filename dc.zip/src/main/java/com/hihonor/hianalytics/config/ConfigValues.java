/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.config;

import org.springframework.stereotype.Component;

/**
 * The interface ConfigValues
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Component
public interface ConfigValues {

    /**
     * 文件变更轮询间隔
     *
     * @author z00502253
     * @since 2019-12-02
     */
    int FILE_ALTERATION_POLLING_INTERVAL = 5000;

    /**
     * 最大使用长度
     *
     * @author z00502253
     * @since 2019-12-02
     */
    int MAX_USER_AGENT_LEN = 2048;
}
