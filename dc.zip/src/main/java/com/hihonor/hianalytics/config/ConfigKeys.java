/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.config;

import org.springframework.stereotype.Component;

/**
 * The interface ConfigKeys
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Component
public interface ConfigKeys {

    /**
     * The Constant LOGREPORT_LOGFOLDER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String LOGREPORT_LOGFOLDER = "logreport.logfolder";

    /**
     * The Constant LOGREPORT_BATCHUPLOAD_SIZE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String LOGREPORT_BATCHUPLOAD_SIZE = "logreport.batchupload.size";

    /**
     * The Constant LOGREPORT_SUPPORTED_BATCHUPLOAD.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String LOGREPORT_SUPPORTED_BATCHUPLOAD = "logreport.supported.batchupload";

    /**
     * The Constant LOGREPORT_SUPPORTED_DEVELOPER_BASE64.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String LOGREPORT_SUPPORTED_DEVELOPER_BASE64 = "logreport.supported.developer.base64";

    /**
     * The Constant SEARCH_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String SEARCH_MAX_LENGTH = "search.max.length";

    /**
     * The Constant MAGIC_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String MAGIC_MAX_LENGTH = "magic.max.length";

    /**
     * The Constant COMMON_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String COMMON_MAX_LENGTH = "common.max.length";

    /**
     * The Constant SDK_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String SDK_MAX_LENGTH = "sdk.max.length";

    /**
     * The Constant EXPOSURE_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String EXPOSURE_MAX_LENGTH = "exposure.max.length";

    /**
     * The Constant CLICK_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String CLICK_MAX_LENGTH = "click.max.length";

    /**
     * The Constant WEB_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String WEB_MAX_LENGTH = "web.max.length";

    /**
     * The Constant PERF_MONITOR_INTERFACE_LIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String PERF_MONITOR_INTERFACE_LIST = "performance.monitor.intefaceList";

    /**
     * The Constant LOG_AUTO_ROLLING_SWITCH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String LOG_AUTO_ROLLING_SWITCH = "log.auto.rolling.switch";

    /**
     * The Constant MARKETING_WEB_DEFAULT_COOKIE_DOMAIN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String MARKETING_WEB_DEFAULT_COOKIE_DOMAIN = "default.cookie.domain";

    /**
     * The Constant CLICK_REDIRECT_HOST_WHITELIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String CLICK_REDIRECT_HOST_WHITELIST = "click.redirect.host.whiteList";

    /**
     * The Constant CLICK_REDIRECT_HOST_FORMAT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String CLICK_REDIRECT_HOST_FORMAT = "click.redirect.host.format";

    /**
     * The Constant PERF_MONITOR_INTERVAL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String PERF_MONITOR_INTERVAL = "performance.monitor.interval";

    /**
     * The Constant DEFAULT_BUSINESS_LOGGERS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEFAULT_BUSINESS_LOGGERS = "default.business.loggers";

    /**
     * The Constant INDEPENDENT_BUSINESS_APPID_LIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String INDEPENDENT_BUSINESS_APPID_LIST = "independent.business.appidList";

    /**
     * The Constant INDEPENDENT_BUSINESS_INTERFACE_LIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String INDEPENDENT_BUSINESS_INTERFACE_LIST = "independent.business.intefaceList";

    /**
     * The Constant SDK_MAGIC_CLIENT_IP_SWITCH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String SDK_MAGIC_CLIENT_IP_SWITCH = "sdkmagic.client.ip.switch";

    /**
     * The Constant COMMON_CLIENT_IP_SWITCH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String COMMON_CLIENT_IP_SWITCH = "common.client.ip.switch";

    /**
     * The Constant VMALL_FI_KAFKA_USE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_USE = "vmall.FI.kafka.use";

    /**
     * The Constant VMALL_FI_KAFKA_USER_KEYTAB_FILE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_USER_KEYTAB_FILE = "vmall.FI.kafka.user.keytab.file";

    /**
     * The Constant VMALL_DMP_WHITELIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_DMP_WHITELIST = "vmall.dmp.whiteList";

    /**
     * The Constant VMALL_FI_KAFKA_BOOTSTRAP_SERVERS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_BOOTSTRAP_SERVERS = "vmall.FI.kafka.bootstrap.servers";

    /**
     * The Constant VMALL_FI_KAFKA_CLIENT_ID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_CLIENT_ID = "vmall.FI.kafka.client.id";

    /**
     * The Constant VMALL_FI_KAFKA_KEY_SERIALIZER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_KEY_SERIALIZER = "vmall.FI.kafka.key.serializer";

    /**
     * The Constant VMALL_FI_KAFKA_KVALUE_SERIALIZER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_KVALUE_SERIALIZER = "vmall.FI.kafka.value.serializer";

    /**
     * The Constant VMALL_FI_KAFKA_SECURITY_PROTOCOL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_SECURITY_PROTOCOL = "vmall.FI.kafka.security.protocol";

    /**
     * The Constant VMALL_FI_KAFKA_SASL_KERBEROS_SERVICE_NAME.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_SASL_KERBEROS_SERVICE_NAME = "vmall.FI.kafka.sasl.kerberos.service.name";

    /**
     * The Constant VMALL_FI_KAFKA_ACKS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_ACKS = "vmall.FI.kafka.acks";

    /**
     * The Constant VMALL_FI_KAFKA_USER_PRINCIPAL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_USER_PRINCIPAL = "vmall.FI.kafka.user.principal";

    /**
     * The Constant VMALL_FI_KAFKA_KRB5_CONF_FILE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String VMALL_FI_KAFKA_KRB5_CONF_FILE = "vmall.FI.kafka.krb5.conf.file";

    /**
     * The Constant ABC_1.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String ABC_1 = "abc.1";

    /**
     * The Constant CDF_2.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String CDF_2 = "cdf.2";

    /**
     * The Constant ROOT_KEY_SALT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String ROOT_KEY_SALT = "rootKeySalt";

    /**
     * The Constant WORK_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String WORK_KEY = "workKey";

    /**
     * The Constant PIG_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String pig_key = "first";

    /**
     * The Constant DOG_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String dog_key = "second";

    /**
     * The Constant DUCK_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String duck_key = "third";

    /**
     * The Constant CAT_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String cat_key = "salt";

    /**
     * The Constant PSI_WORK_KEY_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String psi_workKey_key = "psiWorkKey";

    /**
     * The Constant HASDK_SPECIAL_APPIDLIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String HASDK_SPECIAL_APPIDLIST = "hasdk.special.appid.list";

    /**
     * The Constant AES_ABC_PACS5PADDING.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String aes_abc_pkcs5padding = "aes.cbc.pkcs5padding";

    /**
     * The Constant HASDK_BUSINESS_APPIDLIST_SWITCH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String HASDK_BUSINESS_APPIDLIST_SWITCH = "hasdk.business.appidList.switch";

    /**
     * The Constant HASDK_BUSINESS_APPIDLIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String HASDK_BUSINESS_APPIDLIST = "hasdk.business.appidList";

    /**
     * The Constant ROOT_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String ROOT_KEY = "root_key_comp_hard"; // 根密钥组件

    /**
     * The Constant KEY_FILE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String KEY_FILE = "com.hihonor.hianalytics.config.commonConfig";

    /**
     * Debugview 需求 start
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_USE = "debugview.FI.kafka.use";

    /**
     * The Constant DEBUGVIEW_FI_KERBEROS_DOMAIN_NAME.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KERBEROS_DOMAIN_NAME = "debugview.kerberos.domain.name";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_TOPIC.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_TOPIC = "debugview.FI.kafka.topic";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_USER_KEYTAB_FILE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_USER_KEYTAB_FILE = "debugview.FI.kafka.user.keytab.file";

    /**
     * The Constant DEBUGVIEW_DMP_WHITELIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_DMP_WHITELIST = "debugview.dmp.whiteList";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_BOOTSTRAP_SERVERS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_BOOTSTRAP_SERVERS = "debugview.FI.kafka.bootstrap.servers";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_CLIENT_ID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_CLIENT_ID = "debugview.FI.kafka.client.id";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_KEY_SERIALIZER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_KEY_SERIALIZER = "debugview.FI.kafka.key.serializer";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_KVALUE_SERIALIZER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_KVALUE_SERIALIZER = "debugview.FI.kafka.value.serializer";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_SECURITY_PROTOCOL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_SECURITY_PROTOCOL = "debugview.FI.kafka.security.protocol";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_SASL_KERBEROS_SERVICE_NAME.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_SASL_KERBEROS_SERVICE_NAME = "debugview.FI.kafka.sasl.kerberos.service.name";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_ACKS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_ACKS = "debugview.FI.kafka.acks";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_USER_PRINCIPAL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_USER_PRINCIPAL = "debugview.FI.kafka.user.principal";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_KRB5_CONF_FILE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_KRB5_CONF_FILE = "debugview.FI.kafka.krb5.conf.file";

    /**
     * The Constant DEBUGVIEW_FI_KAFKA_RETRIES.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DEBUGVIEW_FI_KAFKA_RETRIES = "debugview.FI.kafka.retries";

    /** Debugview 需求 end */

    /**
     * The Constant GETSERVERINFO_SWITCH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String GETSERVERINFO_SWITCH = "getserverinfo.switch";

    /**
     * The Constant SENSTITIVE_KEYS_KEY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String SENSTITIVE_KEYS_KEY = "sensitive.keys";

    /**
     * HTTPS SSL配置信息
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String CLIENTAUTH_SUPPORTED_PROTOCOLLIST = "clientauth.supported.protocolList";

    /**
     * compress压缩配置 单次解压最大字节数
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String SINGLE_DECOMPRESS_LENGTH = "single.decompress.length";

    /**
     * decompress max length
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DECOMPRESS_MAX_LENGTH = "decompress.max.length";

    /**
     * jvm Memory usage alarm Percent
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String JVM_MEMORY_ALARM_PERCENT = "jvm.memory.alarm.percent";

    /**
     * The Constant JSSDK_ACCESS_CONTROL_ALLOW_ORIGIN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String JSSDK_ACCESS_CONTROL_ALLOW_ORIGIN = "jssdk.Access.Control.Allow.Origin";

    /**
     * The Constant JSSDK_ACCESS_CONTROL_ALLOW_METHODS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String JSSDK_ACCESS_CONTROL_ALLOW_METHODS = "jssdk.Access.Control.Allow.Methods";

    /**
     * The Constant JSSDK_ACCESS_CONTROL_MAX_AGE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String JSSDK_ACCESS_CONTROL_MAX_AGE = "jssdk.Access.Control.Max.Age";

    /**
     * The Constant JSSDK_ACCESS_CONTROL_ALLOW_HEADERS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String JSSDK_ACCESS_CONTROL_ALLOW_HEADERS = "jssdk.Access.Control.Allow.Headers";

    /**
     * The Constant HA_FLAG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String HA_FLAG = "ha.flag";

    /**
     * The Constant CRASH_MAX_LENGTH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String CRASH_MAX_LENGTH = "crash.max.length";

    /**
     * The Constant INDEPENDENT_BUSINESS_LOG_SIZE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String INDEPENDENT_BUSINESS_LOG_SIZE = "independent.business.log.size";

    /**
     * The Constant INDEPENDENT_BUSINESS_LOG_HISTORY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String INDEPENDENT_BUSINESS_LOG_HISTORY = "independent.business.log.history";

    /**
     * The Constant INDEPENDENT_BUSINESS_LOG_QUEUE_SIZE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String INDEPENDENT_BUSINESS_LOG_QUEUE_SIZE = "independent.business.log.queue.size";

    /**
     * The Constant INDEPENDENT_BUSINESS_LOGFOLDER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String INDEPENDENT_BUSINESS_LOGFOLDER = "independent.business.logfolder";

    /**
     * The Constant INDEPENDENT_BUSINESS_LOGFOLDER_ADD.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String INDEPENDENT_BUSINESS_LOGFOLDER_ADD = "independent.business.logfolder.add";


    /**
     * The Constant INDEPENDENT_BUSINESS_LOGFOLDER.
     *
     * @author w00027882
     * @since 2023-02-06
     */
    String INDEPENDENT_BUSINESS_OPER_LOGFOLDER = "independent.business.oper.logfolder";

    /**
     * The Constant INDEPENDENT_BUSINESS_LOGFOLDER_ADD.
     *
     * @author w00027882
     * @since 2023-02-06
     */
    String INDEPENDENT_BUSINESS_OPER_LOGFOLDER_ADD = "independent.business.oper.logfolder.add";



    /**
     * The Constant DCSDK_CONFIG_FILE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String DCSDK_CONFIG_FILE = "dcsdk.config.file";

    /**
     * The Constant ANALYTICS_GATEWAY_IP_WHITELIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String ANALYTICS_GATEWAY_IP_WHITELIST = "analytics.gateway.ip.whiteList";

    /**
     * The Constant ANALYTICS_GATEWAY_IP_AUTH_ENABLE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    String ANALYTICS_GATEWAY_IP_AUTH_ENABLE = "analytics.gateway.ip.auth.enable";

}