/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.config;

import java.io.File;
import java.net.URL;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * 配置文件监控
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Component
@Slf4j
public class ConfigFileMonitor {

    /**
     * The Constant CONFIGINSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static ConfigFileMonitor configInstance = new ConfigFileMonitor();

    /**
     * The Constant FILE_ALTER_MONITOR.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private FileAlterationMonitor fileAlterationMonitor =
        new FileAlterationMonitor(ConfigValues.FILE_ALTERATION_POLLING_INTERVAL);

    /**
     * 构造函数
     * 饿汉模式
     */

    public static ConfigFileMonitor getConfigInstance() {
        return configInstance;
    }


    /**
     * monitor 监控函数
     *
     * @param path 监控目标
     * @param listener 监控者
     * @author z00502253
     * @since 2022-07-05
     */
    private void monitor(String path, FileAlterationListener listener) {
        FileAlterationObserver observer = new FileAlterationObserver(new File(path));
        observer.addListener(listener);
        fileAlterationMonitor.addObserver(observer);
    }

    /**
     * 结束监控
     *
     * @author z00502253
     * @since 2022-07-05
     */
    public void stop() {
        log.info("monitor stop");
        try {
            fileAlterationMonitor.stop();
        } catch (Exception e) {
            log.error("Failed to stop ConfigFileMonitor,exception is {}", e.getMessage());
        }
    }

    /**
     * 开始监控
     *
     * @author z00502253
     * @since 2022-07-05
     */
    public void start() {
        try {
            URL url = ConfigFileMonitor.class.getResource("/");
            if (url == null) {
                log.error("Failed to stop ConfigFileMonitor");
                return;
            }
            String configDir = url.getFile();
            monitor(configDir, new ConfigFileListener());
            fileAlterationMonitor.start();
        } catch (Exception e) {
            log.error("Failed to stop ConfigFileMonitor,exception is {}", e.getMessage());
        }
    }
}
