/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.config;

import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.utils.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * 服务器自身配置
 *
 * @author lWX788624
 * @since 2019-10-08
 */

@Slf4j
@Configuration
public class ServerConfig {
    /**
     * 配置实例.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static volatile ServerConfig serverConfig;

    /**
     * 配置项对象.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static Properties prop = new Properties();

    public ServerConfig() {
    }

    /**
     * 获取配置实例（单例）
     *
     * @return 配置实例
     * @author z00502253
     * @since 2022-07-05
     */
    public static ServerConfig getInstance() {
        if (null == serverConfig) {
            synchronized (ServerConfig.class) {
                if (null == serverConfig) {
                    serverConfig = new ServerConfig();
                    initProperties();
                }
            }
        }
        return serverConfig;
    }

    @Value("${spring.config.location}")
    private String configLocation;

    /**
     * 导入配置文件 导入配置项：日志存储路径，日志文件名格式等
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private static void initProperties() {
        InputStream in = null;
        try {
            in = ServerConfig.class.getResourceAsStream("/config.properties");
            prop.load(in);
        } catch (FileNotFoundException e) {
            log.error("Can't find config.properties file,exception is {}", e.getMessage());
        } catch (IOException e) {
            log.error("Can't find config.properties file,exception is {}", e.getMessage());
        } finally {
            IOUtils.closeQuietly(in);
        }

    }

    /**
     * 重新初始化配置
     *
     * @author z00502253
     * @since 2022-07-05
     */
    void reInitProperties() {
        initProperties();
    }

    /**
     * 读取字符串值
     *
     * @param key 配置项key
     * @return 配置项值
     * @author z00502253
     * @since 2022-07-05
     */
    public String getAsString(String key) {
        return prop.getProperty(key);
    }

    /**
     * 获取配置
     *
     * @author z00502253
     * @since 2020-02-06
     */
    public String getAsString(String key, String defValue) {
        String result = prop.getProperty(key);
        if (CommonUtils.isNull(result)) {
            return defValue;
        } else {
            return result;
        }
    }

    /**
     * 读取整数值
     *
     * @param key      配置项key
     * @param defValue 默认值
     * @return 配置项值
     * @author z00502253
     * @see [类、类#方法、类#成员]
     * @since 2022-07-05
     */
    public int getAsInt(String key, int defValue) {
        int result;
        try {
            String strValue = prop.getProperty(key);
            if (!CommonUtils.isNull(strValue)) {
                result = Integer.parseInt(strValue);
                return result;
            } else {
                return defValue;
            }
        } catch (Exception e) {
            log.error("Failed to get value for {},exception is {}", key, e.getMessage());
            return defValue;
        }
    }

    /**
     * 获取配置value集合
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public List<String> getAsStringList(String key) {
        List<String> list = new ArrayList<>();
        try {
            String strValue = prop.getProperty(key);
            if (CommonUtils.isNull(strValue)) {
                return null;
            }
            String[] strValues = StringUtils.split(strValue, ",");
            if (strValues != null && strValues.length > 0) {
                list.addAll(Arrays.asList(strValues));
                return list;
            }
        } catch (Exception e) {
            log.error("Failed to get value for {},exception is {}", key, e.getMessage());
        }
        return null;
    }

    /**
     * 读取整数值
     *
     * @param key 配置项key
     * @return 配置项值
     * @author z00502253
     * @see [类、类#方法、类#成员]
     * @since 2022-07-05
     */
    public Map<String, Object> getAsMap(String key) {
        Map<String, Object> result = new HashMap<>();
        try {
            String strValue = prop.getProperty(key);
            if (!StringUtils.isEmpty(strValue)) {
                result = JSONObject.parseObject(strValue);
            }
        } catch (Exception e) {
            log.error("Failed to get value for {},exception is {}", key, e.getMessage());
        }
        return result;
    }
}
