package com.hihonor.hianalytics;

/**
 * @author w00027882
 */

import com.hihonor.hianalytics.utils.SpringBeanUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
@ServletComponentScan
public class DataCollectorApplication {
    public static void main(String[] args) {

        SpringApplication.run(DataCollectorApplication.class, args);
        ApplicationContext applicationContext = SpringBeanUtil.getApplicationContext();
        System.out.println(applicationContext.getApplicationName());
    }
}
