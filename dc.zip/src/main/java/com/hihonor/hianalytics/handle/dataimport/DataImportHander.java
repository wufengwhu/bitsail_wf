/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle.dataimport;

import com.hihonor.hianalytics.handle.dataimport.entity.DataImportEntity;
import com.hihonor.hianalytics.utils.ValidateUtils;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.hihonor.hianalytics.common.exception.HiAnalyticesException;
import org.springframework.stereotype.Service;

/**
 * 功能描述
 *
 * @author l00534385
 * @since 2020-03-11
 */
@Slf4j
public class DataImportHander {
    /**
     * The Constant DATAIMPORTLOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger DATAIMPORTLOGGER = LoggerFactory.getLogger("dataimport");

    /**
     * The Constant SPLIT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String SPLIT = "|";

    /**
     * The Constant SPLIT_ESCAPE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String SPLIT_ESCAPE = "%124%";

    /**
     * processData
     *
     * @param entity vo
     * @author z00502253
     * @since 2022-07-04
     */
    public static void processData(DataImportEntity entity) throws HiAnalyticesException {
        // 校验失败直接抛出异常，servlet会处理
        ValidateUtils.validate(entity);

        String dcsPackageName = "";

        entity.getUserDataSet().forEach(userData -> {
            StringBuilder content = new StringBuilder("" + System.currentTimeMillis()).append(SPLIT)
                .append(entity.getAppId())
                .append(SPLIT)
                .append(entity.getProductId())
                .append(SPLIT)
                .append(dcsPackageName)
                .append(SPLIT)
                .append(userData.getId().replace(SPLIT, SPLIT_ESCAPE))
                .append(SPLIT)
                .append(JSON.toJSONString(userData.getProperties()).replace(SPLIT, SPLIT_ESCAPE));
            DATAIMPORTLOGGER.info(content.toString());
        });

    }
}
