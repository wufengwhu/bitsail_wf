/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.hihonor.hianalytics.handle.dataimport.entity;

import java.util.List;
import java.util.StringJoiner;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 功能描述
 *
 * @author l00534385
 * @since 2020 -03-11
 */
@Data
public class UserData {
    @Length(min = 1, max = 256, message = "userdata.id [%value%] length must between 1 and 256")
    @NotNull(message = "userdata.id not be null")
    @JSONField(name = "id")
    private String id;

    @Valid
    @Size(min = 1, max = 25, message = "userdata.properties size must between 1 and 25")
    @NotNull(message = "userdata.properties not be null")
    @JSONField(name = "properties")
    private List<UserProperty> properties;

    @Override
    public String toString() {
        return new StringJoiner(", ", UserData.class.getSimpleName()
                + "[", "]").add("id='" + id + "'")
            .add("properties=" + properties)
            .toString();
    }
}
