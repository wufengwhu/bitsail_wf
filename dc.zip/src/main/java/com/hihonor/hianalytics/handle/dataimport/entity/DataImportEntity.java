/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.hihonor.hianalytics.handle.dataimport.entity;

import java.util.List;
import java.util.StringJoiner;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 功能描述
 *
 * @author l00534385
 * @since 2020 -03-11
 */
@Data
public class DataImportEntity {

    @Length(min = 1, max = 32, message = "appid [%value%] length must between 1 and 32")
    @NotNull(message = "app_id must not be null")
    private String appId;

    /**
     * 从消息头中获取，需要单独赋值，单独校验
     *
     * @author z00502253
     * @since 2019-12-02
     */

    private String productId;

    @Min(value = 1, message = "data_type [%value%] only support 1")
    @Max(value = 1, message = "data_type [%value%] only support 1")
    @NotNull(message = "data_type must not be null")
    @JSONField(name = "data_type")
    private Integer dataType;

    @Valid
    @Size(min = 1, max = 100, message = "userdata_set size must between 1 to 100")
    @NotNull(message = "userdata_set must not be null")
    @JSONField(name = "userdata_set")
    private List<UserData> userDataSet;

    @Override
    public String toString() {
        return new StringJoiner(", ", DataImportEntity.class.getSimpleName()
                + "[", "]").add("appId='" + appId + "'")
            .add("dataType=" + dataType)
            .add("userDataSet=" + userDataSet)
            .toString();
    }
}
