/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2012-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

import com.alibaba.fastjson.JSON;

import com.hihonor.hianalytics.service.LogPersistent;
import com.hihonor.hianalytics.utils.CommonUtils;
import com.hihonor.hianalytics.utils.EncryptUtils;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.BatchUploadEntity;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.entity.SearchEntity;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 功能描述：大S三方数据采集
 *
 * @author z00502253
 * @since 2020-01-17
 */
@Slf4j
public class LogReportV1Handler extends Handler {

    /**
     * The Constant SPLILT_001.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static  final String SPLILT_001 = "\001";

    /**
     * The Constant ISSUPPORTBATCHUPLOAD.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final boolean ISSUPPORTBATCHUPLOAD =
            "true".equals(ServerConfig.getInstance()
            .getAsString(ConfigKeys.LOGREPORT_SUPPORTED_BATCHUPLOAD));

    public LogReportV1Handler() {
        handlerTypeEnum = HandlerTypeEnum.SEARCHV1;
    }

    /**
     * 设置执行顺序
     *
     * @author z00502253
     * @since 2019-12-02
     */
    @Override
    public void setSequence() {
        sequence.clear();
        sequence.add(HandleEnum.DECOM);
        sequence.add(HandleEnum.SAVE);
    }

    /**
     * 功能描述：大S第三方数据处理
     *
     * @author z00502253
     * @since 2020-01-17
     */
    public boolean doSave(HiAnalyticsEntity hiAnalyticsEntity) {
        // 转为SearchEntity子类对象
        SearchEntity entity = null;
        if (hiAnalyticsEntity instanceof SearchEntity) {
            entity = (SearchEntity) hiAnalyticsEntity;
        }

        // 获取经过解压后的数据
        if (null == entity) {
            log.error("After change SearchEntity is null");
            return false;
        }
        String uploadData = entity.getData();
        // 检查解压后是否存在异常
        if (CommonUtils.isNull(uploadData)) {
            log.error("Do handle save data is null");
            return false;
        }
        // /logreport   String commonSubType = entity.getCommonSubType();
        // 是否支持批量上报 若是则凭装数据
        // todo 批量数据上报是否需要在请求头中增加内容
        if (ISSUPPORTBATCHUPLOAD) {
            BatchUploadEntity batchUploadEntity = JSON.parseObject(uploadData, BatchUploadEntity.class);
            if (batchUploadEntity == null) {
                log.error("After parse,upload message is null");
                return false;
            } else {
                // 如果没有数据 或 size太大了
                if (batchUploadEntity.getMsgs() == null || batchUploadEntity.msgs.size() >
                ServerConfig.getInstance().getAsInt(ConfigKeys.LOGREPORT_BATCHUPLOAD_SIZE,1000)) {
                    log.error("Error is no message or message size more than "
                            + (ConfigKeys.LOGREPORT_BATCHUPLOAD_SIZE));
                    return false;
                }
                entity.setMegs(batchUploadEntity.getMsgs());
                entity.setIp(EncryptUtils.encrypt(ip));
                entity.setServerTime(serverTime);
            }
        } else {
            // 封装落盘消息
            uploadData = serverTime
                    + SPLILT_001 + entity.getAppId()
                    + SPLILT_001 + entity.getLogType()
                    + SPLILT_001 + entity.getRequestId()
                    + SPLILT_001 + EncryptUtils.encrypt(ip)
                    + SPLILT_001
                    + uploadData;
            // 更新报文
            entity.updateData(uploadData);
        }
        // 获取数据上报实例
        LogPersistent logPersistent = LogPersistent.getInstance(entity.getCommonSubType());
        // 数据上报
        return logPersistent.saveSearchLog(entity);
    }
}
