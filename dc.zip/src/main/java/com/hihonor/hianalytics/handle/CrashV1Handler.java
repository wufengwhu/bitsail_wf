/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

import org.springframework.stereotype.Service;

/**
 * 功能描述：Crash日志采集上报处理器
 *
 * @author zWX811366
 * @since 2019-11-26
 */

public class CrashV1Handler extends Handler{

    public CrashV1Handler() {
        handlerTypeEnum = HandlerTypeEnum.CRASHV1;
    }

    /**
     * 设置执行顺序
     *
     * @author z00502253
     * @since 2022-08-18
     */
    @Override
    public void setSequence() {
        sequence.clear();
        sequence.add(HandleEnum.DECOM);
        sequence.add(HandleEnum.SAVE);
    }
}
