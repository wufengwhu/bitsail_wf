/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Slf4j
@NoArgsConstructor
public final class HandlerFactory {
    /**
     * 创建Handle对象实例
     *
     * @param c Handle类
     * @return Handle对象实例
     * @see [类、类#方法、类#成员]
     * @author lWX788624
     * @since 2019-10-08
     */
    public static Handler createHandler(Class c) {
        Handler handler = null;
        try {
            handler = (Handler) Class.forName(c.getName()).newInstance();
        } catch (Exception e) {
            log.error("Can't create handler's instance,exception is {}",e.getMessage());
        }
        return handler;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static Handler createHandler(Class c, boolean debugDeploy) {
        Handler handler = createHandler(c);
        if (debugDeploy) {
            handler.setDebug();
        }
        return handler;
    }
}
