/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
public class WebV2Handler extends Handler {

    public WebV2Handler() {
        handlerTypeEnum = HandlerTypeEnum.WEBV2;
    }

    /**
     * 设置执行顺序
     *
     * @author z00502253
     * @since 2022-08-18
     */
    @Override
    public void setSequence() {
        sequence.clear();
        sequence.add(HandleEnum.SETDATA);
        sequence.add(HandleEnum.SAVE);
    }
}
