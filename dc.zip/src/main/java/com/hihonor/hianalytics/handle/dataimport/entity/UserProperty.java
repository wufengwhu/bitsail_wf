/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.hihonor.hianalytics.handle.dataimport.entity;

import java.util.StringJoiner;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

/**
 * 功能描述
 *
 * @author l00534385
 * @since 2020 -03-11
 */
@Data
public class UserProperty {
    @Length(min = 1, max = 256, message = "userdata_set.properties.id [%value%] length must between 1 and 256")
    @Pattern(regexp = "^[a-zA-Z_][a-zA-Z0-9_]{6,}",
        message = "userdata_set.properties.id vale [%value%] must composed of numbers, " +
                "letters and underscores, and cannot start with numbers")
    @NotNull(message = "userdata_set.properties.id not be null")
    private String id;

    @Length(min = 1, max = 256, message = "userdata_set.properties.value [%value%] length must between 1 and 256")
    @NotNull(message = "userdata_set.properties.value not be null")
    private String value;

    @Override
    public String toString() {
        return new StringJoiner(", ", UserProperty.class.getSimpleName()
                + "[", "]").add("id='" + id + "'")
            .add("value='" + value + "'")
            .toString();
    }
}
