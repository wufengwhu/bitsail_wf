/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
public enum HandleEnum {

    /**
     * 解压缩操作
     *
     * @author z00502253
     * @since 2019-12-02
     */
    DECOM("decom"),
    /**
     * 设置未加密数据
     *
     * @author z00502253
     * @since 2019-12-02
     */
    SETDATA("setdata"),
    /**
     * 保存数据操作
     *
     * @author z00502253
     * @since 2019-12-02
     */
    SAVE("save");

    /**
     * 数据类型名.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String name;

    /**
     * 构造数据类型.
     *
     * @param arg 数据类型名
     *
     * @author z00502253
     * @since 2019-12-02
     */
    HandleEnum(final String arg) {
        name = arg;
    }

    /**
     * 获取数据类型名.
     *
     * @return 数据类型名
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String getName() {
        return name;
    }

}
