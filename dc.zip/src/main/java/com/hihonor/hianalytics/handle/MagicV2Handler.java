/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

import org.springframework.stereotype.Service;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
public class MagicV2Handler extends Handler {

    public MagicV2Handler() {
        handlerTypeEnum = HandlerTypeEnum.MAGICV2;
    }

    /**
     * 设置执行顺序
     *
     * @author z00502253
     * @since 2022-08-18
     */
    @Override
    public void setSequence() {
        sequence.clear();
        sequence.add(HandleEnum.DECOM);
        sequence.add(HandleEnum.SAVE);
    }
}
