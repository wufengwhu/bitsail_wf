/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.debugview.ProducerCallBack;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.service.LogPersistent;
import com.hihonor.hianalytics.utils.CommonUtils;
import com.hihonor.hianalytics.utils.DataCollectorException;
import com.hihonor.hianalytics.utils.EncryptUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.util.TextUtils;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;


/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Data
@Slf4j
public abstract class Handler {


    /**
     * 日志处理顺序.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    List<HandleEnum> sequence = new ArrayList<>();

    /**
     * The Constant COMMONIP_SWITCHLIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public Map<String, Object> commonIpSwitchList =
            ServerConfig.getInstance().getAsMap(ConfigKeys.COMMON_CLIENT_IP_SWITCH);

    /**
     * 通过接口直接调用采集服务器appid名单.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> hasdkSpecialAppidList =
            ServerConfig.getInstance().getAsStringList(ConfigKeys.HASDK_SPECIAL_APPIDLIST);

    /**
     * 是否是HA专有特性
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final boolean IS_HA_VERSION = StringUtils.equalsAnyIgnoreCase(
            ServerConfig.getInstance().getAsString(ConfigKeys.HA_FLAG), "true");

    protected static boolean REALTIME_FLAG = "true".equals(ServerConfig.getInstance().getAsString("realtime.flag"));

    /**
     * 不走采集服务实时通道appid名单.
     *
     * @author w00027882
     * @since 2023-03-09
     */
    private List<String> hasdkNotRealtimeAppidList =
            ServerConfig.getInstance().getAsStringList("hasdk.not.realtime.appid.list");

    /**
     * 接口枚举值
     *
     * @author z00502253
     * @since 2019-12-02
     */
    HandlerTypeEnum handlerTypeEnum;

    /**
     * The Constant IP.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String ip;

    /**
     * The Constant SERVER_TIME.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public long serverTime;

    /**
     * The Constant PRODUCTID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String productId;

    /**
     * The Constant DEBUG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public boolean debug;


    /**
     * The Constant SAVE_RESULT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public boolean saveResult = false;


    private KafkaTemplate<String, String> encryptKafkaTemplate;

    private KafkaTemplate<String, String> decryptKafkaTemplate;

//    private ProducerCallBack producerCallBack;

    private String encryptTopicName;

    private String decryptTopicName;

    /**
     * 设置日志处理的执行顺序
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public abstract void setSequence();

    /**
     * 按设定的日志处理顺序处理日志（必须先设置日志处理顺序）
     *
     * @return 处理是否成功
     * @author lWX788624
     * @since 2019-10-08
     */
    public boolean doHandle(HiAnalyticsEntity entity) {
        boolean result = false;
        if (CommonUtils.isNull(entity.getData())) {
            log.error("Upload data is empty,please check it.");
            return false;
        }
        for (HandleEnum handlerName : sequence) {
            switch (handlerName) {
                case DECOM: {
                    // 走接口请求
                    if (hasdkSpecialAppidList.contains(entity.getAppId())) {
                        String str = hexStringToString(entity.getData());
                        entity.data = str;
                        break;
                    }
                    try {
                        entity.decompressData();
                        break;
                    } catch (DataCollectorException e) {
                        log.error("entity decompress has exception {}", e.getMessage());
                        return false;
                    }
                }
                case SETDATA: {
                    break;
                }
                case SAVE: {
                    result = doSave(entity);
                    break;
                }
                default:
                    break;
            }
        }
        return result;
    }

    /**
     * 把16进制数据转换为字符串。
     *
     * @param s 服务器数据实体
     * @return 处理结果
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String hexStringToString(String s) {
//        if (s == null || s.equals("")) {
//            return null;
//        }
//        s = s.replace(" ", "");
//        byte[] baKeyword = new byte[s.length() / 2];
//        for (int i = 0; i < baKeyword.length; i++) {
//            try {
//                baKeyword[i] = (byte) (0xff & Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16));
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        try {
//            s = new String(baKeyword, "UTF-8");
//            new String();
//        } catch (Exception e1) {
//            e1.printStackTrace();
//        }
//        return s;
        byte[] baKeyword = hexString2ByteArray(s);

        try {
            return new String(baKeyword, "UTF-8");
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return s;
    }


    public static byte[] hexString2ByteArray(String hexString) {
        if (TextUtils.isEmpty(hexString)) {
            return new byte[0];
        }
        hexString = hexString.toUpperCase(Locale.ENGLISH);
        int length = hexString.length() / 2;
        char[] hexChars = hexString.toCharArray();
        byte[] d = new byte[length];
        for (int i = 0; i < length; i++) {
            int pos = i * 2;
            d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
        }
        return d;
    }

    /**
     * Convert char to byte
     *
     * @param c char
     * @return byte
     */
    private static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }

    /**
     * 把数据存储到日志文件。
     *
     * @param entity 服务器数据实体
     * @return 处理结果
     * @author lWX788624
     * @since 2019-10-08
     */
    public boolean doSave(HiAnalyticsEntity entity) {
        String value = entity.getData();
        if (CommonUtils.isNull(value)) {
            log.error("Do handle save data is null");
            return false;
        }
        // 数据压缩后需要校验上报的格式
        if (!checkJsonData(value)) {
            log.error("check JsonData is fail");
            return false;
        }
        // 获取日志实例化对象
        LogPersistent logPersistent = LogPersistent.getInstance(handlerTypeEnum.getName());
        String ipEncrypt = EncryptUtils.encrypt(ip);
        // sdkv123 magic1 crash接口
        if (isSDKOrMagicOrCrash(handlerTypeEnum)) {
            if ("true".equals(ServerConfig.getInstance().getAsString(ConfigKeys.SDK_MAGIC_CLIENT_IP_SWITCH))) {
                value = getValue(value, ipEncrypt);
                entity.updateData(value);
            }
        }
        boolean isEncrypt = entity.isEncrypt();
        // common接口
        if (HandlerTypeEnum.COMMON == handlerTypeEnum) {
            // /common/hmshioperqrt(运营)
            String commonSubType = entity.getCommonSubType();

            // 是否要添加真实的IP
            if ("true".equals(commonIpSwitchList.get(commonSubType))) {
                value = getValue(value, isEncrypt == true ? ipEncrypt : ip);
            } else {
                value = getValue(value, "0.0.0.0");
            }
            entity.updateData(value);
            // modified by w00027882
            // common接口下的 hioperqrt 运营, himaintqrt运维 子类型, 区分加密的数据和去加密的数据
            // add hioperqrt_decrypt 运营去加密, himaintqrt_decrypt 运维去加密
            if ("hioperqrt".equalsIgnoreCase(commonSubType) ||
                    "himaintqrt".equalsIgnoreCase(commonSubType)) {
                commonSubType = isEncrypt == true ? commonSubType : commonSubType + "_decrypt";
            }
            logPersistent = LogPersistent.getInstance(commonSubType);
            // common 接口下的数据才发kafka
            // 20230309 add by w00027882 走实时入湖, 兼容 push 和账号id的加密数据走flume 扫描到kafka
            if (REALTIME_FLAG && !hasdkNotRealtimeAppidList.contains(entity.getAppId())) {
                saveResult = saveLogToKafka(entity);
            }
            // 20230414 add by w00027882 push 和账号id的去加密数据发kafka
            if (REALTIME_FLAG && hasdkNotRealtimeAppidList.contains(entity.getAppId()) && !isEncrypt) {
                saveResult = saveLogToKafka(entity);
            }
        }

        saveResult = logPersistent.saveLog(entity);
        return saveResult;
    }


    public boolean saveLogToKafka(HiAnalyticsEntity entity) {
        String message = entity.getData().replaceAll("\\s*|\t|\r|\n", "");
        boolean isEncrypt = entity.isEncrypt();
        ProducerCallBack producerCallBack = new ProducerCallBack(entity);
        ListenableFuture<SendResult<String, String>> future =
                isEncrypt == true ? encryptKafkaTemplate.send(encryptTopicName, message) :
                        decryptKafkaTemplate.send(decryptTopicName, message);
        future.addCallback(producerCallBack);
        return true;
    }

    /**
     * 功能描述 数据拼接 区分HA和oneData
     *
     * @author z00502253
     * @author lWX788624
     * @since 2019-12-03
     * @since 2019-10-08
     */
    private String getValue(String value, String ipEncrypt) {
        if (IS_HA_VERSION && (!handlerTypeEnum.equals(HandlerTypeEnum.CRASHV1))) {
            value = value + "\001" + ipEncrypt + "\001" + serverTime + "\001" + productId;
        } else {
            value = value + "\001" + ipEncrypt + "\001" + serverTime;
        }
        return value;
    }

    /**
     * 功能描述 是不是SDKV(123) MAGICV(12)接口
     *
     * @author z00502253
     * @author lWX788624
     * @since 2019-12-03
     * @since 2019-10-08
     */
    private boolean isSDKOrMagicOrCrash(HandlerTypeEnum handlerType) {
        return handlerType == HandlerTypeEnum.SDKV1 || handlerType == HandlerTypeEnum.MAGICV1
                || handlerType == HandlerTypeEnum.SDKV2 || handlerType == HandlerTypeEnum.SDKV3
                || handlerType == HandlerTypeEnum.MAGICV2 || handlerType == HandlerTypeEnum.CRASHV1;
    }

    /**
     * checkJsonData
     *
     * @param value String
     * @return boolean
     * @author z00502253
     * @since 2022-08-18
     */
    private boolean checkJsonData(String value) {
        if (this instanceof SdkV1Handler || this instanceof SdkV2Handler) {
            try {
                JSONObject.parseObject(value);
            } catch (JSONException e) {
                log.error("Upload data is not JSONObject ,exception is {}", e.getMessage());
                return false;
            }
        }
        return true;
    }

    public void setDebug() {
        debug = true;
    }
}
