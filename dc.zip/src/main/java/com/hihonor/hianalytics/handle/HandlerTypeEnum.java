/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.handle;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
public enum HandlerTypeEnum {

    SEARCHV1("searchv1"),
    /**
     * 数据采集crash
     *
     * @author z00502253
     * @since 2019-12-02
     */
    CRASHV1("crashv1"),

    /**
     * 数据采集SDKV1
     *
     * @author z00502253
     * @since 2019-12-02
     */
    SDKV1("sdkv1"),

    /**
     * 数据采集SDKV2
     *
     * @author z00502253
     * @since 2019-12-02
     */
    SDKV2("sdkv2"),

    /**
     * 运维数据采集SDKV2
     *
     * @author z00502253
     * @since 2019-12-02
     */
    SDKV3("sdkv3"),

    /**
     * 统一数据采集common
     *
     * @author z00502253
     * @since 2019-12-02
     */
    COMMON("common"),

    /**
     * 数据采集网页JS
     *
     * @author z00502253
     * @since 2019-12-02
     */
    WEBV1("webv1"),

    /**
     * 数据采集网页JS
     *
     * @author z00502253
     * @since 2019-12-02
     */
    WEBV2("webv2"),

    /**
     * 营销曝光
     *
     * @author z00502253
     * @since 2019-12-02
     */
    EXPOSUREV1("exposurev1"),

    /**
     * 营销点击
     *
     * @author z00502253
     * @since 2019-12-02
     */
    CLICKV1("clickv1"),

    /**
     * DMP对接数据
     *
     * @author z00502253
     * @since 2019-12-02
     */
    DMP("dmp"),

    /**
     * 数据采集MAGICV1
     *
     * @author z00502253
     * @since 2019-12-02
     */
    MAGICV1("magicv1"),

    /**
     * 数据采集MAGICV2
     *
     * @author z00502253
     * @since 2019-12-02
     */
    MAGICV2("magicv2");

    /**
     * 日志处理名.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String name;

    /**
     * 日志处理方式.
     *
     * @param arg 日志处理名
     * @author z00502253
     * @since 2019-12-02
     */
    HandlerTypeEnum(final String arg) {
        name = arg;
    }

    /**
     * 获取日志处理名.
     *
     * @return 日志处理名
     * @author z00502253
     * @since 2019-12-02
     */
    public String getName() {
        return name;
    }

}
