/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.*;

import com.huawei.secure.crypto.codec.AegisDecoderException;
import com.huawei.secure.crypto.rootkey.RootKeyUtil;
import com.huawei.secure.crypto.workkey.WorkKeyCryptUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import org.springframework.stereotype.Component;

/**
 * The Class EncryptUtils
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Component
public class EncryptUtils {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(EncryptUtils.class);

    /**
     * The Constant ROOTKEY_UTIL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static RootKeyUtil rootKeyUtil = null;

    /**
     * The Constant FIRST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String first = ServerConfig.getInstance().getAsString(ConfigKeys.pig_key);

    /**
     * The Constant SECOND.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String second = ServerConfig.getInstance().getAsString(ConfigKeys.dog_key);

    /**
     * The Constant THIRD.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String third = ServerConfig.getInstance().getAsString(ConfigKeys.duck_key);

    /**
     * The Constant SALT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String salt = ServerConfig.getInstance().getAsString(ConfigKeys.cat_key);


    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void init() {
        try {
            String workKeyStr = ServerConfig.getInstance().getAsString(ConfigKeys.WORK_KEY);
            String decryptor = decryptor(workKeyStr);
        } catch (Exception e) {
            logger.error("Failed to init EncryptUtils, Exception is {}", e.getMessage());
        }
    }

    /**
     * 功能描述 解密
     *
     * @author lWX788624
     * @since 2021-7-26
     */
    public static String decryptor(String keyStr) {
        try {
            rootKeyUtil = RootKeyUtil.newInstance256(first, second, third, salt);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String decryptWorkKey = null;
        try {
            decryptWorkKey = WorkKeyCryptUtil.decryptWorkKey(keyStr, rootKeyUtil);
        } catch (GeneralSecurityException | AegisDecoderException e) {
            e.printStackTrace();
        }
        return decryptWorkKey;
    }

    /**
     * 功能描述 aes加密
     *
     * @author zw0042249
     * @since 2021-7-27
     */
    public static String encrypt(String plaintext) {
        if (!CommonUtils.isNull(plaintext)) {
            try {
                String secretKey = getSecretKey();
                byte[] byteSize = HexUtils.toBytes(secretKey);
                byte[] bytes = AESCryptorBase64.encryptData(plaintext.getBytes(StandardCharsets.UTF_8), byteSize);
                String ipEncrypt = HexUtils.byteArray2HexString(bytes);
                return ipEncrypt;
            } catch (Exception e) {
                logger.error("Failed to encrypt,exception is {}", e.getMessage());
            }
        }
        return null;
    }

    /**
     * getSecretKey
     *
     * @return String
     * @author z00502253
     * @since 2022-07-05
     */
    public static String getSecretKey() {
        String decryptWorkKey = null;
        try {
            rootKeyUtil = RootKeyUtil.newInstance256(first, second, third, salt);
            decryptWorkKey = WorkKeyCryptUtil.decryptWorkKey(ServerConfig.getInstance()
                    .getAsString(ConfigKeys.WORK_KEY), rootKeyUtil);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (AegisDecoderException e) {
            e.printStackTrace();
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        }
        return decryptWorkKey;// 转换为AES专用密钥
    }
}