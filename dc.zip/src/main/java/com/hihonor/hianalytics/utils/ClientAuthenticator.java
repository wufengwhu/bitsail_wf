/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.hihonor.hianalytics.common.logs.alarm.AlarmLevel;
import com.hihonor.hianalytics.common.logs.token.TokenErrorLogItem;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.Result;
import org.springframework.stereotype.Component;

/**
 * 用于认证客户端合法性。
 * 取http消息头里的token，以及相关信息作为clientId（暂时取client IP），然后调用AGC网关实现认证。
 * 认证后的token会在本地缓存，缓存大小默认为1024*10，缓存有效期默认为3600秒，缓存满载时按LRU算法进行淘汰。
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Component
public class ClientAuthenticator {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(ClientAuthenticator.class);

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static ClientAuthenticator INSTANCE = new ClientAuthenticator();

    /**
     * token缓存.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    Cache<String, String> tokenCache;

    private ClientAuthenticator() {
        tokenCache = CacheBuilder.newBuilder()
            .maximumSize(ServerConfig.getInstance().getAsInt("clientauth.cache.capacity", 1024 * 100))
            .expireAfterWrite(Integer.parseInt(ServerConfig.getInstance()
                            .getAsString("clientauth.cache.expiration")),
                TimeUnit.SECONDS)
            .build();
    }

    public static ClientAuthenticator getInstance() {
        return INSTANCE;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public void addCacheEntryForTest(String clientId, String token) {
        tokenCache.put(token, "OK");
    }

    /**
     * 功能描述 token鉴权
     *
     * @param clientId AGC获取随机数
     * @param token    AGC获取token
     * @param response 响应
     * @author z00502253
     * @since 2019-07-04
     */
    public void authToken(String clientId, String token, TokenErrorLogItem tokenErrorLogItem,
        HttpServletResponse response) {
        // 本地缓存中获取
        boolean localAuthPassed = authLocally(clientId, token);
        if (localAuthPassed) {
            response.setStatus(CommonUtils.SYSTEM_SUCCESS);
        } else {
            // 去AGC远端鉴权
            try {
                Result result = authRemotely(clientId,
                    token,
                    tokenErrorLogItem,
                    ServerConfig.getInstance().getAsString("clientauth.gatewayurl"));
                // 获取AGC内容 判断是否相等
                if (result.getObj() != null) {
                    // 鉴权成功
                    if (result.getObj().equals(token)) {
                        String cacheKey = clientId + "_" + token;
                        tokenCache.put(cacheKey, "OK");
                        response.setStatus(CommonUtils.SYSTEM_SUCCESS);
                    } else {
                        // 不相等 鉴权失败
                        logger.error("Request Token is not equal to the token from AGC response");
                        response.sendError(CommonUtils.NO_AUTHORIZATION,
                                "Request Token is not equal to the token from AGC response");
                    }
                } else {
                    // 鉴权失败 401
                    response.sendError(CommonUtils.NO_AUTHORIZATION,
                            "Client token check fail from AGC");
                }
            } catch (Exception ex) {
                logger.error("After three request,exception is {}", ex.getMessage());
                try {
                    response.sendError(CommonUtils.SYSTEM_AUTHEN, ex.getMessage());
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }
            }
        }
    }

    /**
     * 功能描述 重试三次进行鉴权 远程网关请求鉴权 对于AGC鉴权测试场景： （1）token不传，clientId存在 返回400
     * （2）token传，clientId不传，返回401 （3）两个都不传，400 （4）两个都传且都是错的，401
     * （5）两个都传且有一个是对的，401
     *
     * @author z00502253
     * @since 2019-07-02
     */
    private Result authRemotely(String clientId, String token, TokenErrorLogItem tokenErrorLogItem,
        String authGatewayUrl) {
        Result result = null;

        // 获取最大重试次数和重试时间
        int maxTryCounts = ServerConfig.getInstance().getAsInt("clientauth.retry.counts", 3);
        int intervalTime = ServerConfig.getInstance().getAsInt("clientauth.retry.times", 100);
        for (int i = 0; i < maxTryCounts; i++) {
            boolean isException = false; // 异常捕获并进行重试
            try {
                result = AuthenticatorUtils.authRemotely(clientId, token, tokenErrorLogItem, authGatewayUrl);
            } catch (Exception ex) {
                logger.error("Request to AGC had Exception, count is {}, errorMessage is {}", i + 1, ex.getMessage());
                if (i >= (maxTryCounts - 1)) {

                    // AGC鉴权异常重试已达最大次数，需要告警
                    String staCode = result == null ? "" : result.getRetCode() + "";
                    AlarmLogUtils.sendAlarm(AlarmLevel.MAJOR, new String[] {"agcao"},
                            new String[] {"Request to AGC had Exception.",
                            "The exception is" + ex.getMessage() + ".", "The returnCode of " +
                                    "Request to AGC interface is" + staCode + ".",
                            "Please check service status and logs."});

                    // 已达到最大次数，抛出异常
                    throw new DataCollectorException("Request to AGC interface exception is {}", ex.getMessage(), ex);
                }
                isException = true;
            }
            if (!isException && result != null) {

                // 成功获取token
                if (result.isSuccess()) {
                    logger.debug("Request to AGC success, count is {}", i++);
                    break;
                } else {
                    if (result.getRetCode() != CommonUtils.SYSTEM_ERROR) {
                        logger.error("Request to AGC success,but response code is exception {}", result.getRetCode());
                        break;
                    } else {

                        // 500的场景，说明AGC出问题
                        logger.error("Request to AGC failure, count is {}, errorMessage is {}",
                            i + 1, result.getErrInfo());
                    }
                }
            }

            // 隔100毫秒再去做请求
            try {
                Thread.sleep(intervalTime);
            } catch (InterruptedException e) {
                logger.error("Request to AGC sleep failed.");
            }
        }
        return result;
    }

    /**
     * 功能描述 本地cache对比鉴权
     *
     * @author z00502253
     * @since 2019-07-04
     */
    public boolean authLocally(String clientId, String token) {
        String cacheKey = clientId + "_" + token;
        String cacheResult = tokenCache.getIfPresent(cacheKey);
        if (cacheResult != null) {
            return true;
        }
        return false;
    }
}
