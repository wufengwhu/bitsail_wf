package com.hihonor.hianalytics.utils;


import com.mchange.lang.IntegerUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * The Class HexUtils
 *
 * @author z00502253
 * @since 2022-08-30
 */
@Component
public class HexUtils {

    /**
     * The Constant LOG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger LOG = LoggerFactory.getLogger(HexUtils.class);

    /**
     * The Constant HEX_CHAR_TABLE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final char[] HEX_CHAR_TABLE = {
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'
    };

    /**
     * toBytes
     *
     * @param hexStr String
     * @return byte[]
     * @author z00502253
     * @since 2022-07-05
     */
    public static byte[] toBytes(String hexStr) {
        try {
            if (hexStr == null || hexStr.isEmpty() || hexStr.length() % 2 != 0) {
                LOG.error("Illegal Argument in hex to bytes.");
                return null;
            }
            byte[] bytes = new byte[hexStr.length() / 2];
            for (int n = 0; n < hexStr.length(); n += 2) {
                String item = hexStr.substring(n, n + 2);
                bytes[n / 2] = (byte) IntegerUtils.parseInt(item, 16, 1);
            }
            return bytes;
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Convert hex string to byte[]
     *
     * @param hexString the hex string
     * @return byte[]
     * @author lWX788624
     * @since 2019-10-08
     */
    public static byte[] hexString2ByteArray(String hexString) {
        try {
            if (StringUtils.isEmpty(hexString)) {
                return new byte[0];
            }
            hexString = hexString.toUpperCase(Locale.ENGLISH);
            int length = hexString.length() / 2;
            char[] hexChars = hexString.toCharArray();
            byte[] d = new byte[length];
            for (int i = 0; i < length; i++) {
                int pos = i * 2;
                d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
            }
            return d;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Convert char to byte
     *
     * @param c char
     * @return byte
     * @author lWX788624
     * @since 2019-10-08
     */
    private static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }

    /**
     * byteArray2HexString
     *
     * @param byteArray byte[]
     * @return String
     * @author z00502253
     * @since 2022-07-05
     */
    public static String byteArray2HexString(byte[] byteArray) {
        if (null == byteArray || 0 == byteArray.length) {
            return "";
        }
        final StringBuilder hex = new StringBuilder(2 * byteArray.length);
        for (final byte by : byteArray) {
            hex.append(HEX_CHAR_TABLE[(by & 0xF0) >> 4]).append(HEX_CHAR_TABLE[(by & 0x0F)]);
        }
        return hex.toString();
    }
}
