/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

/**
 * 功能描述
 *
 * @author z00502253
 * @since 2019-08-29
 */
public final class TimeKeys {

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final String YYYYMMDDHHMMSSSSS = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";

    public static final String YYYYMMDD_HH = "yyyy-MM-dd_HH";

    private TimeKeys() {

    }
}