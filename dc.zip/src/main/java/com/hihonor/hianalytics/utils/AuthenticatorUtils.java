/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.StatusLine;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Preconditions;
import com.hihonor.hianalytics.common.logs.PerfLogStatus;
import com.hihonor.hianalytics.common.logs.PerfLogUtils;
import com.hihonor.hianalytics.common.logs.inter.InterPerfLog;
import com.hihonor.hianalytics.common.logs.token.TokenErrorLog;
import com.hihonor.hianalytics.common.logs.token.TokenErrorLogItem;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.Result;
import org.springframework.stereotype.Component;

/**
 * The Class AuthenticatorUtils
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Component
public class AuthenticatorUtils {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(AuthenticatorUtils.class);

    /**
     * The Constant HTTP.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String HTTP = "http";

    /**
     * The Constant HTTPS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String HTTPS = "https";

    /**
     * The Constant SUPPORTED_PROTOCKO_LIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final List<String> supportedProtocolList =
        ServerConfig.getInstance().getAsStringList(ConfigKeys.CLIENTAUTH_SUPPORTED_PROTOCOLLIST);

    /**
     * 功能描述: AGC鉴权
     * 若网关返回200，表示token验证成功，返回token；否则返回null
     * 930还需要判断permission字段是否存在
     * 支持https http
     * @author z00502253
     * @since 2019-07-03
     */
    public static Result authRemotely(String clientId, String tokenToAuth, TokenErrorLogItem tokenErrorLogItem,
        String gatewayUrl) {
        InterPerfLog interLog = new InterPerfLog();
        interLog.setInterName("agcAuthRemotely");
        Result result = new Result();
        result.setErrInfo("success");
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = gatewayUrl.startsWith(HTTPS) ? null : HttpClients.createDefault();

        // https request
        httpClient = getCloseableHttpClient(gatewayUrl, httpClient);

        try {
            HttpGet get = getHttpGet(clientId, tokenToAuth, gatewayUrl);

            // 调用性能统计日志和错误日志
            long startTime = System.currentTimeMillis();
            interLog.setReqTime(System.currentTimeMillis());
            tokenErrorLogItem.setRequestTime(TimeUtils.getAsString(startTime));
            if (httpClient == null) {
                result.setErrInfo("HttpClient is null");
                return result;
            }
            response = httpClient.execute(get);
            if (response == null) {
                result.setErrInfo("CloseableHttpResponse is null");
                return result;
            }
            interLog.setRspTime(System.currentTimeMillis());
            tokenErrorLogItem.setCostTime(System.currentTimeMillis() - startTime);
            StatusLine statusLine = response.getStatusLine();
            Preconditions.checkNotNull(statusLine, "status line should not be null.");
            interLog.setRspStatus(statusLine.getStatusCode());
            tokenErrorLogItem.setReturnCode(String.valueOf(statusLine.getStatusCode()));
            tokenErrorLogItem.setAgcReason(String.valueOf(statusLine.getReasonPhrase()));
            if (statusLine.getStatusCode() == CommonUtils.SYSTEM_SUCCESS) {
                return getResult(tokenErrorLogItem, result, response);
            }
            if (statusLine.getStatusCode() == CommonUtils.NO_AUTHORIZATION) {
                tokenErrorLogItem.setReason("Authenticate to AGC is failed");
                logger.error("Authenticate to AGC is failed."); // 如果为401 鉴权失败 返回
                return result;
            }
            result.setRetCode(statusLine.getStatusCode());
            tokenErrorLogItem.setReason("The status of response from AGC is " + statusLine.getStatusCode());
            logger.error("The status of response from AGC is {}", statusLine.getStatusCode());
            result.setErrInfo("The status of response from AGC is " + statusLine.getStatusCode());
            return result;
        } catch (URISyntaxException | IOException e) {
            interLog.setRspStatus(PerfLogStatus.EXCEPTION_FAIL);
            logger.error("Exception is {}", e.getMessage());
            tokenErrorLogItem.setReason("Exception is " + e.getMessage());
            throw new DataCollectorException("Exception is " + e.getMessage());
        } finally {
            PerfLogUtils.logInterPerf(interLog);
            if (result.getObj() == null) {
                TokenErrorLog.print(tokenErrorLogItem);
            }

            // 关闭流
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    logger.error("Close response io is exception, the exception is {}", e.getMessage());
                }
            }
            if (httpClient != null) {
                try {
                    httpClient.close();
                } catch (IOException e) {
                    logger.error("Close httpClient io is exception, the exception is {}", e.getMessage());
                }
            }
        }
    }

    /**
     * getResult
     *
     * @param tokenErrorLogItem TokenErrorLogItem
     * @param result Result
     * @param response CloseableHttpResponse
     * @return vo
     * @author z00502253
     * @since 2022-08-23
     */
    private static Result getResult(TokenErrorLogItem tokenErrorLogItem, Result result,
        CloseableHttpResponse response) throws IOException {
        String entity = EntityUtils.toString(response.getEntity(), "UTF-8");
        JSONObject jsonObject = JSONObject.parseObject(entity);

        // 如果json对象为空，抛异常进行重试并打日志
        if (jsonObject == null) {
            logger.error("Request from AGC is failure,because jsonObject is null");
            throw new DataCollectorException("Request from AGC is failed,because jsonObject is null");
        }

        // accessToken为空 说明无法匹配 直接返回鉴权失败
        if (jsonObject.get("accessToken") == null) {
            logger.error(
                "Request from AGC is failure,clientid and token are not exist " +
                        "or match or Token from AGC is should not be null");
            return result;
        }
        String accessToken = jsonObject.getJSONObject("accessToken").get("access_token").toString();
        if (StringUtils.isEmpty(accessToken)) {
            logger.error(
                "Request from AGC is failure,clientid and token are not exist or match or " +
                        "Token from AGC is should not be null");
            return result;
        }
        // permissions is null
        JSONArray permissions = jsonObject.getJSONArray("permissions");
        if (permissions == null) {
            logger.error("Request from AGC is failure,because permissions is null");
            throw new DataCollectorException("Requet from AGC is failure,because permissions is null");
        }
        boolean isPermission =
            permissions.contains(ServerConfig.getInstance().getAsString("clientauth.agc.permission"));
        tokenErrorLogItem.setAgcAccessToken(accessToken);
        tokenErrorLogItem.setPermissions(permissions.toJSONString());
        if (isPermission) {
            result.setObj(accessToken); // 如果允许的话，才设置token对象，否则不设置走401的通道
            return result;
        }
        tokenErrorLogItem.setReason("Token permission is rejected");
        logger.error("The permission is rejected");
        return result;
    }

    /**
     * getCloseableHttpClient
     *
     * @param gatewayUrl String
     * @param httpClient CloseableHttpClient
     * @return CloseableHttpClient
     * @author z00502253
     * @since 2022-08-23
     */
    private static CloseableHttpClient getCloseableHttpClient(String gatewayUrl, CloseableHttpClient httpClient) {
        PoolingHttpClientConnectionManager connectionManager;
        if (gatewayUrl.startsWith(HTTPS)) {
            SSLConnectionSocketFactory sslsf = null;
            SSLContextBuilder builder = null;
            try {
                builder = new SSLContextBuilder();

                // 全部信任 不做身份鉴定
                builder.loadTrustMaterial(null, (TrustStrategy) (x509Certificates, s) -> true);

                // "SSLv2Hello", "SSLv3", "TLSv1", "TLSv1.2"
                String[] supportedProtocols =
                    CollectionUtils.isNotEmpty(supportedProtocolList) ? supportedProtocolList.toArray(new String[0])
                        : new String[] {"TLSv1.2"};
                sslsf = new SSLConnectionSocketFactory(builder.build(), supportedProtocols, null,
                    NoopHostnameVerifier.INSTANCE);

                Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory> create()
                        .register(HTTPS, sslsf)
                        .register(HTTP, new PlainConnectionSocketFactory())
                        .build();

                connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
                httpClient = HttpClients.custom().setConnectionManager(connectionManager).build();
            } catch (KeyManagementException e) {
                logger.error("https KeyManagementException is {}", e.getMessage());
            } catch (NoSuchAlgorithmException e) {
                logger.error("https NoSuchAlgorithmException is {}", e.getMessage());
            } catch (KeyStoreException e) {
                logger.error("https KeyStoreException is {}", e.getMessage());
            }
        }
        return httpClient;
    }

    /**
     * getHttpGet
     *
     * @param clientId String
     * @param tokenToAuth String
     * @return HttpGet
     * @author z00502253
     * @since 2022-08-23
     */
    private static HttpGet getHttpGet(String clientId, String tokenToAuth,
        String gatewayUrl) throws URISyntaxException {
        URI uri = new URIBuilder(gatewayUrl.trim()).build();
        HttpGet get = new HttpGet(uri);
        // 设置超时时间
        RequestConfig requestConfig = RequestConfig.custom()
            .setConnectTimeout(ServerConfig.getInstance().getAsInt("clientauth.connect.timeout", 1000))
            .setConnectionRequestTimeout(
                ServerConfig.getInstance().getAsInt("clientauth.connection.request.timeout", 1000))
            .setSocketTimeout(ServerConfig.getInstance().getAsInt("clientauth.socket.timeout", 1000))
            .build();
        get.setConfig(requestConfig);
        // 设置请求头
        get.setHeader("Authorization", "Bearer " + tokenToAuth);
        get.setHeader("client_id", clientId);
        return get;
    }
}
