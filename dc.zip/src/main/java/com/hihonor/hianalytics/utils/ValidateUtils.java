/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.HibernateValidator;

import com.hihonor.hianalytics.common.exception.HiAnalyticesException;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author l00534385
 * @since 2020-03-11
 */
@Component
public class ValidateUtils {

    /**
     * 开启快速结束模式 failFast (true)
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Validator FAIL_FAST_VALIDATOR = Validation.byProvider(HibernateValidator.class)
        .configure()
        .failFast(true)
        .buildValidatorFactory()
        .getValidator();

    /**
     * validate
     *
     * @param obj obj
     * @author z00502253
     * @since 2022-07-05
     */
    public static <T> void validate(T obj) {
        Set<ConstraintViolation<T>> violationSet = FAIL_FAST_VALIDATOR.validate(obj);
        boolean hasError = violationSet != null && violationSet.size() > 0;
        if (hasError) {
            for (ConstraintViolation<T> violation : violationSet) {
                // result.addError(violation.getPropertyPath().toString(), violation.getMessage());
                String message = violation.getMessage();
                if (StringUtils.isNotBlank(message)) {
                    message = message.replace("%value%", String.valueOf(violation.getInvalidValue()));
                }
                throw new HiAnalyticesException(message);
            }
        }
    }
}
