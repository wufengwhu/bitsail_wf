/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.hihonor.hianalytics.common.logs.LogCategory;
import com.hihonor.hianalytics.common.logs.alarm.AlarmInfo;
import org.springframework.stereotype.Component;

/**
 * 警告日志对外接口
 *
 * @author lWX788624
 * @since 2019-10-17
 */
@Component
public class AlarmLogUtils {

    /**
     * The Constant LOG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger LOG = LoggerFactory.getLogger(AlarmLogUtils.class);

    /**
     * The Constant ALARM_LOG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger ALARM_LOG = LoggerFactory.getLogger(LogCategory.ALARM_CATEGORY);

    /**
     * 告警产品
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String DATACOLLECT_PORT = "DT";

    /**
     * 告警手工清除
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String MANUAL_CLEAN = "ADMC";

    /**
     * 发送告警类型
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String ALARM_TYPE_SEND = "firing";

    /**
     * 清除告警类型
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String ALARM_TYPE_CLEAN = "resolved";

    /**
     * 本地主机hostname
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String hostName = null;

    /**
     * 发送告警
     *
     * @param alarmLevel 告警级别，枚举值
     * @param scope 告警发送领域列表
     * @param alarmDetail 告警详情
     * @return alarmId，告警发送时的唯一告警Id，在清除时使用此告警Id，进行告警的清除
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String sendAlarm(String alarmLevel, String[] scope, String[] alarmDetail) {
        if (StringUtils.isEmpty(alarmLevel) || scope == null || scope.length == 0 || alarmDetail == null
            || alarmDetail.length != 3) {
            LOG.error("Send alarm param is not valid.");
            return null;
        }
        AlarmInfo alarmInfo = new AlarmInfo();
        String alarmId = getAlarmId();
        alarmInfo.setId(alarmId);
        alarmInfo.setLevel(alarmLevel);
        alarmInfo.setAlarmDetail(alarmDetail);
        alarmInfo.setOp_type(ALARM_TYPE_SEND);
        alarmInfo.setScope(scope);

        logAlarm(alarmInfo);

        return alarmId;
    }

    /**
     * 清除告警
     *
     * @param alarmId 告警ID，和上报告警时保持一致
     * @param scope 告警恢复领域
     * @param alarmLevel 告警级别，和上报告警时保持一致
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void cleanAlarm(String alarmId, String[] scope, String alarmLevel) {
        if (StringUtils.isEmpty(alarmId) || scope == null || scope.length == 0 || StringUtils.isEmpty(alarmLevel)) {
            LOG.error("Clean alarm param is not valid.");
            return;
        }
        AlarmInfo alarmLog = new AlarmInfo();
        alarmLog.setId(alarmId);
        alarmLog.setLevel(alarmLevel);
        alarmLog.setOp_type(ALARM_TYPE_CLEAN);
        alarmLog.setScope(scope);
        logAlarm(alarmLog);
    }

    /**
     * 通用的告警日志，包含告警的发送和清除 通过设置告警对象的参数来实现不同级别，不同类型的告警的发送或清除。
     * 记录告警日志，后续此告警日志会被采集系统同步到WiseEye上
     *
     * @param alarmInfo alarmInfo
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void logAlarm(AlarmInfo alarmInfo) {
        if (alarmInfo == null || StringUtils.isEmpty(alarmInfo.getId()) || StringUtils.isEmpty(alarmInfo.getLevel())
            || StringUtils.isEmpty(alarmInfo.getOp_type())) {
            LOG.error("Alarm param is not valid.");
            return;
        }

        // 校验告警id为16位长度
        if (alarmInfo.getId().length() != 16) {
            LOG.error("AlarmId is not valid, must be 16 digit number.");
            return;
        }

        // 如果告警详情不为空，则必须要三位数组
        if (alarmInfo.getAlarmDetail() != null && alarmInfo.getAlarmDetail().length != 3) {
            LOG.error("Alarm details is not valid, must be 3 items.");
            return;
        }

        setDefaultValue(alarmInfo);
        setNotify(alarmInfo);
        convertAlarmLog(alarmInfo);

        String jsonStr = JSON.toJSONString(alarmInfo);

        // 创建路径
        ALARM_LOG.info(jsonStr);
    }

    /**
     * 获取唯一的告警Id，此告警Id针对一个告警，只能使用一次； 如果是告警和消除告警的话，需要严格保持一致 产生的告警Id格式为"Search_"
     * + 9位uuid前缀
     *
     * @author z00502253
     * @return String
     */
    private static String getAlarmId() {
        String uuid = UUID.randomUUID().toString().replace("-", "");
        String alarmId = null;
        if (uuid != null) {
            alarmId = DATACOLLECT_PORT + "_" + uuid.substring(0, 13);
        }
        return alarmId;
    }

    /**
     * 根据配置文件值，设置默认的告警通知相关字段值
     *
     * @author z00502253
     * @param alarmInfo alarmInfo
     */
    private static void setNotify(AlarmInfo alarmInfo) {
        // 告警领域如果为空，则默认获取配置项
        if (alarmInfo.getScope() == null || alarmInfo.getScope().length == 0) {
            String scope = "agcao";
            alarmInfo.setScope(new String[] {scope});
        }
    }

    /**
     * 将告警对象转化为满足告警日志格式要求的对象
     *
     * @author z00502253
     * @param alarmInfo alarmInfo
     */
    private static void convertAlarmLog(AlarmInfo alarmInfo) {
        // 将告警详细信息转为为String
        String[] alarmDetails = alarmInfo.getAlarmDetail();
        if (alarmDetails != null && alarmDetails.length == 3) {
            StringBuffer buf = new StringBuffer();
            buf.append("告警详情：").append(alarmDetails[0]).append("\n");
            buf.append("告警原因：").append(alarmDetails[1]).append("\n");
            buf.append("修复建议：").append(alarmDetails[2]);
            alarmInfo.setDetails(buf.toString());
        }
    }

    /**
     * 对于告警默认值进行缺省填充
     *
     * @param alarmInfo alarmInfo
     * @author lWX788624
     * @since 2019-10-08
     */
    private static void setDefaultValue(AlarmInfo alarmInfo) {
        // 告警产品

        alarmInfo.setName(DATACOLLECT_PORT);

        // 告警来源如果为空，则默认获取主机名
        if (StringUtils.isEmpty(alarmInfo.getSource_tag())) {
            String hostName1 = getHostName();
            alarmInfo.setSource_tag(hostName1);
        }

        // 告警清除类型如果为空，则默认为自动清除
        if (StringUtils.isEmpty(alarmInfo.getClear_type())) {
            alarmInfo.setClear_type(MANUAL_CLEAN);
        }

        // 设置默认产生时间为当前时间，不区分发送和清除
        if (alarmInfo.getStart_timestamp() == null) {
            alarmInfo.setStart_timestamp(new Date().getTime());
        }

        // 设置默认清除时间为当前时间，发送时为0；清除时为当前时间
        if (alarmInfo.getEnd_timestamp() == null) {
            // 发送告警时，清除时间设置为0
            if (ALARM_TYPE_SEND.equals(alarmInfo.getOp_type())) {
                alarmInfo.setEnd_timestamp(0L);
            } else {
                alarmInfo.setEnd_timestamp(new Date().getTime());
            }
        }
    }

    /**
     * 获取主机名，如果异常，则固定常量主机名
     *
     * @author z00502253
     * @return String
     */
    private static String getHostName() {
        if (hostName != null) {
            return hostName;
        }
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            hostName = inetAddress.getHostName();
        } catch (UnknownHostException unknownHostException) {
            LOG.error("Can not get hostname, error msg is {}", unknownHostException.getMessage());
            hostName = "UnknownHost";
        }
        return hostName;
    }

}
