/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import org.apache.commons.lang3.time.DateFormatUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 功能描述：时间工具类
 *
 * @author z00502253
 * @since 2019-08-29
 */
public abstract class TimeUtils {

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String getAsString(long time) {
        return DateFormatUtils.format(time, TimeKeys.YYYYMMDDHHMMSS);
    }

    public static String getLogTimeAsString(long time) {
        return DateFormatUtils.format(time, TimeKeys.YYYYMMDD_HH);
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String getAsString(Date date) {
        if (date == null) {
            date = new Date();
        }
        return DateFormatUtils.format(date, TimeKeys.YYYYMMDDHHMMSSSSS);
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static Date parseDate(String inputTime, String pattern) throws ParseException {
        // 初始化格式初始工具
        final DateFormat dateFormat = new SimpleDateFormat(pattern);
        // 格式化字符串
        return dateFormat.parse(inputTime);
    }
}
