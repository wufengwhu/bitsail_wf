/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The Class FileUtil.
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Component
public final class FileUtil {

    /**
     * The Constant FILEPAHT_PATTERN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Pattern FILEPAHT_PATTERN =
        Pattern.compile("(.*([/\\\\]{1}[\\.\\.]{1,2}|[\\.\\.]{1,2}[/\\\\]{1}|\\.\\.).*|\\.)");

    /**
     * The Constant PATH_WHITE_LIST.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String PATH_WHITE_LIST =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-=[];\\',./ ~!@#$%^&*()_+\"{}|:<>?";

    /**
     * Check file path.
     *
     * @param attributeFile the attribute file
     * @return the string
     * @throws IOException
     * Signals that an I/O exception has occurred.
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String checkFilePath(String attributeFile) throws IOException {
        String path = null;
        if (isSafePath(attributeFile)) {
            path = checkFile(attributeFile);
        } else {

            throw new IOException("Invalid file path");
        }

        return path;
    }

    /**
     * Checks if is safe path.
     *
     * @param filePath  the file path
     * @return true, if is safe path
     * @author lWX788624
     * @since 2019-10-08
     */
    public static boolean isSafePath(final String filePath) {
        Matcher matcher = FILEPAHT_PATTERN.matcher(filePath);
        boolean isSafe = !matcher.matches();
        return isSafe;
    }

    /**
     * Check file.
     *
     * @param filePath the file path
     * @return the string
     * @author lWX788624
     * @since 2019-10-08
     */
    private static String checkFile(final String filePath) {
        if (null == filePath) {
            return null;
        }

        final StringBuffer tmpStrBuf1 = new StringBuffer();
        for (int i = 0; i < filePath.length(); i++) {
            for (int j = 0; j < PATH_WHITE_LIST.length(); j++) {
                if (filePath.charAt(i) == PATH_WHITE_LIST.charAt(j)) {
                    tmpStrBuf1.append(PATH_WHITE_LIST.charAt(j));
                    break;
                }
            }
        }

        return tmpStrBuf1.toString();
    }

}
