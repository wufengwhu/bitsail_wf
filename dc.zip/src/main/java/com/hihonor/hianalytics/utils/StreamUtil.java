package com.hihonor.hianalytics.utils;


import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;


/**
 * @author w00027882
 */
@Slf4j
public final class StreamUtil {
    public static final String TAG = "StreamUtil";


    public static byte[] getBitZip(byte[] sourceArray) {
        byte[] returnByte = null;
        // Deflater 压缩
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Deflater deflater = new Deflater();
        deflater.setInput(sourceArray);
        deflater.finish();
        byte[] buff = new byte[1024];
        int byteNum = 0;
        while (!deflater.finished()) {
            byteNum = deflater.deflate(buff);
            out.write(buff, 0, byteNum);
        }
        returnByte = out.toByteArray();
        // 释放资源
        deflater.end();
        closeStream(out);
        return returnByte;
    }

    private static void closeStream(OutputStream os) {
        if (os != null) {
            try {
                os.close();
            } catch (IOException e) {
                log.error(TAG, "closeStream(): Exception: close OutputStream error!");
            }
        }
    }
}
