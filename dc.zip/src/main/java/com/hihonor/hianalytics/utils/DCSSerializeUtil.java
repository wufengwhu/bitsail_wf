/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hihonor.hianalytics.common.exception.HiAnalyticesException;

/**
 * dcs序列化工具类
 *
 * @author l00534385
 * @since 2020 -03-13
 */
public final class DCSSerializeUtil {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DCSSerializeUtil.class);

    /**
     * Instantiates a new serialize util.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private DCSSerializeUtil() {

    }

    /**
     * Serialize.
     *
     * @param object the object
     * @return the byte[]
     * @author lWX788624
     * @since 2019-10-08
     */
    public static byte[] serialize(Object object) {
        ObjectOutputStream oos = null;
        ByteArrayOutputStream baos = null;
        try {
            // 序列化
            baos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(baos);
            oos.writeObject(object);
            byte[] bytes = baos.toByteArray();
            return bytes;
        } catch (IOException e) {
            throw new HiAnalyticesException("SerializeUtilserializeIOException", e);
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException e) {
                    LOGGER.info("[Exception:]{}", e);
                }
            }
        }
    }

    /**
     * Unserialize.
     *
     * @param bytes the bytes
     * @return the object
     * @author lWX788624
     * @since 2019-10-08
     */
    public static Object unserialize(byte[] bytes) {
        ByteArrayInputStream bais = null;
        try {
            // 反序列化
            bais = new ByteArrayInputStream(bytes);
            ObjectInputStream ois = new ObjectInputStream(bais);
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new HiAnalyticesException("SerializeUtilUnserializeIOException", e);
        } finally {
            if (bais != null) {
                try {
                    bais.close();
                } catch (IOException e) {
                    LOGGER.info("[Exception:]{}", e);
                }
            }
        }
    }

}
