/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.InflaterOutputStream;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.DomainConfig;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.GetServerInfoResponse;
import org.springframework.stereotype.Component;

/**
 * The Class CommonUtils
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Component
public final class CommonUtils {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(CommonUtils.class);

    /**
     * 功能描述 decompress max length
     *
     * @author z00502253
     * @since 2019-11-21
     */
    private static final int DECOMPRESS_MAX_LENGTH =
        ServerConfig.getInstance().getAsInt(ConfigKeys.DECOMPRESS_MAX_LENGTH, 1024 * 1024);

    /**
     * 功能描述 Single compression maximum
     *
     * @author z00502253
     * @since 2019-11-21
     */
    private static final int SINGLE_DECOMPRESS_LENGTH =
        ServerConfig.getInstance().getAsInt(ConfigKeys.SINGLE_DECOMPRESS_LENGTH, 1024);

    /**
     * 功能描述 HEX_CHAR_TABLE
     *
     * @author z00502253
     * @since 2019-11-21
     */
    private static final char[] HEX_CHAR_TABLE =
        {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    private static Pattern redirectHostFormatPattern = null;

    /**
     * 功能描述 dmpDomainPattern
     *
     * @author z00502253
     * @since 2019-11-21
     */
    private static Pattern dmpDomainPattern = null;

    /**
     * 功能描述: redirectHostWhiteArr
     *
     * @author z00502253
     * @since 2019-11-21
     */
    private static String[] redirectHostWhiteArr;

    /**
     * 功能描述 cookie name
     *
     * @author z00502253
     * @since 2019-11-21
     */
    private static final String COOKIE_NAME = "_pk_hi_ssid";

    /**
     * 功能描述 lineBreakPattern
     *
     * @author z00502253
     * @since 2019-11-21
     */
    private static Pattern lineBreakPattern = null;

    /**
     * 功能描述  响应成功标识
     *
     * @author zw0042249
     * @since 2022-04-16
     */
    public static final int SYSTEM_SUCCESS = 200;

    /**
     * 功能描述  响应标识
     *
     * @author zw0042249
     * @since 2022-04-19
     */
    public static final String RESPONSE_CODE = "200002";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final int PARAMETER_INVALID = 400;

    /**
     * 功能描述 无权限
     *
     * @author z00502253
     * @since 2019-12-03
     */
    public static final int NO_AUTHORIZATION = 401;

    /**
     * 功能描述 参数为空
     *
     * @author z00502253
     * @since 2019-12-03
     */
    public static final int PARAMETER_EMPTY = 402;

    /**
     * 功能描述
     *
     * @author zw0042249
     * @since 2022-04-16
     */
    public static final int SYSTEM_AUTHEN = 403;

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final int NO_SERVICE_ID = 404;

    /**
     * 功能描述 上报数据长度超过限制大小
     *
     * @author zwx811366
     * @since 2019-01-06
     */
    public static final int REQUEST_CONTENT_INVALID = 413;


    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final int SYSTEM_ERROR = 500;

    /**
     * 功能描述 init初始化
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void init() {
        dmpDomainPattern = Pattern.compile(ServerConfig.getInstance().getAsString(ConfigKeys.VMALL_DMP_WHITELIST),
            Pattern.CASE_INSENSITIVE);
        String redirectHostWhiteList =
            ServerConfig.getInstance().getAsString(ConfigKeys.CLICK_REDIRECT_HOST_WHITELIST).substring(1,
                ServerConfig.getInstance().getAsString(ConfigKeys.CLICK_REDIRECT_HOST_WHITELIST).length() - 2);
        redirectHostWhiteArr = StringUtils.split(redirectHostWhiteList, "|");
        lineBreakPattern = Pattern.compile("\n|\r|%0D|%0d|%0A|%0a");
        redirectHostFormatPattern =
            Pattern.compile(ServerConfig.getInstance().getAsString(ConfigKeys.CLICK_REDIRECT_HOST_FORMAT),
                Pattern.CASE_INSENSITIVE);
    }

    /**
     * 解压缩数据
     *
     * @param compressData 待解压缩数据
     * @return 解压缩后数据
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String deCompress(byte[] compressData) throws DataCollectorException {
        if (null == compressData || compressData.length < 1) {
            logger.error("Decompress data is null.");
            return null;
        }
        ByteArrayOutputStream bos = null;
        InflaterOutputStream zos = null;
        try {
            bos = new ByteArrayOutputStream();
            zos = new InflaterOutputStream(bos);
            boolean inputFlag = true;
            int offset = 0;
            int len = CommonUtils.SINGLE_DECOMPRESS_LENGTH;
            while (inputFlag) {
                // less than minimum compression value
                if (compressData.length < len) {
                    zos.write(compressData);
                    logger.debug("Direct compressing,byte length is {}", compressData.length);
                    break;
                }
                zos.write(compressData, offset, len);
                offset += len;
                if ((offset + len) > compressData.length) {
                    len = compressData.length - offset;
                    zos.write(compressData, offset, len);
                    logger.debug("Last decompress length is {} and byte length is {}", len, bos.toByteArray().length);
                    break;
                }
                logger.debug("Decompress length is {} and byte length is {}", len, bos.toByteArray().length);
                if (bos.toByteArray().length > CommonUtils.DECOMPRESS_MAX_LENGTH) {
                    throw new DataCollectorException("ByteData after deCompress is too long");
                }
            }

            // Judging the length of the byteData that decompression has alreday finished
            logger.debug("The final byteData length after deCompress is {}", bos.toByteArray().length);
            // 这边会导致解压前的大小为1M之内，但是解压之后肯定大于1M，因此也会发生错误，因此可以写的大一些
            // hasdk有没有对上报上的大小做限定
            if (bos.toByteArray().length > CommonUtils.DECOMPRESS_MAX_LENGTH) {
                throw new DataCollectorException("The final byteData length after deCompress is too long");
            }
            return new String(bos.toByteArray(), "UTF-8");
        } catch (IOException e) {
            logger.error("Can't decompress data,exception is {}", e.getMessage());
            return null;
        } finally {
            if (null != zos) {
                try {
                    zos.close();
                } catch (IOException e) {
                    logger.error("Can't close InflaterOutputStream,exception is {}", e.getMessage());
                }
            }
            if (null != bos) {
                try {
                    bos.close();
                } catch (IOException e) {
                    logger.error("Can't close ByteArrayOutputStream,exception is {}", e.getMessage());
                }
            }
        }
    }

    /**
     * byte数组转16进制字符串
     *
     * @param b 待转换数据
     * @return 转换后16进制字符串
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String byteArray2HexString(byte[] b) {
        if (b == null) {
            logger.error("byteArray2HexString data is null.");
            return null;
        }
        final StringBuilder hex = new StringBuilder(2 * b.length);
        for (final byte by : b) {
            hex.append(HEX_CHAR_TABLE[(by & 0xF0) >> 4]).append(HEX_CHAR_TABLE[by & 0x0F]);
        }
        return  hex.toString();
    }

    /**
     * 16进制字符串转byte数组
     *
     * @param content 待转换数据
     * @return 转换后byte数组
     * @author lWX788624
     * @since 2019-10-08
     */
    public static byte[] hexString2ByteArray(String content) {
        if (StringUtils.isEmpty(content)) {
            logger.error("HexString2ByteArray data is null.");
            return new byte[0];
        }
        byte high;
        byte low;
        int len = content.length() / 2;
        byte[] bytes = new byte[len];
        for (int i = 0, k = 0; i < len; i++, k += 2) {
            high = (byte) (Character.digit(content.charAt(k), 16) & 0x0F);
            low = (byte) (Character.digit(content.charAt(k + 1), 16) & 0x0F);
            bytes[i] = (byte) ((high << 4) | low);
        }
        return bytes;
    }

    /**
     * 删掉正则匹配上的字符
     *
     * @param input 待转换字符串
     * @return 转换后字符串
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String delLineBreakChars(String input) {
        String dest = null;

        if (input != null) {
            Matcher mc = lineBreakPattern.matcher(input);
            dest = mc.replaceAll("");
        }

        return dest;
    }

    /**
     * 判断输入的字符串是否为DMP对接数据
     *
     * @param field 输入字符串
     * @return 匹配结果
     * @author lWX788624
     * @since 2019-10-08
     */
    public static boolean dmpChk(String field) {
        if (field == null) {
            return false;
        }

        Matcher matcher = dmpDomainPattern.matcher(field);
        return matcher.matches();
    }

    /**
     * 判断传入的多级域名对应的二级域名是否在白名单中
     *
     * @param urlHost   重定向URL对应的多级域名
     * @param whiteList 二级域名白名单
     * @return true or false
     * @author lWX788624
     * @since 2019-10-08
     */
    public static boolean isUrlHostWhiteList(String urlHost, String[] whiteList) {
        if (whiteList == null || whiteList.length == 0) {
            return true;
        }

        for (String item : whiteList) {
            if (StringUtils.equals(urlHost, item)) {
                return true;
            }
            if (StringUtils.endsWith(urlHost, item)) {
                try {
                    // 根据域名长度计算，截取域名前的字符串
                    String urlTmp = urlHost.substring(0, urlHost.length() - item.length());

                    // 过滤evilhihonor.com这种形式
                    if (!urlTmp.endsWith(".")) {
                        continue;
                    }

                    // 校验是否不包含特殊字符，如果不包含，则认为校验通过，如hihonor.hihonor.com，则校验通过，否则继续校验
                    String regularException = "^[A-Za-z0-9.-]+$";
                    boolean isVaild = urlTmp.matches(regularException);
                    if (isVaild) {
                        return true;
                    }
                } catch (Exception e) {
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * 判断输入的URL是否为可跳转的白名单URL
     *
     * @param redirectUrl 输入字符串
     * @return 匹配结果
     * @author lWX788624
     * @since 2019-10-08
     */
    public static boolean redirectUrlCheck(String redirectUrl) {
        if (StringUtils.isEmpty(redirectUrl)) {
            return false;
        }

        String uliHost = "";
        String newRedirectUrl = redirectUrl.replace("\\", "/");
        try {
            URI uri = new URI(newRedirectUrl);
            uliHost = uri.getHost();
        } catch (URISyntaxException e) {
            logger.error("Can not parse the redirect url,exception is {}", e.getMessage());
            return false;
        }

        return isUrlHostWhiteList(uliHost, redirectHostWhiteArr);
    }

    /**
     * 获取IP地址 通过用户请求报头获取用户IP地址
     *
     * @param request 请求
     * @return IP地址
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String getClientIp(HttpServletRequest request) {
        String[] proxyHeaderKeys = {"Proxy-Client-IP", "WL-Proxy-Client-IP", "http_client_ip", "HTTP_X_FORWARDED_FOR"};
        String clientIp = request.getHeader("x-forwarded-for");

        if (StringUtils.isEmpty(clientIp) || StringUtils.equalsIgnoreCase("unknown", clientIp)) {
            // proxyHeaderKeys
            for (String proxy : proxyHeaderKeys) {
                if (StringUtils.isNotEmpty(request.getHeader(proxy))) {
                    clientIp = request.getHeader(proxy);
                    break;
                }
            }
        }

        if (StringUtils.isEmpty(clientIp) || StringUtils.equalsIgnoreCase("unknown", clientIp)) {
            // todo 内网IP
            clientIp = request.getRemoteAddr();
        }

        // 如果是多级代理，那么取第一个ip为客户ip 114.xxxxx,192.168xxx
        if (StringUtils.isNotEmpty(clientIp) && StringUtils.indexOf(clientIp, ",") != -1) {
            // 测试时取第一个IP 原来是取最后一个 估计是只穿了一个IP
            clientIp = clientIp.split(",")[0];
            // StringUtils.substring(clientIp, StringUtils.lastIndexOf(clientIp, ",") + 1, clientIp.length()).trim();
        }
        return validateIp(clientIp);
    }

    /**
     * 判断IP是否合法
     *
     * @param ip IP地址
     * @return 是否IP地址
     * @author lWX788624
     * @since 2019-10-08
     */
    private static String validateIp(String ip) {
        if (ip == null) {
            return "";
        }
        ip = ip.trim();
        if (ip.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")) {
            String[] ips = ip.split("\\.");
            if (Integer.parseInt(ips[0]) < 255 && Integer.parseInt(ips[1]) < 255 && Integer.parseInt(ips[2]) < 255
                && Integer.parseInt(ips[3]) < 255) {
                return ip;
            }
        }
        return "";
    }

    /**
     * 获取cookie ID 如果已经存在cookie ID则直接获取，没有则生成一个新的cookie ID
     *
     * @param request  请求
     * @param response 响应
     * @return cookie ID
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String getCookieId(HttpServletRequest request, HttpServletResponse response) {
        String cookieId = "";
        boolean flag = false;

        Cookie[] cookies = request.getCookies();

        if (cookies != null && cookies.length > 0) {
            for (Cookie ck : cookies) {
                if (COOKIE_NAME.equalsIgnoreCase(ck.getName())) {
                    cookieId = ck.getValue();
                    flag = true;
                }
            }
        }

        if (!flag) {
            // aec-cbc加密
            cookieId = UUID.randomUUID().toString().replaceAll("-", "");
            // cookieId = MD5Util.MD5EncodeUtf8(UUID.randomUUID().toString().replaceAll("-", ""));
            Cookie cookie = new Cookie(COOKIE_NAME, cookieId);
            cookie.setSecure(true);
            cookie.setHttpOnly(true);
            cookie.setDomain(ServerConfig.getInstance().getAsString(ConfigKeys.MARKETING_WEB_DEFAULT_COOKIE_DOMAIN));
            cookie.setMaxAge(2 * 365 * 24 * 60 * 60);
            cookie.setPath("/");
            // 第三方cookie持久化必须遵循P3P简化隐私策略
            response.setHeader("P3P",
                "CP=\"NON DSP COR CURa ADMa DEVa TAIa PSAa PSDa IVAa IVDa CONa HISa TELa " +
                        "OTPa OUR UNRa IND UNI COM NAV INT DEM CNT PRE LOC\"");
            response.addCookie(cookie);
        }

        return cookieId;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static boolean isNull(String str) {
        return StringUtils.isEmpty(str) || StringUtils.equalsIgnoreCase("null", str);
    }

    /**
     * 功能描述 解析入参并查配置文件返回对应的url
     *
     * @param body     请求体
     * @param respData 返回对象
     * @param type     老接口 old 新接口 new
     * @author z00502253
     * @since 2019-07-04
     */
    public static void getServerDomain(String body, GetServerInfoResponse respData, String type) {
        String isoCode = null;
        String url = null;
        try {
            if (body.length() > 1024 * 4) {
                logger.error("/getServerInfo request parameters too long");
                respData.setResultcode("200001");
                return;
            }

            JSONObject jsonOjb = JSONObject.parseObject(body);
            isoCode = jsonOjb.getString("isoCode");

            if (CommonUtils.isNull(isoCode)) {
                logger.error("/getServerInfo parameter isoCode empty");
                respData.setResultcode("200001");
                return;
            }
            // 老接口返回首个域名
            if ("old".equals(type)) {
                String returnCode = DomainConfig.getInstance().getAsStringIgnoreCase(isoCode);
                if (CommonUtils.isNull(returnCode)) {
                    logger.error("/getServerInfo can't find url by isoCode: " + CommonUtils.delLineBreakChars(isoCode));
                    respData.setResultcode(RESPONSE_CODE);
                    return;
                }
                url = returnCode.split(",")[0];
                respData.setServerUrl(url);
                if (CommonUtils.isNull(url)) {
                    logger.error("/getServerInfo can't find url by isoCode: " + CommonUtils.delLineBreakChars(isoCode));
                    respData.setResultcode(RESPONSE_CODE);
                    return;
                }
            } else {
                // 新接口返回list
                String returnCode = DomainConfig.getInstance().getAsStringIgnoreCase(isoCode);
                if (CommonUtils.isNull(returnCode)) {
                    logger.error("/getServerInfo can't find url by isoCode: " + CommonUtils.delLineBreakChars(isoCode));
                    respData.setResultcode(RESPONSE_CODE);
                    return;
                }
                String[] urls = returnCode.split(",");
                if (urls.length > 0) {
                    respData.setServerUrls(Arrays.asList(urls));
                } else {
                    logger.error("/getServerInfo can't find urls by isoCode："
                            + CommonUtils.delLineBreakChars(isoCode));
                    respData.setResultcode(RESPONSE_CODE);
                    return;
                }
            }
            respData.setResultcode("0");
        } catch (JSONException e) {
            logger.error("Request data(getServerInfo) isn't JSONObject,exception is {}", e.getMessage());
            respData.setResultcode("200001");
        }
    }

    /**
     * 功能描述: 获取本机IP
     *
     * @author z00502253
     * @since 2020-02-03
     */
    public static String getLocalIp() {
        String localIp;
        try {
            localIp = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            logger.error("Can not get hostname, error msg is {}", e.getMessage());
            localIp = "UnknownIp";
        }
        return localIp;
    }
}
