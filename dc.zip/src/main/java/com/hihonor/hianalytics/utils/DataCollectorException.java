/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import org.springframework.stereotype.Component;

/**
 * 功能描述
 * 异常公共接口
 * @author z00502253
 * @since 2019-07-02
 */
@Component
public class DataCollectorException extends RuntimeException {

    /**
     * The Constant UID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = -2395958981285222493L;

    /**
     * 错误码
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String errorCode = null;

    public DataCollectorException(){}

    public DataCollectorException(String errorMsg) {
        super(errorMsg);
    }

    public DataCollectorException(String errorMsg, Throwable ex) {
        super(errorMsg, ex);
    }

    public DataCollectorException(String errorMsg, String errorCode) {
        super(errorMsg);
        this.errorCode = errorCode;
    }

    public DataCollectorException(String errorMsg, String errorCode, Throwable ex) {
        super(errorMsg, ex);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

}
