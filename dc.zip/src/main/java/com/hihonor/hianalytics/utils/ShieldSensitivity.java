/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.utils;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.serializer.ValueFilter;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;

/**
 * 功能描述
 *
 * @author z00502253
 * @since 2019-08-29
 */
public final class ShieldSensitivity {

    /**
     * The Constant FIXED_CHAR_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int FIXED_CHAR_LEN = 5;

    /**
     * The Constant HIDE_CHAR_FIXED.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String HIDE_CHAR_FIXED = "*****";

    /**
     * The Constant KEYS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static List<String> keys = ServerConfig.getInstance().getAsStringList(ConfigKeys.SENSTITIVE_KEYS_KEY);

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     * @author lWX788624
     * @since 2019-10-08
     */
    public static final ValueFilter valueFilter = new ValueFilter() {
        @Override
        public Object process(Object object, String name, Object value) {
            if (keys == null) {
                return value;
            }

            boolean need = false;
            for (String key : keys) {
                if (StringUtils.endsWithIgnoreCase(key, name)) {
                    need = true;
                    break;
                }
            }
            if (!need) {
                return value;
            }

            if (!(value instanceof String)) {
                return value;
            }

            return overlayWithStar(String.valueOf(value));
        }
    };

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     * @author lWX788624
     * @since 2019-10-08
     */
    public static String overlayWithStar(String value) {
        // 判断参数不能为空
        if (StringUtils.isEmpty(value)) {
            return value;
        }
        int reserveHeadLen = value.length() / 3;// 保留首尾，中间为*号，分三份
        int starsLen = value.length() - reserveHeadLen * 2;
        String stars = StringUtils.repeat("*", starsLen);
        return StringUtils.overlay(value, stars, reserveHeadLen, reserveHeadLen + starsLen);
    }
}
