/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.debugview;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * 功能描述 DebugView Kafka发送
 *
 * @author z00502253
 * @since 2019-09-18
 */

public class DebugKafkaProducer {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(DebugKafkaProducer.class);

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static DebugKafkaProducer INSTANCE = new DebugKafkaProducer();

    /**
     * The Constant ENABLED.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean enabled = false;

    /**
     * The Constant DEBUGVIEWPRODUCER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static KafkaProducer<String, String> debugViewProducer;

    /**
     * The Constant TOPIC.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String topic = ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_TOPIC);

    private DebugKafkaProducer() {
        String isKafkaEnabled = ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_USE);
        if (StringUtils.equalsIgnoreCase(isKafkaEnabled, "true")) {
            // 初始化Kafka的配置
            try {
//                DebugSecurityProducer.securityPrepare();
                debugViewProducer = DebugSecurityProducer.geSecurityProducer();
                enabled = true;
            } catch (Exception e) {
                logger.error("Failed to use SecurityProducer,exception is {}", e.getMessage());
            }
        }
    }

    /**
     * 功能描述 （饿汉式单例）构造方法
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static DebugKafkaProducer getInstance() {
        return INSTANCE;
    }

    private boolean isEnabled() {
        return enabled;
    }

    private void disable() {
        enabled = false;
    }

    /**
     * 发送Kafka消息
     * 930版本异步发送机制
     * <p>
     * 1130 kafka可靠性 稳定性 研究
     *
     * @param topic   主题
     * @param content 内容
     * @author z00502253
     * @since 2022-07-05
     */
    private void sendMessage(String topic, String handlerType, String content) {
        if (!enabled) {
            return;
        }
        // 默认轮询选择分区 =》org.apache.kafka.clients.producer.internals.DefaultPartitioner.partition
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, content);
        try {
//            debugViewProducer.send(record,
//                    new ProducerCallBack(System.currentTimeMillis()));
        } catch (Exception e) {
            logger.error("Failed to send message to debugview kafka,exception is {}", e.getMessage());
        }
    }

    /**
     * 发送数据
     *
     * @param entity      数据实体
     * @param handlerType 处理类型
     * @author z00502253
     * @since 2022-07-05
     */
    public void sendData(HiAnalyticsEntity entity, String handlerType) {
        String content = entity.getData();
        if (enabled) {
            try {
                DebugKafkaProducer.getInstance().sendMessage(topic, handlerType, content);
            } catch (Exception e) {
                DebugKafkaProducer.getInstance().disable();
                logger.error("Can't connect to debugView kafka server, exception is {}", e.getMessage());
            }
        }
    }
}
