/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.debugview;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import com.hihonor.hianalytics.vmall.security.KafkaLoginUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import org.springframework.stereotype.Component;

/**
 * 功能描述:DebugView Kafka 配置
 *
 * @author z00502253
 * @since 2019-09-20
 */
@Component
public class DebugSecurityProducer {

    /**
     * Broker地址列表.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static String BOOTSTRAP_SERVERS = "bootstrap.servers";

    /**
     * 客户端ID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static String CLIENT_ID = "client.id";

    /**
     * Key序列化类.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static String KEY_SERIALIZER = "key.serializer";

    /**
     * Value序列化类.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static String VALUE_SERIALIZER = "value.serializer";

    /**
     * 协议类型:当前支持配置为SASL_PLAINTEXT或者PLAINTEXT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static String SECURITY_PROTOCOL = "security.protocol";

    /**
     * 服务名.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static String SASL_KERBEROS_SERVICE_NAME = "sasl.kerberos.service.name";

    /**
     * 确认模式.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final static String ACKS = "acks";

    /**
     * The Constant ZOOKEEPER_SERVER_PRINCIPAL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String ZOOKEEPER_SERVER_PRINCIPAL = "zookeeper/hadoop.hadoop.com";

    /**
     * The Constant KERBEROS_DOMAIN_NAME.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String KERBEROS_DOMAIN_NAME = "kerberos.domain.name";

    /**
     * 异常（kafka出现异常 连接不上等）重试次数.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String RETRIES = "retries";

    /**
     * 用户自己申请的机机账号keytab文件名称.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String USER_KEY_TAB_FILE =
        ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_USER_KEYTAB_FILE);

    /**
     * 用户申请的krb5文件名称.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String KRB5_CONF_FILE =
        ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_KRB5_CONF_FILE);

    /**
     * 用户自己申请的机机账号名称.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String USER_PRINCIPAL =
        ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_USER_PRINCIPAL);

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static KafkaProducer<String, String> geSecurityProducer() {
        Properties props = new Properties();

        props.put(BOOTSTRAP_SERVERS,
            ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_BOOTSTRAP_SERVERS));
        // 客户端ID
        props.put(CLIENT_ID, ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_CLIENT_ID));
        // Key序列化类
        props.put(KEY_SERIALIZER, ServerConfig.getInstance()
                .getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_KEY_SERIALIZER));
        // Value序列化类
        props.put(VALUE_SERIALIZER,
            ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_KVALUE_SERIALIZER));
        // 协议类型:当前支持配置为SASL_PLAINTEXT或者PLAINTEXT
        props.put(SECURITY_PROTOCOL,
            ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_SECURITY_PROTOCOL));
        // 服务名
        props.put(SASL_KERBEROS_SERVICE_NAME,
            ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_SASL_KERBEROS_SERVICE_NAME));
        // 重试次数 默认重试3次
        props.put(RETRIES, ServerConfig.getInstance().getAsInt(ConfigKeys.DEBUGVIEW_FI_KAFKA_RETRIES,3));

        props.put(KERBEROS_DOMAIN_NAME,
            ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KERBEROS_DOMAIN_NAME));
        String acks = ServerConfig.getInstance().getAsString(ConfigKeys.DEBUGVIEW_FI_KAFKA_ACKS);
        if (StringUtils.isNotEmpty(acks)) {
            props.put(ACKS, acks);
        }

        return new KafkaProducer<>(props);
    }

    /**
     * 功能描述 加载安全配置
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void securityPrepare() throws IOException {
        URL url = ServerConfig.class.getResource("/");
        if (url == null) {
            return;
        }
        String filePath = url.getFile();
        // 鉴权文件
        String krbFile = filePath + KRB5_CONF_FILE;
        String userKeyTableFile = filePath + USER_KEY_TAB_FILE;

        // windows路径下分隔符替换
        userKeyTableFile = userKeyTableFile.replace("\\", "\\\\");
        krbFile = krbFile.replace("\\", "\\\\");

        KafkaLoginUtils.setKrb5Config(krbFile);
        KafkaLoginUtils.setZookeeperServerPrincipal(ZOOKEEPER_SERVER_PRINCIPAL);
        KafkaLoginUtils.setJaasFile(USER_PRINCIPAL, userKeyTableFile);
    }
}