/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.debugview;

import com.hihonor.hianalytics.common.logs.alarm.AlarmLevel;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.service.LogPersistent;
import com.hihonor.hianalytics.utils.AlarmLogUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaSendCallback;
import org.springframework.kafka.support.SendResult;

/**
 * 功能描述：kafka异步调用
 *
 * @author z00502253
 * @since 2019-10-23
 */

@Slf4j
@Data
public class ProducerCallBack implements KafkaSendCallback<String, String> {

    private HiAnalyticsEntity entity;

    public ProducerCallBack(HiAnalyticsEntity entity) {
        this.entity = entity;
    }

    @Override
    public void onFailure(KafkaProducerException e) {
        log.error("Failed send message to kafka, exception is {}", e.getMessage());
        // 内部会重试 需要配置下参数
        String[] alarmDetails = new String[]{"Send to kafka is failed ",
                "Maybe kafka cluster has exception.", "Please check service status and logs."};
        AlarmLogUtils.sendAlarm(AlarmLevel.MAJOR, new String[]{"agcao"}, alarmDetails);

        // 怎加异常持久化
        // TODO 当前仅针对加密数据异常持久化， 后续需要补充去加密的流程
        if (null != entity && entity.isEncrypt()) {
            LogPersistent logPersistent = LogPersistent.getInstance("kafka_send_failed");
            logPersistent.saveLog(entity);
        }
    }

    @Override
    public void onSuccess(SendResult<String, String> result) {
        RecordMetadata recordMetadata = result.getRecordMetadata();
        log.debug("message ,topic is {},offset is {}, partition is {},startTime is {}",
                recordMetadata.topic(),
                recordMetadata.offset(),
                recordMetadata.partition(),
                System.currentTimeMillis());
        // TODO 方便本地测试，成功发送也当作失败，异常持久化, 生产代码注释掉
        if (null != entity && entity.isEncrypt()) {
            LogPersistent logPersistent = LogPersistent.getInstance("kafka_send_failed");
            logPersistent.saveLog(entity);
        }
    }
}
