/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import ch.qos.logback.classic.AsyncAppender;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy;
import ch.qos.logback.core.util.FileSize;
import ch.qos.logback.core.util.OptionHelper;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;

/**
 * The Class LogbackLogBuilder
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Service
public class LogbackLogBuilder implements LogBuilder {

    /**
     * 数据采集路径
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public String LOG_FOLDER = "logfolder";

    /**
     * maxHistory
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final static int LOG_MAX_HISTORY_BY_HOUR = ServerConfig.getInstance()
            .getAsInt(ConfigKeys.INDEPENDENT_BUSINESS_LOG_HISTORY, 72);

    /**
     * maxFileSize
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final static String LOG_SIZE = ServerConfig.getInstance()
            .getAsString(ConfigKeys.INDEPENDENT_BUSINESS_LOG_SIZE);

    /**
     * Queue Size
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public final static int QUEUE_SIZE = ServerConfig.getInstance()
            .getAsInt(ConfigKeys.INDEPENDENT_BUSINESS_LOG_QUEUE_SIZE, 512);


    @Value("${independent.business.oper.decrypt.logfolder}")
    private String independentHioperqrtDecryptLogDir = "hioperqrt_decrypt";

    @Value("${independent.business.decrypt.logfolder}")
    private String independentHimaintqrtDecryptLogDir = "himaintqrt_decrypt";

    /**
     * 功能描述：修改为异步落盘，单独落盘logger
     * <p>
     * eg：com.hihonor.appmarket
     *
     * @author z00502253
     * @since 2019-12-02
     */
    @Override
    public Logger build(String directory, String name) {
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        String logName = getLoggerName(directory, name);
        ch.qos.logback.classic.Logger logger = context.getLogger(logName);
        String logSavePath = context.getProperty(LOG_FOLDER);
        logger.setAdditive(false);

        // 普通appender
        RollingFileAppender appender = new RollingFileAppender();
        appender.setContext(context);
        appender.setName(logName);
        String dataFolder;
        // 基于时间和大小 滚动策略
        SizeAndTimeBasedRollingPolicy policy = new SizeAndTimeBasedRollingPolicy();
        // 针对大S的做文件处理
        if (ServerConfig.getInstance().getAsString(ConfigKeys.LOGREPORT_LOGFOLDER,
                "logreport").equals(directory) && !"hmshimaintqrt".equals(name)) {
            appender.setFile(OptionHelper.substVars(
                    logSavePath + File.separator + logName + "logs" + File.separator + "v1_logreport.log",
                    context));
            dataFolder = OptionHelper.substVars(logSavePath + File.separator + logName + "logs" + File.separator
                    + "v1_logreport" + "_%d{yyyy-MM-dd_HH}.%i.log", context);
            policy.setFileNamePattern(dataFolder);
        }

        if (ServerConfig.getInstance().getAsString(ConfigKeys.INDEPENDENT_BUSINESS_LOGFOLDER,
                "hmshimaintqrt").equals(name)
                || ServerConfig.getInstance().getAsString(ConfigKeys.INDEPENDENT_BUSINESS_LOGFOLDER_ADD,
                "himaintqrt").equals(name)) {
            appender.setFile(OptionHelper.substVars(
                    logSavePath + File.separator + logName + "logs" + File.separator + "v1_"
                            + name + "server24_13.log", context));
            dataFolder = OptionHelper.substVars(logSavePath + File.separator + logName + "logs"
                    + File.separator + "v1_" + name + "server24_13_%d{yyyy-MM-dd_HH}.%i.log", context);
            policy.setFileNamePattern(dataFolder);
        }

        // add by w00027882，增加独立业务运营数据的单独落盘
        if (ServerConfig.getInstance().getAsString(ConfigKeys.INDEPENDENT_BUSINESS_OPER_LOGFOLDER,
                "hmshioperqrt").equals(name)
                || ServerConfig.getInstance().getAsString(ConfigKeys.INDEPENDENT_BUSINESS_OPER_LOGFOLDER_ADD,
                "hioperqrt").equals(name)) {
            appender.setFile(OptionHelper.substVars(
                    logSavePath + File.separator + logName + "logs" + File.separator + "v1_"
                            + name + "server24_13.log", context));
            dataFolder = OptionHelper.substVars(logSavePath + File.separator + logName + "logs"
                    + File.separator + "v1_" + name + "server24_13_%d{yyyy-MM-dd_HH}.%i.log", context);
            policy.setFileNamePattern(dataFolder);
        }

        // add by w00027882 增加独立业务去加密数据的落盘目录 eg: name=hioperqrt_decrypt
        if (independentHioperqrtDecryptLogDir.equalsIgnoreCase(name)
                || independentHimaintqrtDecryptLogDir.equalsIgnoreCase(name)) {
            appender.setFile(OptionHelper.substVars(
                    logSavePath + File.separator + logName + "logs" + File.separator + "v1_"
                            + name + "server24_13.log", context));
            dataFolder = OptionHelper.substVars(logSavePath + File.separator + logName + "logs"
                    + File.separator + "v1_" + name + "server24_13_%d{yyyy-MM-dd_HH}.%i.log", context);
            policy.setFileNamePattern(dataFolder);
        }

        policy.setMaxHistory(LOG_MAX_HISTORY_BY_HOUR);
        if (StringUtils.isNotEmpty(LOG_SIZE)) {
            policy.setMaxFileSize(FileSize.valueOf(LOG_SIZE));
        } else {
            policy.setMaxFileSize(new FileSize(300 * 1024 * 1024));
        }
        policy.setParent(appender);
        policy.setContext(context);
        policy.start();

        // 输出日志内容
        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(context);
        encoder.setPattern("%msg%n");
        encoder.start();

        appender.setRollingPolicy(policy);
        appender.setEncoder(encoder);
        appender.start();

        // 异步asyncAppender 队列大小512 不丢失日志 添加附加的appender
        AsyncAppender asyncAppender = new AsyncAppender();
        asyncAppender.setQueueSize(QUEUE_SIZE);
        asyncAppender.setDiscardingThreshold(0);
        // 设置非阻塞 阻塞队列使用offer
        asyncAppender.setContext(context);
        asyncAppender.addAppender(appender);
        asyncAppender.start();

        // logger.addAppender(appender);
        // 每一个节点都需要.start()，才能加入到这个类拼凑出来的格式中。
        logger.addAppender(asyncAppender);
        logger.setLevel(Level.INFO);
        return logger;
    }

    /**
     * 功能描述 构建logger name
     *
     * @author z00502253
     * @since 2019-12-03
     */
    private String getLoggerName(String directory, String name) {
        if (StringUtils.isEmpty(directory)) {
            return name;
        } else {
            return directory + File.separator + name;
        }
    }

    /**
     * 功能描述 构建ch.qos.logback.classic.Logger
     *
     * @author z00502253
     * @since 2019-12-03
     */
    @Override
    public Logger build(String name) {
        return build(StringUtils.EMPTY, name);
    }
}
