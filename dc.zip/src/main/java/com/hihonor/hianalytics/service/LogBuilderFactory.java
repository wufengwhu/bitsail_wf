/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import org.springframework.stereotype.Component;

/**
 * The Class LogBuilderFactory
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Component
public class LogBuilderFactory {

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */


    public static LogBuilder getLogBuilder() {
        return new LogbackLogBuilder();
    }
}
