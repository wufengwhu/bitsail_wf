/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import static java.lang.Long.parseLong;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import org.springframework.stereotype.Service;

/**
 * The Class PerformanceMonitor
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Service
public class PerformanceMonitor {

    /**
     * The Constant COUNT_INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static PerformanceMonitor countInstance = new PerformanceMonitor();

    /**
     * The Constant THREADFACTORY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private ThreadFactory threadFactory =
        new ThreadFactoryBuilder().setNameFormat("logs-count-monitor").setDaemon(true).build();

    /**
     * The Constant SERVICE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor(threadFactory);

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static PerformanceMonitor getInstance() {
        return countInstance;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public void start() {
        // 每一分钟去触发一次 接口请求与日志数量统计写入日志
        service.scheduleAtFixedRate(new CountMonitorRunnable(),
            60,
            parseLong(ServerConfig.getInstance().getAsString(ConfigKeys.PERF_MONITOR_INTERVAL)),
            TimeUnit.SECONDS);
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public void stop() {
        service.shutdown();
    }

    private static class CountMonitorRunnable implements Runnable {

        @Override
        public void run() {
            Request2LogCounter.print();
        }
    }

}
