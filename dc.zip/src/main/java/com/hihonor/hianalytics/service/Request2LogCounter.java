/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import java.util.Calendar;
import java.util.Map;
import java.util.TreeMap;

import com.alibaba.fastjson.JSON;
import com.google.common.util.concurrent.AtomicLongMap;
import org.springframework.stereotype.Service;

/**
 * The Class Request2LogCounter
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Service
public class Request2LogCounter {

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static Request2LogCounter INSTANCE = new Request2LogCounter();

    /**
     * The Constant COUNT_CONTAINER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static AtomicLongMap<String> countContainer = AtomicLongMap.create();

    private Request2LogCounter() {

    }

    public static Request2LogCounter getInstance() {
        return INSTANCE;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void count(String name) {
        countContainer.incrementAndGet(name);
    }

    /**
     * 接口请求与日志数量统计写入日志
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void print() {
        Map<String, Long> logCountMap = new TreeMap<>();
        for (String key : countContainer.asMap().keySet()) {
            long quantity = countContainer.getAndUpdate(key, (x) -> 0L);
            logCountMap.put(key, quantity);
        }
        long serverTime = Calendar.getInstance().getTimeInMillis();
        String jsonStr = JSON.toJSONString(logCountMap);
        String value = jsonStr + "\001" + serverTime;
        LoggerContainer.getInstance().getLogger("perfmonitor").info(value);
    }
}