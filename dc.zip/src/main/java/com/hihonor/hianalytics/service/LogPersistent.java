/*
 * Copyright (c) hihonor Technoies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.entity.SearchEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Slf4j
@Service
public final class LogPersistent {

    /**
     * The Constant HANDLER_TYPE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String handlerType;

    /**
     * 日志持久化实例Map.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static Map<String, LogPersistent> defaultLoggerPersistentMap = new ConcurrentHashMap<>();

    /**
     * 自定义日志持久化实例map.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static Map<String, LogPersistent> extendLoggerPersistentMap = new ConcurrentHashMap<>();

    /**
     * The Constant PERSISTENT_SUFFIX.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String PERSISTENT_SUFFIX = "-Persistent";

    /**
     * The Constant ISSUPPORTBATCHUPLOAD.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final boolean ISSUPPORTBATCHUPLOAD =
            "true".equals(ServerConfig.getInstance()
                    .getAsString(ConfigKeys.LOGREPORT_SUPPORTED_BATCHUPLOAD));

    /**
     * The Constant SPLILT_001.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String SPLILT_001 = "\001";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void init() {
        List<String> defaultBusinessLoggers =
                ServerConfig.getInstance().getAsStringList(ConfigKeys.DEFAULT_BUSINESS_LOGGERS);

        if (CollectionUtils.isEmpty(defaultBusinessLoggers)) {
            log.error("No default business loggers config");
            return;
        }
        for (String logger : defaultBusinessLoggers) {
            int index = logger.indexOf("common");
            // 以common开头的logger
            if (index == -1) {
                continue;
            }
            String name = logger.substring(index + 6);
            try {
                int i1 = Integer.parseInt(name);
                if (i1 > 0 && i1 < 41) {
                    LoggerContainer.getInstance().getLogger("common" + i1);
                    extendLoggerPersistentMap.put(logger, new LogPersistent(logger));
                }

            } catch (Exception e) {
                log.error("Invalid logger config for {},exception is {}", logger, e.getMessage());
            }
            break;
        }
    }

    public LogPersistent() {
    }

    /**
     * 日志持久化构造函数，初始化日志存储路径及日志文件名格式。
     */
    public LogPersistent(String handlerType) {
        this.handlerType = handlerType;
    }

    /**
     * 获取日志持久化实例 通过日志处理方式枚举对象获取日志持久化实例。
     *
     * @param handlerType 日志处理方式枚举对象
     * @return 日志持久化实例
     * @author lWX788624
     * @since 2019-10-08
     */
    public static LogPersistent getInstance(String handlerType) {
        LogPersistent logPersistent;
        if (StringUtils.contains(handlerType, "common")) {
            logPersistent = extendLoggerPersistentMap.get(handlerType);
            if (logPersistent == null) {
                logPersistent = new LogPersistent(handlerType);
                extendLoggerPersistentMap.put(handlerType, logPersistent);
            }
        } else {
            logPersistent = defaultLoggerPersistentMap.get(handlerType);
            if (logPersistent == null) {
                logPersistent = new LogPersistent(handlerType);
                defaultLoggerPersistentMap.put(handlerType, logPersistent);
            }

        }
        return logPersistent;
    }


    /**
     * 功能描述：数据落盘
     *
     * @author z00502253
     * @since 2019-10-08
     */
    public void doSave(HiAnalyticsEntity entity) {
        String content = entity.getData().replaceAll("\\s*|\t|\r|\n", "");
        String loggerName;
        List<String> independentBusinessAppIdList =
                ServerConfig.getInstance().getAsStringList(ConfigKeys.INDEPENDENT_BUSINESS_APPID_LIST);
        if (CollectionUtils.isEmpty(independentBusinessAppIdList)) {
            independentBusinessAppIdList = new ArrayList<>();
        }

        List<String> independentBusinessInterfaceList =
                ServerConfig.getInstance().getAsStringList(ConfigKeys.INDEPENDENT_BUSINESS_INTERFACE_LIST);
        if (CollectionUtils.isEmpty(independentBusinessInterfaceList)) {
            independentBusinessInterfaceList = new ArrayList<>();
        }

        // 单独落盘接口,且app-id在白名单内
        if (independentBusinessAppIdList.contains(entity.getAppId())
                && independentBusinessInterfaceList.contains(entity.getUrlPath())) {
            loggerName = entity.getAppId() + File.separator + handlerType;
        } else {
            loggerName = handlerType;
        }
        // 在default名单（logback.xml），非单独落盘落盘
        LoggerContainer.getInstance().getLogger(loggerName).info(content);
        String interfaceName = loggerName.substring(loggerName.lastIndexOf(File.separator) + 1);
        Request2LogCounter.count(interfaceName + PERSISTENT_SUFFIX);
    }

    /**
     * 把日志追加到日志文件
     *
     * @param entity 数据实体
     * @return 日志追加是否成功
     * @author lWX788624
     * @since 2019-10-08
     */
    public boolean saveLog(HiAnalyticsEntity entity) {
        doSave(entity);
        return true;
    }

    /**
     * saveSearchLog
     *
     * @param searchEntity vo
     * @return boolean
     * @author z00502253
     * @since 2022-07-04
     */
    public boolean saveSearchLog(SearchEntity searchEntity) {
        String content;
        String loggerName;
        // 大S 三方数据上报
        loggerName = ServerConfig.getInstance().getAsString(ConfigKeys.LOGREPORT_LOGFOLDER,
                "logreport") + File.separator + searchEntity.getAppId();
        // 批量数据上报
        if (ISSUPPORTBATCHUPLOAD) {
            // 数据凭接与落盘
            for (String item : searchEntity.getMegs()) {
                content = searchEntity.getServerTime() + SPLILT_001 + searchEntity.getAppId() + SPLILT_001
                        + searchEntity.getLogType() + SPLILT_001 + searchEntity.getRequestId() + SPLILT_001
                        + searchEntity.getIp() + SPLILT_001 + item;
                // 数据落盘
                LoggerContainer.getInstance().getLogger(loggerName).info(content);
            }
        } else {
            content = searchEntity.getData();
            LoggerContainer.getInstance().getLogger(loggerName).info(content);
        }
        String interfaceName = loggerName.substring(loggerName.lastIndexOf(File.separator) + 1);
        Request2LogCounter.count(interfaceName + PERSISTENT_SUFFIX);
        return true;
    }


}