/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.DateUtils;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

/**
 * The Class TriggerLoggingTimer
 *
 * @author z00502253
 * @since 2022-08-24
 */
public class TriggerLoggingTimer {

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static TriggerLoggingTimer instance = new TriggerLoggingTimer();

    /**
     * The Constant THREAD_FACTORY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private ThreadFactory threadFactory =
        new ThreadFactoryBuilder().setNameFormat("trigger-logging-timer").setDaemon(true).build();

    /**
     * The Constant EXECUTORS.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private ScheduledExecutorService executors = Executors.newSingleThreadScheduledExecutor(threadFactory);

    public static TriggerLoggingTimer getInstance() {
        return instance;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public void start() {
        Date now = new Date();
        Date nextHour = DateUtils.ceiling(now, Calendar.HOUR);
        executors.scheduleAtFixedRate(new TriggerLoggingRunnable(),
            nextHour.getTime() - now.getTime(),
            1000 * 60 * 60,
            TimeUnit.MILLISECONDS);
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public void stop() {
        executors.shutdown();
    }

    /**
     * 功能描述 每一分钟绕接一次 防止小时文件不生成
     *
     * @author z00502253
     * @since 2019-12-04
     */
    private static class TriggerLoggingRunnable implements Runnable {

        @Override
        public void run() {
            LoggerContainer.getInstance().triggerRolling();
        }
    }
}
