/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Class LoggerContainer
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Service
@Slf4j
public class LoggerContainer {

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static LoggerContainer INSTANCE = new LoggerContainer();

    /**
     * The Constant CONTAINER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private final Map<String, Logger> container = new HashMap<>();

    /**
     * The Constant SLASH.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String SLASH = "/";

    /**
     * 功能描述 饿汉单例模式
     * 设置默认的分盘
     * 设置公共的分盘（common1~40）
     * 设置单独落盘（com.hihonor.appmarket）
     *
     * @author z00502253
     * @since 2019-12-03
     */
    private LoggerContainer() {
        buildDefaultLogger();
        buildCommonLogger();
        buildAppLogger();
    }

    public static LoggerContainer getInstance() {
        return INSTANCE;
    }

    /**
     * 功能描述 构造分业务落盘的文件
     *
     * @author z00502253
     * @since 2019-12-03
     */
    private void buildAppLogger() {
        List<String> independentBusinessAppIdList =
                ServerConfig.getInstance().getAsStringList(ConfigKeys.INDEPENDENT_BUSINESS_APPID_LIST);

        List<String> independentBusinessInterfaceList =
                ServerConfig.getInstance().getAsStringList(ConfigKeys.INDEPENDENT_BUSINESS_INTERFACE_LIST);
        // 预置单独生成的日志文件
        if (CollectionUtils.isEmpty(independentBusinessAppIdList)) {
            log.warn("IndependentBusinessAppIdList is empty,please check it!");
            return;
        }

        // 接口列表
        if (CollectionUtils.isEmpty(independentBusinessInterfaceList)) {
            log.error("IndependentBusinessInterfaceList is empty,please check it!");
            return;
        }
        // 单独生成的那些文件 里面都有independent.business.interfaceList配置的文件夹
        for (String appId : independentBusinessAppIdList) {
            for (String separateLogInterface : independentBusinessInterfaceList) {
                if (StringUtils.isEmpty(separateLogInterface)) {
                    continue;
                }

                String name = separateLogInterface;
                int index = separateLogInterface.lastIndexOf(SLASH);
                if (index != -1) {
                    name = separateLogInterface.substring(index + 1);
                }
                getLogger(appId + File.separator + name);
            }
        }
    }

    /**
     * 功能描述 自定义 common1-40
     *
     * @author z00502253
     * @since 2019-12-03
     */
    private void buildCommonLogger() {
        // common1-40个自定义日志
        for (int i = 1; i <= 40; i++) {
            container.put("common" + i, LoggerFactory.getLogger("common" + i));
        }
    }

    /**
     * 功能描述 构建默认的logger
     *
     * @author z00502253
     * @since 2019-12-03
     */
    private void buildDefaultLogger() {
        // 接口日志写入实例
        Logger sdkLogger = LoggerFactory.getLogger("sdk");
        container.put("sdkv1", sdkLogger);

        Logger sdkv2Logger = LoggerFactory.getLogger("sdkv2");
        container.put("sdkv2", sdkv2Logger);

        Logger sdkv3Logger = LoggerFactory.getLogger("sdkv3");
        container.put("sdkv3", sdkv3Logger);

        Logger webLogger = LoggerFactory.getLogger("web");
        container.put("webv1", webLogger);

        Logger webv2Logger = LoggerFactory.getLogger("webv2");
        container.put("webv2", webv2Logger);

        Logger dmpLogger = LoggerFactory.getLogger("dmp");
        container.put("dmp", dmpLogger);

        Logger magicLogger = LoggerFactory.getLogger("magicv1");
        container.put("magicv1", magicLogger);

        Logger magicv2Logger = LoggerFactory.getLogger("magicv2");
        container.put("magicv2", magicv2Logger);

        Logger clickLogger = LoggerFactory.getLogger("click");
        container.put("clickv1", clickLogger);

        Logger exposurev1Logger = LoggerFactory.getLogger("exposure");
        container.put("exposurev1", exposurev1Logger);

        Logger hmshioperrtLogger = LoggerFactory.getLogger("hmshioperrt");
        container.put("hmshioperrt", hmshioperrtLogger);

        Logger hmshioperqrtLogger = LoggerFactory.getLogger("hmshioperqrt");
        container.put("hmshioperqrt", hmshioperqrtLogger);

        Logger hmshioperbatchLogger = LoggerFactory.getLogger("hmshioperbatch");
        container.put("hmshioperbatch", hmshioperbatchLogger);

        Logger hmshimaintrtLogger = LoggerFactory.getLogger("hmshimaintrt");
        container.put("hmshimaintrt", hmshimaintrtLogger);

        Logger hmshimaintqrtLogger = LoggerFactory.getLogger("hmshimaintqrt");
        container.put("hmshimaintqrt", hmshimaintqrtLogger);

        Logger hmshimaintbatchLogger = LoggerFactory.getLogger("hmshimaintbatch");
        container.put("hmshimaintbatch", hmshimaintbatchLogger);

        Logger hioperrtLogger = LoggerFactory.getLogger("hioperrt");
        container.put("hioperrt", hioperrtLogger);

        Logger hioperqrtLogger = LoggerFactory.getLogger("hioperqrt");
        container.put("hioperqrt", hioperqrtLogger);

        // add by w00027882
        Logger hioperqrtDecryptLogger = LoggerFactory.getLogger("hioperqrt_decrypt");
        container.put("hioperqrt_decrypt", hioperqrtDecryptLogger);

        // add by w00027882 at 20230628
        Logger kafkaSendFailedLogger = LoggerFactory.getLogger("kafka_send_failed");
        container.put("kafka_send_failed", kafkaSendFailedLogger);

        Logger hioperbatchLogger = LoggerFactory.getLogger("hioperbatch");
        container.put("hioperbatch", hioperbatchLogger);

        Logger himaintrtLogger = LoggerFactory.getLogger("himaintrt");
        container.put("himaintrt", himaintrtLogger);

        Logger himaintqrtLogger = LoggerFactory.getLogger("himaintqrt");
        container.put("himaintqrt", himaintqrtLogger);

        // add by w00027882
        Logger himaintqrtDecryptLogger = LoggerFactory.getLogger("himaintqrt_decrypt");
        container.put("himaintqrt_decrypt", himaintqrtDecryptLogger);

        Logger himaintbatchLogger = LoggerFactory.getLogger("himaintbatch");
        container.put("himaintbatch", himaintbatchLogger);

        Logger perfmonitorLogger = LoggerFactory.getLogger("perfmonitor");
        container.put("perfmonitor", perfmonitorLogger);

        Logger crashv1Logger = LoggerFactory.getLogger("crashv1");
        container.put("crashv1", crashv1Logger);

        Logger defaultLogger = LoggerFactory.getLogger(LoggerContainer.class);
        container.put("default", defaultLogger);
    }

    /**
     * 功能描述：获取对应的logger对象
     *
     * @param name com.hihonor.appmarket
     * @author z00502253
     * @since 2019-08-08
     */
    public Logger getLogger(String name) {
        Logger logger = container.get(name);
        if (logger != null) {
            return logger;
        }
        synchronized (LoggerContainer.class) {
            logger = container.get(name);
            if (logger != null) {
                return logger;
            }
            // 判断是不是 需要单独落盘的  logreport/a123dsdsaxd
            int index = name.indexOf(File.separator);
            if (index == -1) {
                logger = LogBuilderFactory.getLogBuilder().build(name);
            } else {
                // 单独落盘的
                String directory = name.substring(0, index);
                String logName = name.substring(index + 1);
                logger = LogBuilderFactory.getLogBuilder().build(directory, logName);
            }
            container.put(name, logger);
        }
        return logger;
    }

    /**
     * 所有logger写入空值，强制绕接
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public synchronized void triggerRolling() {
        buildAppLogger();
        for (Map.Entry<String, Logger> entry : container.entrySet()) {
            Logger logger = entry.getValue();
            logger.info("");
        }
    }
}
