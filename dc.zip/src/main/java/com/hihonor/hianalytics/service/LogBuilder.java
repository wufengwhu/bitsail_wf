/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.service;

import org.slf4j.Logger;

/**
 * The interface LogBuilder
 *
 * @author z00502253
 * @since 2022-08-24
 */
public interface LogBuilder {

    /**
     * 功能描述
     *
     * @param directory directory
     * @param logName logName
     * @return void
     */
    Logger build(String directory, String logName);

    /**
     * 功能描述
     *
     * @param logName logName
     * @return void
     * @author z00502253
     * @since 2019-12-02
     */
    Logger build(String logName);

}
