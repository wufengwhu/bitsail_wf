package com.hihonor.hianalytics.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author w00027882
 */
@Service
@Slf4j
public class CallbackTaskServiceImpl implements CallbackTaskService {

    @Resource(name = "encryptKafkaTemplate")
    private KafkaTemplate<String, String> encryptKafkaTemplate;

    @Value("${kafka.producer.encrypt.topic}")
    private String encryptTopicName;

    @Override
    public void sendRetry(String message) {
        encryptKafkaTemplate.send(encryptTopicName, message);
    }
}
