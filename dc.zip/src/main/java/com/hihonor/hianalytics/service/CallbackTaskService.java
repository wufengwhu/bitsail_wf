package com.hihonor.hianalytics.service;

/**
 * @author w00027882
 */
public interface CallbackTaskService {
    /**
     * 异常持久化的日志，重新再发送kafka
     *
     * @param data
     */
    void sendRetry(String data);
}
