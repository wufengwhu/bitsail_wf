/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.vmall;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hihonor.hianalytics.vmall.security.SecurityProducer;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.filter.Filter;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;

/**
 * The Class FiKafkaProducer
 *
 * @author z00502253
 * @since 2022-08-29
 */
public class FiKafkaProducer {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(FiKafkaProducer.class);

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static FiKafkaProducer INSTANCE = new FiKafkaProducer();

    /**
     * The Constant ENABLED.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private boolean enabled = false;

    /**
     * The Constant FIPRODUCER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static KafkaProducer<Integer, String> fiProducer;

    /**
     * The Constant FILERMAP.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static Map<String, ArrayList<Filter>> filterMap;

    private FiKafkaProducer() {
        String isKafkaEnabled = ServerConfig.getInstance().getAsString(ConfigKeys.VMALL_FI_KAFKA_USE);
        if (StringUtils.equalsIgnoreCase(isKafkaEnabled, "true")) {
            // 初始化Kafka的配置
            try {
                SecurityProducer.securityPrepare();
                fiProducer = SecurityProducer.geSecurityProducer();
            } catch (Exception e) {
                logger.error("Failed to use SecurityProducer,exception is {}", e.getMessage());
            }
            enabled = true;

            // 初始化Filters
            initFilters();
        }

    }

    public static FiKafkaProducer getInstance() {
        return INSTANCE;
    }

    private boolean isEnabled() {
        return enabled;
    }

    private void disable() {
        enabled = false;
    }

    /**
     * 发送Kafka消息
     *
     * @param topic 主题
     * @param content 内容
     * @author lWX788624
     * @since 2019-10-08
     */
    private synchronized void sendMessage(String topic, String content) {
        if (!enabled) {
            return;
        }
        // 构造消息记录
        ProducerRecord<Integer, String> record = new ProducerRecord<>(topic, 0, content);
        try {
            fiProducer.send(record).get();
        } catch (Exception e) {
            logger.error("Failed to send message to vmall kafka,exception is {}", e.getMessage());
        }
    }

    /**
     * 初始化过滤器
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private static void initFilters() {
        filterMap = new HashMap<>();
        String flows = ServerConfig.getInstance().getAsString("vmall.FI.kafka.flows");
        if (StringUtils.isNotEmpty(flows)) {
            for (String flow : flows.split(",")) {
                if (StringUtils.isNotEmpty(flow)) {
                    Filter filter = null;
                    String handleType =
                        ServerConfig.getInstance().getAsString("vmall.FI.kafka." + flow + ".handlertype");
                    String className =
                        ServerConfig.getInstance().getAsString("vmall.FI.kafka." + flow + ".filter.class");

                    if (StringUtils.isEmpty(handleType)) {
                        logger.error("HandlerType must be set");
                        continue;
                    }
                    if (StringUtils.isEmpty(className)) {
                        logger.error("ClassName must be set");
                        continue;
                    }

                    try {
                        Constructor<?> c = Class.forName(className).getConstructor(String.class);
                        filter = (Filter) c.newInstance(flow);
                    } catch (Exception e) {
                        logger.error("Init vmall kafka filters failed,exception is {}", e.getMessage());
                    }

                    // 如果配置项有问题，则返回。
                    if (null == filter || !filter.checkParam()) {
                        logger.error("Init vmall kafka filters failed");
                        continue;
                    }

                    ArrayList<Filter> value = filterMap.get(handleType.toUpperCase());
                    ArrayList<Filter> list = (null == value) ? new ArrayList<>() : value;
                    list.add(filter);
                    filterMap.put(handleType.toUpperCase(), list);
                }
            }
        }
    }

    /**
     * 发送数据
     *
     * @param entity 数据实体
     * @param handlerType 处理类型
     * @author lWX788624
     * @since 2019-10-08
     */
    public void sendData(HiAnalyticsEntity entity, String handlerType) {
        String content = entity.getData();
        if (FiKafkaProducer.getInstance().isEnabled()) {
            List<Filter> filters = filterMap.get(handlerType.toUpperCase());
            if (null == filters) {
                return;
            }
            try {
                sendData(content, filters);
            } catch (Exception e) {
                FiKafkaProducer.getInstance().disable();
                logger.error("Can't connect to vamll kafka server,stop send data,exception is {}", e.getMessage());
            }
        }
    }

    /**
     * sendData
     *
     * @param content String
     * @param filters List<Filter>
     * @author z00502253
     * @since 2022-08-23
     */
    private void sendData(String content, List<Filter> filters) {
        for (Filter filter : filters) {
            if (filter.contains(content)) {
                FiKafkaProducer.getInstance().sendMessage(filter.getTopic(), content);
            }
        }
    }
}
