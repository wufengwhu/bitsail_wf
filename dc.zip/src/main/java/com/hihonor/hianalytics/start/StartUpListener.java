/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.start;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.hihonor.hianalytics.service.LogPersistent;
import com.hihonor.hianalytics.service.PerformanceMonitor;
import com.hihonor.hianalytics.service.TriggerLoggingTimer;
import com.hihonor.hianalytics.utils.CommonUtils;
import com.hihonor.hianalytics.utils.EncryptUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import com.hihonor.hianalytics.config.ConfigFileMonitor;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.common.logs.SysInfoCollectorStartup;

/**
 * The Class StartUpListener
 *
 * @author z00502253
 * @since 2022-08-24
 */
@WebListener
@Slf4j
public class StartUpListener implements ServletContextListener {

    /**
     * contextInitialized
     *
     * @param event event
     * @author z00502253
     * @since 2022-07-05
     */
    @Override
    public void contextInitialized(ServletContextEvent event) {
        log.info("StartUpListener: begin contextInitialized");
        EncryptUtils.init();
        CommonUtils.init();
        LogPersistent.init();

        // 启动触发绕接定时器
        if (StringUtils.equalsIgnoreCase(ServerConfig.getInstance().getAsString(ConfigKeys.LOG_AUTO_ROLLING_SWITCH),
            "on")) {
            TriggerLoggingTimer.getInstance().start();
        }
        // 上报告警模块
        sendAlarm();

        // 启动请求日志打印监控
        PerformanceMonitor.getInstance().start();

        // 启动配置文件监控
        ConfigFileMonitor.getConfigInstance().start();
        log.info("StartUpListener: success contextInitialized");
    }

    /**
     * sendAlarm
     *
     * @author z00502253
     * @since 2022-08-19
     */
    private void sendAlarm() {
        // 内存达到70%后，上报告警
        SysInfoCollectorStartup.getInstance().startup();
    }

    /**
     * contextDestroyed
     *
     * @param event event
     * @author z00502253
     * @since 2022-07-05
     */
    @Override
    public void contextDestroyed(ServletContextEvent event) {

        if (StringUtils.equalsIgnoreCase(ServerConfig.getInstance().getAsString(ConfigKeys.LOG_AUTO_ROLLING_SWITCH),
            "on")) {
            TriggerLoggingTimer.getInstance().stop();
            SysInfoCollectorStartup.getInstance().stop();
        }
        PerformanceMonitor.getInstance().stop();

        if (ConfigFileMonitor.getConfigInstance() != null) {
            ConfigFileMonitor.getConfigInstance().stop();
        }
    }
}
