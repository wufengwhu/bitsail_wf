package com.hihonor.hianalytics.start;

import com.hihonor.hianalytics.common.logs.SysInfoCollectorStartup;
import com.hihonor.hianalytics.config.ConfigFileMonitor;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.service.PerformanceMonitor;
import com.hihonor.hianalytics.service.TriggerLoggingTimer;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStoppedEvent;
import org.springframework.stereotype.Component;

/**
 * @author w00027882
 */
@Component
@Slf4j
public class StopApplicationListener implements ApplicationListener<ContextStoppedEvent> {

    @Override
    public void onApplicationEvent(ContextStoppedEvent event) {
        if (StringUtils.equalsIgnoreCase(ServerConfig.getInstance().getAsString(ConfigKeys.LOG_AUTO_ROLLING_SWITCH),
                "on")) {
            TriggerLoggingTimer.getInstance().stop();
            SysInfoCollectorStartup.getInstance().stop();
        }
        PerformanceMonitor.getInstance().stop();

        if (ConfigFileMonitor.getConfigInstance() != null) {
            ConfigFileMonitor.getConfigInstance().stop();
        }
    }
}
