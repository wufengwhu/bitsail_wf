/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.start;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hihonor.hianalytics.service.Request2LogCounter;
import com.hihonor.hianalytics.utils.ClientAuthenticator;
import com.hihonor.hianalytics.utils.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.hihonor.hianalytics.common.logs.token.TokenErrorLogItem;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;

/**
 * The Class RequestMonitorFilter
 *
 * @author z00502253
 * @since 2022-08-24
 */
@Slf4j
@WebFilter(urlPatterns = "/*", filterName = "InterfaceFilter", asyncSupported = true)
public class RequestMonitorFilter implements Filter {

    /**
     * The Constant REQUEST_SUFFIX.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String REQUEST_SUFFIX = "-Request";

    /**
     * The Constant IMPORT_USER_URL.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String IMPORT_USER_URL = "/analytics/datacollection/import/user";

    /**
     * 性能监控的接口列表
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> perfMonitorInterfaceList =
        ServerConfig.getInstance().getAsStringList(ConfigKeys.PERF_MONITOR_INTERFACE_LIST);

    @Override
    public void init(FilterConfig filterConfig) {

    }

    /**
     * doFilter
     *
     * @param request request
     * @param response response
     * @param chain chain
     * @author z00502253
     * @since 2022-07-05
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        // 存在URI绕过的问题
        String uri = httpServletRequest.getRequestURI();
        String interfaceName = uri.substring(uri.lastIndexOf("/") + 1);
        boolean agcWhiteFlag = false; // token鉴权白名单标识

        // 限制http request content长度，防止DOS攻击
        if (request.getContentLength() > ServerConfig.getInstance().getAsInt("http.content.length",
                3) * 1024 * 1024) {
            log.error("Http request content length too long");
            httpServletResponse.sendError(CommonUtils.REQUEST_CONTENT_INVALID,
                    "Http request content length too long.");
            return;
        }

        // 使用白名单过滤请求，防止攻击
        if (!StringUtils.equals(interfaceName, "sdkv2") && CollectionUtils.isNotEmpty(perfMonitorInterfaceList)
            && perfMonitorInterfaceList.contains(interfaceName)) {
            Request2LogCounter.count(interfaceName + REQUEST_SUFFIX);
        }

        // 当前版本对用户属性同步接口放通token校验，该接口通过白名单方式进行校验，其他接口保持不变
        if (!IMPORT_USER_URL.equalsIgnoreCase(uri)) {
            // token鉴权
            if (authTokenMethod(httpServletRequest, httpServletResponse, agcWhiteFlag)) {
                return;
            }
        }
        // debug部署模式下，消息头里需要x-hasdk-debug:true
        if ("true".equals(ServerConfig.getInstance().getAsString("debug.deploy"))) {
            String debugHeader = httpServletRequest.getHeader("x-hasdk-realtime");
            if (StringUtils.isEmpty(debugHeader) || !"true".equals(debugHeader)) {
                log.error("debug header must exist and be true in debug deployment.");
                httpServletResponse.sendError(CommonUtils.PARAMETER_INVALID,
                        "debug header must exist and be true.");
                return;
            }
        }
        chain.doFilter(request, response);
    }

    /**
     * authTokenMethod
     *
     * @param httpServletRequest HttpServletRequest
     * @param httpServletResponse HttpServletResponse
     * @return boolean
     * @author z00502253
     * @since 2022-08-19
     */
    private boolean authTokenMethod(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
        boolean agcWhiteFlag) throws IOException {
        if ("true".equals(ServerConfig.getInstance().getAsString("clientauth.enable"))) {

            // appId在白名单内，无需进行token鉴权
            String appId = httpServletRequest.getHeader("App-Id");
            if ("true".equals(ServerConfig.getInstance().getAsString("agc.business.appidList.switch"))) {

                // 获取token鉴权白名单列表
                List<String> agcBusinessAppidList =
                    ServerConfig.getInstance().getAsStringList("agc.business.appidList");
                if (StringUtils.isNotEmpty(appId) && CollectionUtils.isNotEmpty(agcBusinessAppidList)
                    && agcBusinessAppidList.contains(appId)) {
                    agcWhiteFlag = true;
                }
            }

            // 需要进行token鉴权
            if (!agcWhiteFlag) {
                String token = httpServletRequest.getHeader("x-hasdk-token");
                String clientId = httpServletRequest.getHeader("x-hasdk-clientid");
                if (CommonUtils.isNull(clientId) || CommonUtils.isNull(token)) {
                    log.error("Failed authenticate,because token or client_id is null.");
                    httpServletResponse.sendError(CommonUtils.PARAMETER_EMPTY, "token or client_id is null.");
                    return true;
                }

                // 先从本地缓存中去获取，失败则去远端鉴权
                TokenErrorLogItem tokenErrorLogItem = new TokenErrorLogItem(appId, clientId);
                tokenErrorLogItem.setRequestAccessToken(token);
                tokenErrorLogItem.setProductId(httpServletRequest.getHeader("x-hasdk-productid"));
                ClientAuthenticator.getInstance().authToken(clientId, token, tokenErrorLogItem, httpServletResponse);
                if (httpServletResponse.getStatus() != CommonUtils.SYSTEM_SUCCESS) {
                    log.error("Authenticate fail");
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void destroy() {

    }
}
