/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.AsyncContext;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.handle.CrashV1Handler;
import com.hihonor.hianalytics.handle.Handler;
import com.hihonor.hianalytics.handle.HandlerFactory;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.utils.CommonUtils;

/**
 * 功能描述:Crash日志采集上报接口
 *
 * @author zWX811366
 * @since 2019-11-25
 */
@WebServlet(name = "HiCrashV1", urlPatterns = "/v1/crashlogs/*", asyncSupported = true)
public class HiCrashV1Servlet extends HttpServlet {

    /**
     * The Constant serialVersionUID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = 7116541534058573028L;

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiCrashV1Servlet.class);

    /**
     * The Constant MAX_DATA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_DATA_LEN =
            ServerConfig.getInstance().getAsInt(ConfigKeys.CRASH_MAX_LENGTH, 1048576);

    /**
     * debug view 开关.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static boolean debugDeploy = "true".equals(ServerConfig.getInstance().getAsString("debug.deploy"));

    /**
     * 字节缓冲区大小 4096.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int BUFFER_SIZE = 4096;

    /**
     * doPost
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @author z00502253
     * @since 2022-08-23
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
        try {
            if (req.getContentLength() <= 0 || StringUtils.isEmpty(req.getHeader("content-length"))) {
                logger.error("/crash {} Upload data is empty,please check it.", req.getHeader("App-Id"));
                resp.sendError(CommonUtils.PARAMETER_INVALID, "content is empty");
                return;
            }
            // 对上报数据进行大小校验（20191126：暂不对必传入参作校验）
            if (req.getContentLength() > MAX_DATA_LEN) {
                logger.error("/crashv1 upload data too long");
                resp.sendError(CommonUtils.REQUEST_CONTENT_INVALID, "Upload data is too long");
                return;
            }
            // 获取字节输入流对象并注册事件监听器
            final ServletInputStream inputStream = req.getInputStream();
            inputStream.setReadListener(new HiCrashV1Servlet.CrashServletReadListener(inputStream, req));
        } catch (IOException e) {
            logger.error("/crashv1 get upload data failed:{}", e.getMessage());
            sendError(resp);
        }
    }

    /**
     * sendError
     *
     * @param resp resp
     * @author z00502253
     * @since 2022-08-18
     */
    private static void sendError(HttpServletResponse resp) {
        try {
            resp.sendError(CommonUtils.PARAMETER_INVALID, "System error");
        } catch (IOException e) {
            logger.error("/crashv1 send response failed:{}", e.getMessage());
        }
    }

    /**
     * CrashServletReadListener
     *
     * @author z00502253
     * @since 2022-08-18
     */
    private static class CrashServletReadListener implements HiServletReadListener {
        private byte[] buffer = new byte[BUFFER_SIZE];
        private ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        private final ServletInputStream inputStream;
        private final AsyncContext asyncContext;
        private final HttpServletRequest request;

        public CrashServletReadListener(ServletInputStream inputStream, HttpServletRequest request) {
            this.inputStream = inputStream;
            asyncContext = request.startAsync();
            this.request = request;
        }

        /**
         * onDataAvailable
         *
         * @author z00502253
         * @since 2022-08-23
         */
        @Override
        public void onDataAvailable() {
            try {
                do {
                    // 从缓存中读取字节流中的数据，并以整数形式返回实际读取的字节数
                    int length = inputStream.read(buffer);
                    outputStream.write(buffer, 0, length);
                    // 检查数据可以被读取而不会阻塞
                } while (inputStream.isReady());
            } catch (IOException e) {
                logger.error("/crashv1 get upload data failed: {}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
                asyncContext.complete();
            }
        }

        /**
         * onAllDataRead
         *
         * @author z00502253
         * @since 2022-08-23
         */
        @Override
        public void onAllDataRead() {
            try {
                Handler handler = HandlerFactory.createHandler(CrashV1Handler.class, debugDeploy);
                handler.setIp(CommonUtils.getClientIp(request));
                handler.setServerTime(System.currentTimeMillis());
                handler.setSequence();
                // 处理上报日志
                boolean result =
                        handler.doHandle(new HiAnalyticsEntity(CommonUtils
                                .byteArray2HexString(outputStream.toByteArray()),
                                request.getHeader("App-Id"), request.getRequestURI()));
                if (!result) {
                    logger.error("/crashv1 data format not match");
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                            "Invalid request");
                }
            } catch (IOException e) {
                logger.error("/crashv1 send response failed:{}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
            }
            asyncContext.complete();
        }

        /**
         * onError
         *
         * @param throwable Throwable
         * @author z00502253
         * @since 2022-08-23
         */
        @Override
        public void onError(Throwable throwable) {
            logger.error("/crashv1 on error is {}", throwable.getMessage());
            sendError((HttpServletResponse) asyncContext.getResponse());
            asyncContext.complete();
        }
    }
}
