/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hihonor.hianalytics.handle.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.entity.WebV1Model;
import com.hihonor.hianalytics.utils.CommonUtils;

/**
 * 功能描述 JSSDK请求处理器
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@WebServlet(name = "HiWebV1", urlPatterns = "/webv1/*", asyncSupported = true)
public class HiWebV1Servlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiWebV1Servlet.class);

    /**
     * The Constant SERIALVERSIONUID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = 4975942175338755471L;

    /**
     * The Constant MAX_DATA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_DATA_LEN = ServerConfig.getInstance()
            .getAsInt(ConfigKeys.WEB_MAX_LENGTH, 1024 * 1024);

    /**
     * The Constant DEBUGDEPLOY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static boolean debugDeploy = "true".equals(ServerConfig.getInstance().getAsString("debug.deploy"));

    /**
     * doPost
     *
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @author z00502253
     * @since 2022-08-19
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        // post请求则需要处理浏览器跨域问题 测试时设置开关
        if (request.getMethod().equals("POST")) {
            setResponseAccess(response);
            try {
                request.setCharacterEncoding("UTF-8");
            } catch (Exception e) {
                logger.error("web setCharacterEncoding is error,error is {}", e);
            }
        }
        doGet(request, response);
    }

    /**
     * 处理客户端的请求信息。
     *
     * @param request  请求
     * @param response 响应
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        if (request.getMethod().equals("GET")) {
            response.setHeader("Access-Control-Allow-Origin", "*");
        }
        try {
            if (validateRequestInfo(request, response)) {
                return;
            }
            WebV1Model webV1Model = getWebV1Model(request, response);
            if (webV1Model == null) {
                return;
            }
            Handler handler = HandlerFactory.createHandler(WebV1Handler.class, debugDeploy);
            handler.setSequence();
            boolean result = handler.doHandle(
                new HiAnalyticsEntity(webV1Model.toString(),
                        request.getHeader("App-Id"), request.getRequestURI()));
            if (!result) {
                try {
                    logger.error("/web save data failed.");
                    response.sendError(CommonUtils.SYSTEM_ERROR, "System error");
                } catch (IOException e) {
                    logger.error("/web send response failed,exception is {}", e.getMessage());
                }
                return;
            }
            if (CommonUtils.dmpChk(webV1Model.getIdsite())
                && ServerConfig.getInstance().getAsString("vmall.dmp.type").contains(webV1Model.getTypeId())) {
                handler.setHandlerTypeEnum(HandlerTypeEnum.DMP);
                try {
                    handler.doHandle(new HiAnalyticsEntity(JSONObject.toJSONString(BeanUtils.describe(webV1Model)),
                        request.getHeader("App-Id"), request.getRequestURI()));
                } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                    logger.error("/web send rsponse failed,exception is {}", e.getMessage());
                }
            }
        } catch (IOException e) {
            logger.error("/web send response failed");
        }
    }

    /**
     * 功能描述 获取web接口数据，生成WebV1Model模型
     *
     * @author z00502253
     * @since 2019-11-08
     */
    private WebV1Model getWebV1Model(HttpServletRequest request, HttpServletResponse response) throws IOException {
        WebV1Model webV1Model = new WebV1Model();
        webV1Model.setSid(CommonUtils.getCookieId(request, response));

        // 请求中必须包含的请求参数
        String[] args = {"idsite", "url", "_id", "_idts", "_idvc"};

        // 设置数据 校验参数
        if (!webV1Model.setData(request.getParameterMap(), webV1Model, args, true)
                || !webV1Model.chkClientTime() || !webV1Model.chkData()) {
            logger.error("/web request don't contains must params");
            response.sendError(CommonUtils.PARAMETER_INVALID, "Invalid request");
            return null;
        }

        webV1Model.setIp(CommonUtils.getClientIp(request));
        webV1Model.setLanguage(request.getHeader("Accept-Language"));
        String ua = request.getHeader("user-agent");
        webV1Model.setUa(ua != null && ua.length() > 2048 ? ua.substring(0, 2048) : ua);
        Date date = new Date();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        webV1Model.setServerts(sf.format(date));
        return webV1Model;
    }

    /**
     * 功能描述 校验request 请求参数
     *
     * @author z00502253
     * @since 2019-11-08
     */
    private boolean validateRequestInfo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (StringUtils.length(request.getQueryString()) > MAX_DATA_LEN) {
            logger.error("/web upload data too long");
            response.sendError(CommonUtils.REQUEST_CONTENT_INVALID, "Upload data too long");
            return true;
        }

        if (request.getParameterMap() == null) {
            logger.error("/web request has no parameters");
            response.sendError(CommonUtils.PARAMETER_INVALID, "Invalid request");
            return true;
        }
        return false;
    }

    /**
     * 功能描述 解决跨域问题
     *
     * @author z00502253
     * @since 2019-11-08
     */
    private void setResponseAccess(HttpServletResponse response) {
        // 允许该域发起跨域请求
        response.setHeader("Access-Control-Allow-Origin",
                ServerConfig.getInstance().getAsString(ConfigKeys.JSSDK_ACCESS_CONTROL_ALLOW_ORIGIN));
        // 允许的外域请求方式
        response.setHeader("Access-Control-Allow-Methods",
                ServerConfig.getInstance().getAsString(ConfigKeys.JSSDK_ACCESS_CONTROL_ALLOW_METHODS));
        // 在999999秒内不需要再发送预检验请求，可以缓存该结果
        response.setHeader("Access-Control-Max-Age",
                ServerConfig.getInstance().getAsString(ConfigKeys.JSSDK_ACCESS_CONTROL_MAX_AGE));
        // 允许跨域请求包含某请求头,x-requested-with请求头为异步请求
        if (StringUtils.isEmpty(ServerConfig.getInstance()
                .getAsString(ConfigKeys.JSSDK_ACCESS_CONTROL_ALLOW_HEADERS))) {
            response.setHeader("Access-Control-Allow-Headers",
                    ServerConfig.getInstance().getAsString(ConfigKeys.JSSDK_ACCESS_CONTROL_ALLOW_HEADERS));
        }
    }
}
