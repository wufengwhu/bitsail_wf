/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.hihonor.hianalytics.common.exception.HiAnalyticesException;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.handle.dataimport.DataImportHander;
import com.hihonor.hianalytics.handle.dataimport.entity.DataImportEntity;
import com.hihonor.hianalytics.utils.CommonUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.AsyncContext;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019 -10-08
 */
@WebServlet(name = "HiDataImportV1", urlPatterns = "/analytics/datacollection/import/user", asyncSupported = true)
public class HiDataImportV1Servlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiDataImportV1Servlet.class);

    /**
     * 参数错误响应码
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String INVALIDPARAMETER_CODE = "10020";

    /**
     * 系统错误
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String SYSTEM_ERROR_CODE = "19999";

    /**
     * 处理客户端的请求信息。
     *
     * @param req      请求
     * @param response 响应
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse response) {
        try {
            // ip白名单鉴权只有主动设置为false时，才跳过ip白名单鉴权
            if (!"false".equalsIgnoreCase(
                    ServerConfig.getInstance().getAsString(ConfigKeys.ANALYTICS_GATEWAY_IP_AUTH_ENABLE))) {
                // 增加ip白名单鉴权，IP从X-Forwarded-For字段获取，该字段由网关清理后重新设置，外部请求统一从apigw
                List<String> ipWhiteList =
                        ServerConfig.getInstance().getAsStringList(ConfigKeys.ANALYTICS_GATEWAY_IP_WHITELIST);
                // 获取网关地址
                String gatewayIP = req.getHeader("x-forwarded-for");
                if (StringUtils.isNotBlank(gatewayIP)) {
                    gatewayIP = gatewayIP.contains(",") ? gatewayIP.split(",")[0] : gatewayIP;
                }
                if (!ipWhiteList.contains(gatewayIP)) {
                    logger.error("client ip not on white list");
                    sendValidateError(response, "client ip not on white list");
                    return;
                }
            }
            final ServletInputStream inputStream = req.getInputStream();
            inputStream.setReadListener(new DataImportV1ServletReadListener(inputStream, req));
        } catch (IOException e) {
            logger.error("/data/import get data failed, exception is {}", e.getMessage());
            sendError(response);
        }
    }

    /**
     * sendError
     *
     * @param resp    resp
     * @param retCode int
     * @param msg     msg
     * @author z00502253
     * @since 2022-08-18
     */
    private static void sendError(HttpServletResponse resp, int retCode, Result msg) {
        try {
            resp.addHeader("Content-Type", "application/json; charset=UTF-8");
            resp.setStatus(retCode);
            resp.getOutputStream().write(JSON.toJSONString(msg).getBytes("UTF-8"));
        } catch (IOException e) {
            logger.error("/data/import send response failed, exception is {}", e.getMessage());
        }
    }

    /**
     * sendSuccess
     *
     * @param resp resp
     * @author z00502253
     * @since 2022-08-18
     */
    private static void sendSuccess(HttpServletResponse resp) {
        try {
            resp.addHeader("Content-Type", "application/json; charset=UTF-8");
            resp.getOutputStream().write(JSON.toJSONString(new Result()).getBytes("UTF-8"));
        } catch (IOException e) {
            logger.error("/data/import send response failed, exception is {}", e.getMessage());
        }
    }

    /**
     * sendValidateError
     *
     * @param resp resp
     * @param msg  msg
     * @author z00502253
     * @since 2022-08-18
     */
    private static void sendValidateError(HttpServletResponse resp, String msg) {
        Result result = new Result(INVALIDPARAMETER_CODE, msg);
        sendError(resp, CommonUtils.PARAMETER_INVALID, result);
    }

    /**
     * sendError
     *
     * @param resp resp
     * @author z00502253
     * @since 2022-08-18
     */
    private static void sendError(HttpServletResponse resp) {
        Result result = new Result(SYSTEM_ERROR_CODE, "System error");
        sendError(resp, CommonUtils.SYSTEM_ERROR, result);
    }

    private static class DataImportV1ServletReadListener implements HiServletReadListener {
        private byte[] buffer = new byte[4 * 1024];

        private StringBuilder sb = new StringBuilder();

        private final ServletInputStream inputStream;

        private final AsyncContext asyncContext;

        private final HttpServletRequest request;

        /**
         * Instantiates a new Data import v 1 servlet read listener.
         *
         * @param inputStream the input stream
         * @param request     the request
         */
        public DataImportV1ServletReadListener(ServletInputStream inputStream, HttpServletRequest request) {
            this.inputStream = inputStream;
            asyncContext = request.startAsync();
            this.request = request;
        }

        /**
         * onDataAvailable
         *
         * @author z00502253
         * @since 2022-08-18
         */
        @Override
        public void onDataAvailable() {
            try {
                do {
                    int length = inputStream.read(buffer);
                    sb.append(new String(buffer, 0, length, "utf-8"));
                } while (inputStream.isReady());
            } catch (IOException e) {
                logger.error("/data/import get data failed, exception is {}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
                asyncContext.complete();
            }
        }

        /**
         * onAllDataRead
         *
         * @author z00502253
         * @since 2022-08-18
         */
        @Override
        public void onAllDataRead() {
            String body = sb.toString();
            DataImportEntity dataImportEntity = JSON.parseObject(body, DataImportEntity.class);
            try {
                String productId = request.getHeader("product_id");
                dataImportEntity.setProductId(productId);
                String appId = request.getHeader("app_id");
                dataImportEntity.setAppId(appId);
                DataImportHander.processData(dataImportEntity);
                sendSuccess((HttpServletResponse) asyncContext.getResponse());
            } catch (HiAnalyticesException ex) {
                logger.error("/data/import data format not match,exception is {}", CommonUtils.delLineBreakChars(body));
                sendValidateError((HttpServletResponse) asyncContext.getResponse(), ex.getMessage());
            }
            asyncContext.complete();
        }

        /**
         * onError
         *
         * @param throwable throwable
         * @author z00502253
         * @since 2022-08-18
         */
        @Override
        public void onError(Throwable throwable) {
            logger.error("/data/import on error,error is {}", throwable.getMessage());
            sendError((HttpServletResponse) asyncContext.getResponse());
            asyncContext.complete();
        }

    }

    /**
     * The type Result.
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static class Result {
        @JSONField(name = "result_code")
        private String code = "0";

        @JSONField(name = "result_msg")
        private String msg = "success";

        public Result() {
        }

        /**
         * Instantiates a new Result.
         *
         * @param code the code
         * @param msg  the msg
         * @author lWX788624
         * @since 2019-10-08
         */
        public Result(String code, String msg) {
            this.code = code;
            this.msg = msg;
        }

        /**
         * Gets code.
         *
         * @return the code
         * @author lWX788624
         * @since 2019-10-08
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets code.
         *
         * @param code the code
         * @author lWX788624
         * @since 2019-10-08
         */
        public void setCode(String code) {
            this.code = code;
        }

        /**
         * Gets msg.
         *
         * @return the msg
         * @author lWX788624
         * @since 2019-10-08
         */
        public String getMsg() {
            return msg;
        }

        /**
         * Sets msg.
         *
         * @param msg the msg
         * @author lWX788624
         * @since 2019-10-08
         */
        public void setMsg(String msg) {
            this.msg = msg;
        }
    }
}
