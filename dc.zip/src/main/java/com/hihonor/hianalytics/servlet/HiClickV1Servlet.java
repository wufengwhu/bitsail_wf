/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ConfigValues;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.handle.Handler;
import com.hihonor.hianalytics.handle.HandlerFactory;
import com.hihonor.hianalytics.handle.HandlerTypeEnum;
import com.hihonor.hianalytics.handle.WebV1Handler;
import com.hihonor.hianalytics.entity.ClickV1Model;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.utils.CommonUtils;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@WebServlet(name = "HiClickV1", urlPatterns = "/clickv1/*")
public class HiClickV1Servlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiClickV1Servlet.class);

    /**
     * 注释内容 获取配置参数
     *
     * @author z00502253
     * @since 2019-12-02
     */
    
    private static final long serialVersionUID = 4975942175338755471L;

    /**
     * The Constant MAX_DATA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_DATA_LEN =
        ServerConfig.getInstance().getAsInt(ConfigKeys.CLICK_MAX_LENGTH, 1024 * 1024);

    /**
     * The Constant MAX_UA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_UA_LEN = ConfigValues.MAX_USER_AGENT_LEN;

    /**
     * The Constant DEBUGDEPLOY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static boolean debugDeploy = "true".equals(ServerConfig.getInstance().getAsString("debug.deploy"));

    /**
     * 处理客户端的请求信息。
     *
     * @param request 请求
     * @param response 响应
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            // 校验上传的数据长度（字节长度）
            if (StringUtils.length(request.getQueryString()) > MAX_DATA_LEN) {
                logger.error("/clickv1 upload data too long");
                response.sendError(CommonUtils.REQUEST_CONTENT_INVALID, "Upload data too long");
                return;
            }
            if (request.getParameterMap() == null) {
                logger.error("/clickv1 request has no parameters");
                response.sendError(CommonUtils.PARAMETER_INVALID, "Invalid request");
                return;
            }
            // 设置响应
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            // 请求中必须包含的请求参数
            ClickV1Model model = new ClickV1Model();
            String[] args = {"cid", "sid", "url"};
            // todo 参数校验 应该提前
            if (model.setData(request.getParameterMap(), model, args, false)) {
                model.setIp(CommonUtils.getClientIp(request));
                String ua = request.getHeader("user-agent");
                model.setUa(ua != null && ua.length() > MAX_UA_LEN ? ua.substring(0, MAX_UA_LEN) : ua);
                model.setCookieId(CommonUtils.getCookieId(request, response));
                Handler handler = HandlerFactory.createHandler(WebV1Handler.class, debugDeploy);
                handler.setHandlerTypeEnum(HandlerTypeEnum.CLICKV1);
                handler.setSequence();
                handler.doHandle(new HiAnalyticsEntity(CommonUtils.delLineBreakChars(model.toString()),
                        request.getHeader("App-Id"),
                        request.getRequestURI()));
                // 白名单校验
                if (CommonUtils.redirectUrlCheck(model.getUrl())) {
                    response.sendRedirect(CommonUtils.delLineBreakChars(model.getUrl()));
                } else {
                    logger.error("/clickv1 untrusted redirect url, error is {}", model.getUrl());
                    response.sendError(CommonUtils.PARAMETER_INVALID, "Invalid request");
                }
            } else {
                logger.error("/clickv1 request don't contains must params");
                response.sendError(CommonUtils.PARAMETER_INVALID, "Invalid request");
            }
        } catch (IOException e) {
            logger.error("/clickv1 send response failed,exception is {}", e.getMessage());
        }
    }
}
