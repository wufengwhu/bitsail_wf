/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.AsyncContext;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.handle.Handler;
import com.hihonor.hianalytics.handle.HandlerFactory;
import com.hihonor.hianalytics.handle.SdkV1Handler;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.utils.CommonUtils;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@WebServlet(name = "HiSdkV1", urlPatterns = "/sdkv1/*", asyncSupported = true)
public class HiSDKV1Servlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiSDKV1Servlet.class);

    /**
     * 注释内容  获取参数配置
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = 1280928981676239081L;

    /**
     * The Constant MAX_DATA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_DATA_LEN = ServerConfig.getInstance().
            getAsInt(ConfigKeys.SDK_MAX_LENGTH, 100000);

    /**
     * The Constant DEBUGDEPLOY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static boolean debugDeploy = "true".equals(ServerConfig.getInstance().getAsString("debug.deploy"));

    /**
     * 处理客户端的请求信息。
     *
     * @param req  请求
     * @param resp 响应
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
        try {
            if (req.getContentLength() > MAX_DATA_LEN) {
                logger.error("/sdkv1 upload data too long");
                resp.sendError(CommonUtils.REQUEST_CONTENT_INVALID, "Upload data too long");
                return;
            }
            final ServletInputStream inputStream = req.getInputStream();
            inputStream.setReadListener(new SDKV1ServletReadListener(inputStream, req));
        } catch (IOException e) {
            logger.error("/sdkv1 get upload data failed:{}", e.getMessage());
            sendError(resp);
        }
    }

    /**
     * sendError
     *
     * @param resp HttpServletResponse
     * @author z00502253
     * @since 2022-08-19
     */
    private static void sendError(HttpServletResponse resp) {
        try {
            resp.sendError(CommonUtils.PARAMETER_INVALID, "System error");
        } catch (IOException e) {
            logger.error("/sdkv1 send response failed:{}", e.getMessage());
        }
    }

    private static class SDKV1ServletReadListener implements HiServletReadListener {
        private byte[] buffer = new byte[4 * 1024];

        private StringBuilder sb = new StringBuilder(MAX_DATA_LEN);

        private final ServletInputStream inputStream;

        private final AsyncContext asyncContext;

        private final HttpServletRequest request;

        public SDKV1ServletReadListener(ServletInputStream inputStream, HttpServletRequest request) {
            this.inputStream = inputStream;
            asyncContext = request.startAsync();
            this.request = request;
        }

        /**
         * onDataAvailable
         *
         * @author z00502253
         * @since 2022-08-19
         */
        @Override
        public void onDataAvailable() {
            try {
                do {
                    int length = inputStream.read(buffer);
                    sb.append(new String(buffer, 0, length, "utf-8"));
                } while (inputStream.isReady());
            } catch (IOException e) {
                logger.error("/sdkv1 get upload data failed:{}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
                asyncContext.complete();
            }
        }

        /**
         * onAllDataRead
         *
         * @author z00502253
         * @since 2022-08-19
         */
        @Override
        public void onAllDataRead() {
            String body = sb.toString();
            try {
                JSONObject jsonOjb = JSONObject.parseObject(body);
                if (jsonOjb == null) {
                    logger.error("/sdkv1 data format not match");
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                            "Invalid request");
                    asyncContext.complete();
                    return;
                }
                if (StringUtils.isEmpty(jsonOjb.getString("ek")) || isEdEmpty(jsonOjb)) {
                    logger.error("/sdkv1 ek or ed is null, {}",CommonUtils.delLineBreakChars(body));
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                        "Invalid request");
                    asyncContext.complete();
                    return;
                }
                Handler handler = HandlerFactory.createHandler(SdkV1Handler.class, debugDeploy);
                handler.setIp(CommonUtils.getClientIp(request));
                handler.setServerTime(Calendar.getInstance().getTimeInMillis());
                handler.setSequence();
                boolean result = handler.doHandle(
                    new HiAnalyticsEntity(jsonOjb.toString(),
                            request.getHeader("App-Id"), request.getRequestURI()));
                if (!result) {
                    logger.error("/sdkv1 data format not match, {}", CommonUtils.delLineBreakChars(body));
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                        "Invalid request");
                }
            } catch (JSONException e1) {
                logger.error("/sdkv1 data isn't JSONObject, {}", CommonUtils.delLineBreakChars(body));
                sendError((HttpServletResponse) asyncContext.getResponse());
            } catch (IOException e) {
                logger.error("/sdkv1 send response failed, {}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
            }
            asyncContext.complete();
        }

        /**
         * onError
         *
         * @param throwable Throwable
         * @author z00502253
         * @since 2022-08-19
         */
        @Override
        public void onError(Throwable throwable) {
            logger.error("/sdkv1 on error,error is {}", throwable.getMessage());
            sendError((HttpServletResponse) asyncContext.getResponse());
            asyncContext.complete();
        }
    }
}
