/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.handle.CommonHandler;
import com.hihonor.hianalytics.handle.Handler;
import com.hihonor.hianalytics.handle.HandlerFactory;
import com.hihonor.hianalytics.utils.CommonUtils;
import com.hihonor.hianalytics.utils.SpringBeanUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.AsyncContext;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Optional;

/**
 * @author w00027882
 */
@WebServlet(name = "HiCommonServlet", urlPatterns = "/common/*", asyncSupported = true)
@Service
public class HiCommonServlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiCommonServlet.class);

    /**
     * The Constant serialVersionUID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = 5535833911773660937L;

    // todo NIO的缓冲区 是不是可以设置大一点 4*1024 4096
    private static final int BUFFER_SIZE = 4096;

    /**
     * The Constant MAX_DATA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_DATA_LEN =
            ServerConfig.getInstance().getAsInt(ConfigKeys.COMMON_MAX_LENGTH, 1024 * 1024);

    /**
     * 是否是HA专有特性
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final boolean IS_HA_VERSION = StringUtils.equalsAnyIgnoreCase(
            ServerConfig.getInstance().getAsString(ConfigKeys.HA_FLAG), "true");

    /**
     * 默认的logger.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> defaultBusinessLoggers =
            ServerConfig.getInstance().getAsStringList(ConfigKeys.DEFAULT_BUSINESS_LOGGERS);

    /**
     * haSDK的白名单.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private List<String> hasdkBusinessAppidList =
            ServerConfig.getInstance().getAsStringList(ConfigKeys.HASDK_BUSINESS_APPIDLIST);

    /**
     * The Constant DEBUGDEPLOY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static boolean debugDeploy = "true".equals(ServerConfig.getInstance().getAsString("debug.deploy"));

    @Resource(name = "encryptKafkaTemplate")
    private KafkaTemplate<String, String> encryptKafkaTemplate;

    @Resource(name = "decryptKafkaTemplate")
    private KafkaTemplate<String, String> decryptKafkaTemplate;

    @Value("${kafka.producer.encrypt.topic}")
    private String encryptTopicName;

    @Value("${kafka.producer.decrypt.topic}")
    private String decryptTopicName;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
        try {
            if (businessCheck(req, resp)) {
                return;
            }
        } catch (IOException e) {
            logger.error("/common get upload data failed, exception is {}", e.getMessage());
            sendError(resp);
        }
    }

    private boolean businessCheck(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String uri = req.getPathInfo();
        String appVer = req.getHeader("App-Ver");
        String appId = req.getHeader("App-Id");
        if (CollectionUtils.isEmpty(defaultBusinessLoggers)) {
            logger.error("/common wrong config with " + ConfigKeys.DEFAULT_BUSINESS_LOGGERS);
            resp.sendError(CommonUtils.SYSTEM_ERROR, "System error");
            return true;
        }
        // HASDK_BUSINESS_APPIDLIST_SWITCH 是否进行白名单校验
        if ("true".equals(ServerConfig.getInstance().getAsString(ConfigKeys.HASDK_BUSINESS_APPIDLIST_SWITCH))) {
            if (CollectionUtils.isEmpty(hasdkBusinessAppidList)) {
                logger.error("/common wrong config with " + ConfigKeys.HASDK_BUSINESS_APPIDLIST);
                resp.sendError(CommonUtils.SYSTEM_ERROR, "System error");
                return true;
            }
            // 白名单校验
            if (!hasdkBusinessAppidList.contains(appId)) {
                logger.error("/common no App-Id matched");
                resp.sendError(CommonUtils.PARAMETER_INVALID, "No App-Id matched");
                return true;
            }
        }
        // /common/{serviceId}
        if (StringUtils.length(uri) <= 0) {
            logger.error("/common no serviceId matched");
            resp.sendError(CommonUtils.NO_SERVICE_ID, "No serviceId matched");
            return true;
        }
        if (!defaultBusinessLoggers.contains(uri.substring(1))) {
            logger.error("/common no serviceId matched");
            resp.sendError(CommonUtils.NO_SERVICE_ID, "No serviceId matched");
            return true;
        }
        if (CommonUtils.isNull(appVer)) {
            logger.error("/common no App-Ver in header");
            resp.sendError(CommonUtils.PARAMETER_INVALID, "No App-Ver in header");
            return true;
        }
        if (req.getContentLength() > MAX_DATA_LEN) {
            logger.error("/common upload data too long");
            resp.sendError(CommonUtils.REQUEST_CONTENT_INVALID, "Upload data too long");
            return true;
        }
        final ServletInputStream inputStream = req.getInputStream();
        inputStream.setReadListener(new CommonServletReadListener(inputStream, req));
        return false;
    }

    private static void sendError(HttpServletResponse resp) {
        try {
            resp.sendError(CommonUtils.PARAMETER_INVALID, "System error");
        } catch (IOException e) {
            logger.error("/common send response failed, exception is {}", e.getMessage());
        }
    }

    private static class CommonServletReadListener implements HiServletReadListener {
        private byte[] buffer = new byte[BUFFER_SIZE];

        private ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        private final ServletInputStream inputStream;

        private final AsyncContext asyncContext;

        private final HttpServletRequest request;

        public CommonServletReadListener(ServletInputStream inputStream, HttpServletRequest request) {
            this.inputStream = inputStream;
            asyncContext = request.startAsync();
            this.request = request;
        }

        // 数据可用时触发执行
        @Override
        public void onDataAvailable() {
            try {
                do {
                    int length = inputStream.read(buffer);
                    outputStream.write(buffer, 0, length);
                } while (inputStream.isReady());
            } catch (IOException e) {
                logger.error("/common get upload data failed, exception is {}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
                asyncContext.complete();
            }
        }


        // 数据读完时触发
        @Override
        public void onAllDataRead() {
            try {
                Handler handler = HandlerFactory.createHandler(CommonHandler.class, debugDeploy);
                HiCommonServlet commonServlet = SpringBeanUtil.getBean(HiCommonServlet.class);
                handler.setIp(CommonUtils.getClientIp(request));
                // todo  ProductId 是否在空串时加“”“""
                if (IS_HA_VERSION) {
                    String productId = request.getHeader("x-hasdk-productid");
                    if (StringUtils.isNotEmpty(productId)) {
                        handler.setProductId(URLEncoder.encode(productId, "UTF-8"));
                    } else {
                        handler.setProductId("");
                    }
                }
                handler.setSequence();
                handler.setServerTime(System.currentTimeMillis());
                handler.setDecryptKafkaTemplate(commonServlet.decryptKafkaTemplate);
                handler.setEncryptKafkaTemplate(commonServlet.encryptKafkaTemplate);
                handler.setDecryptTopicName(commonServlet.decryptTopicName);
                handler.setEncryptTopicName(commonServlet.encryptTopicName);

                boolean result = handler.doHandle(new HiAnalyticsEntity(CommonUtils.byteArray2HexString(outputStream.toByteArray()),
                        request.getHeader("App-Id"), request.getRequestURI(),
                        Boolean.valueOf(Optional.ofNullable(request.getHeader("isEncrypt")).orElse("true"))));

                if (!result) {
                    logger.error("/common data format not match");
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                            "Invalid request");
                }
            } catch (IOException e) {
                logger.error("/common send response failed:{}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
            }
            asyncContext.complete();
        }

        // 数据出错时触发
        @Override
        public void onError(Throwable throwable) {
            logger.error("/common on error is {}", CommonUtils.byteArray2HexString(outputStream.toByteArray()));
            sendError((HttpServletResponse) asyncContext.getResponse());
            asyncContext.complete();
        }
    }
}
