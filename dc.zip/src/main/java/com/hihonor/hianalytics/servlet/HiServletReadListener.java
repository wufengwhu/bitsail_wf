/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import javax.servlet.ReadListener;
import javax.servlet.annotation.WebListener;

import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.utils.CommonUtils;

/**
 * The Class HiServletReadListener
 *
 * @author z00502253
 * @since 2022-08-24
 */
@WebListener
public interface HiServletReadListener extends ReadListener {

    /**
     * 功能描述
     *
     * @param jsonOjb jsonOjb
     * @return boolean
     * @author lWX788624
     * @since 2019-10-08
     */
    default boolean isEdEmpty(JSONObject jsonOjb) {
        Object edObject = jsonOjb.get("ed");
        String ed;
        if (edObject instanceof JSONObject) {
            return ((JSONObject) edObject).size() == 0;
        }

        if (edObject instanceof String) {
            ed = (String) edObject;
            return CommonUtils.isNull(ed);
        }
        return false;
    }
}
