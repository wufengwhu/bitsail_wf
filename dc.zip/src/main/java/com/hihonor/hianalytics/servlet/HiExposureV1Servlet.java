/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ConfigValues;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.handle.Handler;
import com.hihonor.hianalytics.handle.HandlerFactory;
import com.hihonor.hianalytics.handle.HandlerTypeEnum;
import com.hihonor.hianalytics.handle.WebV1Handler;
import com.hihonor.hianalytics.entity.ExposureV1Model;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;
import com.hihonor.hianalytics.utils.CommonUtils;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@WebServlet(name = "HiExposureV1", urlPatterns = "/exposurev1/*")
public class HiExposureV1Servlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiExposureV1Servlet.class);

    /**
     * 注释内容 获取配置参数
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = 4975942175338755471L;

    /**
     * The Constant MAX_DATA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_DATA_LEN =
        ServerConfig.getInstance().getAsInt(ConfigKeys.EXPOSURE_MAX_LENGTH, 1024 * 1024);

    /**
     * The Constant MAX_UA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_UA_LEN = ConfigValues.MAX_USER_AGENT_LEN;

    /**
     * The Constant DEBUGDEPLOY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static boolean debugDeploy = "true".equals(ServerConfig.getInstance().getAsString("debug.deploy"));

    /**
     * N 处理客户端的请求信息。
     *
     * @param request  请求
     * @param response 响应
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            if (StringUtils.length(request.getQueryString()) > MAX_DATA_LEN) {
                logger.error("/exposurev1 upload data too long");
                response.sendError(CommonUtils.REQUEST_CONTENT_INVALID, "Upload data too long");
                return;
            }

            if (request.getParameterMap() == null) {
                logger.error("/exposurev1 request has no parameters");
                response.sendError(CommonUtils.PARAMETER_INVALID, "Invalid request");
                return;
            }
            // 设置响应
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);

            ExposureV1Model model = new ExposureV1Model();
            // 请求中必须包含的请求参数
            String[] args = {"cid", "sid"};
            if (model.setData(request.getParameterMap(), model, args, false)) {
                // IP地址
                model.setIp(CommonUtils.getClientIp(request));
                String ua = request.getHeader("user-agent");
                model.setUa(ua != null && ua.length() > MAX_UA_LEN ? ua.substring(0, MAX_UA_LEN) : ua);
                model.setCookieId(CommonUtils.getCookieId(request, response));
                Handler handler = HandlerFactory.createHandler(WebV1Handler.class, debugDeploy);
                handler.setHandlerTypeEnum(HandlerTypeEnum.EXPOSUREV1);
                handler.setSequence();
                boolean result = handler.doHandle(new HiAnalyticsEntity(CommonUtils.delLineBreakChars(model.toString()),
                    request.getHeader("App-Id"), request.getRequestURI()));
                if (!result) {
                    logger.error("/exposurev1 save data failed.");
                    try {
                        response.sendError(CommonUtils.SYSTEM_ERROR, "System error");
                    } catch (IOException e) {
                        logger.error("/exposurev1 send rsponse failed, exception is {}", e.getMessage());
                    }
                }
            } else {
                logger.error("/exposurev1 request don't contains must params");
                response.sendError(CommonUtils.PARAMETER_INVALID, "Invalid request");
            }
        } catch (IOException e) {
            logger.error("/exposurev1 send rsponse failed, exception is {}", e.getMessage());
        }
    }
}
