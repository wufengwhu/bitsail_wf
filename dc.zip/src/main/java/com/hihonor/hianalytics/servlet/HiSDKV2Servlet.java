/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.AsyncContext;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hihonor.hianalytics.service.Request2LogCounter;
import com.hihonor.hianalytics.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.handle.Handler;
import com.hihonor.hianalytics.handle.HandlerFactory;
import com.hihonor.hianalytics.handle.HandlerTypeEnum;
import com.hihonor.hianalytics.handle.SdkV2Handler;
import com.hihonor.hianalytics.entity.HiAnalyticsEntity;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@WebServlet(name = "HiSdkV2", urlPatterns = "/sdkv2/*", asyncSupported = true)
public class HiSDKV2Servlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiSDKV2Servlet.class);

    /**
     * The Constant REQUEST_SUFFIX.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String REQUEST_SUFFIX = "-Request";

    /**
     * The Constant SERIALVERSIONUID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = 8151758723147229235L;

    /**
     * The Constant MAX_DATA_LEN.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int MAX_DATA_LEN = ServerConfig.getInstance().
            getAsInt(ConfigKeys.SDK_MAX_LENGTH, 100000);

    /**
     * The Constant DEBUGDEPLOY.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static boolean debugDeploy = "true".equals(ServerConfig.getInstance().getAsString("debug.deploy"));

    /**
     * 处理客户端的请求信息。
     *
     * @param req      请求
     * @param response 响应
     * @author lWX788624
     * @since 2019-10-08
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse response) {
        try {
            if (req.getContentLength() > MAX_DATA_LEN) {
                logger.error("/sdkv2 upload data too long");
                response.sendError(CommonUtils.REQUEST_CONTENT_INVALID, "Upload data too long");
                return;
            }
            final ServletInputStream inputStream = req.getInputStream();
            inputStream.setReadListener(new SDKV2ServletReadListener(inputStream, req));
        } catch (IOException e) {
            logger.error("/sdkv2 get upload data failed, exception is {}", e.getMessage());
            sendError(response);
        }
    }

    /**
     * sendError
     *
     * @param resp HttpServletResponse
     * @author z00502253
     * @since 2022-08-19
     */
    private static void sendError(HttpServletResponse resp) {
        try {
            resp.sendError(CommonUtils.PARAMETER_INVALID, "System error");
        } catch (IOException e) {
            logger.error("/sdkv2 send response failed,exception is {}", e.getMessage());
        }
    }

    private static class SDKV2ServletReadListener implements HiServletReadListener {
        private byte[] buffer = new byte[4 * 1024];

        private StringBuilder sb = new StringBuilder(MAX_DATA_LEN);

        private final ServletInputStream inputStream;

        private final AsyncContext asyncContext;

        private final HttpServletRequest request;

        public SDKV2ServletReadListener(ServletInputStream inputStream, HttpServletRequest request) {
            this.inputStream = inputStream;
            asyncContext = request.startAsync();
            this.request = request;
        }

        /**
         * onDataAvailable
         *
         * @author z00502253
         * @since 2022-08-19
         */
        @Override
        public void onDataAvailable() {
            try {
                do {
                    int length = inputStream.read(buffer);
                    sb.append(new String(buffer, 0, length, "utf-8"));
                } while (inputStream.isReady());
            } catch (IOException e) {
                logger.error("/sdkv2 get upload data failed, exception is {}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
                asyncContext.complete();
            }
        }

        /**
         * onAllDataRead
         *
         * @author z00502253
         * @since 2022-08-19
         */
        @Override
        public void onAllDataRead() {
            try {
                String body = sb.toString();
                JSONObject jsonOjb = JSONObject.parseObject(body);
                String sn = null;
                if (jsonOjb == null) {
                    logger.error("/sdkv2 data format not match");
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                            "Invalid request");
                    asyncContext.complete();
                    return;
                }
                try {
                    sn = jsonOjb.getString("sn");
                } catch (JSONException e) {
                    logger.error("/sdkv2 sn not exist,exception is {}", CommonUtils.delLineBreakChars(body));
                }
                Handler handler = HandlerFactory.createHandler(SdkV2Handler.class, debugDeploy);
                handler.setIp(CommonUtils.getClientIp(request));
                handler.setServerTime(Calendar.getInstance().getTimeInMillis());
                handler.setSequence();

                boolean result = process(sn, jsonOjb, handler);
                if (!result) {
                    logger.error("/sdkv2 data format not match,exception is {}", CommonUtils.delLineBreakChars(body));
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                        "Invalid request");
                }
            } catch (IOException ex) {
                logger.error("Cant't get upload data or SdkV2 sendError failed,exception is {}", ex.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse());
            }
            asyncContext.complete();
        }

        /**
         * onError
         *
         * @param throwable Throwable
         * @author z00502253
         * @since 2022-08-19
         */
        @Override
        public void onError(Throwable throwable) {
            logger.error("/sdkv2 on error,error is {}", throwable.getMessage());
            sendError((HttpServletResponse) asyncContext.getResponse());
            asyncContext.complete();
        }

        /**
         * process
         *
         * @param sn String
         * @param jsonOjb JSONObject
         * @param handler Handler
         * @return boolean
         * @author z00502253
         * @since 2022-08-19
         */
        private boolean process(String sn, JSONObject jsonOjb, Handler handler) {
            // sn存在且sn为1，表示是运维大数据，表示是feedback sdk上报的运维打点数据
            if (!CommonUtils.isNull(sn) && "1".equals(sn)) {
                Request2LogCounter.count(HandlerTypeEnum.SDKV3.getName() + REQUEST_SUFFIX);
                // 只允许一种情况，ed不为空，ek为空
                if (!isEdEmpty(jsonOjb) && "".equals(jsonOjb.getString("ek"))) {
                    handler.setHandlerTypeEnum(HandlerTypeEnum.SDKV3);
                    return handler.doHandle(new HiAnalyticsEntity(jsonOjb.toString(), request.getHeader("App-Id"),
                        request.getRequestURI()));
                } else {
                    return false;
                }
            } else if (CommonUtils.isNull(sn) || "0".equals(sn)) {// sn不存在 或者sn为0，表示运营数据，表示bi sdk 上报的运营数据
                Request2LogCounter.count(HandlerTypeEnum.SDKV2.getName() + REQUEST_SUFFIX);
                // ed和ek都不为空
                if (!isEdEmpty(jsonOjb) && !CommonUtils.isNull(jsonOjb.getString("ek"))) {
                    handler.setHandlerTypeEnum(HandlerTypeEnum.SDKV2);
                    return handler.doHandle(new HiAnalyticsEntity(jsonOjb.toString(), request.getHeader("App-Id"),
                        request.getRequestURI()));
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }
}
