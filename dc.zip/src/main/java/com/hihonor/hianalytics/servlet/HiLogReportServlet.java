/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import com.hihonor.hianalytics.utils.CommonUtils;
import com.hihonor.hianalytics.config.HttpReturnCode;
import com.hihonor.hianalytics.handle.Handler;
import com.hihonor.hianalytics.handle.HandlerFactory;
import com.hihonor.hianalytics.handle.LogReportV1Handler;
import com.hihonor.hianalytics.entity.SearchEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.AsyncContext;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 功能描述
 *
 * @author z00502253
 * @since 2020-01-17
 */
@WebServlet(name = "HiSearchServlet", urlPatterns = "/logserv/v1.0.0/logreport", asyncSupported = true)
public class HiLogReportServlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiLogReportServlet.class);

    /**
     * The Constant BUFFER_SIZE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int BUFFER_SIZE = 4096;

    /**
     * The Constant APPID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String appId;

    /**
     * The Constant LOGTYPE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String logType;

    /**
     * doPost
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @author z00502253
     * @since 2022-08-18
     */
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) {
        try {
            // 设置请求头信息
            req.setCharacterEncoding("UTF-8");
            // 检查请求头等内容
            if (!doCheck(req, resp)) {
                return;
            }
            // 数据处理
            final ServletInputStream inputStream = req.getInputStream();
            inputStream.setReadListener(new HiLogReportServletReadListener(appId, logType, inputStream, req));
        } catch (IOException e) {
            logger.error("/logreport can't upload data to server, exception is {}", e.getMessage());
            sendError(resp, CommonUtils.PARAMETER_INVALID,"Can't upload data to DataCollector Server");
        }
    }

    /**
     * 功能描述：校验基本信息
     *
     * @author z00502253
     * @since 2020-01-17
     */
    public boolean doCheck(HttpServletRequest req, HttpServletResponse resp) {
        appId = req.getHeader("appId");
        logType = req.getHeader("logType");
        if (CommonUtils.isNull(logType)) {
            logger.error("The Attribute of logType is not in the request header");
            sendError(resp, HttpReturnCode.PARAMETER_INVALID,
                    "The Attribute of logType is not in the request header");
            return false;
        }
        if (CommonUtils.isNull(appId)) {
            logger.error("The Attribute of appId is not in the request header");
            sendError(resp, HttpReturnCode.PARAMETER_INVALID,
                    "The Attribute of appId is not in the request header");
            return false;
        }
        return true;
    }

    /**
     * 功能描述：异步处理监听器
     *
     * @author z00502253
     * @since 2020-01-17
     */
    private static class HiLogReportServletReadListener implements HiServletReadListener {

        private byte[] buffer = new byte[BUFFER_SIZE];

        private ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        private final ServletInputStream inputStream;

        private final AsyncContext asyncContext;

        private final HttpServletRequest request;

        private String appId;

        private String logType;

        public HiLogReportServletReadListener(String appId, String logType, ServletInputStream inputStream,
                                              HttpServletRequest request) {
            this.appId = appId;
            this.logType = logType;
            this.inputStream = inputStream;
            this.asyncContext = request.startAsync();
            this.request = request;
        }

        /**
         * 功能描述：有数据时回调方法
         *
         * @author z00502253
         * @since 2020-01-17
         */
        @Override
        public void onDataAvailable() {
            try {
                do {
                    int length = inputStream.read(buffer);
                    outputStream.write(buffer, 0, length);
                } while (inputStream.isReady());
            } catch (IOException e) {
                logger.error(
                    "/HiLogReportServletReadListener onDataAvailable," +
                            "can't upload data to server, exception is {}",
                    e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse(), HttpReturnCode.SYSTEM_ERROR,
                    "Can't upload data to DataCollector Server");
                asyncContext.complete();
            }
        }

        /**
         * 功能描述：数据处理
         *
         * @author z00502253
         * @since 2020-01-17
         */
        @Override
        public void onAllDataRead() {
            try {
                Handler handler = HandlerFactory.createHandler(LogReportV1Handler.class);
                handler.setIp(CommonUtils.getClientIp(request));
                handler.setServerTime(System.currentTimeMillis());
                handler.setSequence();
                boolean result = handler.doHandle(new SearchEntity(CommonUtils.
                        byteArray2HexString(outputStream.toByteArray()),
                        appId, logType, request.getRequestURI(), request.getHeader("requestId")));
                if (!result) {
                    logger.error("/logReport data format not match");
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                            "Invalid request");
                }
            } catch (IOException e) {
                logger.error("/logReport send response failed:{}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse(),HttpReturnCode.SYSTEM_ERROR,
                        "Can't upload data to DataCollector Server");
            }
            asyncContext.complete();
        }

        /**
         * 功能描述：异常处理
         *
         * @author z00502253
         * @since 2020-01-17
         */
        @Override
        public void onError(Throwable throwable) {
            logger.error("/logReport on error is {}", throwable.getMessage());
            sendError((HttpServletResponse) asyncContext.getResponse(), HttpReturnCode.SYSTEM_ERROR,
                "Can't upload data to DataCollector Server");
            asyncContext.complete();
        }
    }

    /**
     * sendError
     *
     * @param resp HttpServletResponse
     * @param retCode int
     * @param msg String
     * @author z00502253
     * @since 2022-08-18
     */
    private static void sendError(HttpServletResponse resp, int retCode, String msg) {
        try {
            resp.sendError(retCode, msg);
        } catch (IOException e) {
            logger.error("/c send response failed, exception is {}", e.getMessage());
        }
    }
}
