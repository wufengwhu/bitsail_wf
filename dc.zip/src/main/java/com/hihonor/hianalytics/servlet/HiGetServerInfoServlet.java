/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.servlet;

import java.io.IOException;

import javax.servlet.AsyncContext;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.entity.GetServerInfoResponse;
import com.hihonor.hianalytics.utils.CommonUtils;

/**
 * The Class HiGetServerInfoServlet
 *
 * @author z00502253
 * @since 2022-08-24
 */
@WebServlet(name = "HiGetServerInfoServlet", urlPatterns = "/getServerInfo/*", asyncSupported = true)
public class HiGetServerInfoServlet extends HttpServlet {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger(HiGetServerInfoServlet.class);

    /**
     * The Constant BUFFER_SIZE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final int BUFFER_SIZE = 4096;

    /**
     * The Constant serialVersionUID.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final long serialVersionUID = -4723143888266461289L;

    /**
     * doPost
     *
     * @param request request
     * @param response response
     * @author z00502253
     * @since 2022-08-18
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Content-type", "text/html;charset=UTF-8");
        try {
            final AsyncContext asyncContext = request.startAsync();
            final ServletInputStream inputStream = request.getInputStream();
            inputStream.setReadListener(new GetServerInfoServletReadListener(inputStream, asyncContext));
        } catch (IOException e) {
            logger.error("/getServerInfo cant't get body, exception is {}", e.getMessage());
            sendError(response, "100002");
        }
    }

    /**
     * sendError
     *
     * @param resp resp
     * @param retCode String
     * @author z00502253
     * @since 2022-08-18
     */
    private static void sendError(HttpServletResponse resp, String retCode) {
        try {
            GetServerInfoResponse respData = new GetServerInfoResponse();
            respData.setResultcode(retCode);
            resp.getOutputStream().write(respData.toString().getBytes("UTF-8"));
        } catch (IOException e) {
            logger.error("Failed to send response for getServerInfo, exception is {}", e.getMessage());
        }
    }

    private static class GetServerInfoServletReadListener implements HiServletReadListener {
        private byte[] buffer = new byte[BUFFER_SIZE];

        private StringBuilder sb = new StringBuilder(BUFFER_SIZE);

        private final ServletInputStream inputStream;

        private final AsyncContext asyncContext;

        public GetServerInfoServletReadListener(ServletInputStream inputStream, AsyncContext asyncContext) {
            this.inputStream = inputStream;
            this.asyncContext = asyncContext;
        }

        /**
         * onDataAvailable
         *
         * @author z00502253
         * @since 2022-08-18
         */
        @Override
        public void onDataAvailable() {
            try {
                do {
                    int length = inputStream.read(buffer);
                    sb.append(new String(buffer, 0, length, "utf-8"));
                } while (inputStream.isReady());
            } catch (IOException e) {
                logger.error("/getServerInfo cant't get body, exception is {}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse(), "100002");
                asyncContext.complete();
            }
        }

        /**
         * onAllDataRead
         *
         * @author z00502253
         * @since 2022-08-18
         */
        @Override
        public void onAllDataRead() {
            try {
                GetServerInfoResponse respData = new GetServerInfoResponse();
                if (StringUtils.isEmpty(sb.toString())) {
                    logger.error("/getServerInfo data format not match");
                    ((HttpServletResponse) asyncContext.getResponse()).sendError(CommonUtils.PARAMETER_INVALID,
                            "Invalid request");
                    asyncContext.complete();
                    return;
                }
                if ("true".equals(ServerConfig.getInstance().getAsString(ConfigKeys.GETSERVERINFO_SWITCH))) {
                    CommonUtils.getServerDomain(sb.toString(), respData, "new");
                } else {
                    CommonUtils.getServerDomain(sb.toString(), respData, "old");
                }
                asyncContext.getResponse().getOutputStream().write(respData.toString().getBytes("UTF-8"));
            } catch (IOException e) {
                logger.error("/getServerInfo cant't write response, exception is {}", e.getMessage());
                sendError((HttpServletResponse) asyncContext.getResponse(), "100002");
            }
            asyncContext.complete();
        }

        /**
         * onError
         *
         * @param e Throwable
         * @author z00502253
         * @since 2022-08-18
         * @author z00502253
         * @since 2022-08-18
         */
        @Override
        public void onError(Throwable e) {
            logger.error("/getServerInfo on error, exception is {}", e.getMessage());
            sendError((HttpServletResponse) asyncContext.getResponse(), "100002");
            asyncContext.complete();
        }
    }
}
