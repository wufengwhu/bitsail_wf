/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.filter;

import com.hihonor.hianalytics.config.ServerConfig;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Kafka过滤器抽象类
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Data
@Slf4j
@NoArgsConstructor
public abstract class Filter {

    /**
     * The Constant FLOW.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String flow;

    /**
     * 字段间的分隔符
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String separator;

    /**
     * 取第几个字段
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    protected String index;

    /**
     * 过滤掉字段中不包含condition的事件
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    String condition;

    /**
     * topic
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    private String topic;

    /**
     * 默认构造函数
     *
     * @param flow flow
     */
    public Filter(String flow) {
        this.flow = flow;
    }

    /**
     * 判断必配配置项是否正确
     *
     * @return 必配配置项是否正确
     * @author z00502253
     * @since 2022-08-24
     */
    public boolean checkParam() {
        topic = ServerConfig.getInstance().getAsString("vmall.FI.kafka." + flow + ".topic");
        separator = ServerConfig.getInstance().getAsString("vmall.FI.kafka." + flow + ".filter.separator");
        index = ServerConfig.getInstance().getAsString("vmall.FI.kafka." + flow + ".filter.index");
        condition = ServerConfig.getInstance().getAsString("vmall.FI.kafka." + flow + ".filter.condition");

        // 判断是否配置必配项
        if (StringUtils.isEmpty(topic)) {
            log.error("Vmall kafka topic must be set");
            return false;

        }
        if (StringUtils.isEmpty(separator)) {
            log.error("Vmall kafka separator must be set");
            return false;
        }

        if (StringUtils.isEmpty(index)) {
            log.error("Vmall kafka index must be set");
            return false;
        }

        if (StringUtils.isEmpty(condition)) {
            log.error("Vmall kafka condition must be set");
            return false;
        }
        return true;
    }

    /**
     * 判断内容中某字段是否包含给定的过滤条件
     *
     * @param content 待判断内容
     * @return 判断结果
     * @author z00502253
     * @since 2022-08-24
     */
    public abstract boolean contains(String content);
}
