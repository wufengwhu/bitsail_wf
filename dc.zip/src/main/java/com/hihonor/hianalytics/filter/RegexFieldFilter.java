/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.filter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * kafka过滤器
 *
 * @author lWX788624
 * @since 2019-10-08
 */
@Data
@Slf4j
public class RegexFieldFilter extends Filter {
    /**
     * 构造函数，初始化
     * @param flow flow
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public RegexFieldFilter(String flow) {
        super(flow);
    }

    /**
     * 判断内容中某字段是否包含给定的过滤条件
     * @param content 待判断内容
     * @return 判断结果
     * @author z00502253
     * @since 2022-08-24
     */
    @Override
    public boolean contains(String content) {
        String field;
        try {
            field = content.split(separator)[Integer.parseInt(index)];
        } catch (ArrayIndexOutOfBoundsException e) {
            log.error("RegexFieldFilter has exception {}", e.getMessage());
            return false;
        }

        Pattern pattern = Pattern.compile(condition, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(field);
        return matcher.matches();
    }
}
