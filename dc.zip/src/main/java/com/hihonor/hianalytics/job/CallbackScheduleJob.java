package com.hihonor.hianalytics.job;

import com.hihonor.hianalytics.service.CallbackTaskService;
import com.hihonor.hianalytics.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * @author w00027882
 * 异步发送kafka的，异常持久化的定时任务
 * TODO 简陋版本， 定时任务的执行结果，没有跟踪，待优化
 */

@Component
@EnableScheduling
@Slf4j
public class CallbackScheduleJob {

    @Autowired
    private CallbackTaskService taskService;

    @Value("${datacollector.kafka.send.failed.path}")
    private String failedPath;

    @Scheduled(cron = "0 15 * * * *")
    public void run() {
        // ${logfolder}/kafka/send_failed_%d{yyyy-MM-dd_HH}.log
        String lastHourFormat = TimeUtils.getLogTimeAsString(System.currentTimeMillis()
                - 1 * 60 * 60 * 1000);
        String fileName = "send_failed_" + lastHourFormat + ".log";
        log.info("begin to scan file {} in send kafka failed dir {}", fileName, failedPath);
        // TODO 目前只处理了加密数据
        File file = new File(failedPath + fileName);
        if (file.exists()) {
            try {
                List<String> lines = FileUtils.readLines(file, StandardCharsets.UTF_8);
                lines.forEach(data -> taskService.sendRetry(data));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        //TODO 定时任务 retry 发送失败告警，人工介入
    }

}
