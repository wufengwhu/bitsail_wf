/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs;

import com.hihonor.hianalytics.common.logs.alarm.AlarmLevel;
import com.hihonor.hianalytics.common.logs.general.GeneralPerfLog;
import com.hihonor.hianalytics.config.ConfigKeys;
import com.hihonor.hianalytics.config.ServerConfig;
import com.hihonor.hianalytics.utils.AlarmLogUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author z00502253
 * @since 2019-12-06
 */
@Component
@Slf4j
public class SysInfoCollector implements Runnable {


//    GeneralPerfLog generalPerfLog = GeneralPerfLog.getInstance();

    /**
     * The Constant JVM_MEMORY_ALARM_PERCENT.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String JVM_MEMORY_ALARM_PERCENT =
            ServerConfig.getInstance().getAsString(ConfigKeys.JVM_MEMORY_ALARM_PERCENT);

    @Override
    public void run() {
        try {
            // 获取JVM当前占用的总内存
            Long usedMemory = getUsedMemory();

            // 获取JVM的最大内存
            Long maxMemory = getMaxMemory();

            // 设置通用性能指标值
            GeneralPerfLog generalPerfLog = GeneralPerfLog.getInstance();
            generalPerfLog.setUsedMemory(usedMemory);
            generalPerfLog.setMaxMemory(maxMemory);

            // 记录性能统计日志
            PerfLogUtils.logGeneralPerf(generalPerfLog);

            // 检测并发送或恢复告警
            checkAndAlarm(usedMemory, maxMemory);
        } catch (Exception ex) {
            log.error("Collect system info failed, err msg is {}", ex.getMessage());
        }
    }

    /**
     * 功能描述 JVM内存使用告警
     *
     * @author z00502253
     * @since 2019-12-06
     */
    private void checkAndAlarm(long usedMemory, long maxMemory) {
        long alarmPercent = Long.parseLong(JVM_MEMORY_ALARM_PERCENT);
        long usedPercent = usedMemory * 100 / maxMemory;
        // 告警
        if (usedPercent > alarmPercent) {
            String[] alarmDetails = new String[]{"Jvm used percent is more than " + alarmPercent + " percent.",
                    "Maybe service used too much memory.", "Please check service status and logs."};
            AlarmLogUtils.sendAlarm(AlarmLevel.MAJOR, new String[]{"agcao"}, alarmDetails);
        }
    }

    /**
     * 功能描述 获取JVM使用内存
     *
     * @author z00502253
     * @since 2019-12-06
     */
    private Long getUsedMemory() {
        long freeMem = (Runtime.getRuntime().freeMemory()) / (1024L * 1024L);
        long totalMem = (Runtime.getRuntime().totalMemory()) / (1024L * 1024L);
        long usedMem = totalMem - freeMem;
        log.debug("Total memory:{}, free memory:{}, used memory:{}", totalMem, freeMem, usedMem);
        return Long.valueOf(usedMem);
    }

    /**
     * 功能描述 获取JVM最大内存
     *
     * @author z00502253
     * @since 2019-12-06
     */
    private Long getMaxMemory() {
        long maxMem = (Runtime.getRuntime().maxMemory()) / (1024L * 1024L);
        log.debug("Max memory: {}", maxMem);
        return Long.valueOf(maxMem);
    }
}
