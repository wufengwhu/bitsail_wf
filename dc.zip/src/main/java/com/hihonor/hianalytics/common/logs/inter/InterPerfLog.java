/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs.inter;

/**
 * 功能描述: 性能接口日志
 *
 * @author z00502253
 * @since 2019-07-10
 */
public class InterPerfLog {

    /**
     * 成功标识符
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int SUCCESS = 0;

    /**
     * 异常失败
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int EXCEPTION_FAIL = 1003;


    /**
     * 接口名称
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String interName;

    /**
     * 请求开始时间，相对于1970年的毫秒数
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private long reqTime;

    /**
     * 请求响应时间，相对于1970年的毫秒数
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private long rspTime;

    /**
     * 响应状态码，0-成功，其他失败
     *
     * @author c00266543
     * @since 2019-12-02
     */
    private int rspStatus;

    public InterPerfLog() {}

    public InterPerfLog(String interName, long reqTime) {
        this.interName = interName;
        this.reqTime = reqTime;
    }

    public String getInterName() {
        return interName;
    }

    public void setInterName(String interName) {
        this.interName = interName;
    }

    public long getReqTime() {
        return reqTime;
    }

    public void setReqTime(long reqTime) {
        this.reqTime = reqTime;
    }

    public long getRspTime() {
        return rspTime;
    }

    public void setRspTime(long rspTime) {
        this.rspTime = rspTime;
    }

    public int getRspStatus() {
        return rspStatus;
    }

    public void setRspStatus(int rspStatus) {
        this.rspStatus = rspStatus;
    }
}
