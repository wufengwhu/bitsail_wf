/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2020-2020. All rights reserved.
 */

package com.hihonor.hianalytics.common.exception;

/**
 * 运行时异常，用于业务校验报错，统一处理错误信息
 *
 * @author l00534385
 * @since 2020 -03-11
 */
public class HiAnalyticesException extends RuntimeException {

    /**
     * Instantiates a new Hi analytices exception.
     *
     * @param message the message
     * @author z00502253
     * @since 2022-07-05
     */
    public HiAnalyticesException(String message) {
        super(message);
    }

    /**
     * Instantiates a new Hi analytices exception.
     *
     * @param message the message
     * @param cause   the cause
     * @author z00502253
     * @since 2022-07-05
     */
    public HiAnalyticesException(String message, Throwable cause) {
        super(message, cause);
    }
}
