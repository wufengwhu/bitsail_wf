/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs.token;

/**
 * 功能描述：专门用来记录token失败日志
 *
 * @author z00502253
 * @since 2019-08-29
 */
public class TokenErrorLogItem {

    /**
     * 调用的appid
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String appId;

    /**
     * 请求的ClientId
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String requestClientId;

    /**
     * 请求的token
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String requestAccessToken;

    /**
     * AGC返回的token
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String AgcAccessToken;

    /**
     * 调用服务的起始时间
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String requestTime;

    /**
     * 调用token的时间
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private long costTime;

    /**
     * permission字段错误
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String permissions;

    /**
     * 失败码
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String returnCode;

    /**
     * 失败的原因
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String reason;

    /**
     * 调用的productId
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String productId;

    /**
     * agc失败的原因
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private String agcReason;

    public TokenErrorLogItem(String appId, String requestClientId) {
        this.appId = appId;
        this.requestClientId = requestClientId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getRequestClientId() {
        return requestClientId;
    }

    public void setRequestClientId(String requestClientId) {
        this.requestClientId = requestClientId;
    }

    public String getRequestAccessToken() {
        return requestAccessToken;
    }

    public void setRequestAccessToken(String requestAccessToken) {
        this.requestAccessToken = requestAccessToken;
    }

    public String getAgcAccessToken() {
        return AgcAccessToken;
    }

    public void setAgcAccessToken(String agcAccessToken) {
        AgcAccessToken = agcAccessToken;
    }

    public String getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    public long getCostTime() {
        return costTime;
    }

    public void setCostTime(long costTime) {
        this.costTime = costTime;
    }

    public String getPermissions() {
        return permissions;
    }

    public void setPermissions(String permissions) {
        this.permissions = permissions;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getAgcReason() {
        return agcReason;
    }

    public void setAgcReason(String agcReason) {
        this.agcReason = agcReason;
    }
}
