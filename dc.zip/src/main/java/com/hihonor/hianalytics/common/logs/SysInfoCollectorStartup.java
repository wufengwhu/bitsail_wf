/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 功能描述
 *
 * @author lWX788624
 * @since 2019-10-15
 */
@Slf4j
@Component
public class SysInfoCollectorStartup {

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static volatile SysInfoCollectorStartup INSTANCE;


    public ScheduledExecutorService scheduledThreadPool() {
        return Executors.newScheduledThreadPool(1);
    }


    private ScheduledExecutorService executorService;

//    ScheduledExecutorService scheduledThrPool = Executors.newScheduledThreadPool(1);

    private SysInfoCollectorStartup() {
        executorService = scheduledThreadPool();
    }

    public static SysInfoCollectorStartup getInstance() {
        if (null == INSTANCE) {
            synchronized (SysInfoCollectorStartup.class) {
                if (null == INSTANCE) {
                    INSTANCE = new SysInfoCollectorStartup();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-15
     */
    public void startup() {
        try {
            // 启动周期性系统信息采集线程,延迟1分钟，每隔3分钟采集信息
            executorService.scheduleAtFixedRate(new SysInfoCollector(),
                    60L, 3 * 60L, TimeUnit.SECONDS);
        } catch (Exception ex) {
            log.error("SysInfoCollector startup failed, err msg is {}", ex.getMessage());
        }
    }

    /**
     * 功能描述 每隔3分钟打印jvm内存使用率
     *
     * @author lWX788624
     * @since 2019-10-15
     */
    public void stop() {
        executorService.shutdown();
    }

}
