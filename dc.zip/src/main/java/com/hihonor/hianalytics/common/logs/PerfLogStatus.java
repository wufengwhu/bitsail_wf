/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs;

/**
 * 功能描述
 *
 * @author z00502253
 * @since 2019-07-18
 */
public class PerfLogStatus {

    /**
     * 成功响应
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int SUCCESS = 0;

    /**
     * 连接异常
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int CONNECT_FAIL = 1001;

    /**
     * 认证失败
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int AUTH_FAIL = 1002;

    /**
     * 异常失败
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int EXCEPTION_FAIL = 1003;

    /**
     * 参数不合法
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int PARAM_INVALID_FAIL = 1004;

    /**
     * 响应对象为空错误
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int RSP_ENTITY_EMPTY_FAIL = 1005;

    /**
     * 响应JSON报文为空错误
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int RSP_JSON_EMPTY_FAIL = 1006;

    /**
     * 未知异常
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final int UNKNOWN_FAIL = 9999;
}