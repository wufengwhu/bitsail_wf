/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs.general;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 * 通用性能统计对象，含系统CPU、JVM内存占用量、磁盘空间、磁盘读写等指标
 * 当前阶段先实现JVM内存占用量指标，其他指标通过OS工具实现
 *
 * @author z00502253
 * @since 2019-12-06
 */
@Component
@Data
@NoArgsConstructor
public class GeneralPerfLog {

    /**
     * The Constant INSTANCE.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static volatile GeneralPerfLog INSTANCE;

    /**
     * 功能描述 饿汉式单例模式
     *
     * @author z00502253
     * @since 2019-12-06
     */
    public static GeneralPerfLog getInstance() {
        if (null == INSTANCE) {
            synchronized (GeneralPerfLog.class) {
                if (null == INSTANCE) {
                    INSTANCE = new GeneralPerfLog();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * JVM进程中内存占用量，单位M，和系统内存占用量无关
     *
     * @author z00502253
     */
    private Long usedMemory;

    /**
     * JVM进程中最大内存，单位M，和-Xmx参数对应
     *
     * @author z00502253
     */
    private Long maxMemory;
}
