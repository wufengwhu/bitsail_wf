/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs;

import java.net.InetAddress;
import java.net.UnknownHostException;

import com.hihonor.hianalytics.common.logs.general.GeneralPerfLog;
import com.hihonor.hianalytics.common.logs.inter.InterPerfLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述 接口日志统计工具类
 *
 * @author z00502253
 * @since 2019-07-10
 */
public class PerfLogUtils {

    /**
     * The Constant LOG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger LOG = LoggerFactory.getLogger(PerfLogUtils.class);

    /**
     * The Constant INTER_PERF_LOG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger INTER_PERF_LOG = LoggerFactory.getLogger(LogCategory.PERF_INTER_CATEGORY);

    /**
     * The Constant GENERAL_PERF_LOG.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger GENERAL_PERF_LOG = LoggerFactory.getLogger(LogCategory.PERF_GENERAL_CATEGORY);

    /**
     * The Constant PERF_LOG_SEP.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String PERF_LOG_SEP = "|";

    /**
     * The Constant HOST_NAME.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static String hostName;

    /**
     * 模块名 DataCollector
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String MODULE_DATACOLLECTOR = "DataCollector";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void logInterPerf(InterPerfLog interPerfLog) {
        StringBuffer buf = new StringBuffer();
        buf.append(PERF_LOG_SEP).append(getHostName());
        buf.append(PERF_LOG_SEP).append(getModuleName());
        buf.append(PERF_LOG_SEP).append(interPerfLog.getInterName());
        buf.append(PERF_LOG_SEP).append(interPerfLog.getReqTime());
        buf.append(PERF_LOG_SEP).append(interPerfLog.getRspTime());
        buf.append(PERF_LOG_SEP).append(interPerfLog.getRspTime() - interPerfLog.getReqTime());
        buf.append(PERF_LOG_SEP).append(interPerfLog.getRspStatus());

        INTER_PERF_LOG.info(buf.toString());
    }

    /**
     * logGeneralPerf
     *
     * @param generalPerfLog generalPerfLog
     * @author z00502253
     * @since 2022-07-04
     */
    public static void logGeneralPerf(GeneralPerfLog generalPerfLog) {
        StringBuffer buf = new StringBuffer();
        buf.append(PERF_LOG_SEP).append(getHostName());
        buf.append(PERF_LOG_SEP).append(getModuleName());
        buf.append(PERF_LOG_SEP).append(generalPerfLog.getUsedMemory());
        buf.append(PERF_LOG_SEP).append(generalPerfLog.getMaxMemory());

        GENERAL_PERF_LOG.info(buf.toString());
    }

    /**
     * getHostName
     *
     * @return String
     * @author z00502253
     * @since 2022-08-18
     */
    private static String getHostName() {
        if (hostName != null) {
            return hostName;
        }
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostName = addr.getHostName();
        } catch (UnknownHostException e) {
            LOG.error("Can not get hostname, error msg is {}", e.getMessage());
            hostName = "UnknownHost";
        }
        return hostName;
    }

    /**
     * getModuleName
     *
     * @return String
     * @author z00502253
     * @since 2022-08-18
     */
    private static String getModuleName() {
        return MODULE_DATACOLLECTOR;
    }
}
