/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs;

/**
 * 功能描述 日志常量值
 *
 * @author z00502253
 * @since 2019-07-10
 */
public class LogCategory {

    /**
     * 接口性能统计日志Category常量值
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final String PERF_INTER_CATEGORY = "Perf_Interface_Log";

    /**
     * 通用性能统计日志Category常量值
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final String PERF_GENERAL_CATEGORY = "Perf_General_Log";

    /**
     * 告警日志Category常量值
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final String ALARM_CATEGORY = "ALARM_Log";
}
