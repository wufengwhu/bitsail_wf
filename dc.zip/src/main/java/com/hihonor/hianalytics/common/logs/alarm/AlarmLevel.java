/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs.alarm;

import org.springframework.stereotype.Component;

/**
 * 告警级别
 * 致命critical | 严重 major | 一般 minor | 提示 notice
 *
 * @author lWX788624
 * @since 2019-10-21
 */
@Component
public class AlarmLevel {

    /**
     * CRITICAL
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final String CRITICAL = "critical";

    /**
     * MAJOR
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final String MAJOR = "major";

    /**
     * MINOR
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final String MINOR = "minor";

    /**
     * NOTICE
     *
     * @author z00502253
     * @since 2019-12-02
     */
    public static final String NOTICE = "notice";
}
