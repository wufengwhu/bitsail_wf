/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs.token;

import com.hihonor.hianalytics.utils.ShieldSensitivity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 功能描述：TokenError打印日志类
 *
 * @author z00502253
 * @since 2019-08-29
 */
public class TokenErrorLog {

    /**
     * The Constant LOGGER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final Logger logger = LoggerFactory.getLogger("Token_Error_Log");

    /**
     * The Constant LOG_SPLITTER.
     *
     * @author z00502253
     * @since 2019-12-02
     */
    private static final String LOG_SPLITTER = "|";

    /**
     * 功能描述
     *
     * @author lWX788624
     * @since 2019-10-08
     */
    public static void print(TokenErrorLogItem log) {
        StringBuilder sb = new StringBuilder();
        sb.append(LOG_SPLITTER)
            .append(log.getAppId())
            .append(LOG_SPLITTER)
            .append(log.getRequestClientId())
            .append(LOG_SPLITTER)
            .append(log.getProductId())
            .append(LOG_SPLITTER)
            .append(ShieldSensitivity.overlayWithStar(log.getRequestAccessToken()))
            .append(LOG_SPLITTER)
            .append(ShieldSensitivity.overlayWithStar(log.getAgcAccessToken()))
            .append(LOG_SPLITTER)
            .append(log.getRequestTime())
            .append(LOG_SPLITTER)
            .append(log.getCostTime())
            .append(LOG_SPLITTER)
            .append(log.getReason())
            .append(LOG_SPLITTER)
            .append(log.getReturnCode())
            .append(LOG_SPLITTER)
            .append(ShieldSensitivity.overlayWithStar(log.getPermissions()))
            .append(LOG_SPLITTER)
            .append(log.getAgcReason());
        logger.error(sb.toString());
    }
}
