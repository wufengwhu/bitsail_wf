/*
 * Copyright (c) hihonor Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.hihonor.hianalytics.common.logs.alarm;

import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * 告警日志对象
 *
 * @author lWX788624
 * @since 2019-10-17
 */
@Data
@Component
public class AlarmInfo {

    /**
     * 告警ID，完整的告警Id为16位格式数字，字母，下划线组合
     * 在API中会固定拼接前缀，故此字段为6位纯数字，不包含固定前缀
     * 必填，按照规划统一分配
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String id;

    /**
     * 告警类型，搜索全局唯一，必填
     * 需要在告警AlarmType类中定义或获取
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String alarmType;

    /**
     * 告警的产品名称
     * 可选，外部不用传入
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String name;

    /**
     * 告警级别：致命critical | 严重 major | 一般 minor | 提示 notice
     * 必填，枚举值
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String level;

    /**
     * 归属领域，可选，这个通过系统配置直接获取。
     * 领域，同云眼CMDB中的领域名称。
     * 用于标识告警通知发给哪些领域运维人员。
     * 这是一个数组，可以包含多个领域。
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String[] scope;

    /**
     * 告警来源，可选，默认获取主机名
     * 标识告警产生来源，领域内可唯一标识上报来来。
     * 参考，但不限此此：(主机名|应用名|进程名|数据库实例名|其他格式。
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String source_tag;

    /**
     * 告警类型，可选通过接口类型来自动填写
     * (产生告警 firing) | (清除告警 resolved)
     * 为空则认为是firing
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String op_type;

    /**
     * 告警详情，可选，建议填写
     * 建议格式如下（不强制约束）：短信内容不包含此字段。
     * 告警详情：
     * 告警原因：
     * 修复建议：
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String[] alarmDetail;

    /**
     * 告警详情，和alarmDetail为一一对应关系，此字段为内部格式，用于上报告警日志，对外不可见
     *
     * @author c00266543
     * @since 2022-07-05
     */
    private String details;

    /**
     * 清除类型，可选，默认自动清除
     * ADAC: 告警可自动清除, 默认.
     * ADMC: 告警需手动清除
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String clear_type;

    /**
     * 产生时间，可选默认填写上报的当前时间
     * 用格林时间上报，不用本地时间上报
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private Long start_timestamp;

    /**
     * 清除时间，可选默认填写当前时间
     * 用格林时间上报，不用本地时间上报. 生产告警时填0
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private Long end_timestamp;

    /**
     * 接收人列表，可选，通过领域来发送告警信息
     * 约束：
     * 1. 邮件和手机二者一起最多20个，超出部分的名单发送忽略。
     * 2. 如果产生告警指定发送列表，则清除告警告警也需要指定发送列表。
     * 3. 可以不填写此字段或者字段值为空，不定义，则按默认策略（按领域运维人员列表）发送。
     *
     * @author z00502253
     * @since 2022-07-05
     */
    private String receive;
}
