#!/usr/bin/env perl
use strict;
use Cwd;
use File::Spec;

my $strTime = `date '+%Y%m%d%H%M%S'`;
my $strDate = `date '+%Y%m%d'`;
chomp($strTime);
chomp($strDate);

my $strUserName = `whoami`;
chomp($strUserName);

my $iDebugMode = $ARGV[0];

my $strOripath = cwd;
my $strCurPath = cwd;
$strCurPath = File::Spec->catfile($strCurPath, "tools");
chdir($strCurPath);
my $strLog = "JVMinfo_" . $strTime . ".log";
my $strLogFile = File::Spec->catfile($strCurPath, "collectJVM_" . $strTime . ".log");

my $strLogBak = File::Spec->catfile($strOripath, "logbak");
if (!-d $strLogBak)
{
	writeLog("INFO", "create directory $strLogBak"); 
	mkdir($strLogBak);
}

$strLogBak = File::Spec->catfile($strOripath, "logbak", $strDate);
if (!-d $strLogBak)
{
	writeLog("INFO", "create directory $strLogBak"); 
	mkdir($strLogBak);
}

sub getDate
{
	my $strTime = shift @_;
	my $strFlag = shift @_;
	
	my ($sec,$min,$hour,$mday,$mon,$year) = localtime($strTime);
	$mon  += 1;
	$year += 1900;
	
	$mon   = "0" . $mon  if ($mon  >= 0 && $mon  <= 9);
	$mday  = "0" . $mday if ($mday >= 0 && $mday <= 9);
	$hour  = "0" . $hour if ($hour >= 0 && $hour <= 9);
	$min   = "0" . $min  if ($min  >= 0 && $min  <= 9);
	$sec   = "0" . $sec  if ($sec  >= 0 && $sec  <= 9);
	
	return "$year-$mon-$mday $hour:$min:$sec";

}

sub writeLog
{
    my $strLevel = shift @_;
    my $strCont  = shift @_;
    my $iCurTime = time();
    
    open(LOGFILE, ">> $strLogFile");
    printf LOGFILE "[%s] [%3s] %s\n",getDate($iCurTime), $strLevel, $strCont;
    printf "[%s] [%3s] %s\n", getDate($iCurTime), $strLevel, $strCont;
    close(LOGFILE);
}

sub collectInfo
{
    my $command = shift @_;
    my $logname = shift @_;
    my $strInfo = shift @_;
    
    for (my $i = 0; $i < 3; $i++)
    {
        `$command > $logname`;
        if (-s $logname)
        {
            last;
        }
        writeLog ("ERROR", "Collecting $strInfo information failed, try again");
    }
}

sub collectJVMInfo
{
    my $pid = shift @_;
    my $strCollectPath = shift @_;
    
    writeLog("INFO", "Collecting stack information");
    collectInfo("$ENV{JAVA_HOME}/bin/jstack $pid", "$strCollectPath/jstack.log", "stack");
    
    writeLog("INFO", "Collecting jmap heap information");
    collectInfo("$ENV{JAVA_HOME}/bin/jmap -heap $pid", "$strCollectPath/jmap_heap.log", "jmap heap");
    
    writeLog("INFO", "Collecting JVM information");
    collectInfo("$ENV{JAVA_HOME}/bin/jinfo $pid", "$strCollectPath/jinfo.log", "JVM");
    
    writeLog("INFO", "Collecting jmap histo information");
    collectInfo("$ENV{JAVA_HOME}/bin/jmap $pid", "$strCollectPath/jmap_histo.log", "jmap histo");
    
    writeLog("INFO", "Collecting jstat -gcutil information");
    `$ENV{JAVA_HOME}/bin/jstat -gcutil $pid > $strCollectPath/jstat.log`;
	
	if ($iDebugMode == 1)
	{
	    writeLog("INFO", "Collect headdump information");
	    `$ENV{JAVA_HOME}/bin/jmap -dump:file=$strCollectPath/jmap_dump.bin $pid`;
	}
}

sub getTomcatID
{
    my $pid=`$ENV{JAVA_HOME}/bin/jps | grep Bootstrap | awk '{print \$1}'`;
    chomp($pid);
    if (!$pid)
    {
        $pid=`ps -ef | grep $strUserName | grep Bootstrap | awk '{print \$1}'`;
    }
    return $pid
}

################################### main ################################
my $strCollectPath = File::Spec->catfile($strCurPath, "log");

if (!-d $strCollectPath)
{
	writeLog("INFO", "create directory $strCollectPath"); 
	mkdir($strCollectPath);
}

my $pid = getTomcatID();

if ($pid !~ m/^\d+$/)
{
    writeLog("ERROR", "java pid is not exist, can't collect JVM info");
    `mv $strLogFile $strLogBak`;
    exit 0;
}

writeLog("INFO", "collect JAVA INFO [ProcessID: $pid]");
collectJVMInfo($pid, $strCollectPath);

my $strPKGName = sprintf "%s_%s.tar.gz", "JVMinfo", $strTime;

writeLog("INFO", "compress the dump info and run log");
`tar -zcf $strPKGName $strLog log/*`;

writeLog("INFO", "mv log files to log directory");
`mv $strPKGName $strLogBak`;

writeLog("INFO", "delete all the log files");
`rm -r $strCollectPath`;
`mv $strLogFile $strLogBak`;
