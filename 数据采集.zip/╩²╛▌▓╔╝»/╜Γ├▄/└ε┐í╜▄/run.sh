#!/bin/bash
CLASS_NAME=com.honour.cloud.context.HosDataDecrypt
JAR_PATH=/srv/BigData/data1/task_script_dir/onedata_dwi_clouddt/clouddt/sdk/hosdecrypt/spark_hdfs.jar
DATA_PATH=obs://mrs-bigdata-it-preprod/user/dmp_dwi_clouddt/dwb_tmp/hos_data_all_tmp
#DATE_DAY=`date -d "2 hour ago" +"%Y%m%d"`
DATE_DAY=$1
#DATE_HOUR=`date -d "2 hour ago" +"%H"`
DATE_HOUR=$2
env=prepro
format=$3
KERBEROS_USER=dmp_dwi_clouddt
KERBEROS_USER_KEYTAB=/srv/BigData/data1/FusionInsight/keytab/dmp_dwi_clouddt.keytab
source /srv/BigData/data1/FusionInsight/client/bigdata_env
kinit -kt $KERBEROS_USER_KEYTAB $KERBEROS_USER
hdfs dfs -rm -r $DATA_PATH/$DATE_DAY/$DATE_HOUR
if [ $? -ne 0 ]; then
    echo "rm event hour path failed"
else
    echo "rm event hour path succeed"
fi

spark_job_conf="
   --conf spark.dynamicAllocation.enabled=true \
   --conf spark.shuffle.service.enabled=true \
   --conf spark.dynamicAllocation.maxExecutors=150 \
   --conf spark.dynamicAllocation.minExecutors=64 \
   --conf spark.hadoop.hive.exec.dynamic.partition=true \
   --conf spark.hadoop.hive.exec.dynamic.partition.mode=nonstric \
   --conf spark.sql.hive.caseSensitiveInferenceMode=NEVER_INFER
"


spark-submit --master yarn \
 --deploy-mode cluster \
 --executor-memory 2g \
 --executor-cores 2 \
 --num-executors 150 \
 --queue QDWIClouddt \
 --driver-memory 4G \
 $spark_job_conf \
 --principal $KERBEROS_USER \
 --driver-class-path /srv/BigData/data1/task_script_dir/onedata_dwi_clouddt/clouddt/sdk/hosdecrypt \
 --files /srv/BigData/data1/task_script_dir/onedata_dwi_clouddt/clouddt/sdk/hosdecrypt/repair_table.conf \
 --keytab $KERBEROS_USER_KEYTAB \
 --class $CLASS_NAME $JAR_PATH \
 $DATE_DAY \
 $DATE_HOUR \
 $env \
 $format