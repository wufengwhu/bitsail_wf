CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_aipluginengine_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT '荣耀接入智慧能力业务访问小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;

-- dwi_clouddt.dwb_hasdk_aipluginengine_event_inc_h
-- com.hihonor.aipluginengine


CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_xrmn_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT '音频业务访问小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;

-- dwi_clouddt.dwb_hasdk_xrmn_event_inc_h
-- com.hihonor.xrmn

CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_gameassistant_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT 'gameassistant业务访问小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;

-- com.hihonor.gameassistant
-- dwi_clouddt.dwb_hasdk_gameassistant_event_inc_h

CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_servicerecommend_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT '精品服务业务访问小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;

-- com.hihonor.health.ios
-- dwi_clouddt.dwb_hasdk_health_ios_event_inc_h

CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_health_ios_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT '运动健康ios业务访问小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;


-- com.hihonor.wearappmarket
-- dwi_clouddt.dwb_hasdk_wearappmarket_event_inc_h
-- 手表应用市场SDK


CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_wearappmarket_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT '手表应用市场SDK业务访问小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;


CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_hos_text_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT 'hos业务访问小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;



CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_abtest_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT 'ad实验小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;

CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_absdk_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT '广告sdk小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;

CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_all_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT 'ha打点业务小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;

-- dwi_clouddt.dwb_hasdk_pushagent2_event_inc_h
-- com.hihonor.android.pushagent2
CREATE EXTERNAL TABLE IF NOT EXISTS `dwi_clouddt.dwb_hasdk_pushagent2_event_inc_h`
(
    `key`                     string COMMENT 'key值',
    `appid`                   string COMMENT '每个app默认唯一的id',
    `hmac`                    string COMMENT '算法签名',
    `report_time`             string COMMENT '上报时间',
    `imei`                    string COMMENT '端侧设备id',
    `androidid`               string COMMENT 'android id',
    `uuid`                    string COMMENT '应用安装后的uuid',
    `udid`                    string COMMENT '设备的统一id',
    `oaid`                    string COMMENT '设备的广告id',
    `serviceid`               string COMMENT '数据来源',
    `appver`                  string COMMENT '应用版本',
    `channel`                 string COMMENT '渠道',
    `magicver`                string COMMENT 'EMUI版本',
    `libver`                  string COMMENT 'SDK版本号',
    `mcc`                     string COMMENT '移动设备国家代码',
    `mnc`                     string COMMENT '移动设备网络代码',
    `model`                   string COMMENT '设备型号',
    `packagename`             string COMMENT '应用包名',
    `romver`                  string COMMENT 'ROM版本',
    `event`                   string COMMENT '消息id',
    `eventtime`               string COMMENT '消息采集时间',
    `type`                    string COMMENT '消息类型',
    `os`                      string COMMENT '操作系统',
    `osver`                   string COMMENT '操作系统版本',
    `screenheight`            string COMMENT '屏幕高度',
    `screenwidth`             string COMMENT '屏幕宽度',
    `properties`              string COMMENT '消息自定义消息',
    `client_ip_addr`          string COMMENT '客户端IP地址',
    `sdk_name`                string COMMENT 'SDK名称',
    `up_id`                   string COMMENT '帐号编号',
    `adv_switch_open_sign`    string COMMENT '广告开关打开标志',
    `sn_code`                 varchar(128) COMMENT 'SN码',
    `evt_global_pub_attr`     string COMMENT '事件全局公共属性',
    `req_id`                  varchar(128) COMMENT '请求编号',
    `service_tag_name`        varchar(128) COMMENT '业务标签名',
    `visit_id`                string COMMENT '上报数据包的消息ID',
    `device_id`               string COMMENT '设备编号',
    `device_id_type_cd`       string COMMENT '设备编号类型代码',
    `server_time`             string COMMENT '服务器时间',
    `evt_session_name`        string COMMENT '事件会话名称',
    `first_session_evt_sign`  string COMMENT '首个会话事件标识',
    `event_value`             string COMMENT '事件内容',
    `evt_os_language`         string COMMENT 'events中操作系统语言',
    `hw_mobile_customize_ver` string COMMENT '手机定制版本(用于标识发货地)',
    `launch_type`             string COMMENT '启动类型',
    `launch_command`          string COMMENT '启动命令',
    `brand`                   string COMMENT '手机品牌',
    `pub_manufacturer`        string COMMENT '手机制造商'
)
    COMMENT 'ha打点push业务优化点位小时表'
    PARTITIONED BY (
        `pt_d` string COMMENT '天分区',
        `pt_h` string COMMENT '小时分区')
    row format delimited fields terminated by '\t'
    stored as textfile
;


-- 解密总表 中间表 三级分区表
create table if not exists dwi_clouddt.repair_event_pro_all
(
    key                     String,
    appid                   String,
    hmac                    String,
    report_time             String,
    imei                    String,
    androidid               String,
    uuid                    String,
    udid                    String,
    oaid                    String,
    serviceid               String,
    appver                  String,
    channel                 String,
    magicver                String,
    libver                  String,
    mcc                     String,
    mnc                     String,
    model                   String,
    packagename             String,
    romver                  String,
    event                   String,
    eventtime               String,
    `type`                  String,
    os                      String,
    osver                   String,
    screenheight            String,
    screenwidth             String,
    properties              String,
    client_ip_addr          String,
    sdk_name                String,
    up_id                   String,
    adv_switch_open_sign    String,
    sn_code                 String,
    evt_global_pub_attr     String,
    req_id                  String,
    service_tag_name        String,
    visit_id                String,
    device_id               String,
    device_id_type_cd       String,
    server_time             String,
    evt_session_name        String,
    first_session_evt_sign  String,
    event_value             String,
    evt_os_language         String,
    hw_mobile_customize_ver String,
    launch_type             String,
    launch_command          String,
    brand                   String,
    pub_manufacturer        String
)
    partitioned by (pt_d string, pt_h string, table_name string)
    stored AS orc
    tblproperties ("orc.compress" = "zlib")
--     LOCATION 'obs://mrs-honor-bigdata-prod/user/hive/warehouse/dwi_clouddt.db/repair_event_pro_all'
;

-- dwr_clouddt_export.dwb_hasdk_photos_orc_event_inc_h
create external table if not exists dwr_clouddt_export.dwb_hasdk_photos_orc_event_inc_h
(
    key                     String,
    appid                   String,
    hmac                    String,
    report_time             String,
    imei                    String,
    androidid               String,
    uuid                    String,
    udid                    String,
    oaid                    String,
    serviceid               String,
    appver                  String,
    channel                 String,
    magicver                String,
    libver                  String,
    mcc                     String,
    mnc                     String,
    model                   String,
    packagename             String,
    romver                  String,
    event                   String,
    eventtime               String,
    `type`                  String,
    os                      String,
    osver                   String,
    screenheight            String,
    screenwidth             String,
    properties              String,
    client_ip_addr          String,
    sdk_name                String,
    up_id                   String,
    adv_switch_open_sign    String,
    sn_code                 String,
    evt_global_pub_attr     String,
    req_id                  String,
    service_tag_name        String,
    visit_id                String,
    device_id               String,
    device_id_type_cd       String,
    server_time             String,
    evt_session_name        String,
    first_session_evt_sign  String,
    event_value             String,
    evt_os_language         String,
    hw_mobile_customize_ver String,
    launch_type             String,
    launch_command          String,
    brand                   String,
    pub_manufacturer        String
)
    partitioned by (pt_d string, pt_h string)
    stored AS orc
    tblproperties ("orc.compress" = "zlib")
;

-- com.hihonor.adsdk
-- dwi_clouddt.dwb_hasdk_absdk_orc_event_inc_h
create external table if not exists dwi_clouddt.dwb_hasdk_absdk_orc_event_inc_h
(
    key                     String,
    appid                   String,
    hmac                    String,
    report_time             String,
    imei                    String,
    androidid               String,
    uuid                    String,
    udid                    String,
    oaid                    String,
    serviceid               String,
    appver                  String,
    channel                 String,
    magicver                String,
    libver                  String,
    mcc                     String,
    mnc                     String,
    model                   String,
    packagename             String,
    romver                  String,
    event                   String,
    eventtime               String,
    `type`                  String,
    os                      String,
    osver                   String,
    screenheight            String,
    screenwidth             String,
    properties              String,
    client_ip_addr          String,
    sdk_name                String,
    up_id                   String,
    adv_switch_open_sign    String,
    sn_code                 String,
    evt_global_pub_attr     String,
    req_id                  String,
    service_tag_name        String,
    visit_id                String,
    device_id               String,
    device_id_type_cd       String,
    server_time             String,
    evt_session_name        String,
    first_session_evt_sign  String,
    event_value             String,
    evt_os_language         String,
    hw_mobile_customize_ver String,
    launch_type             String,
    launch_command          String,
    brand                   String,
    pub_manufacturer        String
)
    partitioned by (pt_d string, pt_h string)
    stored AS orc
    tblproperties ("orc.compress" = "zlib")


